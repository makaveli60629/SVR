
(function(){
  const status = document.getElementById('admin-status');
  const API_BASE = window.SVR_API_BASE || '';
  async function refreshStatus(){
    if(!status || !API_BASE) return;
    try{
      const res = await fetch(`${API_BASE}/api/admin/status`, {cache:'no-store'});
      const data = await res.json();
      const online = !!data.isOnline;
      status.dataset.state = online ? 'online' : 'offline';
      status.textContent = online ? '● Admin Online' : '● Admin Offline';
    }catch(e){ status.dataset.state='offline'; status.textContent='● Admin Offline'; }
  }
  const form = document.getElementById('svr-message-form');
  const result = document.getElementById('svr-message-result');
  if(form){
    form.addEventListener('submit', async (ev)=>{
      ev.preventDefault();
      const payload = {
        name: document.getElementById('svr-name')?.value || '',
        email: document.getElementById('svr-email')?.value || '',
        message: document.getElementById('svr-message')?.value || '',
        source: 'public_site'
      };
      if(!payload.message.trim()){ result.textContent = 'Please enter a message.'; return; }
      if(API_BASE){
        try{
          const res = await fetch(`${API_BASE}/api/messages`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
          if(!res.ok) throw new Error('send failed');
          result.textContent='Message sent.'; form.reset(); return;
        }catch(e){ /* local fallback below */ }
      }
      const key='svr_public_messages';
      const list=JSON.parse(localStorage.getItem(key)||'[]');
      list.push({...payload, createdAt:new Date().toISOString()});
      localStorage.setItem(key, JSON.stringify(list));
      result.textContent='Message saved locally until the API is connected.';
      form.reset();
    });
  }
  refreshStatus(); setInterval(refreshStatus, 60000);
})();
