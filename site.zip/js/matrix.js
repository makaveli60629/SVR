
const canvas = document.getElementById('matrix');
const ctx = canvas.getContext('2d');
let width, height, columns, drops;
const binary = ['0','1'];
const secrets = ['I LOVE SHY', 'I LOVE SCARLETT'];
let secretIndex = 0;
let secretCharIndex = 0;
let nextSecretAt = 70;
let frame = 0;
function resize(){
  width = canvas.width = window.innerWidth;
  height = canvas.height = Math.max(window.innerHeight, document.documentElement.scrollHeight);
  const font = getFont();
  columns = Math.floor(width / font);
  drops = Array.from({length: columns}, () => Math.floor(Math.random() * height / font));
}
function getFont(){ return window.innerWidth < 700 ? 13 : 16; }
function maybeSecret(){
  frame++;
  if(frame < nextSecretAt) return binary[Math.floor(Math.random()*binary.length)];
  const phrase = secrets[secretIndex];
  const ch = phrase[secretCharIndex++];
  if(secretCharIndex >= phrase.length){
    secretCharIndex = 0;
    secretIndex = (secretIndex + 1) % secrets.length;
    nextSecretAt = frame + 90 + Math.floor(Math.random()*160);
  } else {
    nextSecretAt = frame + 8 + Math.floor(Math.random()*18);
  }
  return ch === ' ' ? binary[Math.floor(Math.random()*binary.length)] : ch;
}
function draw(){
  const font = getFont();
  ctx.fillStyle = 'rgba(3,2,7,0.075)';
  ctx.fillRect(0,0,width,height);
  ctx.font = `${font}px monospace`;
  for(let i=0;i<drops.length;i++){
    const text = Math.random() < 0.012 ? maybeSecret() : binary[Math.floor(Math.random()*2)];
    ctx.fillStyle = text === '0' || text === '1' ? '#b26cff' : '#ffffff';
    ctx.shadowColor = '#b26cff';
    ctx.shadowBlur = text === '0' || text === '1' ? 4 : 12;
    ctx.fillText(text, i*font, drops[i]*font);
    if(drops[i]*font > height && Math.random() > 0.975) drops[i] = 0;
    drops[i]++;
  }
}
resize();
window.addEventListener('resize', resize);
setInterval(draw, 33);
