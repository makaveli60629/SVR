(function(){
  const canvas=document.getElementById('matrix');
  if(!canvas) return;
  const ctx=canvas.getContext('2d');
  let width=0,height=0,columns=0,drops=[];
  const font=15;
  const binary='01'.split('');
  const hidden=['I LOVE SHY','I LOVE SCARLETT'];
  let tick=0;

  function resize(){
    width=canvas.width=window.innerWidth;
    height=canvas.height=window.innerHeight;
    columns=Math.ceil(width/font);
    drops=Array.from({length:columns},()=>Math.floor(Math.random()*height/font));
  }

  function draw(){
    tick++;
    ctx.fillStyle='rgba(0,0,0,0.06)';
    ctx.fillRect(0,0,width,height);
    ctx.font=font+'px monospace';

    for(let i=0;i<drops.length;i++){
      const x=i*font;
      const y=drops[i]*font;
      const reveal=(tick%520===0 && i%29===0) ? hidden[(tick/520|0)%hidden.length] : null;
      const text=reveal ? reveal : binary[Math.floor(Math.random()*binary.length)];
      ctx.fillStyle=reveal ? '#ffffff' : (Math.random()>.965 ? '#e0c3ff' : '#b26cff');
      ctx.shadowColor=reveal ? '#c77dff' : '#9d4edd';
      ctx.shadowBlur=reveal ? 14 : 6;
      ctx.fillText(text,x,y);
      if(y>height && Math.random()>0.975) drops[i]=0;
      drops[i]++;
    }
    ctx.shadowBlur=0;
  }

  window.addEventListener('resize',resize,{passive:true});
  resize();
  setInterval(draw,33);
})();
