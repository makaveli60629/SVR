(() => {
  const canvas = document.getElementById('matrixRain');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const phrases = ['SVR', 'POKER', 'SCARLETT', 'I LOVE SHY', 'I LOVE SCARLETT', '0101', 'ROYAL', 'IMPACT'];
  let w, h, cols, drops;
  function resize(){w=canvas.width=innerWidth;h=canvas.height=innerHeight;cols=Math.floor(w/18);drops=Array(cols).fill(1+Math.random()*h/18)}
  resize(); addEventListener('resize', resize);
  function draw(){ctx.fillStyle='rgba(0,0,0,.085)';ctx.fillRect(0,0,w,h);ctx.font='16px monospace';ctx.fillStyle='#27ff89';for(let i=0;i<drops.length;i++){const text=Math.random()>.985?phrases[(Math.random()*phrases.length)|0]:String.fromCharCode(0x30A0+Math.random()*96);ctx.fillText(text,i*18,drops[i]*18);if(drops[i]*18>h&&Math.random()>.975)drops[i]=0;drops[i]+=1}requestAnimationFrame(draw)}
  draw();
})();
