(() => {
  const API_BASE = window.SVR_API_BASE || 'https://YOUR-API-NAME.azurewebsites.net';
  const statusEl = document.getElementById('adminStatus');
  async function loadStatus(){
    if(!statusEl || API_BASE.includes('YOUR-API-NAME')) return;
    try{const r=await fetch(`${API_BASE}/api/admin/status`); const d=await r.json(); statusEl.textContent=d.isOnline?'● Admin Online':'● Admin Offline'; statusEl.classList.toggle('online',!!d.isOnline)}catch(e){}
  }
  const form=document.getElementById('messageForm');
  if(form){form.addEventListener('submit', async e=>{e.preventDefault(); const fd=new FormData(form); const payload=Object.fromEntries(fd.entries()); const out=document.getElementById('messageResult'); if(API_BASE.includes('YOUR-API-NAME')){localStorage.setItem('svr_pending_message',JSON.stringify({...payload,createdAt:new Date().toISOString()})); if(out) out.textContent='Saved locally for preview. Connect API to send to Azure SQL.'; form.reset(); return;} try{const r=await fetch(`${API_BASE}/api/messages`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); if(!r.ok) throw new Error('Message failed'); if(out) out.textContent='Message sent.'; form.reset();}catch(err){if(out) out.textContent='Message not sent. API connection needs review.';}})}
  loadStatus(); setInterval(loadStatus, 60000);
})();
