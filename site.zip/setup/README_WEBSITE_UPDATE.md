# SVR Website Update ZIP

This package restores/updates the public website only. It does not include or modify `/game`.

Included:
- Matrix public launch page
- Responsive website page
- About / Sponsorship / Membership / Store / Impact / Contact sections
- Admin dashboard preview page
- Membership preview page
- Public message drop frontend hook
- Admin Online / Offline placeholder hook

Backend note:
Set `window.SVR_API_BASE` or edit `site/js/site-public-hooks.js` once the Azure App Service API URL is ready.
