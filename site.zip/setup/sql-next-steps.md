# SQL next steps
Connect the public message form through a secure backend API before writing to Azure SQL. Do not put SQL secrets in static website files.
