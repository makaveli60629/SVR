# Stripe notes
Checkout is disabled until backend, keys, legal review, and admin controls are approved.
