# Dealer System

- Shuffles deck
- Deals cards
- Controls round flow

Future:
- Animations
- NPC integration
