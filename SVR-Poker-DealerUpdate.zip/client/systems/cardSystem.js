export function createDeck() {
    const suits = ['H','D','C','S'];
    const values = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
    let deck = [];
    suits.forEach(s => {
        values.forEach(v => {
            deck.push(v + s);
        });
    });
    return deck;
}