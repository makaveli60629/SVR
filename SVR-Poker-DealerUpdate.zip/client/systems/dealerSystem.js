export function startDealer() {
    console.log("Dealer initialized");
    shuffleDeck();
    dealCards();
}

function shuffleDeck() {
    console.log("Shuffling deck...");
}

function dealCards() {
    console.log("Dealing cards to players...");
}