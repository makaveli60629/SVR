let isCharging = false;
let targetPosition = null;

export function onFistClench() {
    isCharging = true;
    console.log("Charging teleport...");
}

export function onFistRelease() {
    console.log("Teleport triggered");
    isCharging = false;
}