import { startDealer } from './systems/dealerSystem.js';
import './systems/reikiTeleportSystem.js';

console.log("Game Start");
startDealer();