const http = require('http');
const server = http.createServer((req,res)=>{
    res.end("SVR Poker Dealer Update Running");
});
server.listen(3000);