# SVR Poker – Dealer System Update

Includes:
- AI Dealer System
- Card Dealing Logic
- Reiki Teleport (base)
- Scene Structure

Run:
npm install
npm start
