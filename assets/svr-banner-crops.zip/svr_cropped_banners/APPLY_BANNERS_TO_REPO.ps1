cd C:\Users\ronal\SVR

$BannerSource = "$env:USERPROFILE\Downloads\svr-banner-crops\site\assets\banners"
$RepoBannerDir = ".\site\assets\banners"

New-Item -ItemType Directory -Force -Path $RepoBannerDir | Out-Null
Copy-Item "$BannerSource\*.webp" $RepoBannerDir -Force

git add site/assets/banners
git commit -m "Add cropped SVR site banner assets"
git push origin main
