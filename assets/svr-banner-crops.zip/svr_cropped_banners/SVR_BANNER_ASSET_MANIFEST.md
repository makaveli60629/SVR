# SVR Banner Asset Manifest

Cropped from `banner.jpg` into six clean website banner assets.

- `01-scorpion-vr-exclusive.webp` — Scorpion VR Exclusive — crop box [0, 0, 509, 209]
- `02-svr-store-preview.webp` — SVR Store Preview — crop box [515, 0, 1024, 209]
- `03-reiki-hub.webp` — Reiki Hub — crop box [0, 215, 509, 420]
- `04-pga-golf-hub.webp` — PGA Golf Hub — crop box [515, 215, 1024, 420]
- `05-smoker-lounge.webp` — Smoker Lounge — crop box [0, 426, 509, 635]
- `06-scorpion-poker-room.webp` — Scorpion Poker Room — crop box [515, 426, 1024, 635]

Recommended repo path: `site/assets/banners/`.
