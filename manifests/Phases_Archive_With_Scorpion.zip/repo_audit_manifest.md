# SVR Poker Project — Comprehensive Audit Manifest (2026-05-06)

## Overview
This document captures the current state of the *SVR Poker* repository, highlights issues addressed in prior phases, outlines remaining work, and recommends a roadmap for future development. All fixes and improvements must preserve modularity, maintain the **no‑music** lock, one‑controller movement, snap‑turning, trigger‑release teleportation, and VR comfort constraints.

## Completed Phases (already locked in)

1. **Audio Removal & Lock (Phase A)**
   - Removed all packaged audio files and directories (`assets/audio`).
   - Replaced `modules/audio.js` with a no‑op module to prevent any autoplay.
   - Removed music hotkeys (`M` and `N`) and watch music buttons.
   - Disabled XR session audio priming, tap‑to‑start behaviour, and autoplay.

2. **Teleport & Watch Safety Fixes (Phase B)**
   - Added a visible teleport arc and marker ring.
   - Fixed teleport state resets, removed fist‑gesture toggles, and disabled pinch‑release teleport to avoid accidental jumps.
   - Enabled controller trigger‑release teleport only while TP is armed.
   - Added controller fallback for the watch and improved button sizes for easier interaction.

3. **Player Control & Gameplay Loop (Phase C)**
   - Added player controls for **fold**, **call**, **raise**, and **next hand**. Keyboard and watch shortcuts available.
   - Updated the watch HUD to display player chips, hand rank, pot size, and action prompts.
   - Added chip stack adjustments when the player bets/raises and hand result tracking.

4. **One‑Controller Movement (Phase D)**
   - Enabled full locomotion and snap‑turn using either controller; you no longer need both controllers active simultaneously.
   - Updated dead‑zone handling and flick thresholds for smoother locomotion.

5. **Hub Private Room Teleport & Audit (Phase E)**
   - Removed heavy hub rooms from the lobby (Reiki, PGA, Legend, Sponsor, Smoker) and replaced them with light storefront portals.
   - Added private scenes for each hub accessible via teleport: Zen Den, PGA VIP, Legend VIP, Sponsor Room, Smoker Lounge, Scorpion Poker Room, and Scorpion VIP.
   - Expanded movement clamp for private scenes.

6. **Storefront Alignment & Scorpion Isolation (Phase F)**
   - Implemented a `runModLock` audit to verify that required scene targets are available at boot and ensure audio remains disabled.
   - Added lobby storefront portal panels with clear signage and moved Scorpion Poker Room to a private teleport scene.
   - Updated index and watch buttons to reflect new storefront and private room names.

## Remaining Issues & Required Fixes

1. **Seat Alignment & Seating Behaviour**
   - The player must always sit correctly: the chair should be at the table edge, and the watch should remain accessible. Testing is needed to ensure seat transforms (position/rotation) are applied per seat.
   - In some phases, teleporting to a seat may place the player too high or too low relative to the table; adjust seat anchor heights and offsets.

2. **Chip Stack & Bet Movement**
   - Chips must lie flat on the table, move smoothly when bets are placed, and stack visibly for winners. The demo should showcase chips pushing into the pot and transferring to the winner.
   - Card dealing currently starts from the right; update `poker_demo.js` to deal from the **dealer's left** side (counter‑clockwise) as in standard poker.

3. **World Backdrop: Moon, Mars & Stars**
   - The sky backdrop currently does not display the moon, Mars, or stars despite textures. Investigate `world_skyline.js` to ensure the objects (`moon`, `mars`, `stars`) are added to the scene and positioned above the skyline.
   - Textures may need reloading or scaling; verify that emissive intensities and sizes make the bodies visible from the lobby.

4. **Watch Teleport & Scene Buttons**
   - Continue refining watch interactions to ensure teleport buttons always reflect the correct TP state (e.g., `TP SAFE` vs. `TP ARMED`).
   - Add scene buttons for all new private rooms (Zen Den, PGA VIP, etc.) on the watch and index page, ensuring their labels fit without overlap.

5. **Modularization & Performance**
   - Verify that modules are isolated and re‑usable. Each scene/hub should have its own function (e.g., `addPgaStorefront`, `addPgaPrivateRoom`).
   - Keep file size under 25 MB to satisfy GitHub ZIP constraints. Remove unused assets and compress textures if necessary.

6. **Backend & Server Audit**
   - Inspect backend routes (site.zip / webex‑game‑site.zip if applicable) to ensure endpoints match the new scenes and that authentication flows (if any) are secure.
   - Confirm that any backend services still attempt to stream audio are disabled.

## Future Work

1. **Physical Chip & Card Interactions**
   - Implement VR interactions allowing players to pick up chips and push them into the pot, and to peek at their cards. This requires physics and hand‑tracking integration.

2. **Saved‑Hand Replay & Jumbotron**
   - Add a replay system that records interesting hands and plays them back on lobby screens or private jumbotrons.
   - Provide watch controls to start/stop the replay.

3. **Performance & Optimization**
   - Continue to reduce draw calls by batching static geometry and using instanced meshes for repeated elements (e.g., city buildings).
   - Lower texture resolutions or implement level‑of‑detail for distant objects to improve Quest frame rates.

4. **Polish & QA**
   - Perform playtesting to catch minor glitches (e.g., seat entry misalignment, teleport arcs clipping through objects).
   - Provide localization support for non‑English players.

## Conclusion
This audit summarises the improvements made so far and identifies tasks required to deliver a fully polished VR poker experience. With the remaining fixes, modularization, and future features addressed, the project will be ready for a complete gameplay demo.
