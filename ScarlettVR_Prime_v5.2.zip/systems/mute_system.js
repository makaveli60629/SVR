
const muted = new Set();
export function toggleMute(id){
  if(muted.has(id)) muted.delete(id);
  else muted.add(id);
}
