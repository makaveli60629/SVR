
export function calculateRank(xp){
  return Math.min(100, Math.floor(xp/1000));
}
