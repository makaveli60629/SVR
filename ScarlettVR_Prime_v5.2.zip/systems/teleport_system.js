
export const teleportRegistry = {
  poker_pit: "scenes/poker_pit.scene",
  reiki_mountain: "scenes/reiki/reiki_mountain.scene",
  golf_range: "scenes/golf_range.scene"
};

export async function teleportTo(id){
  console.log("Teleporting to:", id);
}
