import { teleportTo } from './systems/teleport_system.js';
console.log('World initialized');