Phase 50 audit
- boosted moon/earth visibility and height
- lowered stable table build and pushed felt deeper into recessed play surface
- widened seat snap slightly for easier seating
- packaged as full deploy-safe replacement build


## Phase 52
- boosted moon brightness, halo, and fill light
- pushed moon higher and farther back
- boosted earth brightness and halo
- pushed earth higher and farther back for cleaner separation


Phase 55 notes:
- Restored poker_table.obj loader as primary table pass.
- Rebalanced moon/earth brightness and distance to avoid face-overlay feel.
- Teleport toggle moved from fist to left-forearm watch-hand pinch near face.


Phase 57 notes:
- Added quest-safe boot tuning (lower render cost, safer shadows, lighter skyline/star counts).
- Added clickable watch radio toggle with uploaded playlist URL fallback handling.
- Added custom table.obj poker table fallback with felt and leather textures.
- Rebalanced moon/earth to read cleaner in Quest and desktop.
