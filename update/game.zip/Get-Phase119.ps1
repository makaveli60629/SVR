$ErrorActionPreference = 'Stop'

$RepoRoot = $PSScriptRoot
$TempZip = Join-Path $env:TEMP 'svr_phase119_game.zip'
$RawUrl = 'https://raw.githubusercontent.com/makaveli60629/SVR/main/update/game.zip'
$FallbackUrl = 'https://github.com/makaveli60629/SVR/raw/main/update/game.zip'

Write-Host 'SVR Poker - Phase 119 resend downloader'
Write-Host 'Target repo:' $RepoRoot

function Get-ZipFile {
    param([string]$Url)
    Write-Host "Trying $Url"
    Invoke-WebRequest -Uri $Url -OutFile $TempZip -UseBasicParsing
    if (!(Test-Path $TempZip)) { throw 'Download did not create the zip file.' }
    $size = (Get-Item $TempZip).Length
    if ($size -lt 1024) { throw "Downloaded file is too small ($size bytes)." }
}

try {
    try {
        Get-ZipFile -Url $RawUrl
    } catch {
        Write-Warning $_
        Get-ZipFile -Url $FallbackUrl
    }

    if (Test-Path (Join-Path $RepoRoot 'game')) {
        Remove-Item -Recurse -Force (Join-Path $RepoRoot 'game')
    }

    Expand-Archive -Path $TempZip -DestinationPath $RepoRoot -Force
    Remove-Item $TempZip -Force -ErrorAction SilentlyContinue

    Write-Host 'Done. Phase 119 game package expanded into the repo root.' -ForegroundColor Green
    Write-Host 'Next steps:'
    Write-Host '  git add .'
    Write-Host '  git commit -m "Apply SVR Phase 119 resend"'
    Write-Host '  git pull --rebase origin main'
    Write-Host '  git push origin main'
} catch {
    Write-Error $_
    exit 1
}
