# Textures Directory

Place texture images for your models and environment here. The demo build procedurally generates felt and wood textures, but you can replace these with high-resolution textures.
