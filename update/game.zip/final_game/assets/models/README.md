# Models Directory

Place your 3D models (GLB/GLTF/FBX) into this directory. The demo build uses procedural geometry for the table and NPC placeholders. To use high-quality assets:

- Save your poker table model as `table.glb` or `table.fbx`.
- Save your primary NPC model as `eric.glb` (and optionally `claudia.glb` for a second avatar).
- Additional NPCs can be named `npc_1.glb`, `npc_2.glb`, etc.

Textures for the models should be placed in `../textures` and referenced via the appropriate loader.
