(function(){window.SVRSeat={sit(){const rig=document.getElementById('rig'); if(rig)rig.setAttribute('position','0 1.62 3.2')}};})();
