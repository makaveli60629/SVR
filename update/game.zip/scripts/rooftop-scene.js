AFRAME.registerComponent('rooftop-scene', {
  init: function () {
    const scene = this.el;
    const rig = document.getElementById('rig');
    const pads = Array.from(document.querySelectorAll('.teleportable'));
    const teleEl = document.getElementById('teleportState');
    const left = document.getElementById('leftHand');
    const right = document.getElementById('rightHand');
    const camera = document.getElementById('camera');
    let teleportEnabled = false;
    let currentPad = 0;

    function setTeleportState(val) {
      teleportEnabled = val;
      teleEl.textContent = val ? 'ON' : 'OFF';
      pads.forEach(p => p.setAttribute('visible', val));
    }

    function cycleTeleport() {
      currentPad = (currentPad + 1) % pads.length;
      const pos = pads[currentPad].getAttribute('position');
      rig.setAttribute('position', { x: pos.x, y: 0, z: pos.z });
    }

    setTeleportState(false);

    window.addEventListener('keydown', (e) => {
      if (e.key.toLowerCase() === 't') setTeleportState(!teleportEnabled);
      if (teleportEnabled && e.key.toLowerCase() === 'g') cycleTeleport();
    });

    [left, right].forEach(hand => {
      if (!hand) return;
      hand.addEventListener('gripdown', () => setTeleportState(!teleportEnabled));
      hand.addEventListener('pinchstarted', () => setTeleportState(!teleportEnabled));
      hand.addEventListener('triggerdown', () => {
        if (teleportEnabled) cycleTeleport();
      });
    });

    // Floating purple/cyan glow particles
    const field = document.getElementById('particleField');
    for (let i = 0; i < 40; i++) {
      const orb = document.createElement('a-sphere');
      const x = (Math.random() - 0.5) * 16;
      const z = -2 - Math.random() * 12;
      const y = 0.2 + Math.random() * 2.5;
      const r = 0.03 + Math.random() * 0.05;
      const cyan = Math.random() > 0.55;
      const color = cyan ? '#35d1ff' : '#b84cff';
      orb.setAttribute('position', `${x} ${y} ${z}`);
      orb.setAttribute('radius', r);
      orb.setAttribute('color', color);
      orb.setAttribute('material', `emissive:${color}; emissiveIntensity:2; shader:standard`);
      const rise = 2 + Math.random() * 4;
      const dur = 4000 + Math.random() * 5000;
      orb.setAttribute('animation__rise', `property: position; to: ${x + (Math.random()-0.5)*0.6} ${y+rise} ${z + (Math.random()-0.5)*0.6}; dir: alternate; dur: ${dur}; loop: true; easing: easeInOutSine`);
      orb.setAttribute('animation__fade', `property: material.opacity; from: 0.25; to: 0.95; dir: alternate; dur: ${Math.round(dur*0.6)}; loop: true`);
      field.appendChild(orb);
    }

    // Simple mobile joystick
    const pad = document.getElementById('mobilePad');
    const stick = document.getElementById('mobileStick');
    let active = false, sx = 0, sy = 0;
    const max = 32;

    function centerStick() {
      stick.style.left = '35px';
      stick.style.top = '35px';
    }

    function setStick(clientX, clientY) {
      const rect = pad.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      let dx = clientX - cx;
      let dy = clientY - cy;
      const len = Math.hypot(dx, dy) || 1;
      if (len > max) { dx = dx / len * max; dy = dy / len * max; }
      sx = dx / max;
      sy = dy / max;
      stick.style.left = `${35 + dx}px`;
      stick.style.top = `${35 + dy}px`;
    }

    if (pad) {
      pad.addEventListener('pointerdown', e => { active = true; setStick(e.clientX, e.clientY); });
      window.addEventListener('pointermove', e => { if (active) setStick(e.clientX, e.clientY); });
      window.addEventListener('pointerup', () => { active = false; sx = 0; sy = 0; centerStick(); });
    }

    scene.addEventListener('renderstart', () => {
      scene.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.6));
    });

    scene.addEventListener('loaded', () => {
      scene.addBehavior({ tick: function (time, delta) {
        if (!active) return;
        const pos = rig.getAttribute('position');
        const rot = camera.object3D.rotation.y;
        const speed = delta * 0.0025;
        const forwardX = -Math.sin(rot) * -sy * speed;
        const forwardZ = -Math.cos(rot) * -sy * speed;
        const strafeX = Math.cos(rot) * sx * speed;
        const strafeZ = -Math.sin(rot) * sx * speed;
        rig.setAttribute('position', { x: pos.x + forwardX + strafeX, y: pos.y, z: pos.z + forwardZ + strafeZ });
      }});
    });
  }
});
