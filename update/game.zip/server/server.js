
const express = require("express")
const http = require("http")
const {Server} = require("socket.io")
const sqlite3 = require("sqlite3").verbose()
const PokerEngine = require("./pokerEngine")

const app = express()
const server = http.createServer(app)
const io = new Server(server)

app.use(express.static("../game"))

const db = new sqlite3.Database("./bankroll.db")

db.serialize(()=>{
 db.run(`
 CREATE TABLE IF NOT EXISTS players(
  id TEXT PRIMARY KEY,
  chips INTEGER
 )
 `)
})

const game = new PokerEngine()

io.on("connection",(socket)=>{

 console.log("player connected",socket.id)

 db.get("SELECT * FROM players WHERE id=?",[socket.id],(err,row)=>{
  if(!row){
   db.run("INSERT INTO players(id,chips) VALUES(?,?)",[socket.id,10000])
  }
 })

 game.addPlayer(socket.id)
 io.emit("gameState",game)

})

server.listen(3000,()=>{
 console.log("SVR Poker server running on port 3000")
})
