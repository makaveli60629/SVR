
class PokerEngine{
 constructor(){
  this.players=[]
  this.pot=0
 }
 addPlayer(id){
  this.players.push({id,chips:1000})
 }
}
module.exports = PokerEngine
