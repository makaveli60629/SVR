import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.163.0/build/three.module.js';

export function initLighting(scene) {
    // Ambient and directional lighting create a soft purple glow
    const ambient = new THREE.HemisphereLight(0x734a91, 0x0d001a, 0.6);
    scene.add(ambient);

    const dir = new THREE.DirectionalLight(0xbb9acc, 0.8);
    dir.position.set(5, 10, 7.5);
    scene.add(dir);
}
