export function initPerformance(renderer) {
    // Clamp pixel ratio for performance stability
    const maxPixelRatio = 1.25;
    const pixelRatio = Math.min(window.devicePixelRatio, maxPixelRatio);
    renderer.setPixelRatio(pixelRatio);
    // Set a purple-toned clear color to avoid black flicker
    renderer.setClearColor(0x0d001a);
    renderer.setSize(window.innerWidth, window.innerHeight);
}
