import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.163.0/build/three.module.js';

export function initTable(scene) {
    // Simple poker table geometry
    const tableGeometry = new THREE.CylinderGeometry(5, 5, 0.3, 32);
    const tableMaterial = new THREE.MeshStandardMaterial({ color: 0x3e2a67 });
    const table = new THREE.Mesh(tableGeometry, tableMaterial);
    table.position.set(0, 0, 0);
    scene.add(table);
}
