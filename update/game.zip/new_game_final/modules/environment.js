import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.163.0/build/three.module.js';

export function initEnvironment(scene) {
    // Base starfield
    const starsGeometry = new THREE.BufferGeometry();
    const starCount = 800;
    const positions = [];
    for (let i = 0; i < starCount; i++) {
        positions.push((Math.random() - 0.5) * 150);
        positions.push(Math.random() * 70 + 10);
        positions.push((Math.random() - 0.5) * 150);
    }
    starsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    const starsMaterial = new THREE.PointsMaterial({ color: 0x8852a3, size: 0.7 });
    const stars = new THREE.Points(starsGeometry, starsMaterial);
    scene.add(stars);

    // Moon and Mars
    const moonGeo = new THREE.SphereGeometry(1.5, 32, 32);
    const moonMat = new THREE.MeshStandardMaterial({ color: 0xcbb3e5 });
    const moon = new THREE.Mesh(moonGeo, moonMat);
    moon.position.set(-14, 25, -40);
    scene.add(moon);

    const marsGeo = new THREE.SphereGeometry(0.8, 32, 32);
    const marsMat = new THREE.MeshStandardMaterial({ color: 0xe36464 });
    const mars = new THREE.Mesh(marsGeo, marsMat);
    mars.position.set(12, 21, -32);
    scene.add(mars);

    // Circular rooftop walkway ring
    const ringGeo = new THREE.TorusGeometry(7, 0.15, 16, 100);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x8852a3, emissive: 0x8852a3 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0;
    scene.add(ring);

    // Buildings silhouettes
    function createBuilding(x, width, height, depth, color) {
        const geo = new THREE.BoxGeometry(width, height, depth);
        const mat = new THREE.MeshBasicMaterial({ color: 0x0d001a, emissive: color });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(x, height / 2 + 0.15, -15);
        return mesh;
    }

    const buildingConfigs = [
        { x: -8, w: 1.2, h: 8, d: 1.2, c: 0x6d5a96 },
        { x: -5, w: 1.0, h: 6, d: 1.2, c: 0x5a4885 },
        { x: -2, w: 0.8, h: 5.5, d: 1.0, c: 0x4e3c78 },
        { x: 1, w: 1.0, h: 7, d: 1.2, c: 0x6d5a96 },
        { x: 4, w: 1.4, h: 6.2, d: 1.4, c: 0x5a4885 },
        { x: 7, w: 1.0, h: 7.5, d: 1.0, c: 0x4e3c78 },
    ];

    buildingConfigs.forEach(cfg => {
        const building = createBuilding(cfg.x, cfg.w, cfg.h, cfg.d, cfg.c);
        scene.add(building);
    });
}
