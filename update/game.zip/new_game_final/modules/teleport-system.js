// Simplified teleport system with glow indicator and floor marker
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.163.0/build/three.module.js';

export function initTeleportSystem(camera, scene, renderer) {
    const controller = renderer.xr.getController(0);
    scene.add(controller);

    const raycaster = new THREE.Raycaster();
    const markerGeometry = new THREE.CircleGeometry(0.5, 32);
    const markerMaterial = new THREE.MeshBasicMaterial({ color: 0xa066d1, side: THREE.DoubleSide, transparent: true, opacity: 0.5 });
    const marker = new THREE.Mesh(markerGeometry, markerMaterial);
    marker.rotation.x = -Math.PI / 2;
    marker.visible = false;
    scene.add(marker);

    let teleportEnabled = true;

    controller.addEventListener('selectstart', () => {
        if (!teleportEnabled) return;
        marker.visible = true;
    });

    controller.addEventListener('selectend', () => {
        if (!teleportEnabled) return;
        if (marker.visible) {
            camera.position.set(marker.position.x, camera.position.y, marker.position.z);
        }
        marker.visible = false;
    });

    controller.addEventListener('squeeze', () => {
        // Toggle teleport by squeezing the grip
        teleportEnabled = !teleportEnabled;
    });

    renderer.setAnimationLoop(() => {
        if (teleportEnabled) {
            // Cast ray to find intersection with the table plane or floor
            raycaster.setFromCamera({ x: 0, y: 0 }, camera);
            const intersects = raycaster.intersectObjects(scene.children, true);
            if (intersects.length > 0) {
                const intersect = intersects.find(i => i && i.object && i.object.geometry instanceof THREE.CylinderGeometry);
                if (intersect) {
                    marker.position.copy(intersect.point);
                    marker.position.y = 0.01;
                    marker.visible = true;
                }
            } else {
                marker.visible = false;
            }
        } else {
            marker.visible = false;
        }
    });
}
