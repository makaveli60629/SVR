// Placeholder NPC system with simple objects representing Carla and Eric
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.163.0/build/three.module.js';

export function initNPCs(scene) {
    // Create simple capsule-like NPCs with different colors
    const npcGeometry = new THREE.CylinderGeometry(0.3, 0.3, 1.6, 16);
    const carlaMaterial = new THREE.MeshStandardMaterial({ color: 0xa772e8 });
    const ericMaterial = new THREE.MeshStandardMaterial({ color: 0x6c64c6 });

    const carla = new THREE.Mesh(npcGeometry, carlaMaterial);
    carla.position.set(-2, 0.8, 1);
    scene.add(carla);

    const eric = new THREE.Mesh(npcGeometry, ericMaterial);
    eric.position.set(2, 0.8, 1);
    scene.add(eric);
}
