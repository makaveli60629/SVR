import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.163.0/build/three.module.js';

export function initEnvironment(scene) {
    // Add starfield for rooftop atmosphere
    const starsGeometry = new THREE.BufferGeometry();
    const starCount = 600;
    const positions = [];
    for (let i = 0; i < starCount; i++) {
        positions.push((Math.random() - 0.5) * 100);
        positions.push(Math.random() * 60 + 10);
        positions.push((Math.random() - 0.5) * 100);
    }
    starsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    const starsMaterial = new THREE.PointsMaterial({ color: 0x8852a3, size: 0.7 });
    const stars = new THREE.Points(starsGeometry, starsMaterial);
    scene.add(stars);

    // Moon
    const moonGeo = new THREE.SphereGeometry(1.2, 32, 32);
    const moonMat = new THREE.MeshStandardMaterial({ color: 0xcbb3e5 });
    const moon = new THREE.Mesh(moonGeo, moonMat);
    moon.position.set(-12, 22, -35);
    scene.add(moon);

    // Mars with orange texture
    const marsGeo = new THREE.SphereGeometry(0.7, 32, 32);
    const marsMat = new THREE.MeshStandardMaterial({ color: 0xe36464 });
    const mars = new THREE.Mesh(marsGeo, marsMat);
    mars.position.set(10, 19, -28);
    scene.add(mars);
}
