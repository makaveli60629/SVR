import { initPerformance } from './modules/performance.js';
import { initLighting } from './modules/lighting.js';
import { initTeleportSystem } from './modules/teleport-system.js';
import { initNPCs } from './modules/npc-system.js';
import { initEnvironment } from './modules/environment.js';
import { initTable } from './modules/table.js';

import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.163.0/build/three.module.js';
import { VRButton } from 'https://cdn.jsdelivr.net/npm/three@0.163.0/examples/jsm/webxr/VRButton.js';

let scene, camera, renderer;

function init() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.set(0, 1.6, 3); // spawn 3m from origin
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.xr.enabled = true;
    document.body.appendChild(renderer.domElement);

    initPerformance(renderer);
    initLighting(scene);
    initEnvironment(scene);
    initTable(scene);
    initNPCs(scene);
    initTeleportSystem(camera, scene, renderer);

    window.addEventListener('resize', onWindowResize);
    document.body.appendChild(VRButton.createButton(renderer));
    renderer.setAnimationLoop(render);
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function render() {
    renderer.render(scene, camera);
}

init();
