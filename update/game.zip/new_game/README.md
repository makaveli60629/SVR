# Scarlett VR Poker Game (Modular Build)

This build contains a cleaned-up, modularized version of the VR poker game.  Key improvements include:

* **Performance module**: clamps device pixel ratio and sets a purple-toned clear color to improve performance on lower-end devices.
* **Lighting module**: sets ambient and directional lights to create a rich purple glow without dark patches.
* **Environment module**: adds stars, a high moon, and Mars to the skyline for a rooftop atmosphere.
* **Table module**: creates a basic cylindrical poker table with proper position and scale.
* **Teleport system**: implements a ray-cast based teleport with a purple floor marker; toggled by squeezing the controller.
* **NPC system**: adds simple NPC placeholders (Carla and Eric) as cylinders with distinct colors.

The `index.html` loads `main.js`, which composes the scene by invoking each module.  All JavaScript modules are ES modules and may be replaced or extended independently.

## Deployment

To deploy this game, compress the `new_game/` directory into a `game.zip` and place it in your repository's `update` folder as `game.zip`.  The GitHub Pages workflow will pick up the updated game overlay automatically.
