SVR Poker Phase 43 Hotfix

Primary boot fix:
- Fixed a fatal JavaScript boot issue in game/main.js that could leave the page stuck on "Booting…" with a black screen.
- Rebuilt the main boot flow with explicit boot error handling.
- Added clearer runtime and promise rejection display.
- Added assets/ui/logo.png so the teleport decal can resolve a real logo path.

Deploy note:
- Replace update/game.zip with this zip and push to main.
- Hard refresh after GitHub Pages finishes deploying.
