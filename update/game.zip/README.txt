SVR Poker - Next Phase Patch

Included:
- game/index.html
- game/modules/quest-watch.js
- game/modules/moon-upgrade.js

Phase focus:
- keep Quest forearm watch patch
- add larger cinematic moon
- move moon higher and more centered ahead
- slow moon drift/rotation
- add star dome
- reduce harsh glow from scene lighting
