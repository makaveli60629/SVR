
SVR Poker Engine 1.5 Cyberpunk Build

Features
- Cyberpunk rooftop poker club
- Neon skyline
- Correct poker table scale
- VR hands
- Wrist watch UI
- Matrix rain
- WASD movement

Install
Extract into /game folder
