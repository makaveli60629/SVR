SVR Poker Demo v1

Contents
- index.html
- assets/logo-table.png
- models/eric.fbx
- models/male-sitting-pose.fbx
- js/teleport.js

Notes
- This package is intentionally flat and GitHub-friendly.
- index.html is in the ZIP root.
- The included FBX assets are copied into /models.
- Current scene uses a stable built-in table so the demo boots cleanly.
- Replace the NPC placeholder with your FBX/GLB pipeline when ready.

Recommended deploy
- Extract directly into your repo game folder.
- Keep index.html at the game root.
