SVR Poker - Watch wrist-joint patch

Included:
- game/index.html
- game/modules/quest-watch.js
- game/modules/moon-upgrade.js

Focus:
- fix watch anchoring to true wrist joint
- remove thumb-line anchoring
- use palm fallback before camera fallback
- keep previous moon module intact
