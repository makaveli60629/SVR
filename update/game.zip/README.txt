SVR Poker - Phase 3 Modular Recovery

Upload this file as:
  update/game.zip

This zip changes GAME ONLY. It does not include site files.

Main fixes:
- Real lobby feel restored with circular rooftop, skyline, signs, walls, moon/Mars, stars, purple lighting.
- Modular JS structure.
- 3 meter spawn facing the table.
- Watch on both hands.
- Right-hand teleport with purple glow and SVR floor marker.
- Scene portal placeholders for Poker, Reiki, PGA, and Scorpion.
- Asset-ready folders for table.glb, eric.glb, carla.glb.

Test:
  https://svrpoker.com/game/
