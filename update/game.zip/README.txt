
SVR Poker Game (Rooftop Build)

Place your models in:

game/assets/models/

Required models:

table.glb
moon.fbx
npc_sitting.fbx
player.glb

Open game/index.html or host the folder on your website.
