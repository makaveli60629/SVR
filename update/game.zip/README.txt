SVR Poker Demo v3 Matrix

Changes in this build
- Hands added
- Left wrist watch added
- Table resized down
- NPC moved next to the table
- Movement enabled with WASD + mouse look
- Purple live Matrix rain overlay added
- Root index.html preserved for GitHub-friendly deployment

Files
- index.html
- js/game.js
- assets/models/table.glb
- assets/models/player.glb
- assets/texture/moon_diffuse.png
- assets/texture/tablefelt.png
- assets/ui/logo-table.png

Deploy
- Extract this ZIP into your repo game folder
- Keep index.html in the root of the game folder
