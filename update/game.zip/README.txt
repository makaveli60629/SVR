SVR Quest Demo Patch · Modular Phase

What this phase does:
- converts the wrist watch into a modular forearm device rig
- keeps the device Quest-only and hidden until wrist data is valid
- places the device sideways and long down the inner forearm
- adds modular Meta hand material overrides using your HAND_C / HAND_N / HAND_S textures
- keeps moon/sky work in a separate module so wrist work does not overwrite scene work

Module layout:
- game/modules/watch-ui.js
- game/modules/forearm-device.js
- game/modules/meta-hand-materials.js
- game/modules/moon-upgrade.js

Main files changed:
- game/index.html
- game/assets/textures/HAND_C.png
- game/assets/textures/HAND_N.png
- game/assets/textures/HAND_S.png

How to update the forearm device UI from game logic:
- window.SVRWatchUI.setState({
    pot: '25,000',
    stack: '91,200',
    cards: ['Q♠','Q♥'],
    board: ['A♣','10♦','9♠','2♥'],
    buttons: ['FOLD','CHECK','BET','ALL IN']
  });

Primary tuning module for wrist placement:
- game/modules/forearm-device.js
- window.SVRForearmDeviceLayout.left

Primary tuning values:
- forearmOffset: move device toward elbow
- liftOffset: move device higher above the hand/arm mesh
- lateralOffset: move device left/right across the forearm
