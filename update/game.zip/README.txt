
SVR Poker v1 Project

Run server:
1. cd server
2. npm install express socket.io sqlite3
3. node server.js

Open browser:
http://localhost:3000
