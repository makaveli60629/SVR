SVR Poker test-room patch. Fixes watch floor issue, removes floor spheres, adds higher brighter Mars, and upgrades the full moon with stronger contrast while keeping stars behind the moon.
