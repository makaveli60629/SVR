SVR Poker Stable Visual Core

Upload this package as update/game.zip. Site files are not included or changed.

PowerShell:
Rename-Item .\game.zip game.zip

Phase 2 notes:
- Moon and Mars are higher and farther back.
- Teleport floor marker should now always appear when teleport is ON.
- Hand/controller fallback model was refined to a stylized glove shape.
- Extra table chips and polish added.
