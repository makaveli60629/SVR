SVR Poker - Test Room phase

Included:
- game/index.html
- game/modules/quest-watch.js
- game/modules/moon-upgrade.js

This phase is a TEST ROOM ONLY build.
It is intended to tune:
- Quest forearm watch
- Moon size / height / look
- Mars placement / look
- sky mood

Lobby protection:
- do not move these values into the lobby until approved
- the target copy values are exposed in window.SVRCelestialLayout.lobbyCopyHint

Celestial target values in this build:
- moon position: -10 58 -145
- moon scale: 2.05 2.05 2.05
- moon rotation: 0 18 0
- mars position: 42 49 -160
- mars scale: 4.4 4.4 4.4
