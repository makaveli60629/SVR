SVR Poker test-room patch
- removes screen overlay debug text
- uses Quest wrist/world forearm watch anchor
- uses safer high moon + high Mars staging for the test room
- adds bundled moon diffuse/bump textures for Quest-safe detail
