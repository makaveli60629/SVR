SVR Poker Demo v2

What changed
- Uses the real table.glb from the project archive.
- Adds a cleaner cyber-rooftop environment.
- Corrected player spawn at 0 1.6 3.
- Keeps index.html in ZIP root for easier GitHub deployment.
- Adds skyline, neon rail, moon texture, chips, cards, and logo projection.

Controls
- Mouse to look
- WASD to move
- VR mode available on supported browsers / headsets

Deploy
- Extract into your repo game folder.
- Keep index.html at the game root.
