Extract this ZIP directly into your SVR repo root, then run:
powershell -ExecutionPolicy Bypass -File .\Get-Phase119.ps1

If git push is rejected, run:
git pull --rebase origin main
git push origin main
