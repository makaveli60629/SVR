SVR Poker test-room patch

Included in this build:
- wrist-first Quest watch anchor update
- visibly faster moon and Mars orbit/rotation
- higher moon and Mars staging for the test room
- packaged moon diffuse and bump textures

Not included yet:
- the 3 hand-art images from chat are not bundled as raw asset files in this zip, so the hand texture overlay hook is not applied in this phase.
