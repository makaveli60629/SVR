SVR Poker test-room patch

This phase keeps the lobby untouched and updates only the test room.

Included:
- brighter, higher Mars
- large textured moon sphere with crater pass
- Quest watch fallback fixed to use wrist, palm, then hand-root
- star field preserved

Replace update/game.zip in your repo with this file.
