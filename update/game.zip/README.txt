SVR Quest Demo Patch · Modular Table Preview Phase

What this phase does:
- makes the forearm watch slightly larger while keeping the same wrist placement
- adds a modular table preview pass in the test room
- keeps the table work isolated from the lobby so layout tuning does not overwrite lobby progress
- leaves moon/sky and hand material work in separate modules

Module layout:
- game/modules/watch-ui.js
- game/modules/forearm-device.js
- game/modules/meta-hand-materials.js
- game/modules/moon-upgrade.js
- game/modules/table-preview.js

Main files changed:
- game/index.html
- game/modules/forearm-device.js
- game/modules/table-preview.js

What the table preview adds:
- felt ellipse pass
- rail ring + brass accent ring
- community card strip
- six betting spots
- center logo plate
- chip tray bars

Primary tuning module for the new table pass:
- game/modules/table-preview.js
