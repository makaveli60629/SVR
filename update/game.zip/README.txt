SVR Quest Forearm Watch Patch

What this does:
- adds a Quest-only left forearm watch
- attaches the watch to the left hand tracking entity
- draws the watch UI from a canvas so you can replace the data with your own game state
- keeps desktop/browser mode unchanged

Files:
- game/index.html
- game/modules/quest-watch.js

Main tuning line:
- in game/modules/quest-watch.js
  root.setAttribute('position', '0.055 -0.025 -0.085');
  root.setAttribute('rotation', '88 0 92');

If the watch sits too high/low or turns wrong on Quest, adjust those two values only.

To update the screen from your own poker logic:
- call window.SVRWatchUI.setState({
    pot: '25,000',
    stack: '91,200',
    cards: ['Q♠','Q♥'],
    board: ['A♣','10♦','9♠','2♥'],
    buttons: ['FOLD','CHECK','BET','ALL IN']
  });
