v218b blink fix
- removed pulsing from seat rings
- made rim emissive static
- reduced felt/table accent glow
- disabled earth/moon spark groups
- stopped claudia idle bob/arm shimmer
- trimmed unused assets to stay under github size limit
