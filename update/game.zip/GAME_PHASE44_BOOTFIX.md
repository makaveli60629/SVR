SVR Game Phase 44

Primary boot fix:
- removed importmap dependency
- switched Three.js imports to direct jsDelivr module URLs
- kept local-first asset loading
- added pre-module boot watchdog so failures do not look like a silent black screen

Deploy:
- replace update/game.zip with this zip
- push to main
- hard refresh after Pages finishes
