SVR Poker Phase 63 Quest Boot Fix

This build patches the bundled VR button/session flow so Quest no longer requests extra optional features during immersive entry.

Changes:
- VRButton now honors app-supplied session options
- Quest requests local-floor only
- offerSession auto-launch removed
- build stamp updated to phase63


Phase 64 patch: disabled auto-entry from sessiongranted so Quest only enters VR after a fresh manual tap on ENTER VR.
