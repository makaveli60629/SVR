Audit findings:
- repo game/index.html is a minimal prototype scene
- update/game.zip in source only contains game/index.html
- textures are present in game/assets/texture
- GLB files are present in game/assets/models (player.glb, table.glb)
- FBX assets exist locally but GitHub workflow excludes *.fbx on deploy
- no OBJ files were found in the current project zip
Fixes in this build:
- stable full lobby scene with VR button
- buildings outside wall
- textured moon and visible mars
- real table base with stable felt/rail/logo/pass line overlay
- Cards.glb dealer
- simple wrist watch anchored in VR
