# SVR Poker Game Phase 42

## What this phase changes
- aligns the newer modular game preview with the repo's actual asset layout (`game/assets/models/...`)
- includes the live-required FBX file for Eric inside the zip so GitHub Pages deploys keep the dealer model
- adds a stronger skyline room, moon + earth backdrop, poker stools, seat markers, logo felt decal, chips, and cards
- fixes VR entry so hand tracking is optional instead of required
- fixes teleport so it still works when only one hand is available

## Audit findings
1. The repo deploy workflow excludes `*.fbx` from the base copy step, so any FBX needed at runtime must ship in `update/game.zip`.
2. The checked-in repo game source and the newer modular preview are out of sync.
3. The newer preview used asset paths like `table/table.fbx` and `npc/eric/eric.fbx`, while the repo stores them under `game/assets/models/table.glb` and `game/assets/models/eric/eric.fbx`.
4. That mismatch is a real reason the newer preview can partially boot but miss table/dealer assets after deploy.

## Files bundled here
- `game/index.html`
- `game/main.js`
- `game/modules/*`
- `game/assets/models/table.glb`
- `game/assets/models/eric/eric.fbx`
- `game/assets/ui/logo_table.png`

## Install
Replace `update/game.zip` in the repo with this zip, commit, and push to `main`.
