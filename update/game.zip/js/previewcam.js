
// Simple third‑person preview using screen capture
const video=document.getElementById("preview");

navigator.mediaDevices.getDisplayMedia({video:true})
.then(stream=>{
video.srcObject=stream;
});
