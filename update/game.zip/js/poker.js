
AFRAME.registerComponent('poker-table',{
init:function(){

const scene=this.el

// table felt
let table=document.createElement('a-cylinder')
table.setAttribute('color','#0b6623')
table.setAttribute('radius','1.8')
table.setAttribute('height','0.15')
table.setAttribute('position','0 1 -3')
scene.appendChild(table)

// table rail
let rail=document.createElement('a-torus')
rail.setAttribute('radius','1.9')
rail.setAttribute('radius-tubular','0.1')
rail.setAttribute('rotation','90 0 0')
rail.setAttribute('position','0 1.1 -3')
rail.setAttribute('color','#4b2e1e')
scene.appendChild(rail)

// seats
for(let i=0;i<6;i++){

let angle=(i/6)*Math.PI*2

let x=Math.sin(angle)*2.8
let z=-3+Math.cos(angle)*2.8

let seat=document.createElement('a-cylinder')
seat.setAttribute('radius','0.4')
seat.setAttribute('height','0.5')
seat.setAttribute('color','#111')
seat.setAttribute('position',`${x} 0.25 ${z}`)

scene.appendChild(seat)

}

// chip stacks
for(let i=0;i<8;i++){

let chip=document.createElement('a-cylinder')
chip.setAttribute('radius','0.07')
chip.setAttribute('height','0.02')
chip.setAttribute('color','#e63946')

let x=(Math.random()*1.2)-0.6
let z=-3+(Math.random()*1.2)-0.6

chip.setAttribute('position',`${x} 1.1 ${z}`)

scene.appendChild(chip)

}

}
})
