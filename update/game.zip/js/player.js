
AFRAME.registerComponent('player-init',{
init:function(){
console.log("Player rig ready");
}
});
