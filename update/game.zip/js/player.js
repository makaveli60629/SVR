AFRAME.registerComponent('player-spawn',{
init:function(){
this.el.setAttribute("position","0 1.6 3")
console.log("Player spawned facing table")
}
})