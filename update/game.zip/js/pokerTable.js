AFRAME.registerComponent('poker-table',{

init:function(){

console.log("Poker table module active")

}

})