
AFRAME.registerComponent('skyline',{
init:function(){

const scene=this.el

for(let i=0;i<120;i++){

let b=document.createElement('a-box')

let x=(Math.random()*400)-200
let z=(Math.random()*-400)-50
let h=Math.random()*60+10

b.setAttribute('position',`${x} ${h/2} ${z}`)
b.setAttribute('height',h)
b.setAttribute('width',Math.random()*10+6)
b.setAttribute('depth',Math.random()*10+6)

b.setAttribute('color','#1a1a1a')

scene.appendChild(b)

}

console.log("City skyline generated")

}
})
