
AFRAME.registerComponent('skyline',{
init:function(){

const scene=this.el

for(let i=0;i<200;i++){

let b=document.createElement('a-box')

let x=(Math.random()*1200)-600
let z=(Math.random()*-1200)-100
let h=Math.random()*200+40

b.setAttribute('position',`${x} ${h/2} ${z}`)
b.setAttribute('height',h)
b.setAttribute('width',Math.random()*20+10)
b.setAttribute('depth',Math.random()*20+10)
b.setAttribute('color','#151515')

scene.appendChild(b)

}

}
})
