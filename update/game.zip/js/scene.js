
AFRAME.registerComponent('skyline',{
init:function(){

const scene=this.el

for(let i=0;i<140;i++){

let b=document.createElement('a-box')

let x=(Math.random()*600)-300
let z=(Math.random()*-600)-60
let h=Math.random()*80+10

b.setAttribute('position',`${x} ${h/2} ${z}`)
b.setAttribute('height',h)
b.setAttribute('width',Math.random()*12+6)
b.setAttribute('depth',Math.random()*12+6)
b.setAttribute('color','#1a1a1a')

scene.appendChild(b)

}

console.log("SVR city generated")

}
})
