(function () {
  function matrixRain() {
    const canvas = document.getElementById('matrix');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    function size() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    size();
    window.addEventListener('resize', size);

    const glyphs = 'アァカサタナハマヤャラワ0123456789SVRPOKER#$%&*';
    let fontSize = 16;
    let columns = Math.floor(window.innerWidth / fontSize);
    let drops = Array(columns).fill(1);

    function resetColumns() {
      columns = Math.floor(window.innerWidth / fontSize);
      drops = Array(columns).fill(1);
    }
    window.addEventListener('resize', resetColumns);

    function draw() {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.12)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.font = fontSize + 'px monospace';

      for (let i = 0; i < drops.length; i++) {
        const text = glyphs[Math.floor(Math.random() * glyphs.length)];
        const x = i * fontSize;
        const y = drops[i] * fontSize;

        ctx.fillStyle = Math.random() > 0.88 ? '#d7b6ff' : '#8a3dff';
        ctx.fillText(text, x, y);

        if (y > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
      requestAnimationFrame(draw);
    }
    draw();
  }

  function addWindows(sceneEl, x, z, cols, rows, w, h, gapX, gapY) {
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const p = document.createElement('a-plane');
        p.setAttribute('width', w);
        p.setAttribute('height', h);
        p.setAttribute('position', `${x + c * gapX} ${1.4 + r * gapY} ${z}`);
        p.setAttribute('color', (r + c) % 3 === 0 ? '#f0cb76' : '#8f55ff');
        p.setAttribute('material', 'emissive:#ffffff; emissiveIntensity:0.22; side:double');
        sceneEl.appendChild(p);
      }
    }
  }

  window.addEventListener('DOMContentLoaded', function () {
    matrixRain();

    const scene = document.querySelector('a-scene');
    if (!scene) return;

    addWindows(scene, -12.1, -19.55, 4, 4, 0.32, 0.28, 0.95, 1.0);
    addWindows(scene, -6.0, -22.98, 3, 7, 0.28, 0.22, 0.95, 0.95);
    addWindows(scene, -0.35, -21.48, 2, 5, 0.22, 0.22, 0.9, 1.0);
    addWindows(scene, 4.9, -25.02, 3, 8, 0.28, 0.22, 0.95, 1.0);
    addWindows(scene, 9.8, -21.75, 4, 6, 0.32, 0.26, 0.95, 0.95);

    const table = document.getElementById('tableEntity');
    if (table) {
      table.addEventListener('model-loaded', () => console.log('Table loaded'));
      table.addEventListener('model-error', (e) => console.warn('Table failed', e));
    }

    const npc = document.getElementById('npcWrap');
    if (npc) {
      let t = 0;
      function bob() {
        t += 0.03;
        const y = Math.sin(t) * 0.015;
        npc.object3D.position.y = y;
        requestAnimationFrame(bob);
      }
      bob();
    }
  });
})();
