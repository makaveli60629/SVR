(function () {
  function addWindowRows(sceneEl, x, z, cols, rows, w, h, gapX, gapY) {
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const p = document.createElement('a-plane');
        p.setAttribute('width', w);
        p.setAttribute('height', h);
        p.setAttribute('position', `${x + c * gapX} ${1.3 + r * gapY} ${z}`);
        p.setAttribute('color', (r + c) % 3 === 0 ? '#f0c96d' : '#7a5cff');
        p.setAttribute('material', 'emissive: #ffffff; emissiveIntensity: 0.25; side: double');
        sceneEl.appendChild(p);
      }
    }
  }

  window.addEventListener('DOMContentLoaded', function () {
    const scene = document.querySelector('a-scene');
    if (!scene) return;

    addWindowRows(scene, -12, -19.49, 4, 4, 0.32, 0.28, 0.95, 1.0);
    addWindowRows(scene, -5.2, -21.99, 3, 6, 0.28, 0.24, 0.95, 1.0);
    addWindowRows(scene, 0.1, -20.49, 2, 5, 0.22, 0.22, 0.9, 1.0);
    addWindowRows(scene, 5.0, -24.01, 3, 8, 0.28, 0.22, 0.95, 1.0);
    addWindowRows(scene, 10.2, -20.49, 4, 5, 0.32, 0.26, 0.95, 1.0);

    const table = document.querySelector('[gltf-model="#tableModel"]');
    if (table) {
      table.addEventListener('model-loaded', function () {
        console.log('SVR table model loaded');
      });
      table.addEventListener('model-error', function (e) {
        console.warn('SVR table model failed', e);
      });
    }
  });
})();
