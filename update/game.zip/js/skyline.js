
AFRAME.registerComponent('skyline',{
init:function(){

const scene=this.el

for(let i=0;i<160;i++){

let b=document.createElement('a-box')

let x=(Math.random()*800)-400
let z=(Math.random()*-800)-60
let h=Math.random()*150+30

b.setAttribute('position',`${x} ${h/2} ${z}`)
b.setAttribute('height',h)
b.setAttribute('width',Math.random()*12+6)
b.setAttribute('depth',Math.random()*12+6)
b.setAttribute('color','#1a1a1a')

scene.appendChild(b)

}

console.log("SVR skyline generated")

}
})
