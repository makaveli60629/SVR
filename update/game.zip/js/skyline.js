
AFRAME.registerComponent('skyline',{
init:function(){

const scene = this.el

for(let i=0;i<60;i++){

let b=document.createElement('a-box')

let x=(Math.random()*120)-60
let z=(Math.random()*-120)-20

let h=Math.random()*25+5

b.setAttribute('position',`${x} ${h/2} ${z}`)
b.setAttribute('height',h)
b.setAttribute('width',Math.random()*6+4)
b.setAttribute('depth',Math.random()*6+4)

b.setAttribute('color','#1a1a1a')

scene.appendChild(b)

}

console.log("Chicago skyline generated")

}
})
