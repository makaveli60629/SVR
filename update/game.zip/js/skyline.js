
AFRAME.registerComponent('skyline',{
init:function(){

const scene=this.el

for(let i=0;i<80;i++){

let b=document.createElement('a-box')

let x=(Math.random()*200)-100
let z=(Math.random()*-200)-40

let h=Math.random()*40+10

b.setAttribute('position',`${x} ${h/2} ${z}`)
b.setAttribute('height',h)
b.setAttribute('width',Math.random()*8+6)
b.setAttribute('depth',Math.random()*8+6)

b.setAttribute('color','#1a1a1a')

scene.appendChild(b)

}

}
})
