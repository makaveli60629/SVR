
AFRAME.registerComponent('skyline',{
init:function(){

const scene=this.el

for(let i=0;i<150;i++){

let b=document.createElement('a-box')

let x=(Math.random()*500)-250
let z=(Math.random()*-500)-50
let h=Math.random()*150+20

b.setAttribute('position',`${x} ${h/2} ${z}`)
b.setAttribute('height',h)
b.setAttribute('width',Math.random()*14+6)
b.setAttribute('depth',Math.random()*14+6)
b.setAttribute('color','#1a1a1a')

scene.appendChild(b)

}

}
})
