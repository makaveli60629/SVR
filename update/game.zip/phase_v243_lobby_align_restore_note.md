scene restore + lobby alignment v2.4.3
- aligned chairs symmetrically around the table
- restored sponsor, legends, and store lobby panels
- centered dealer behind the table and refined dealing arc
- kept black table, pass line, logo, stars, moon, mars, dim mood
- preserved lobby music watch toggle
