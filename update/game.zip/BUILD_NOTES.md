SVR game phase v2.1.8
- Switched hands to XR hand mesh model factory for native Meta-style hand visuals; removed custom phone-like hand props.
- Refined wrist watch anchor and rotated forearm shell to align along wrist-to-elbow.
- Re-centered all four sponsor matrix walls floor-to-ceiling.
- Raised and brightened Earth + Moon; Earth now orbits the room and Moon orbits Earth.
- Removed stage bump under the table and flattened/sank the center platform slightly.
- Scaled table larger, moved dealer side to the spawn-facing edge, and anchored Claudia to the dealer side.
- Added runtime attempt to use walking.fbx animation on Claudia, with fallback upper-body motion.
- Hid thin flat cap meshes on the table model to reduce blinking overlays.
- Tightened floor and wall texture tiling, increased skyline realism, and retained sponsor billboards.
