SVR next phase patch built on 2026-03-17
