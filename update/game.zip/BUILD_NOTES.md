SVR Poker game-only v2.1.3
- removed custom controller hand props for hand-free controller view
- updated forearm watch placement and viewer-facing UI
- replaced floor textures with uploaded Poliigon slate set and tighter tiling
- darkened scene slightly while brightening Earth/Moon and adding orbit glow sprites
- upgraded spawn matrix billboard to binary rain with launch phrases and logo overlay
- flipped Eric to the opposite direction
- attempted stronger Claudia upright/scale correction using walking rig first
