SVR next drop build

Changes in this package:
- game-only stability and polish pass
- preview camera adds an extra orbit shot and still auto-runs in site/iframe view
- audio status is clearer and recoverable when browser audio is still locked
- desktop testing shortcuts added: M music, N next track, J join, L leave
- wrist console now shows audio error/help text when unlock is required
- room lighting boosted slightly and seat rings pulse for better readability
- stars now twinkle subtly for a cleaner atmosphere pass
