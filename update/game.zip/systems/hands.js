(function(){AFRAME.registerComponent('svr-hand-safe',{init(){}});})();
