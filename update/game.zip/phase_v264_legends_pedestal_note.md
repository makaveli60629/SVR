Legends pedestal patch v264
- added a northwest legends pedestal area
- added plaque text for ASSASSIN 1
- added rope rails and spotlight
- added a silhouette placeholder because assasin1.glb is too large to ship in the under-25MB package as-is
