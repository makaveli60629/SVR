V291
- added rising purple/pink glowing lobby sprites
- reduced fog for clearer planet visibility
- moved moon higher and closer for better detail
- moved Mars higher and clearer in the background
- enlarged halos and improved moon/Mars lighting
- build label updated to 20260321-v291
