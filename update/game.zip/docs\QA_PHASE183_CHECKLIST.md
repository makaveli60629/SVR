# QA Phase 199

- [ ] Confirm build marker says `PHASE-252-FORWARD-RESTORE-QUEST-POKER-LOCK`.
- [ ] Press `F` during a player turn and confirm YOU appears under MUCKED/FOLDED.
- [ ] Let showdown complete and confirm folded players are excluded from side-pot winners.
- [ ] Confirm hand history still records winner, pot, winning five cards, side pots, contributions, and stacks.
- [ ] Confirm public Matrix launch page is unchanged.
