# PHASE-227-PILOT-ISSUE-TEMPLATE-LOCK

## Purpose
Phase 227 adds an in-game runbook for the simplified one-command PowerShell update flow.

## Locked boundaries
- Public Matrix launch page untouched.
- Direct `/game` deploy preserved.
- `update/game.zip` backup preserved.
- Site additions are internal admin-only helpers.

## Test
Open `/game/?v=phase227-runbook` and press `N`.
