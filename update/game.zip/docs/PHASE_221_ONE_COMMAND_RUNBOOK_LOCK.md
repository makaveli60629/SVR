# PHASE-224-QA-SHORTCUT-INDEX-LOCK

## Purpose
Phase 224 adds an in-game runbook for the simplified one-command PowerShell update flow.

## Locked boundaries
- Public Matrix launch page untouched.
- Direct `/game` deploy preserved.
- `update/game.zip` backup preserved.
- Site additions are internal admin-only helpers.

## Test
Open `/game/?v=phase224-runbook` and press `N`.
