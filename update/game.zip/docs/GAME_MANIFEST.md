# GAME MANIFEST

## Polish + alignment priorities
- lower blinking and shimmer
- smoother frame rate
- watch faces user and stays on forearm baseline
- moon is large, high, and clearly visible in north sky
- lobby room stays compact and readable
- table demo and hover cards are presentation-ready
