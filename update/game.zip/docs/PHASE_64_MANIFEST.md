# PHASE-64-REPO-SCRIPT-TRUTH-LOCK

- Adds visible build label.
- Restores deterministic deploy version files.
- Locks poker controls: Fold, Check, Call, Raise, Next Hand.
- Adds real hand evaluator and winner payout.
- Keeps 5 bots + 1 open player seat.
- Keeps package lightweight for GitHub Pages.
