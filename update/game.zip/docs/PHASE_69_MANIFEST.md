# SVR Poker Phase 69 — Stability + Director Pass

This phase continues from the P66R hotfix baseline.

## Changes
- tightened watch fit and enlarged watch buttons
- lowered mobile render cost for Android/Quest
- improved skyline visibility and promenade/carpet glow
- moved matrix/store features farther off the front table axis
- upgraded CAM 3 director with more shots and smoother drift
- raised poker cards slightly for better readability

## Deploy
Copy this `game.zip` into `update/game.zip`, commit, pull --rebase, and push from the repo folder.
