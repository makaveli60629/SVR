# SVR Poker Phase 65 Manifest

## Locked baseline
- Recovered larger lobby shell stays locked
- Red carpet promenade is preserved and refined
- Preview camera remains preview-only

## Added in Phase 65
- richer red carpet trim and entry detail
- calmer world pulses for a smoother lobby feel
- upgraded CAM 3 director with multiple auto-moving shot angles
- full real 52-card Texas Hold'em autoplay demo remains active
- module stabilization pass for watch/camera/world timing

## Keep locked
- restored lobby shell
- skyline shell
- red carpet path
- Matrix wall / Legend Wall / Store frontage
- preview-only CAM 3 behavior
