# SVR Poker — Phase 61 Asset Audit

## Baseline audited
- Current working `game.zip` recovery shell from phase 57
- `SVR-main.zip`
- `ChatGPT_SVR_Poker_Operator_Manifest_2026-03-29.md`

## Key findings
- The current safe runtime remains the boot-safe recovery shell, so this pass stays on that base.
- The full-screen splash layer was the main blocker for the spectator preview, so this pass replaces it with a compact dock.
- CAM 3 remains a browser-side spectator view and now stays visible during framework load and scene boot.

## Assets included in this build
- `game/assets/textures/logo.png`
- `game/assets/textures/logo-table.png`
- `game/assets/textures/tablefelt.png`
- `game/assets/textures/moon_diffuse.png`

## Runtime design choices
- No FBX or GLTF file is required at boot.
- Demo-critical geometry is still built from A-Frame primitives.
- CAM 3 uses the live runtime scene and cycles through safe preset angles.
- The compact dock keeps manual VR entry without covering the spectator feed.
