SVR Poker audit fix (2026-03-30)

Confirmed issues in the prior uploaded build:
1. /game/index.html and /game/main.js still reported Phase 52 / build 20260329-P52 even though later docs claimed Phase 67.
2. preview.html and cam3.html requested cam=director, but main.js did not implement a director mode. It silently fell back to orbit.
3. The desktop VR button showed the default "VR NOT SUPPORTED" badge, which looked like a runtime error even when the desktop build itself was fine.
4. The Matrix wall was still placed near the front table axis and the carpet/store presentation was too subtle.

This pack fixes those mismatches and makes the changes visible in the runtime UI.
