# Phase 66R Manifest

- Keeps the restored lobby shell and carpet unchanged.
- Adds Android-smart renderer tuning for Quest/Android browsers.
- Adds dual-stick XR controls: left stick move, right stick snap turn.
- Preserves preview-only CAM 3 and the autoplay full poker demo.
