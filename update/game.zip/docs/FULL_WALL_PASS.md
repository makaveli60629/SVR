# Full Wall Pass

This phase adds a broader lobby wall layout so the room feels game-ready:
- league wall
- help/controls wall
- mission wall
- poker basics wall
- live preview wall

Purpose: reduce empty wall space and make the lobby read like a complete playable destination.
