Phase 70
- Removed live preview overlay writing.
- Locked preview and embedded live views to CAM 3 director auto-move.
- Kept gameplay view separate from the preview feed.
- Preserved the recovered lobby shell and third-camera system.
