# QA Phase 188

- [ ] Open /game/?v=phase188.
- [ ] Confirm build marker shows PHASE-194-PLAYTEST-WIZARD-LOCK
- [ ] Enter or preview game without black screen.
- [ ] During player turn, watch shows actor YOU and countdown.
- [ ] When no call is facing player, watch button reads CHECK.
- [ ] When call is facing player, watch button reads CALL $amount.
- [ ] RAISE button shows min raise amount.
- [ ] NEXT HAND watch button starts next hand.
- [ ] Public root Matrix page is unchanged.
