# Polish + Alignment Check

## Scope of this pass
This phase is a **polish/alignment check pass** only.

It is intended to preserve the current working package and make the next player audit easier.
It does **not** claim that gameplay is final.

## What was checked

### 1. Package integrity
- Source package extracted successfully
- Manifest/docs folder present
- Audio folder present
- Model/assets folder present

### 2. JavaScript syntax
The following files passed `node --check`:
- `main.js`
- `modules/asset_base.js`
- `modules/audio.js`
- `modules/config.js`
- `modules/core_scene.js`
- `modules/desktop_controls.js`
- `modules/gestures.js`
- `modules/hands.js`
- `modules/teleport.js`
- `modules/watch.js`
- `modules/world_skyline.js`

### 3. Alignment areas to audit in-headset
#### Watch
- forearm placement
- screen facing direction
- button hit response
- no wrist clipping

#### Table
- felt visible
- felt inside playable surface
- pass line readable
- chips flat
- hover cards facing player

#### Lobby
- spawn facing north
- compass markers readable
- league wall readable
- store wall placement readable
- Reiki presentation area visible

#### Sky
- moon high in north sky
- moon readable from spawn and from table
- no heavy blinking / shimmer
- stars visible but not noisy

#### Motion / controls
- watch teleport only
- no accidental fist teleport behavior
- live preview camera auto-moves in iframe/embed
- no startup crash

## Current recommendation
Use this package for a **player-facing alignment audit** and send back findings in this order:
1. Watch
2. Teleport
3. Table/felt
4. Hover cards
5. Reiki area
6. Store wall
7. Moon / stars / blinking
8. Frame rate / freezes

## Notes
This pass is intentionally conservative so the current working build is not destabilized before your next audit.
