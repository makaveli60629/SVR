Hotfix: fixes black screen caused by using isMobile/isAndroid before createCore() returned those values. Also repackaged the game so the intended app is at the zip root for clean deployment.
