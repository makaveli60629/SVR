# Phase 199 QA Checklist

- [ ] /game/version.json shows PHASE-229-POWER-DEPLOY-WATCHER-LOCK
- [ ] During player turn, the hand-history panel shows an AID line.
- [ ] Free check shows FREE CHECK / 0% call cost.
- [ ] Calling a bet shows pot-odds percentage.
- [ ] Browser event `svr_poker_decision_aid_update` fires without console errors.
- [ ] Root public Matrix page remains unchanged.
