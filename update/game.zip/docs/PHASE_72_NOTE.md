Phase 72: packaged from the fuller nested main-scene runtime, with preview overlays removed and CAM 3 locked to fullscreen director mode. Single-runtime package only.
