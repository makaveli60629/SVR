# PHASE-229-POWER-DEPLOY-WATCHER-LOCK

Phase 213 aligns the boot script cache marker, main runtime build marker, version.json, and bridge import marker.

## Fixes
- Updates `index.html` script query from stale phase values to `boot.js?v=phase229`.
- Updates `boot.js` fallback/no-cache reload/import query markers to Phase 213.
- Adds `modules/boot_cache_watchdog.js` to detect stale version or boot cache mismatch.
- Adds cache-busted `enterprise_bridge_phase229.js`.
- Keeps public Matrix launch page untouched.

## Test
Open `/game/?v=phase229-bootcache`, then verify the HUD says `PHASE-229-POWER-DEPLOY-WATCHER-LOCK` and the game does not remain stuck on Booting.
