# SVR Poker Demo Manifest

This package contains a simplified poker game demo that runs entirely in the browser without any external dependencies or heavy 3D assets. It is intended as a placeholder while the full 3D lobby and assets are restored.

## Contents

* `index.html` – The entry point of the demo. Provides a simple UI with a button to simulate a single round of Texas Hold’em and display the results.
* `main.js` – Orchestrates a sample poker hand using the core game logic. Sets up three players, deals cards, runs a betting sequence, deals community cards, and resolves the showdown. It renders a textual log of the hand in the UI.
* `core/` – Contains modular game logic used by `main.js`:
  * `deck.js` – Creates and shuffles a standard 52‑card deck and draws cards without mutation.
  * `tableState.js` – Manages table state, players, dealing hands, and dealing community cards.
  * `bettingRound.js` – Handles betting actions (fold, check, call, bet/raise, all‑in) and pot calculation.
  * `handEvaluator.js` – Evaluates five‑card hands using a high‑card only scoring system and determines the best hand out of seven cards.
  * `showdown.js` – Computes the showdown outcome by evaluating each player’s best hand and returning winners and ranked results.
* `docs/MANIFEST.md` – This file.

## Limitations

* This demo does **not** include the full 3D lobby, table models, Meta hand tracking, or VR environment from the original project due to missing assets. Instead, it demonstrates the underlying poker logic in a minimal, text‑based interface.
* The hand evaluator currently only distinguishes between hands based on high card values. Support for pairs, straights, flushes, etc. would need to be added for a complete game.
* There is no persistent state between hands; each click of the “Simulate Hand” button runs a fresh simulation.

## Usage

Open `index.html` in a web browser and click the “Simulate Hand” button to run a sample round of poker. The log will display the board cards, each player’s hand, the total pot, and the ranked results. Use this as a foundation for further development or integration with a 3D environment when the original assets become available.