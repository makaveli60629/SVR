# Player Alignment Audit

## What to check first
- Is the watch on the forearm and readable?
- Is the table felt visible and centered?
- Are the six-seat hover cards upright and facing the player?
- Is the Reiki area clearly visible in the lobby?
- Does the store wall read correctly from the lobby?
- Is the moon high and visible in the north sky?
- Does anything blink, shimmer, freeze, or disappear?

## Report format
Send back issues in this format:
- `watch:`
- `table:`
- `cards:`
- `reiki:`
- `store:`
- `moon:`
- `performance:`

Example:
- `watch: too low on wrist`
- `table: no felt visible`
- `moon: still blinking right eye`
