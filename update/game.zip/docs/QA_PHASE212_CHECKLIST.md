# QA Phase 213 Checklist

1. Open `/game/?v=phase236-bootdiag`.
2. Confirm the HUD build marker says `PHASE-236-VR-INPUT-DIAGNOSTIC-LOCK`.
3. Press `D` and confirm the boot diagnostic overlay opens.
4. Click/trigger copy/download diagnostic JSON.
5. Confirm no public Matrix page files were changed.
