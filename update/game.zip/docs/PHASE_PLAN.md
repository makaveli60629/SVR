# SVR Poker Phase Plan

## Phase 1 — Stability Core
- Lock renderer clear color to purple/black.
- Clamp pixel ratio.
- Disable expensive shadow map defaults.
- Add boot recovery overlay.

## Phase 2 — Real Lobby Recovery
- Restore rooftop circular lobby feel.
- Add solid walls, purple skyline, Willis/Trump/Hancock-style landmark silhouettes.
- Add moon, Mars, star field, floating glow sprites.
- Keep spawn 3 meters away facing the table.

## Phase 3 — Interaction + Watch
- Right hand teleport with grip/fist/pinch toggle.
- Trigger release jumps.
- Purple hand glow and SVR logo floor marker.
- Forearm watch on both hands with readable screen.

## Phase 4 — Scene Setup
- Poker, Reiki, PGA, Scorpion pads staged as modular portal placeholders.
- Future real scenes can replace placeholders without touching core lobby.

## Phase 5 — Asset Integration
- Drop table.glb into assets/models/table.glb.
- Drop eric.glb and carla.glb into assets/models.
- Future FBX/GLB loader path is already prepared.

## Phase 6 — Multiplayer
- Add socket/WebRTC sync for head, hands, seat state, table state.
