# SVR Poker — Phase 58

## Focus
- lower blink/flicker
- move Matrix wall off the table sightline
- make CAM 3 preview auto-direct more clearly
- auto-enable preview mode when the game is embedded in a site iframe
- enlarge and stabilize the watch buttons
- lift cards so they read better from the player side
- keep BOT tags readable at the chairs

## Note
This remains a reconstruction from the backup references. The uploaded backup still does not contain a complete exact copy of the older lobby shell.
