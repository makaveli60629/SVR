Phase 71 Original Merge

Baseline:
- last known good original-lobby backup from game_chat_only_copy.zip

Merged work:
- original lobby shell preserved
- red carpet / promenade restored
- matrix wall, legend wall, store frontage added into the original shell
- preview-only CAM 3 pages restored
- dual-stick Quest controls preserved
- watch anchor/buttons enlarged and tightened
- teleport stays armed by TP/watch and fires on trigger release
- autoplay poker table flow reintroduced for demo readability

Notes:
- this build intentionally avoids the broken shell-recovery branch
- gameplay page and preview page are separated
