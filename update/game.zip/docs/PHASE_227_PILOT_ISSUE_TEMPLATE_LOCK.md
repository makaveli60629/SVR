# PHASE-229-POWER-DEPLOY-WATCHER-LOCK

## Purpose
Phase 229 adds a concise pilot issue template so testers can copy/paste consistent bug reports with URL, device, action, expected result, actual result, and screenshot notes.

## Locked boundaries
- Public Matrix launch page untouched.
- Direct `/game` deploy preserved.
- `update/game.zip` backup preserved.
- Site additions are internal admin-only helpers.

## Test
Open `/game/?v=phase229-issuetemplate` and press `F2`.
