# SVR Poker — Phase 61 Changelog

## Focus of this pass
- remove the full-screen splash blocker
- keep CAM 3 visible during boot and desktop monitoring
- preserve the stable loader and XR baseline

## What changed
- replaced the full-screen splash card with a compact **live control dock**
- kept **CAM 3** visible during framework load and scene boot
- kept **Enter VR** available without blocking the spectator preview
- auto-hides the control dock after entering VR and restores it after exit
- refreshed docs/manifests for this phase
