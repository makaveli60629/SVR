SVR Poker phase 12 models pack

Included for faster future passes:
- moon.glb
- store.glb
- table.glb
- tablefelt.png
- eric/eric.fbx
- eric/eric-diffuse-small.webp
- claudia/claudia.fbx
- claudia/cards.fbx
- claudia/dealer-stool.fbx
- claudia/claudia-diffuse-better.webp
- claudia/claudia-diffuse.webp

These are additional organized copies. The current game build still keeps its active runtime assets in /game/assets for stability.
