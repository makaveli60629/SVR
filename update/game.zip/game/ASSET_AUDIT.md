# SVR game asset audit

## Included in this pass
- assets/logo.webp
- assets/table.glb
- assets/tablefelt.png
- assets/eric.fbx
- assets/eric-diffuse-small.webp
- assets/claudia.fbx
- assets/claudia-diffuse-better.webp
- assets/cards.fbx
- assets/dealer-stool.fbx
- assets/moon-diffuse.webp
- assets/moon-bump.webp

## Implemented in-room
- player rig moved to a proper floor-based XR root so spawn/teleport works from the room floor instead of the table center
- spawn set about 10 meters from the table and facing the table
- table scaled down again and seat spacing widened so the chairs stop clipping into the table
- extra old felt/trim overlay removed when the real table model is loaded
- brighter moon, skyline, ceiling, and lounge lighting for headset visibility
- lower wall height so the moon, earth, and skyline read better
- Eric repositioned to the side of the table
- Claudia moved behind the dealer line instead of bouncing in the table center
- tabletop preview cards and player-seat cards/chips added for poker feel tests
- VR hand/controller teleport glow only appears when teleport mode is active
- approximate Meta-style hand teleport added: fist-near-face toggles teleport, pinch teleports to the glowing logo marker when hand tracking is available
- controller teleport and desktop/mobile movement remain available

## Intentionally disabled in this pass
- imported cards.fbx mesh on the table, because it was contributing to the doubled/overlapping tabletop clutter

## Still not fully solved
- final polished Quest hand-tracked fist gesture tuning across all browser/device combinations
- full grab/pickup logic for cards and chips
- final seated poker interaction set and chair lock polish
- multiplayer gameplay and account-linked inventory logic
