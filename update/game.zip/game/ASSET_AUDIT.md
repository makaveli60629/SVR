# SVR game asset audit

## Included in this pass
- assets/logo.webp
- assets/table.glb
- assets/tablefelt.png
- assets/eric.fbx
- assets/eric-diffuse-small.webp
- assets/claudia.fbx
- assets/claudia-diffuse-better.webp
- assets/cards.fbx
- assets/dealer-stool.fbx
- assets/moon-diffuse.webp
- assets/moon-bump.webp

## Implemented in-room
- real table model centered and scaled down for cleaner seating layout
- player spawn set about 10 meters from the table edge
- brighter moon, skyline, ceiling, and lounge lighting for headset visibility
- lower wall height so the moon, earth, and skyline read better
- Eric scaled up and repositioned to the table correctly
- Claudia scaled up, retextured, and moved off the table center
- dealer stool aligned behind the dealer
- cards placed on the live table without the previous bounce issue
- desktop movement, mobile sticks, VR entry, and controller teleport support
- meta-style desktop hands and VR hand/controller glow accents
- cyan and purple teleport glow feedback on hands and teleport marker
- logo chair seat interaction, radio prop, watch overlay, and atmosphere sprites

## Still not fully solved
- final Quest hand-tracked fist-near-face teleport gesture logic
- physical wristwatch attached to a tracked Quest hand mesh
- final seated poker interaction set for chips, cards, and chair locking
- multiplayer gameplay and account-linked inventory logic
