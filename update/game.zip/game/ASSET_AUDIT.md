# SVR game asset audit

## Included in this pass
- assets/logo.webp
- assets/logo-table.webp
- assets/logo-table-top.png
- assets/table.glb
- assets/tablefelt.png
- assets/eric.fbx
- assets/eric-diffuse.jpg

## Implemented in-room
- real uploaded table model loaded through GLTF
- felt/top overlay using the table-felt art
- stronger skyline glow and moon lighting
- smaller, wider atmosphere sprites
- cleaner HUD and hidden crosshair until desktop pointer lock
- desktop movement + mobile dual-stick movement
- teleport fallback
- radio prop and audio toggle

## Still not fully solved
- Quest hand-tracked fist-near-face teleport
- wristwatch physically attached to a tracked hand model
- seated Eric pose using the proper sitting animation rig
- full gameplay interactions like chip pickup, sitting, and live multiplayer room feed
