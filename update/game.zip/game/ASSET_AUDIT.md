# SVR game asset audit

Included in this build:
- assets/logo.webp
- assets/logo-table.webp
- assets/eric.fbx
- assets/eric-diffuse.webp

Implemented in-room:
- circular room shell
- skyline glow boxes
- moon + neon lighting
- logo felt table
- movement for desktop and mobile
- teleport fallback

Not fully solved in this pass:
- hand-tracked fist-near-face teleport in Quest browsers
- wristwatch physically attached to a tracked hand
- real uploaded table OBJ/FBX with confirmed texture map, because that model was not present in the provided uploads
