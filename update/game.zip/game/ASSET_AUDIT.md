# SVR game asset audit

## Included in this pass
- assets/logo.webp
- assets/logo-table.webp
- assets/logo-table-top.png
- assets/table.glb
- assets/tablefelt.png
- assets/eric.fbx
- assets/eric-diffuse.jpg
- assets/claudia.fbx
- assets/claudia-diffuse.webp
- assets/cards.fbx
- assets/dealer-stool.fbx
- assets/moon-diffuse.webp
- assets/moon-bump.webp

## Implemented in-room
- WebXR Enter VR button
- brighter room lighting for Oculus / headset viewing
- moon-lit skyline with blinking red roof lights
- tighter player-seat layout with logo chair and sit / stand interaction
- Claudia dealer asset and table card asset load
- desktop movement + mobile dual-stick movement
- VR locomotion when controller axes are exposed by the browser/headset
- real table model with felt surface and atmosphere sprites
- radio toggle and watch overlay

## Still not fully solved
- full hand-tracked fist-near-face teleport
- physical wristwatch attached to a tracked hand mesh
- final dealer seated animation rig
- full chip pickup, chair physics, and multiplayer card logic

## Added in phase 5
- desktop keyboard movement without pointer-lock requirement
- visible desktop hand props with wrist watch
- spawn reset about 3 meters from the table edge after the real table loads
- richer chair detailing and brighter table surface treatment
- stronger moon / skyline / lounge lighting for headset visibility
