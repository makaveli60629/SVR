# SVR Poker Audit + Debug Report

Build: 2026-04-04 (`reiki-audit`)

## What I audited
- repo source layout versus deploy flow
- shipped `update/game.zip` versus checked-in `/game` source
- local WebXR source package (`webex-game-site.zip`)
- asset availability for table, dealer, logo, and test-room wiring
- runtime diagnostics coverage for hand tracking, draw calls, and heap visibility

## Findings

### 1) Source-of-truth split
The project had **three different game code paths**:
1. repo `/game` = older prototype source
2. repo `update/game.zip` = separate A-Frame deploy artifact
3. `webex-game-site.zip` = newer modular Three.js/WebXR source

That split made debugging unreliable because the checked-in source did **not** match the shipped build.

### 2) Deploy behavior was different from the earlier note
The current GitHub Actions workflow copies the repo into `build/`, excludes only `.git`, `.github`, and `update`, then overlays `update/site.zip` and `update/game.zip`.
It does **not** currently exclude `*.fbx` in the base copy.

### 3) Missing debug instrumentation
The newer WebXR source had no direct renderer/memory panel, and the main HUD exposed a **Joints** button with no implementation.

### 4) Test-room route was not enabled as a first-class scene
There was a `sandbox/` scene in the standalone package, but the active repo/source did not expose a named **Reiki test room** route for isolated scene validation.

### 5) Asset reliability was incomplete
The skyline world expected a larger asset tree than the repo actually contained. The safest fix was to keep the room bootable with procedural fallbacks and then stream available local assets when present.

## What I changed
- normalized the game around the newer modular Three.js/WebXR source
- added a **Reiki Test Room** at `/game/reiki/`
- added renderer + heap + draw-call diagnostics panel
- implemented the missing **joint debug** overlay
- added local asset paths for:
  - `assets/table/table.fbx`
  - `assets/npc/eric/eric.fbx`
  - `assets/npc/carla/carla.fbx`
  - `assets/ui/logo.png`
- hardened the skyline room with procedural table + dealer fallbacks
- kept the skyline room spawn roughly **3 meters** from table center
- added a direct HUD link from the main room into the Reiki test room

## What the Reiki Test Room is for
Use `/game/reiki/` to isolate:
- hand visibility
- teleport mode toggling
- pointer target placement
- logo reticle loading
- joint debug spheres
- approximate browser heap + renderer draw-call behavior

## Controls
### Main skyline room
- desktop move: `W A S D`
- up/down: `Space` / `Shift`
- mouse look: click to pointer-lock
- debug: `1` joints, `2` stats
- VR teleport: fist near face to arm/disarm, pinch-release to jump

### Reiki test room
- same controls as the skyline room
- purpose: lighter isolated validation scene

## Remaining gaps
These were **not** fully rebuilt in this pass:
- final seated snap system
- poker rules/gameplay loop
- card/chip interaction pass
- website layout overhaul
- complete Chicago landmark asset pack

## Recommended next step
Unify the repo by making the checked-in `/game` source and `update/game.zip` the same build every time. This patch already does that in the full repo package.
