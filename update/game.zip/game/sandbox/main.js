import * as THREE from "three";
import { VRButton } from "three/addons/webxr/VRButton.js";
import { XRHandModelFactory } from "three/addons/webxr/XRHandModelFactory.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $err = document.getElementById("err");
const $toggleLog = document.getElementById("toggleLog");

function log(...args){
  const line = args.map(a => (typeof a === "string" ? a : JSON.stringify(a, null, 2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}
window.addEventListener("error", (e)=>{
  $err.style.display = "block";
  $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  $err.style.display = "block";
  $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});
$toggleLog.addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

const U = (rel) => new URL(rel, import.meta.url).toString();
const LOGO_TEX = U("../assets/ui/logo.png");
const TP_FALLBACK = U("./tp_fallback.png");

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x030204);
scene.fog = new THREE.FogExp2(0x050408, 0.015);

const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.01, 240);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.35));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.xr.enabled = true;
document.getElementById("app").appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer, {
  requiredFeatures: ["local-floor", "hand-tracking"],
  optionalFeatures: ["bounded-floor"]
}));

scene.add(new THREE.HemisphereLight(0xffffff, 0x08030d, 1.18));
const key = new THREE.PointLight(0xd09dff, 18, 140, 2.0);
key.position.set(0, 9, -6);
scene.add(key);
const fill = new THREE.PointLight(0xff547b, 10, 90, 2.0);
fill.position.set(0, 4, 8);
scene.add(fill);

const stage = new THREE.Group();
scene.add(stage);

const floor = new THREE.Mesh(
  new THREE.CircleGeometry(34, 140),
  new THREE.MeshStandardMaterial({ color: 0x07060b, roughness: 1.0, metalness: 0.0 })
);
floor.rotation.x = -Math.PI / 2;
stage.add(floor);

const sigilRing = new THREE.Mesh(
  new THREE.TorusGeometry(3.1, 0.14, 16, 60),
  new THREE.MeshStandardMaterial({ color: 0xff4f90, roughness: 0.18, metalness: 0.22, emissive: 0x7e103f, emissiveIntensity: 1.0 })
);
sigilRing.rotation.x = Math.PI / 2;
sigilRing.position.y = 0.05;
stage.add(sigilRing);

const sigil = new THREE.Mesh(
  new THREE.CircleGeometry(2.7, 40),
  new THREE.MeshBasicMaterial({ color: 0x170814, transparent:true, opacity:0.75 })
);
sigil.rotation.x = -Math.PI / 2;
sigil.position.y = 0.01;
stage.add(sigil);

for (let i = 0; i < 18; i++){
  const angle = (i / 18) * Math.PI * 2;
  const cliff = new THREE.Mesh(
    new THREE.DodecahedronGeometry(1.1 + (i % 4) * 0.4, 0),
    new THREE.MeshStandardMaterial({ color: 0x221421, roughness: 0.96, metalness: 0.02 })
  );
  cliff.position.set(Math.cos(angle) * 12.5, 0.7 + (i % 3) * 0.35, Math.sin(angle) * 12.5 - 3);
  cliff.scale.set(1.2, 1.9, 1.3);
  stage.add(cliff);
}

for (let i = 0; i < 8; i++){
  const angle = (i / 8) * Math.PI * 2;
  const pillar = new THREE.Mesh(
    new THREE.CylinderGeometry(0.22, 0.32, 4.5, 10),
    new THREE.MeshStandardMaterial({ color: 0x12141f, roughness: 0.75, metalness: 0.18, emissive: 0x290a20, emissiveIntensity: 0.35 })
  );
  pillar.position.set(Math.cos(angle) * 8.2, 2.25, Math.sin(angle) * 8.2 - 3);
  stage.add(pillar);
}

const starGeo = new THREE.BufferGeometry();
const starPos = [];
for (let i = 0; i < 360; i++){
  const angle = Math.random() * Math.PI * 2;
  const r = 24 + Math.random() * 70;
  const y = 10 + Math.random() * 60;
  starPos.push(Math.cos(angle) * r, y, Math.sin(angle) * r - 36);
}
starGeo.setAttribute("position", new THREE.Float32BufferAttribute(starPos, 3));
scene.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xfff7ff, size: 0.2, transparent:true, opacity:0.86 })));

function makeDotTexture(color){
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext("2d");
  const grad = ctx.createRadialGradient(64,64,6,64,64,58);
  grad.addColorStop(0, "rgba(255,255,255,1)");
  grad.addColorStop(0.32, color);
  grad.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0,0,128,128);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
const spriteTexes = [makeDotTexture("rgba(255,84,123,0.95)"), makeDotTexture("rgba(180,132,255,0.95)"), makeDotTexture("rgba(96,214,255,0.95)")];
const ambientSprites = [];
for (let i = 0; i < 140; i++){
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: spriteTexes[i % spriteTexes.length], transparent:true, opacity:0.58, depthWrite:false }));
  const a = Math.random() * Math.PI * 2;
  const r = 2 + Math.random() * 12;
  sprite.position.set(Math.cos(a) * r, 0.16 + Math.random() * 3.4, Math.sin(a) * r - 1.5);
  const s = 0.11 + Math.random() * 0.09;
  sprite.scale.setScalar(s);
  stage.add(sprite);
  ambientSprites.push({ sprite, speed:0.09 + Math.random() * 0.18 });
}

function makeSignTexture(){
  const canvas = document.createElement("canvas");
  canvas.width = 1600;
  canvas.height = 480;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "rgba(5,6,10,0.92)";
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.strokeStyle = "#ff4f90";
  ctx.lineWidth = 14;
  ctx.strokeRect(18,18,canvas.width-36,canvas.height-36);
  ctx.textAlign = "center";
  ctx.fillStyle = "#ffbdd8";
  ctx.font = "700 120px Arial";
  ctx.fillText("SCORPION ROOM", canvas.width / 2, 170);
  ctx.fillStyle = "#ffffff";
  ctx.font = "600 56px Arial";
  ctx.fillText("Neon ritual chamber • movement sandbox • future game portal", canvas.width / 2, 272);
  ctx.fillStyle = "#d8b7ff";
  ctx.font = "600 42px Arial";
  ctx.fillText("Left pinch-drag move • Right pinch teleport", canvas.width / 2, 350);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
const sign = new THREE.Mesh(new THREE.PlaneGeometry(10, 3), new THREE.MeshBasicMaterial({ map: makeSignTexture() }));
sign.position.set(0, 4.6, -12);
stage.add(sign);

const texLoader = new THREE.TextureLoader();
let logoTex = null;
function makeLogo(size){
  const geo = new THREE.PlaneGeometry(size, size);
  const mat = new THREE.MeshBasicMaterial({ map: logoTex, transparent: true, alphaTest: 0.55, depthWrite: false, polygonOffset:true, polygonOffsetFactor:-2, side:THREE.DoubleSide });
  const m = new THREE.Mesh(geo, mat);
  m.rotation.x = -Math.PI / 2;
  m.renderOrder = 999;
  return m;
}
const spawnRing = new THREE.Mesh(new THREE.RingGeometry(0.35, 0.48, 64), new THREE.MeshStandardMaterial({ color: 0xff4f90, roughness: 0.35, metalness: 0.2, emissive: 0x7e103f, emissiveIntensity: 0.95, side: THREE.DoubleSide }));
spawnRing.rotation.x = -Math.PI / 2;
spawnRing.position.set(0, 0.011, 0);
stage.add(spawnRing);
const teleportRing = new THREE.Mesh(new THREE.RingGeometry(0.12, 0.16, 40), new THREE.MeshStandardMaterial({ color: 0xff4f90, roughness: 0.35, metalness: 0.2, emissive: 0x7e103f, emissiveIntensity: 0.95, side: THREE.DoubleSide }));
teleportRing.rotation.x = -Math.PI / 2;
teleportRing.visible = false;
teleportRing.renderOrder = 998;
stage.add(teleportRing);
let spawnLogo = null;
let teleportLogo = null;

async function loadLogo(){
  return new Promise((resolve)=>{
    const tryTex = (url, label) => {
      texLoader.load(url, (t)=>{
        t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = 8;
        logoTex = t;
        spawnLogo = makeLogo(0.82);
        spawnLogo.position.set(0, 0.012, 0);
        stage.add(spawnLogo);
        teleportLogo = makeLogo(0.62);
        teleportLogo.visible = false;
        stage.add(teleportLogo);
        log(label, "loaded:", url);
        $status.textContent = "Scorpion room ready";
        resolve(true);
      }, undefined, ()=>{
        if (label === "LOGO") tryTex(TP_FALLBACK, "FALLBACK");
        else resolve(false);
      });
    };
    tryTex(LOGO_TEX, "LOGO");
  });
}

function showTeleportAt(p){
  teleportRing.visible = true;
  teleportRing.position.set(p.x, 0.012, p.z);
  if (teleportLogo){
    teleportLogo.visible = true;
    teleportLogo.position.set(p.x, 0.013, p.z);
  }
}
function hideTeleport(){
  teleportRing.visible = false;
  if (teleportLogo) teleportLogo.visible = false;
}

const handModelFactory = new XRHandModelFactory();
const hands = [];
for (let i=0;i<2;i++){
  const hand = renderer.xr.getHand(i);
  hand.add(handModelFactory.createHandModel(hand, "mesh"));
  scene.add(hand);
  hands.push(hand);
}
function isPinching(hand){
  const indexTip = hand.joints?.["index-finger-tip"];
  const thumbTip = hand.joints?.["thumb-tip"];
  if (!indexTip || !thumbTip) return false;
  return indexTip.position.distanceTo(thumbTip.position) < 0.025;
}

const tmp = new THREE.Vector3();
const drag = { active:false, startHand:new THREE.Vector3(), startStage:new THREE.Vector3() };
const MOVE_GAIN = 1.15;
const ray = new THREE.Raycaster();
const down = new THREE.Vector3(0,-1,0);

function updateMovement(){
  const left = hands[0];
  if (left?.joints){
    const pinch = isPinching(left);
    const indexTip = left.joints["index-finger-tip"];
    if (indexTip) indexTip.getWorldPosition(tmp);
    if (pinch && !drag.active){
      drag.active = true;
      drag.startHand.copy(tmp);
      drag.startStage.copy(stage.position);
      $status.textContent = "Moving scorpion room…";
    }
    if (!pinch && drag.active){
      drag.active = false;
      $status.textContent = "XR • Left pinch-drag move | Right pinch teleport";
    }
    if (drag.active){
      const dx = (tmp.x - drag.startHand.x) * MOVE_GAIN;
      const dz = (tmp.z - drag.startHand.z) * MOVE_GAIN;
      stage.position.x = drag.startStage.x - dx;
      stage.position.z = drag.startStage.z - dz;
    }
  }
}

function updateTeleport(){
  const right = hands[1];
  if (!right?.joints) return;
  const pinch = isPinching(right);
  const indexTip = right.joints["index-finger-tip"];
  if (!indexTip) return;
  indexTip.getWorldPosition(tmp);
  ray.set(tmp, down);
  const hits = ray.intersectObject(floor, false);
  if (pinch && hits && hits[0]) showTeleportAt(hits[0].point);
  if (right.userData._wasPinching === undefined) right.userData._wasPinching = false;
  if (right.userData._wasPinching && !pinch){
    if (hits && hits[0]){
      const target = hits[0].point.clone();
      const xrCam = renderer.xr.getCamera(camera);
      const head = new THREE.Vector3();
      xrCam.getWorldPosition(head);
      const dx = target.x - head.x;
      const dz = target.z - head.z;
      stage.position.x -= dx;
      stage.position.z -= dz;
      showTeleportAt(target);
      setTimeout(()=>hideTeleport(), 350);
    } else hideTeleport();
  }
  right.userData._wasPinching = pinch;
}

$status.textContent = "Loading Scorpion room…";
$mode.textContent = "Hands: waiting…";
await loadLogo();

renderer.xr.addEventListener("sessionstart", ()=>{
  $status.textContent = "XR • Left pinch-drag move | Right pinch teleport";
  $mode.textContent = "Hands: ON";
  stage.position.set(0, 0, 3.5);
});
renderer.xr.addEventListener("sessionend", ()=>{
  $status.textContent = "XR ended";
  hideTeleport();
});

const clock = new THREE.Clock();
renderer.setAnimationLoop(()=>{
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = clock.elapsedTime;
  sigilRing.material.emissiveIntensity = 0.88 + Math.sin(t * 0.8) * 0.14;
  sign.position.y = 4.6 + Math.sin(t * 0.6) * 0.05;
  for (let i = 0; i < ambientSprites.length; i++){
    const s = ambientSprites[i];
    s.sprite.position.y += dt * s.speed;
    if (s.sprite.position.y > 4.8) s.sprite.position.y = 0.1;
  }
  updateMovement();
  updateTeleport();
  renderer.render(scene, camera);
});

window.addEventListener("resize", ()=>{
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
