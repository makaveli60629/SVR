Movement Sandbox

Open /game/sandbox/ in your browser.
Left-hand pinch + drag to move.
Right-hand pinch release = snap turn.
