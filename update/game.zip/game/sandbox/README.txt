Scorpion room compatibility alias. Primary route: /game/scorpion/
