
import { initScene } from './modules/scene.js'
import { initPlayer } from './modules/player.js'
import { initTeleport } from './modules/teleport.js'
import { initEnvironment } from './modules/environment.js'
import { initNPC } from './modules/npc.js'
import { initTable } from './modules/table.js'
import { initDiagnostics } from './modules/diagnostics.js'

console.log("SVR Poker Engine Boot")

initDiagnostics()
initScene()
initEnvironment()
initPlayer()
initTeleport()
initNPC()
initTable()
