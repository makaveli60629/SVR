import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createXRInput } from "./modules/xr_input.js";
import { createPlayerRig } from "./modules/player_rig.js";
import { buildWorld } from "./modules/world.js";
import { createWatch } from "./modules/watch.js";
import { createTeleportSystem } from "./modules/teleport.js";
import { createInteractionSystem } from "./modules/interaction.js";
import { createPokerDemo } from "./modules/poker_demo.js";
import { CONFIG } from "./modules/config.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $handState = document.getElementById("handState");
const $log = document.getElementById("log");
const QUERY = new URLSearchParams(window.location.search);
const PREVIEW_ONLY = QUERY.get("preview") === "1";
const SHOW_SPECTATOR = PREVIEW_ONLY;
const CAM_MODE = QUERY.get("cam") || (PREVIEW_ONLY ? "broadcast" : "orbit");
if (PREVIEW_ONLY) document.body.classList.add("preview-only");

function log(...args) {
  const line = args.map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" ");
  $log.textContent += `${line}
`;
  $log.scrollTop = $log.scrollHeight;
  console.log(...args);
}

const { scene, camera, renderer, spectatorCamera, spectatorRenderer } = createCore({ containerId: "app", spectatorCanvasId: "spectatorCanvas", enableSpectator: SHOW_SPECTATOR });
const desktop = createDesktopControls({ camera, domElement: renderer.domElement });
const xrInput = createXRInput({ scene, renderer, log });
$status.textContent = PREVIEW_ONLY ? "CAM 3 preview booting…" : "Building phase 52 real lobby…";
const world = await buildWorld(scene, { log });
desktop.setRoomClamp(world.roomClamp);
const playerRig = createPlayerRig({ renderer, camera, desktopControls: desktop, roomClamp: world.roomClamp, log });
playerRig.resetToSpawn();
const watch = createWatch({ scene, camera, renderer });
const teleport = createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp: world.roomClamp });
const interaction = createInteractionSystem({ scene, camera, renderer, playerRig, seats: world.seats, watch, teleport, tableProps: world.tableProps, log });
const poker = createPokerDemo({ scene, chairRings: world.chairRings, statusCb: (text) => { if ($handState) $handState.textContent = text; }, log });
watch.setState({ teleportEnabled: false, seated: false, mode: "DESKTOP" });

renderer.xr.addEventListener("sessionstart", async () => {
  await playerRig.onSessionStart();
  playerRig.resetToSpawn();
  watch.setState({ mode: "XR" });
  $mode.textContent = "Mode: XR";
  $status.textContent = PREVIEW_ONLY ? "CAM 3 preview live" : "XR ready • watch + poker demo live";
});
renderer.xr.addEventListener("sessionend", () => {
  teleport.setEnabled(false);
  interaction.releaseHeldProp();
  watch.setState({ teleportEnabled: false, mode: "DESKTOP" });
  playerRig.resetToSpawn();
  $mode.textContent = "Mode: desktop";
  $status.textContent = PREVIEW_ONLY ? "CAM 3 preview live" : "Desktop ready";
});

let spectatorAngle = 0;
let last = performance.now();

renderer.setAnimationLoop(() => {
  const now = performance.now();
  const dt = Math.min((now - last) / 1000, 0.05);
  last = now;

  const xrPresenting = renderer.xr.isPresenting;
  const xrState = xrInput.getState();

  if (!xrPresenting && !PREVIEW_ONLY) {
    desktop.update(dt);
    watch.setState({ mode: "DESKTOP" });
  } else if (!xrPresenting && PREVIEW_ONLY) {
    watch.setState({ mode: "DESKTOP" });
  } else {
    watch.setState({ mode: xrState.leftHand?.joints?.wrist ? "HAND" : "CTRL" });
  }

  const gp = xrState.rightController?.userData?.gamepad;
  if (xrPresenting && gp?.axes?.length >= 4) {
    const axisX = gp.axes[2] ?? gp.axes[0] ?? 0;
    if (Math.abs(axisX) > CONFIG.SNAP_DEADZONE && !xrState.rightController.userData.snapLatch) {
      xrState.rightController.userData.snapLatch = true;
      playerRig.snapTurn(THREE.MathUtils.degToRad(axisX > 0 ? -CONFIG.SNAP_TURN_DEG : CONFIG.SNAP_TURN_DEG));
    }
    if (Math.abs(axisX) < 0.2) xrState.rightController.userData.snapLatch = false;
  }

  interaction.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand });
  watch.updatePose({ leftHand: xrState.leftHand, leftController: xrState.leftController, rightController: xrState.rightController, xrPresenting });
  teleport.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand, statusCb: (t) => { $status.textContent = t; } });
  scene.userData._tickWorld?.(now * 0.001);
  poker.update(now * 0.001, dt);
  if (!playerRig.isSeated()) playerRig.ensureSafePosition();

  const seated = playerRig.isSeated();
  watch.setState({ seated, teleportEnabled: teleport.isEnabled() });
  if (!PREVIEW_ONLY) {
    $mode.textContent = xrPresenting ? `Mode: XR • ${teleport.isEnabled() ? "TP ON" : "TP OFF"}` : `Mode: desktop • ${seated ? "seated" : "standing"}`;
  }

  renderer.render(scene, camera);

  if (SHOW_SPECTATOR && spectatorCamera && spectatorRenderer) {
    spectatorAngle += dt * 0.12;
    if (CAM_MODE === "broadcast") {
      spectatorCamera.position.set(Math.sin(spectatorAngle * 0.55) * 1.6, CONFIG.SPECTATOR_HEIGHT - 0.8 + Math.sin(spectatorAngle * 0.35) * 0.05, CONFIG.SPECTATOR_RADIUS - 1.8);
      spectatorCamera.lookAt(world.tableCenter.x, 1.3, world.tableCenter.z - 0.1);
    } else {
      const specR = CONFIG.SPECTATOR_RADIUS;
      spectatorCamera.position.set(Math.cos(spectatorAngle) * specR, CONFIG.SPECTATOR_HEIGHT, Math.sin(spectatorAngle) * specR);
      spectatorCamera.lookAt(world.tableCenter.x, 1.2, world.tableCenter.z);
    }
    spectatorRenderer.render(scene, spectatorCamera);
  }
});

window.addEventListener("error", (e) => {
  log("RUNTIME ERROR", e?.error?.stack || e?.message || String(e));
  $status.textContent = "Runtime error • open Logs";
});
window.addEventListener("unhandledrejection", (e) => {
  log("PROMISE ERROR", e?.reason?.stack || e?.reason || String(e));
  $status.textContent = "Promise rejection • open Logs";
});

$status.textContent = PREVIEW_ONLY ? `CAM 3 preview live • ${CAM_MODE}` : "Phase 52 ready • real lobby stabilized";
if ($handState) $handState.textContent = "HAND 1 • shuffling real deck in locked lobby";
window.addEventListener("keydown", (e) => { if (e.code === "KeyN") poker.forceNextHand(); });
log("SVR Poker phase 52 ready", { build: CONFIG.BUILD, camMode: CAM_MODE, showSpectator: SHOW_SPECTATOR });
