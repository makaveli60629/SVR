import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createHands } from "./modules/hands.js";
import { createTeleportRig } from "./modules/teleport.js";
import { buildSkylineRoom } from "./modules/world_skyline.js";
import { assetUrls, loadFirstTexture } from "./modules/asset_base.js";
import { createWristWatch } from "./modules/watch.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $err = document.getElementById("err");
const $toggleLog = document.getElementById("toggleLog");
const $toggleJoints = document.getElementById("toggleJoints");

function log(...args){
  const line = args.map(a => typeof a === "string" ? a : JSON.stringify(a, null, 2)).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}

$toggleLog.addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

const { scene, camera, renderer } = createCore({ containerId: "app" });
camera.position.set(0, 1.6, 4.2);
camera.lookAt(0, 1.15, 0);

window.addEventListener("error", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});

const desktop = createDesktopControls({ camera, domElement: renderer.domElement });
$status.textContent = "Loading world…";
const { roomClamp } = await buildSkylineRoom(scene, { log });

const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
const watch = createWristWatch({ scene, renderer, log });

$toggleJoints.addEventListener("click", ()=>{
  const on = hands.toggleDebug();
  $toggleJoints.textContent = on ? "Joints On" : "Joints";
});

$status.textContent = "Loading logo…";
const logoTexture = await loadFirstTexture(assetUrls("ui/logo.png", "logo.png"), { colorSpace: THREE.SRGBColorSpace });
tp.setLogoTexture(logoTexture);

$status.textContent = "Ready. Enter VR.";
$mode.textContent = "Hands: waiting…";

function setHudVisible(visible){
  const hud = document.getElementById("hud");
  if (hud) hud.style.display = visible ? "flex" : "none";
  $log.style.display = "none";
  $err.style.display = "none";
}

renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});

renderer.xr.addEventListener("sessionend", ()=>{
  setHudVisible(true);
});

let tPrev = performance.now();
renderer.setAnimationLoop(()=>{
  const now = performance.now();
  const dt = Math.min((now - tPrev) / 1000, 0.033);
  tPrev = now;

  if (!renderer.xr.isPresenting) desktop.update(dt);
  if (scene.userData._tickWorld) scene.userData._tickWorld(dt);

  const left = hands.getLeft();
  const right = hands.getRight();

  hands.updateDebug();
  watch.update(dt, left, right);
  tp.update({
    leftHand: left,
    rightHand: right,
    statusCb: (text)=>{ $status.textContent = text; },
    modeCb: (text)=>{ $mode.textContent = text; }
  });

  renderer.render(scene, camera);
});

const canvasEl = renderer.domElement;
canvasEl.addEventListener("webglcontextlost", (e)=>{
  e.preventDefault();
  log("[ERR] WebGL context lost. Reloading…");
  $status.textContent = "WebGL context lost (reloading…)";
  setTimeout(()=>location.reload(), 500);
}, false);
