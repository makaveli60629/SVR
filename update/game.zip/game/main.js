import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { VRButton } from "three/addons/webxr/VRButton.js";
import { XRControllerModelFactory } from "three/addons/webxr/XRControllerModelFactory.js";
import { XRHandModelFactory } from "three/addons/webxr/XRHandModelFactory.js";

const app = document.getElementById('app');
const statusEl = document.getElementById('status');
const modeEl = document.getElementById('mode');
const errorEl = document.getElementById('error');
const teleportBtn = document.getElementById('teleportBtn');
const radioBtn = document.getElementById('radioBtn');
const seatBtn = document.getElementById('seatBtn');
const watchTime = document.getElementById('watchTime');
const crosshair = document.getElementById('crosshair');
const seatHint = document.getElementById('seatHint');
const vrHelp = document.getElementById('vrHelp');
const mobileTeleportBtn = document.getElementById('mobileTeleportBtn');
const mobileSeatBtn = document.getElementById('mobileSeatBtn');
const embedMode = new URLSearchParams(window.location.search).get('embed') === '1';
if (embedMode) document.body.classList.add('embed-mode');
const isAndroid = /Android/i.test(navigator.userAgent || '');
const isTouchDevice = matchMedia('(pointer:coarse)').matches || 'ontouchstart' in window || navigator.maxTouchPoints > 0;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x03030a);
scene.fog = new THREE.FogExp2(0x05050d, 0.0135);

const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.05, 320);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.domElement && (renderer.domElement.style.touchAction = 'none');
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.36;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor');
app.appendChild(renderer.domElement);
renderer.domElement.style.touchAction = 'none';
const vrButton = VRButton.createButton(renderer, {
  optionalFeatures: ['local-floor', 'bounded-floor', 'hand-tracking'],
  requiredFeatures: []
});
document.body.appendChild(vrButton);
if (embedMode) vrButton.style.display = 'none';
renderer.xr.addEventListener('sessionstart', () => { updateWorldOffsetForMode(); placePlayerAtTableSpawn(); ensureSpawnAwayFromTable(true); updateCamera(); enforceSpawnUntil = performance.now() + 6000; });
renderer.xr.addEventListener('sessionend', () => { updateWorldOffsetForMode(); updateCamera(); });

const world = new THREE.Group();
scene.add(world);

const playerRig = new THREE.Group();
scene.add(playerRig);
playerRig.add(camera);
camera.position.set(0, 1.62, 0);

const player = {
  pos: new THREE.Vector3(0, 0, 14.0),
  yaw: Math.PI,
  pitch: -0.05,
  speed: 4.6,
  lookSpeed: 0.00235,
  eyeHeight: 1.62,
  teleportMode: false
};
const roomRadius = 28;
const safeRadius = roomRadius - 2.5;
const xrSpawnDistance = 0;
let xrWorldShiftZ = 0;
const keys = new Set();
const velocity = new THREE.Vector3();
const forward = new THREE.Vector3();
const right = new THREE.Vector3();
const up = new THREE.Vector3(0, 1, 0);
let pointerLocked = false;
let floorMesh;
let wallLightBand;
let neonRing;

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const texLoader = new THREE.TextureLoader();
function loadTexture(path, onLoad) {
  const tex = texLoader.load(path, onLoad, undefined, () => {});
  return tex;
}
let audioCtx = null;
let radioNodes = null;

const tableAnchor = new THREE.Group();
world.add(tableAnchor);

const controllerFactory = new XRControllerModelFactory();
const handModelFactory = new XRHandModelFactory();
const controllers = [];
const controllerGrips = [];
const xrHands = [];
const controllerFists = [];
const controllerGlowMeshes = [];
const xrRaycaster = new THREE.Raycaster();
const xrTempMatrix = new THREE.Matrix4();
const handGestureState = [
  { toggleLatch: false, pinchLatch: false, ray: null },
  { toggleLatch: false, pinchLatch: false, ray: null }
];
let activeTeleportHand = 1;
function buildWatchAccessory(scale = 1) {
  const g = new THREE.Group();
  const strap = new THREE.Mesh(
    new THREE.BoxGeometry(0.07 * scale, 0.012 * scale, 0.11 * scale),
    new THREE.MeshStandardMaterial({ color: 0x251836, roughness: 0.48, metalness: 0.14, emissive: 0x140a23, emissiveIntensity: 0.18 })
  );
  const face = new THREE.Mesh(
    new THREE.BoxGeometry(0.05 * scale, 0.014 * scale, 0.06 * scale),
    new THREE.MeshStandardMaterial({ color: 0x73e6ff, roughness: 0.24, metalness: 0.62, emissive: 0x54d7ff, emissiveIntensity: 0.8 })
  );
  face.position.y = 0.008 * scale;
  g.add(strap, face);
  return g;
}
for (let i = 0; i < 2; i++) {
  const side = i === 0 ? -1 : 1;
  const controller = renderer.xr.getController(i);
  controller.userData.index = i;
  const ray = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, -10)]),
    new THREE.LineBasicMaterial({ color: 0x7fe9ff, transparent: true, opacity: 0.92 })
  );
  ray.name = 'ray';
  ray.visible = false;
  controller.add(ray);

  const fist = new THREE.Group();
  const fistPalm = new THREE.Mesh(
    new THREE.SphereGeometry(0.045, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0xe8dcff, roughness: 0.68, metalness: 0.08, emissive: 0x120d1d, emissiveIntensity: 0.12 })
  );
  fistPalm.scale.set(1.08, 0.82, 1.25);
  const fistKnuckles = new THREE.Mesh(
    new THREE.BoxGeometry(0.072, 0.028, 0.045),
    new THREE.MeshStandardMaterial({ color: 0xf4ebff, roughness: 0.62, metalness: 0.05 })
  );
  fistKnuckles.position.set(0, 0.016, 0.03);
  const fistGlow = new THREE.Mesh(
    new THREE.SphereGeometry(0.09, 16, 16),
    new THREE.MeshBasicMaterial({ color: side < 0 ? 0x61e3ff : 0xc768ff, transparent: true, opacity: 0.0 })
  );
  fistPalm.visible = false;
  fistKnuckles.visible = false;
  fist.add(fistGlow, fistPalm, fistKnuckles);
  fist.position.set(side * 0.018, -0.02, -0.04);
  fist.rotation.set(-0.8, side * 0.18, 0);
  controller.add(fist);
  fist.visible = false;
  controllerGlowMeshes.push(fistGlow);
  controllerFists.push(fist);

  controller.visible = false;
  controller.addEventListener('connected', () => { controller.visible = true; });
  controller.addEventListener('disconnected', () => {
    controller.visible = false;
    ray.visible = false;
    fist.visible = false;
    fistGlow.material.opacity = 0;
  });
  scene.add(controller);
  controllers.push(controller);

  const grip = renderer.xr.getControllerGrip(i);
  grip.visible = false;
  grip.add(controllerFactory.createControllerModel(grip));
  grip.addEventListener('connected', () => { grip.visible = true; });
  grip.addEventListener('disconnected', () => { grip.visible = false; });
  scene.add(grip);
  controllerGrips.push(grip);

  const hand = renderer.xr.getHand(i);
  hand.visible = false;
  hand.addEventListener('connected', () => { hand.visible = true; });
  hand.addEventListener('disconnected', () => {
    hand.visible = false;
    handGlow.material.opacity = 0;
    handRay.visible = false;
  });
  let handModel = null;
  try {
    handModel = handModelFactory.createHandModel(hand, 'mesh');
  } catch (err) {
    try {
      handModel = handModelFactory.createHandModel(hand, 'spheres');
    } catch (innerErr) {
      console.warn('Hand model fallback', innerErr);
    }
  }
  if (handModel) hand.add(handModel);
  const handGlow = new THREE.Mesh(
    new THREE.SphereGeometry(0.075, 16, 16),
    new THREE.MeshBasicMaterial({ color: side < 0 ? 0x61e3ff : 0xc768ff, transparent: true, opacity: 0.0 })
  );
  handGlow.position.set(0, 0, 0);
  hand.add(handGlow);
  hand.userData.glow = handGlow;
  if (i === 0) {
    const xrWatch = buildWatchAccessory(0.74);
    xrWatch.position.set(-0.032, 0.018, 0.016);
    xrWatch.rotation.set(0.28, 0.04, 1.36);
    hand.add(xrWatch);
  }
  const handRay = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, -8)]),
    new THREE.LineBasicMaterial({ color: i === 0 ? 0x61e3ff : 0xc768ff, transparent: true, opacity: 0.95 })
  );
  handRay.visible = false;
  hand.add(handRay);
  hand.userData.ray = handRay;
  handGestureState[i].ray = handRay;
  scene.add(hand);
  xrHands.push(hand);
}

const seatTarget = new THREE.Group();
const seatPad = new THREE.Mesh(
  new THREE.CylinderGeometry(0.34, 0.34, 0.02, 48),
  new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.68, metalness: 0.08, transparent: true, opacity: 0.9 })
);
seatPad.position.y = 0.03;
seatTarget.add(seatPad);
const seatRing = new THREE.Mesh(
  new THREE.TorusGeometry(0.42, 0.028, 12, 96),
  new THREE.MeshStandardMaterial({ color: 0xc56eff, roughness: 0.22, metalness: 0.34, emissive: 0x6d2ce0, emissiveIntensity: 0.9 })
);
seatRing.rotation.x = Math.PI / 2;
seatRing.position.y = 0.045;
seatTarget.add(seatRing);
seatTarget.visible = true;
tableAnchor.add(seatTarget);

let seated = false;
let seatFacing = Math.PI;
const moveVec = new THREE.Vector2();
const lookVec = new THREE.Vector2();
let xrTurnCooldown = 0;
const animatedCards = [];
let tableTopY = 0.96;
let tableRadius = 1.72;
const tableModelGroup = new THREE.Group();
tableAnchor.add(tableModelGroup);
let teleportFlash = 0;
let enforceSpawnUntil = performance.now() + 4000;
let ericActor = null;
let dealerActor = null;
let dealerStoolActor = null;
let cardsActor = null;

const handRig = new THREE.Group();
camera.add(handRig);
const handMaterial = new THREE.MeshStandardMaterial({ color: 0xe8d6ff, roughness: 0.72, metalness: 0.08, emissive: 0x1b1129, emissiveIntensity: 0.14 });
const gloveMaterial = new THREE.MeshStandardMaterial({ color: 0x28163c, roughness: 0.54, metalness: 0.12, emissive: 0x391561, emissiveIntensity: 0.24 });
const watchMaterial = new THREE.MeshStandardMaterial({ color: 0x67e2ff, roughness: 0.28, metalness: 0.52, emissive: 0x4ad1ff, emissiveIntensity: 0.6 });
function buildHand(side = 1) {
  const g = new THREE.Group();
  const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.2, 6, 12), gloveMaterial);
  forearm.rotation.z = Math.PI / 2;
  forearm.position.set(0, 0, 0);
  const palm = new THREE.Mesh(new THREE.SphereGeometry(0.08, 16, 16), handMaterial);
  palm.scale.set(1.15, 0.72, 1.35);
  palm.position.set(side * 0.17, -0.06, -0.09);
  const thumb = new THREE.Mesh(new THREE.CapsuleGeometry(0.022, 0.06, 4, 8), handMaterial);
  thumb.position.set(side * 0.245, -0.05, -0.045);
  thumb.rotation.z = side * 0.9;
  thumb.rotation.x = -0.3;
  const watch = new THREE.Group();
  const strap = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.01, 0.11), gloveMaterial);
  const face = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.012, 0.066), watchMaterial);
  face.position.y = 0.008;
  watch.add(strap, face);
  watch.position.set(side * 0.05, 0.03, 0.01);
  watch.rotation.x = 0.6;
  g.add(forearm, palm, thumb);
  if (side < 0) g.add(watch);
  g.position.set(side * 0.18, -0.18, -0.18);
  g.rotation.set(-0.34, side * 0.22, side * 0.06);
  return g;
}
const leftHand = buildHand(-1);
const rightHand = buildHand(1);
const leftGlow = new THREE.Mesh(new THREE.SphereGeometry(0.11, 20, 20), new THREE.MeshBasicMaterial({ color: 0x61e3ff, transparent: true, opacity: 0 }));
leftGlow.position.set(-0.17, -0.05, -0.06);
leftHand.add(leftGlow);
const rightGlow = new THREE.Mesh(new THREE.SphereGeometry(0.11, 20, 20), new THREE.MeshBasicMaterial({ color: 0xc768ff, transparent: true, opacity: 0 }));
rightGlow.position.set(0.17, -0.05, -0.06);
rightHand.add(rightGlow);
handRig.userData.leftGlow = leftGlow;
handRig.userData.rightGlow = rightGlow;
handRig.add(leftHand, rightHand);
handRig.visible = false;
handRig.position.set(0, -100, -100);

function showError(message) {
  errorEl.textContent = message;
  errorEl.classList.remove('hidden');
}
window.addEventListener('error', (event) => showError(event?.error?.stack || event.message || 'Runtime error'));
window.addEventListener('unhandledrejection', (event) => showError(String(event.reason || 'Promise rejection')));

function updateCamera() {
  playerRig.position.set(player.pos.x, 0, player.pos.z);
  playerRig.rotation.set(0, renderer.xr.isPresenting ? player.yaw : 0, 0);
  camera.rotation.order = 'YXZ';
  camera.position.set(0, renderer.xr.isPresenting ? 0 : player.eyeHeight, 0);
  if (!renderer.xr.isPresenting) {
    camera.rotation.y = player.yaw;
    camera.rotation.x = player.pitch;
  } else {
    camera.rotation.set(0, 0, 0);
  }
}
function clampInsideRoom(vec) {
  const len = Math.hypot(vec.x, vec.z);
  if (len > safeRadius) {
    const scale = safeRadius / len;
    vec.x *= scale;
    vec.z *= scale;
  }
  vec.y = 0;
}
function getSeatPlayerPosition() {
  const dir = seatTarget.position.clone().setY(0).normalize();
  return new THREE.Vector3(
    seatTarget.position.x - dir.x * 0.02,
    0,
    seatTarget.position.z - dir.z * 0.02
  );
}
function updateSeatTarget() {
  const radius = tableRadius + 0.74;
  seatTarget.position.set(0, 0, radius);
  seatFacing = Math.atan2(-seatTarget.position.x, -seatTarget.position.z);
}
function placePlayerAtTableSpawn() {
  const spawnDistance = 10.0;
  player.pos.set(0, 0, spawnDistance);
  player.eyeHeight = 1.62;
  player.yaw = Math.PI;
  player.pitch = -0.045;
  clampInsideRoom(player.pos);
  updateCamera();
}
function ensureSpawnAwayFromTable(force = false) {
  const minDistance = tableRadius + 10.0;
  const dist = Math.hypot(player.pos.x, player.pos.z);
  if (force || dist < minDistance) {
    placePlayerAtTableSpawn();
  }
}
function updateWorldOffsetForMode() {
  xrWorldShiftZ = 0;
  world.position.set(0, 0, 0);
}

function getHandJoint(hand, name) {
  return hand?.joints?.[name] || hand?.getObjectByName?.(name) || null;
}
function getJointWorldPosition(hand, name, target = new THREE.Vector3()) {
  const joint = getHandJoint(hand, name);
  if (!joint) return null;
  return joint.getWorldPosition(target);
}
function hasTrackedHands() {
  return xrHands.some((hand) => !!getHandJoint(hand, 'wrist'));
}
function handFistAmount(hand) {
  const wrist = getJointWorldPosition(hand, 'wrist', new THREE.Vector3());
  if (!wrist) return 0;
  const tips = ['index-finger-tip', 'middle-finger-tip', 'ring-finger-tip', 'pinky-finger-tip'];
  let score = 0;
  for (const tipName of tips) {
    const tip = getJointWorldPosition(hand, tipName, new THREE.Vector3());
    if (!tip) continue;
    const dist = wrist.distanceTo(tip);
    score += THREE.MathUtils.clamp(1 - (dist - 0.045) / 0.055, 0, 1);
  }
  return score / tips.length;
}
function handPinchAmount(hand) {
  const thumb = getJointWorldPosition(hand, 'thumb-tip', new THREE.Vector3());
  const index = getJointWorldPosition(hand, 'index-finger-tip', new THREE.Vector3());
  if (!thumb || !index) return 0;
  const dist = thumb.distanceTo(index);
  return THREE.MathUtils.clamp(1 - (dist - 0.018) / 0.03, 0, 1);
}
function handNearFace(hand) {
  const wrist = getJointWorldPosition(hand, 'wrist', new THREE.Vector3());
  if (!wrist) return false;
  const head = camera.getWorldPosition(new THREE.Vector3());
  return wrist.distanceTo(head) < 0.56;
}
function pickFloorFromHand(hand) {
  const wrist = getHandJoint(hand, 'wrist');
  if (!wrist) return null;
  xrTempMatrix.identity().extractRotation(wrist.matrixWorld);
  xrRaycaster.ray.origin.setFromMatrixPosition(wrist.matrixWorld);
  xrRaycaster.ray.direction.set(0, -0.18, -1).normalize().applyMatrix4(xrTempMatrix);
  const hit = xrRaycaster.intersectObject(floorMesh, false)[0];
  return hit?.point || null;
}
function updateHandTeleportGestures() {
  if (!renderer.xr.isPresenting) return;
  const tracked = hasTrackedHands();
  xrHands.forEach((hand, idx) => {
    const state = handGestureState[idx];
    const glow = hand.userData.glow;
    const ray = state.ray;
    const fist = handFistAmount(hand);
    const pinch = handPinchAmount(hand);
    const nearFace = handNearFace(hand);

    if (nearFace && fist > 0.48 && !state.toggleLatch) {
      activeTeleportHand = idx;
      setTeleportMode(!player.teleportMode);
      teleportFlash = 1;
      state.toggleLatch = true;
    } else if (fist < 0.18) {
      state.toggleLatch = false;
    }

    if (glow) {
      glow.material.opacity = player.teleportMode ? Math.min(1.0, 0.72 + fist * 0.24 + teleportFlash * 0.34) : 0;
    }
    if (ray) ray.visible = false;

    if (player.teleportMode && idx === activeTeleportHand) {
      const point = pickFloorFromHand(hand);
      if (point) {
        placeTeleportMarker(point);
        if (ray) {
          ray.visible = true;
          const wristPos = getJointWorldPosition(hand, 'wrist', new THREE.Vector3()) || hand.getWorldPosition(new THREE.Vector3());
          const dist = wristPos.distanceTo(point);
          ray.scale.z = Math.max(0.2, dist / 8);
        }
        if (pinch > 0.48 && !state.pinchLatch) {
          performTeleport(point);
          teleportFlash = 1;
          state.pinchLatch = true;
        } else if (pinch < 0.12) {
          state.pinchLatch = false;
        }
      }
    } else {
      state.pinchLatch = false;
    }
  });
  controllerFists.forEach((fist) => {
    fist.visible = false;
  });
}

function canSeat() {
  const seatPos = getSeatPlayerPosition();
  const dx = player.pos.x - seatPos.x;
  const dz = player.pos.z - seatPos.z;
  return Math.hypot(dx, dz) < 3.0;
}
function updateSeatHint() {
  const visible = !renderer.xr.isPresenting && !seated && canSeat();
  seatHint.classList.toggle('hidden', !visible);
}
function toggleSeat(force = null) {
  const next = force == null ? !seated : force;
  if (next && !canSeat()) return;
  seated = next;
  if (seated) {
    const seatPos = getSeatPlayerPosition();
    player.pos.copy(seatPos);
    player.eyeHeight = 0.98;
    player.yaw = seatFacing;
    player.pitch = -0.025;
    pointerLocked = false;
    document.exitPointerLock?.();
    seatBtn.classList.add('active');
    seatBtn.textContent = 'Seat: Seated';
  } else {
    player.eyeHeight = 1.62;
    const dir = seatTarget.position.clone().setY(0).normalize();
    player.pos.addScaledVector(dir, 0.92);
    clampInsideRoom(player.pos);
    seatBtn.classList.remove('active');
    seatBtn.textContent = 'Seat: Ready';
  }
  updateCamera();
  updateSeatHint();
}
updateSeatTarget();
placePlayerAtTableSpawn();


function makeEarthTexture() {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 512;
  const ctx = c.getContext('2d');
  const ocean = ctx.createLinearGradient(0, 0, 0, c.height);
  ocean.addColorStop(0, '#74d7ff');
  ocean.addColorStop(0.45, '#1f73d1');
  ocean.addColorStop(1, '#0b2b66');
  ctx.fillStyle = ocean;
  ctx.fillRect(0, 0, c.width, c.height);
  const landColors = ['#5ce08b', '#2cb765', '#7ae08d', '#4acb6d'];
  for (let i = 0; i < 18; i++) {
    ctx.save();
    ctx.translate(Math.random() * c.width, Math.random() * c.height);
    ctx.rotate((Math.random() - 0.5) * 2.4);
    ctx.fillStyle = landColors[i % landColors.length];
    ctx.beginPath();
    const w = 50 + Math.random() * 130;
    const h = 26 + Math.random() * 72;
    ctx.ellipse(0, 0, w, h, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  for (let i = 0; i < 1200; i++) {
    ctx.fillStyle = `rgba(255,255,255,${0.015 + Math.random() * 0.05})`;
    ctx.beginPath();
    ctx.arc(Math.random() * c.width, Math.random() * c.height, 1 + Math.random() * 5, 0, Math.PI * 2);
    ctx.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// lights
scene.add(new THREE.HemisphereLight(0xf4f7ff, 0x090913, 3.0));
const keyLight = new THREE.PointLight(0xffffff, 4.0, 170, 2.0);
keyLight.position.set(0, 13.5, 0);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(1024, 1024);
scene.add(keyLight);
const magenta = new THREE.PointLight(0xc66bff, 3.2, 64, 2.0);
magenta.position.set(-7, 5.5, 5);
scene.add(magenta);
const cyan = new THREE.PointLight(0x61e3ff, 3.5, 86, 2.0);
cyan.position.set(7, 6.4, -4);
scene.add(cyan);
const moonFill = new THREE.DirectionalLight(0xdbe5ff, 3.9);
moonFill.position.set(-18, 24, -36);
scene.add(moonFill);
const tablePink = new THREE.PointLight(0xff77f1, 2.2, 26, 2.0);
tablePink.position.set(-3.2, 4.4, 2.2);
scene.add(tablePink);
const tableBlue = new THREE.PointLight(0x73dfff, 2.0, 28, 2.0);
tableBlue.position.set(3.6, 4.2, -2.4);
scene.add(tableBlue);
const skylineWash = new THREE.HemisphereLight(0xaebdff, 0x090911, 0.9);
scene.add(skylineWash);
const skylineGlow = new THREE.PointLight(0x88b8ff, 4.1, 260, 2.0);
skylineGlow.position.set(0, 9, -24);
scene.add(skylineGlow);
const rimLight = new THREE.DirectionalLight(0xcfe0ff, 1.8);
rimLight.position.set(10, 16, 8);
scene.add(rimLight);
const ceilingGlow = new THREE.PointLight(0xa76cff, 4.6, 180, 2.0);
ceilingGlow.position.set(0, 17, 0);
scene.add(ceilingGlow);
const loungeFillA = new THREE.PointLight(0xff87eb, 3.8, 84, 2.0);
loungeFillA.position.set(-10, 3.8, 10);
scene.add(loungeFillA);
const loungeFillB = new THREE.PointLight(0x7ddfff, 4.0, 84, 2.0);
loungeFillB.position.set(10, 3.8, 10);
scene.add(loungeFillB);

// ground and room shell
floorMesh = new THREE.Mesh(
  new THREE.CircleGeometry(roomRadius + 18, 192),
  new THREE.MeshStandardMaterial({ color: 0x05050a, roughness: 0.94, metalness: 0.04 })
);
floorMesh.rotation.x = -Math.PI / 2;
floorMesh.receiveShadow = true;
world.add(floorMesh);

const wallTexture = (() => {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 1024;
  const ctx = c.getContext('2d');
  const g = ctx.createLinearGradient(0, 0, 0, c.height);
  g.addColorStop(0, '#0f1021');
  g.addColorStop(0.5, '#090913');
  g.addColorStop(1, '#040409');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, c.width, c.height);
  for (let y = 0; y < c.height; y += 64) {
    ctx.fillStyle = y % 128 === 0 ? 'rgba(110,225,255,0.05)' : 'rgba(198,107,255,0.05)';
    ctx.fillRect(0, y, c.width, 3);
  }
  for (let x = 0; x < c.width; x += 32) {
    ctx.fillStyle = 'rgba(255,255,255,0.022)';
    ctx.fillRect(x, 0, 2, c.height);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(14, 1);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
})();
const wall = new THREE.Mesh(
  new THREE.CylinderGeometry(roomRadius, roomRadius, 4.8, 160, 1, true),
  new THREE.MeshStandardMaterial({
    color: 0x0a0a12,
    map: wallTexture,
    roughness: 0.82,
    metalness: 0.08,
    emissive: 0x130922,
    emissiveIntensity: 0.22,
    side: THREE.BackSide
  })
);
wall.position.y = 2.4;
world.add(wall);

wallLightBand = new THREE.Mesh(
  new THREE.TorusGeometry(roomRadius - 0.55, 0.16, 14, 220),
  new THREE.MeshStandardMaterial({ color: 0xc873ff, roughness: 0.22, metalness: 0.3, emissive: 0x6b31d7, emissiveIntensity: 0.8 })
);
wallLightBand.rotation.x = Math.PI / 2;
wallLightBand.position.y = 4.3;
world.add(wallLightBand);

const logoWall = new THREE.Mesh(
  new THREE.PlaneGeometry(6.8, 3.4),
  new THREE.MeshBasicMaterial({ map: texLoader.load('./assets/logo.webp'), transparent: true, opacity: 0.52, depthWrite: false, side: THREE.DoubleSide })
);
logoWall.position.set(0, 3.2, -roomRadius + 0.8);
world.add(logoWall);

neonRing = new THREE.Mesh(
  new THREE.RingGeometry(roomRadius - 6.4, roomRadius - 5.9, 128),
  new THREE.MeshBasicMaterial({ color: 0x411369, transparent: true, opacity: 0.22, side: THREE.DoubleSide })
);
neonRing.rotation.x = -Math.PI / 2;
neonRing.position.y = 0.01;
world.add(neonRing);

// moon + world + store
const moonTexture = loadTexture('./assets/texture/moon_real_diffuse.png', (tex) => { tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1; });
moonTexture.colorSpace = THREE.SRGBColorSpace;
const moonBump = loadTexture('./assets/texture/moon_real_bump.png');
const moonPrimitive = new THREE.Mesh(
  new THREE.SphereGeometry(4.8, 64, 64),
  new THREE.MeshStandardMaterial({
    map: moonTexture,
    bumpMap: moonBump,
    bumpScale: 0.16,
    color: 0xffffff,
    emissive: 0x1d2238,
    emissiveIntensity: 0.08,
    roughness: 0.98,
    metalness: 0.0
  })
);
moonPrimitive.position.set(-18, 15.5, -56);
world.add(moonPrimitive);
const moonGlow = new THREE.PointLight(0xd9e6ff, 5.2, 240, 1.7);
moonGlow.position.copy(moonPrimitive.position);
scene.add(moonGlow);
const earthBaseTexture = makeEarthTexture();
const earthNightTexture = loadTexture('./assets/textures/earth_night_lights_modified.png', (tex) => { tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1; });
const earth = new THREE.Mesh(
  new THREE.SphereGeometry(3.2, 48, 48),
  new THREE.MeshStandardMaterial({
    map: earthBaseTexture,
    emissiveMap: earthNightTexture,
    emissive: 0x7fb7ff,
    emissiveIntensity: 1.25,
    roughness: 0.88,
    metalness: 0.0
  })
);
earth.position.set(21, 17.5, -68);
world.add(earth);
let moon = moonPrimitive;
let storePivot = null;

function buildStoreWallKiosk() {
  if (storePivot) world.remove(storePivot);
  storePivot = new THREE.Group();
  const panel = new THREE.Mesh(
    new THREE.BoxGeometry(3.2, 2.1, 0.22),
    new THREE.MeshStandardMaterial({ color: 0x111320, roughness: 0.42, metalness: 0.22, emissive: 0x160b29, emissiveIntensity: 0.36 })
  );
  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(2.6, 1.45),
    new THREE.MeshBasicMaterial({ map: texLoader.load('./assets/logo.webp'), transparent: true, opacity: 0.95 })
  );
  screen.position.z = 0.121;
  const frame = new THREE.Mesh(
    new THREE.TorusGeometry(1.48, 0.05, 10, 64),
    new THREE.MeshStandardMaterial({ color: 0xc772ff, emissive: 0x6c25d6, emissiveIntensity: 0.86, roughness: 0.18, metalness: 0.44 })
  );
  frame.scale.set(1.0, 0.68, 1.0);
  frame.position.z = 0.13;
  const shelf = new THREE.Mesh(
    new THREE.BoxGeometry(2.1, 0.08, 0.34),
    new THREE.MeshStandardMaterial({ color: 0x1f2231, roughness: 0.55, metalness: 0.16 })
  );
  shelf.position.set(0, -1.18, 0.12);
  storePivot.add(panel, screen, frame, shelf);
  storePivot.position.set(roomRadius - 0.34, 3.15, 0.0);
  storePivot.rotation.y = -Math.PI / 2;
  storePivot.lookAt(new THREE.Vector3(0, 2.0, 0));
  world.add(storePivot);
}

(function loadOptionalStoreModel() {
  const gltfLoader = new GLTFLoader();
  gltfLoader.load('./assets/models/store.glb', (storeGltf) => {
    const storeModel = storeGltf.scene || storeGltf.scenes?.[0];
    if (!storeModel) {
      buildStoreWallKiosk();
      return;
    }
    storeModel.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      if (child.material) child.material = child.material.clone();
    });
    const box = new THREE.Box3().setFromObject(storeModel);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);
    const scale = 2.8 / Math.max(size.x, size.y, size.z, 0.001);
    storeModel.scale.setScalar(scale);
    storeModel.updateMatrixWorld(true);
    const scaled = new THREE.Box3().setFromObject(storeModel);
    const scaledCenter = new THREE.Vector3();
    scaled.getCenter(scaledCenter);
    storeModel.position.set(-scaledCenter.x, -scaledCenter.y, -scaledCenter.z + 0.05);
    storePivot = new THREE.Group();
    storePivot.add(storeModel);
    storePivot.position.set(roomRadius - 0.38, 3.1, -0.8);
    storePivot.rotation.y = -Math.PI / 2;
    storePivot.lookAt(new THREE.Vector3(0, 2.1, 0));
    world.add(storePivot);
  }, undefined, () => buildStoreWallKiosk());
})();

(function addStars() {
  const positions = [];
  for (let i = 0; i < 1900; i++) {
    const radius = 74 + Math.random() * 48;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.45;
    const x = Math.cos(theta) * Math.cos(phi) * radius;
    const y = 10 + Math.sin(phi) * radius * 0.28 + Math.random() * 16;
    const z = Math.sin(theta) * Math.cos(phi) * radius;
    positions.push(x, y, z);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  const m = new THREE.PointsMaterial({ color: 0xd9ebff, size: 0.18, transparent: true, opacity: 0.88, depthWrite: false });
  world.add(new THREE.Points(g, m));
})();

// skyline
(function buildSkyline() {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x0b0c14, roughness: 0.84, metalness: 0.12, emissive: 0x1a1030, emissiveIntensity: 0.34 });
  const winMat = new THREE.MeshStandardMaterial({ color: 0xc2ecff, emissive: 0x8fd2ff, emissiveIntensity: 0.84, roughness: 0.22, metalness: 0.34 });
  const redMat = new THREE.MeshStandardMaterial({ color: 0xff6e89, emissive: 0xff294d, emissiveIntensity: 1.2, roughness: 0.3, metalness: 0.18 });
  const count = 170;
  let aviationLights = 0;
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2;
    const radius = roomRadius + 6 + Math.random() * 8;
    const w = 1 + Math.random() * 2.5;
    const h = 4 + Math.random() * 18;
    const d = 1 + Math.random() * 2.5;
    const x = Math.sin(a) * radius;
    const z = Math.cos(a) * radius;
    const building = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), bodyMat);
    building.position.set(x, h * 0.5, z);
    building.rotation.y = -a + Math.PI / 2;
    building.castShadow = false;
    building.receiveShadow = true;
    group.add(building);

    if (h > 10 && Math.random() > 0.45) {
      const crown = new THREE.Mesh(new THREE.BoxGeometry(w * 1.08, 0.12, d * 1.08), new THREE.MeshStandardMaterial({ color: 0x9de8ff, emissive: 0x63d7ff, emissiveIntensity: 1.0, roughness: 0.16, metalness: 0.42 }));
      crown.position.set(x, h + 0.08, z);
      crown.rotation.y = building.rotation.y;
      group.add(crown);
      if (Math.random() > 0.6) {
        const fin = new THREE.Mesh(new THREE.BoxGeometry(0.12, Math.max(0.9, h * 0.12), 0.12), new THREE.MeshStandardMaterial({ color: 0xc786ff, emissive: 0x7d3bff, emissiveIntensity: 0.92, roughness: 0.2, metalness: 0.34 }));
        fin.position.set(x, h + Math.max(0.5, h * 0.06), z);
        group.add(fin);
      }
    }

    const stripCount = 1 + Math.floor(Math.random() * 4);
    for (let s = 0; s < stripCount; s++) {
      const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.12, d * 1.04), winMat);
      strip.position.set(x, 1.3 + (s + 1) * (h / (stripCount + 1)), z);
      strip.rotation.y = building.rotation.y;
      group.add(strip);
    }

    if (h > 18 && aviationLights < 5 && Math.random() > 0.62) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.4, 10), new THREE.MeshStandardMaterial({ color: 0x394053, roughness: 0.7 }));
      pole.position.set(x, h + 0.7, z);
      group.add(pole);
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 16), redMat.clone());
      bulb.position.set(x, h + 1.45, z);
      bulb.userData.blink = Math.random() * Math.PI * 2;
      group.add(bulb);
      aviationLights += 1;
    }
  }
  world.add(group);
  world.userData.skylineGroup = group;
})();

// atmosphere sprites - smaller and more spread out
const spriteGroup = new THREE.Group();
world.add(spriteGroup);
const spriteTexture = (() => {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.18, 'rgba(97,227,255,0.75)');
  g.addColorStop(0.45, 'rgba(190,99,255,0.25)');
  g.addColorStop(1, 'rgba(190,99,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
})();
for (let i = 0; i < 260; i++) {
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: spriteTexture, color: 0xffffff, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false }));
  const radius = 1.1 + Math.random() * 12.4;
  const angle = Math.random() * Math.PI * 2;
  sprite.position.set(Math.cos(angle) * radius, 0.14 + Math.random() * 9.6, Math.sin(angle) * radius);
  const scale = 0.09 + Math.random() * 0.20;
  sprite.scale.setScalar(scale);
  sprite.userData.speed = 0.32 + Math.random() * 0.8;
  sprite.userData.phase = Math.random() * Math.PI * 2;
  sprite.userData.radius = radius;
  spriteGroup.add(sprite);
}

// table placeholder until real asset loads
const placeholderGroup = new THREE.Group();
placeholderGroup.visible = false;
tableAnchor.add(placeholderGroup);
const placeholderEdge = new THREE.Mesh(
  new THREE.CylinderGeometry(2.2, 2.2, 0.34, 64),
  new THREE.MeshStandardMaterial({ color: 0x181528, roughness: 0.28, metalness: 0.32, emissive: 0x180f28, emissiveIntensity: 0.28 })
);
placeholderEdge.position.y = 0.96;
placeholderEdge.castShadow = true;
placeholderGroup.add(placeholderEdge);
const placeholderStem = new THREE.Mesh(
  new THREE.CylinderGeometry(0.35, 0.42, 1.08, 22),
  new THREE.MeshStandardMaterial({ color: 0x120f1e, roughness: 0.54, metalness: 0.16 })
);
placeholderStem.position.y = 0.44;
placeholderStem.castShadow = true;
placeholderGroup.add(placeholderStem);

const topDecor = new THREE.Group();
const chairGroup = new THREE.Group();
const tableGameplayGroup = new THREE.Group();
tableAnchor.add(topDecor);
tableAnchor.add(chairGroup);
tableAnchor.add(tableGameplayGroup);

function clearTopDecor() {
  while (topDecor.children.length) topDecor.remove(topDecor.children[0]);
}

function clearTableGameplay() {
  while (tableGameplayGroup.children.length) tableGameplayGroup.remove(tableGameplayGroup.children[0]);
}

function addChipStack(x, z, count, color = 0xffffff) {
  const group = new THREE.Group();
  const chipTex = loadTexture('./assets/textures/chip.png', (tex) => { tex.colorSpace = THREE.SRGBColorSpace; });
  const mat = new THREE.MeshStandardMaterial({ color, map: chipTex, roughness: 0.46, metalness: 0.12, emissive: color, emissiveIntensity: 0.06 });
  for (let i = 0; i < count; i++) {
    const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.026, 28), mat);
    chip.position.y = tableTopY + 0.014 + i * 0.023;
    chip.rotation.y = (i % 2) * 0.12;
    chip.castShadow = true;
    chip.receiveShadow = true;
    group.add(chip);
  }
  group.position.set(x, 0, z);
  tableGameplayGroup.add(group);
}

function addCard(x, z, ry = 0, tilt = 0) {
  const card = new THREE.Mesh(
    new THREE.BoxGeometry(0.22, 0.012, 0.32),
    new THREE.MeshStandardMaterial({ color: 0xffffff, map: loadTexture('./assets/textures/card.png', (tex) => { tex.colorSpace = THREE.SRGBColorSpace; }), roughness: 0.88, metalness: 0.02 })
  );
  card.position.set(x, tableTopY + 0.018, z);
  card.rotation.set(tilt, ry, 0);
  card.castShadow = true;
  card.receiveShadow = true;
  tableGameplayGroup.add(card);
}

function rebuildTableGameplay(topWidth = tableRadius * 2.1, topDepth = tableRadius * 1.35) {
  clearTableGameplay();
  const playerZ = topDepth * 0.24;
  addChipStack(-0.54, playerZ + 0.02, 6, 0x66e2ff);
  addChipStack(-0.22, playerZ + 0.00, 4, 0xffffff);
  addChipStack(0.12, playerZ + 0.02, 7, 0xc768ff);
  addCard(-0.16, playerZ - 0.08, Math.PI * 0.05, -0.04);
  addCard(0.10, playerZ - 0.10, -Math.PI * 0.04, 0.03);
}

function makeFeltTexture() {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 1024;
  const ctx = c.getContext('2d');
  const grad = ctx.createRadialGradient(512, 512, 120, 512, 512, 620);
  grad.addColorStop(0, '#1d7269');
  grad.addColorStop(0.45, '#0d4f49');
  grad.addColorStop(1, '#072d2b');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, c.width, c.height);
  for (let i = 0; i < 14000; i++) {
    const x = Math.random() * c.width;
    const y = Math.random() * c.height;
    const a = 0.025 + Math.random() * 0.04;
    ctx.fillStyle = `rgba(255,255,255,${a})`;
    ctx.fillRect(x, y, 1, 1);
  }
  ctx.strokeStyle = 'rgba(214,248,255,0.1)';
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.ellipse(512, 512, 340, 220, 0, 0, Math.PI * 2);
  ctx.stroke();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1;
  return tex;
}

function buildTopDecor() {
  clearTopDecor();
  animatedCards.length = 0;
  if (!placeholderGroup.visible) return;

  const feltTexture = makeFeltTexture();
  const felt = new THREE.Mesh(
    new THREE.PlaneGeometry(tableRadius * 1.7, tableRadius * 1.12),
    new THREE.MeshStandardMaterial({ map: feltTexture, roughness: 0.92, metalness: 0.02, emissive: 0x091c18, emissiveIntensity: 0.08 })
  );
  felt.rotation.x = -Math.PI / 2;
  felt.position.y = tableTopY + 0.004;
  topDecor.add(felt);
}

function rebuildSeating() {
  chairGroup.clear();
  const logoTex = texLoader.load('./assets/logo.webp');
  logoTex.colorSpace = THREE.SRGBColorSpace;
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const group = new THREE.Group();
    const isPlayerSeat = i === 0;
    const baseMat = new THREE.MeshStandardMaterial({ color: isPlayerSeat ? 0x35204f : 0x2a1d42, roughness: 0.58, metalness: 0.08, emissive: isPlayerSeat ? 0x1d0e31 : 0x130a24, emissiveIntensity: 0.2 });
    const accentMat = new THREE.MeshStandardMaterial({ color: isPlayerSeat ? 0xc56eff : 0x7c4bca, roughness: 0.26, metalness: 0.34, emissive: isPlayerSeat ? 0x7a2ae0 : 0x3f176e, emissiveIntensity: 0.58 });
    const metalMat = new THREE.MeshStandardMaterial({ color: 0x12121b, roughness: 0.35, metalness: 0.65 });
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.14, 0.72), baseMat);
    seat.position.y = 0.5;
    const cushion = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.08, 0.62), new THREE.MeshStandardMaterial({ color: isPlayerSeat ? 0x5f348f : 0x442768, roughness: 0.92, metalness: 0.03, emissive: isPlayerSeat ? 0x241138 : 0x180f2b, emissiveIntensity: 0.18 }));
    cushion.position.set(0, 0.63, 0);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.72, 0.1), baseMat);
    back.position.set(0, 0.94, -0.27);
    const backGlow = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.08, 0.03), accentMat);
    backGlow.position.set(0, 1.03, -0.2);
    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.26, 0.48), baseMat);
    armL.position.set(-0.31, 0.72, -0.01);
    const armR = armL.clone();
    armR.position.x *= -1;
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.56, 12), metalMat);
    leg.position.y = 0.25;
    const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.24, 0.05, 16), metalMat);
    foot.position.y = -0.05;
    const trimRing = new THREE.Mesh(new THREE.TorusGeometry(0.29, 0.018, 8, 48), accentMat);
    trimRing.rotation.x = Math.PI / 2;
    trimRing.position.set(0, 0.61, 0);
    const stitchA = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.012, 0.012), accentMat);
    stitchA.position.set(0, 0.67, -0.16);
    const stitchB = stitchA.clone();
    stitchB.position.z = 0.18;
    group.add(seat, cushion, back, backGlow, armL, armR, leg, foot, trimRing, stitchA, stitchB);

    if (isPlayerSeat) {
      const logo = new THREE.Mesh(
        new THREE.PlaneGeometry(0.48, 0.48),
        new THREE.MeshBasicMaterial({ map: logoTex, transparent: true, depthWrite: false })
      );
      logo.position.set(0, 0.69, 0.15);
      logo.rotation.x = -Math.PI / 2;
      group.add(logo);
    }

    group.scale.setScalar(0.66);
    const radius = tableRadius + 0.70;
    group.position.set(Math.sin(angle) * radius, 0, Math.cos(angle) * radius);
    group.rotation.y = angle + Math.PI;
    chairGroup.add(group);
  }
  updateSeatTarget();
}
rebuildSeating();

function positionActors() {
  if (ericActor) {
    const box = new THREE.Box3().setFromObject(ericActor);
    const center = new THREE.Vector3();
    box.getCenter(center);
    const ericAngle = Math.PI * 0.38;
    const ericRadius = tableRadius + 3.1;
    ericActor.position.set(Math.sin(ericAngle) * ericRadius - center.x * 0.02, -box.min.y, Math.cos(ericAngle) * ericRadius - center.z * 0.02);
    ericActor.rotation.y = ericAngle + Math.PI;
  }
  if (cardsActor) {
    const box = new THREE.Box3().setFromObject(cardsActor);
    const center = new THREE.Vector3();
    box.getCenter(center);
    cardsActor.position.set(-center.x, tableTopY + 0.03 - box.min.y, -0.12 - center.z);
    cardsActor.rotation.y = Math.PI * 0.08;
  }
}

function computeVisibleBounds(object) {
  const bounds = new THREE.Box3();
  let hasBounds = false;
  object.updateMatrixWorld(true);
  object.traverse((child) => {
    if (!child.isMesh || !child.visible || !child.geometry) return;
    if (!child.geometry.boundingBox) child.geometry.computeBoundingBox();
    const childBox = child.geometry.boundingBox.clone().applyMatrix4(child.matrixWorld);
    if (!hasBounds) {
      bounds.copy(childBox);
      hasBounds = true;
    } else {
      bounds.union(childBox);
    }
  });
  return hasBounds ? bounds : new THREE.Box3(new THREE.Vector3(), new THREE.Vector3());
}

function buildStableTable() {
  placeholderGroup.visible = true;
  const feltTex = loadTexture('./assets/texture/tablefelt.png', (tex) => {
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1;
  });
  const railTex = loadTexture('./assets/texture/leather_dark.jpg');
  const railBump = loadTexture('./assets/texture/leather_dark_bump.jpg');
  const clothBump = loadTexture('./assets/texture/cloth_bump.jpg');
  const logoTex = loadTexture('./assets/logo.webp', (tex) => { tex.colorSpace = THREE.SRGBColorSpace; });

  tableModelGroup.clear();
  topDecor.clear();
  clearTableGameplay();

  tableRadius = 2.7;
  tableTopY = 1.0;

  placeholderEdge.geometry.dispose?.();
  placeholderEdge.geometry = new THREE.CylinderGeometry(2.7, 2.9, 0.28, 80);
  placeholderEdge.position.y = 0.88;
  placeholderEdge.material = new THREE.MeshStandardMaterial({ map: railTex, bumpMap: railBump, bumpScale: 0.05, color: 0x1c1719, roughness: 0.62, metalness: 0.08, emissive: 0x120d11, emissiveIntensity: 0.06 });

  placeholderStem.geometry.dispose?.();
  placeholderStem.geometry = new THREE.CylinderGeometry(0.34, 0.54, 0.92, 22);
  placeholderStem.position.y = 0.38;
  placeholderStem.material = new THREE.MeshStandardMaterial({ color: 0x17141d, roughness: 0.58, metalness: 0.14 });

  const baseFoot = new THREE.Mesh(
    new THREE.CylinderGeometry(1.08, 1.14, 0.08, 42),
    new THREE.MeshStandardMaterial({ color: 0x0f1017, roughness: 0.62, metalness: 0.16 })
  );
  baseFoot.position.y = 0.04;
  tableModelGroup.add(baseFoot);

  const felt = new THREE.Mesh(
    new THREE.CircleGeometry(1.0, 96),
    new THREE.MeshStandardMaterial({ map: feltTex, bumpMap: clothBump, bumpScale: 0.024, color: 0xffffff, roughness: 0.94, metalness: 0.02, emissive: 0x071411, emissiveIntensity: 0.08 })
  );
  felt.rotation.x = -Math.PI / 2;
  felt.scale.set(2.18, 1.45, 1.0);
  felt.position.y = tableTopY;
  felt.castShadow = true;
  felt.receiveShadow = true;

  const rail = new THREE.Mesh(
    new THREE.TorusGeometry(1.0, 0.085, 16, 128),
    new THREE.MeshStandardMaterial({ map: railTex, bumpMap: railBump, bumpScale: 0.045, color: 0x241919, roughness: 0.54, metalness: 0.08 })
  );
  rail.rotation.x = Math.PI / 2;
  rail.scale.set(2.16, 1.44, 1.0);
  rail.position.y = tableTopY + 0.03;
  rail.castShadow = true;
  rail.receiveShadow = true;

  const logoDecal = new THREE.Mesh(
    new THREE.CircleGeometry(0.42, 64),
    new THREE.MeshBasicMaterial({ map: logoTex, transparent: true, opacity: 0.28, depthWrite: false })
  );
  logoDecal.rotation.x = -Math.PI / 2;
  logoDecal.position.y = tableTopY + 0.002;

  topDecor.add(felt, rail, logoDecal);
  rebuildSeating();
  rebuildTableGameplay(4.35, 2.9);
  placePlayerAtTableSpawn();
  positionActors();
  statusEl.textContent = 'Room loaded. Stable textured table, corrected moon/world textures, and player-rig hands are active.';
}

function loadTableModel() {
  buildStableTable();
}
loadTableModel();

function buildFallbackEric() {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x7d72ff, roughness: 0.58, emissive: 0x2d1b52, emissiveIntensity: 0.35 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.9, 6, 12), mat);
  body.position.y = 1.02;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 24, 24), new THREE.MeshStandardMaterial({ color: 0xd8c2aa, roughness: 0.8 }));
  head.position.y = 1.76;
  group.add(body, head);
  group.position.set(-0.1, 0, -3.55);
  group.rotation.y = Math.PI;
  tableAnchor.add(group);
  ericActor = group;
  positionActors();
}

(async function loadEric() {
  try {
    const loader = new FBXLoader();
    const obj = await loader.loadAsync('./assets/eric.fbx');
    const diffuse = await new Promise((resolve) => texLoader.load('./assets/eric-diffuse-small.webp', resolve, undefined, () => resolve(null)));
    if (diffuse) diffuse.colorSpace = THREE.SRGBColorSpace;
    obj.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      child.material = new THREE.MeshStandardMaterial({
        map: diffuse || null,
        color: diffuse ? 0xffffff : 0x7d72ff,
        roughness: 0.72,
        metalness: 0.03,
        emissive: 0x140d21,
        emissiveIntensity: 0.08
      });
    });
    const box = new THREE.Box3().setFromObject(obj);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);
    const targetHeight = 1.92;
    const scale = targetHeight / Math.max(size.y, 0.001);
    obj.scale.setScalar(scale);
    obj.updateMatrixWorld(true);
    const scaledBox = new THREE.Box3().setFromObject(obj);
    const scaledCenter = new THREE.Vector3();
    scaledBox.getCenter(scaledCenter);
    obj.position.set(2.05 - scaledCenter.x, -scaledBox.min.y, -1.86);
    obj.rotation.y = Math.PI * 0.82;
    tableAnchor.add(obj);
    ericActor = obj;
    positionActors();
  } catch (error) {
    console.warn('Eric fallback', error);
    buildFallbackEric();
  }
})();

(async function loadDealerAndCards() {
  return;
  const loader = new FBXLoader();
  try {
    const [dealer, stool, cards] = await Promise.all([
      loader.loadAsync('./assets/claudia.fbx'),
      loader.loadAsync('./assets/dealer-stool.fbx').catch(() => null),
      loader.loadAsync('./assets/cards.fbx').catch(() => null)
    ]);
    const tex = await new Promise((resolve) => texLoader.load('./assets/claudia-diffuse-better.webp', resolve, undefined, () => texLoader.load('./assets/claudia-diffuse.jpg', resolve, undefined, () => texLoader.load('./assets/claudia-diffuse.webp', resolve, undefined, () => resolve(null)))));
    if (tex) tex.colorSpace = THREE.SRGBColorSpace;

    dealer.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      child.material = new THREE.MeshStandardMaterial({
        map: tex || null,
        color: tex ? 0xffffff : 0xf5d8ff,
        roughness: 0.74,
        metalness: 0.04,
        emissive: 0x140b1f,
        emissiveIntensity: 0.05
      });
    });
    const dealerBox = new THREE.Box3().setFromObject(dealer);
    const dealerSize = new THREE.Vector3();
    const dealerCenter = new THREE.Vector3();
    dealerBox.getSize(dealerSize);
    dealerBox.getCenter(dealerCenter);
    const dealerScale = 2.08 / Math.max(dealerSize.y, 0.001);
    dealer.scale.setScalar(dealerScale);
    dealer.updateMatrixWorld(true);
    const dealerScaled = new THREE.Box3().setFromObject(dealer);
    dealerScaled.getCenter(dealerCenter);
    dealer.position.set(-dealerCenter.x, -dealerScaled.min.y + 0.02, -tableRadius - 2.25);
    dealer.rotation.y = 0;
    tableAnchor.add(dealer);
    dealerActor = dealer;
    positionActors();

    if (stool) {
      stool.traverse((child) => {
        if (!child.isMesh) return;
        child.castShadow = true;
        child.receiveShadow = true;
        child.material = new THREE.MeshStandardMaterial({ color: 0x261a38, roughness: 0.62, metalness: 0.06 });
      });
      const stoolBox = new THREE.Box3().setFromObject(stool);
      const stoolSize = new THREE.Vector3();
      const stoolCenter = new THREE.Vector3();
      stoolBox.getSize(stoolSize);
      stoolBox.getCenter(stoolCenter);
      const stoolScale = 0.86 / Math.max(stoolSize.x, stoolSize.z, 0.001);
      stool.scale.setScalar(stoolScale);
      stool.updateMatrixWorld(true);
      const stoolScaled = new THREE.Box3().setFromObject(stool);
      stoolScaled.getCenter(stoolCenter);
      stool.position.set(-stoolCenter.x, -stoolScaled.min.y, -tableRadius - 2.0);
      stool.rotation.y = Math.PI;
      tableAnchor.add(stool);
      dealerStoolActor = stool;
      positionActors();
    }

    if (cards && false) {
      cards.traverse((child) => {
        if (!child.isMesh) return;
        child.castShadow = true;
        child.receiveShadow = true;
        child.material = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.88, metalness: 0.04 });
      });
      const cardsBox = new THREE.Box3().setFromObject(cards);
      const cardsSize = new THREE.Vector3();
      const cardsCenter = new THREE.Vector3();
      cardsBox.getSize(cardsSize);
      cardsBox.getCenter(cardsCenter);
      const cardsScale = 0.55 / Math.max(cardsSize.x, cardsSize.z, cardsSize.y, 0.001);
      cards.scale.setScalar(cardsScale);
      cards.updateMatrixWorld(true);
      const scaled = new THREE.Box3().setFromObject(cards);
      scaled.getCenter(cardsCenter);
      cards.position.set(-cardsCenter.x, tableTopY + 0.045 - scaled.min.y, -cardsCenter.z);
      cards.rotation.y = Math.PI * 0.08;
      cards.userData.floatCards = false;
      topDecor.add(cards);
      cardsActor = cards;
      positionActors();
    }
  } catch (error) {
    console.warn('Dealer/cards fallback', error);
  }
})();

// radio prop
const radio = new THREE.Group();
const radioBody = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.38, 0.28), new THREE.MeshStandardMaterial({ color: 0x171422, roughness: 0.55 }));
const radioScreen = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 0.03), new THREE.MeshStandardMaterial({ color: 0x59d7ff, emissive: 0x59d7ff, emissiveIntensity: 0.6 }));
radioScreen.position.set(0, 0.05, 0.145);
const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.5, 8), new THREE.MeshStandardMaterial({ color: 0xa8b8ff, roughness: 0.2 }));
antenna.position.set(0.26, 0.38, 0.02);
radio.add(radioBody, radioScreen, antenna);
radio.position.set(-6.2, 0.22, 6.1);
world.add(radio);

// teleport marker
const tpGroup = new THREE.Group();
const tpRing = new THREE.Mesh(new THREE.RingGeometry(0.32, 0.5, 48), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x5a28c8, emissiveIntensity: 1.0, side: THREE.DoubleSide }));
tpRing.rotation.x = -Math.PI / 2;
const tpDisc = new THREE.Mesh(new THREE.CircleGeometry(0.28, 40), new THREE.MeshBasicMaterial({ map: texLoader.load('./assets/logo.webp'), transparent: true, opacity: 0.92 }));
tpDisc.rotation.x = -Math.PI / 2;
tpDisc.position.y = 0.002;
tpGroup.add(tpRing, tpDisc);
tpGroup.visible = false;
world.add(tpGroup);

function setTeleportMode(next) {
  player.teleportMode = next;
  teleportBtn.classList.toggle('active', next);
  teleportBtn.textContent = `Teleport: ${next ? 'On' : 'Off'}`;
  if (mobileTeleportBtn) {
    mobileTeleportBtn.classList.toggle('active', next);
    mobileTeleportBtn.textContent = next ? 'TP On' : 'TP Off';
  }
  if (!next) tpGroup.visible = false;
  modeEl.textContent = next
    ? 'Teleport enabled. In VR with hand tracking, make a fist near your face to toggle and pinch to jump to the glowing logo marker.'
    : 'Desktop: WASD / arrows move • click to lock for mouse look • T teleport • F sit • Mobile: dual sticks • VR: Enter VR button';
}

function placeTeleportMarker(point) {
  const target = point.clone();
  target.y = 0.012;
  tpGroup.position.copy(target);
  tpGroup.visible = true;
}
function performTeleport(target) {
  seated = false;
  seatBtn.classList.remove('active');
  seatBtn.textContent = 'Seat: Ready';
  const desired = new THREE.Vector3(target.x, 0, target.z);
  clampInsideRoom(desired);
  player.pos.copy(desired);
  updateCamera();
  updateSeatHint();
}

teleportBtn.addEventListener('click', () => {
  setTeleportMode(!player.teleportMode);
});
window.addEventListener('keydown', (event) => {
  keys.add(event.code);
  if (event.code === 'KeyT') setTeleportMode(!player.teleportMode);
  if (event.code === 'KeyF') toggleSeat();
});
window.addEventListener('keyup', (event) => keys.delete(event.code));
seatBtn.addEventListener('click', () => toggleSeat());
mobileSeatBtn?.addEventListener('click', () => toggleSeat());
mobileTeleportBtn?.addEventListener('click', () => setTeleportMode(!player.teleportMode));
for (const controller of controllers) {
  controller.addEventListener('selectstart', () => {
    if (canSeat()) {
      toggleSeat();
      return;
    }
    if (!player.teleportMode) return;
    const point = pickFloorFromXRController(controller);
    if (point) {
      placeTeleportMarker(point);
      performTeleport(point);
      teleportFlash = 1;
    }
  });
}

renderer.domElement.addEventListener('click', () => {
  if (!pointerLocked && matchMedia('(hover:hover)').matches && !player.teleportMode) renderer.domElement.requestPointerLock?.();
});
document.addEventListener('pointerlockchange', () => {
  pointerLocked = document.pointerLockElement === renderer.domElement;
  crosshair.classList.toggle('active', pointerLocked && !matchMedia('(hover:none)').matches);
});
document.addEventListener('mousemove', (event) => {
  if (!pointerLocked) return;
  player.yaw -= event.movementX * player.lookSpeed;
  player.pitch -= event.movementY * player.lookSpeed;
  player.pitch = THREE.MathUtils.clamp(player.pitch, -1.05, 1.05);
});

function pickFloor(clientX, clientY) {
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const hit = raycaster.intersectObject(floorMesh, false)[0];
  return hit?.point || null;
}
function pickFloorFromXRController(controller) {
  xrTempMatrix.identity().extractRotation(controller.matrixWorld);
  xrRaycaster.ray.origin.setFromMatrixPosition(controller.matrixWorld);
  xrRaycaster.ray.direction.set(0, 0, -1).applyMatrix4(xrTempMatrix);
  const hit = xrRaycaster.intersectObject(floorMesh, false)[0];
  return hit?.point || null;
}
renderer.domElement.addEventListener('pointerdown', (event) => {
  if (!player.teleportMode) {
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const hitSeat = raycaster.intersectObject(seatPad, false)[0];
    if (hitSeat && canSeat()) toggleSeat();
    return;
  }
  const point = pickFloor(event.clientX, event.clientY);
  if (!point) return;
  placeTeleportMarker(point);
  performTeleport(point);
  teleportFlash = 1;
});

// mobile joysticks + external gamepad support
const stickState = {
  move: { active: false, id: null, origin: new THREE.Vector2(), delta: new THREE.Vector2() },
  look: { active: false, id: null, origin: new THREE.Vector2(), delta: new THREE.Vector2() }
};
const moveZone = document.getElementById('moveZone');
const lookZone = document.getElementById('lookZone');
const moveKnob = document.getElementById('moveKnob');
const lookKnob = document.getElementById('lookKnob');

function setupStick(zone, knob, state) {
  const reset = () => {
    state.active = false;
    state.id = null;
    state.delta.set(0, 0);
    knob.style.transform = 'translate(0px, 0px)';
  };
  zone.addEventListener('pointerdown', (event) => {
    state.active = true;
    state.id = event.pointerId;
    state.origin.set(event.clientX, event.clientY);
    zone.setPointerCapture(event.pointerId);
  });
  zone.addEventListener('pointermove', (event) => {
    if (!state.active || event.pointerId !== state.id) return;
    const dx = event.clientX - state.origin.x;
    const dy = event.clientY - state.origin.y;
    const limit = 40;
    const len = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(limit, len);
    state.delta.set((dx / len) * (clamped / limit), (dy / len) * (clamped / limit));
    knob.style.transform = `translate(${state.delta.x * limit}px, ${state.delta.y * limit}px)`;
  });
  const end = (event) => {
    if (event.pointerId !== state.id) return;
    reset();
  };
  zone.addEventListener('pointerup', end);
  zone.addEventListener('pointercancel', end);
}
setupStick(moveZone, moveKnob, stickState.move);
setupStick(lookZone, lookKnob, stickState.look);

const gamepadState = { teleportLatch: false, seatLatch: false };
function readStandardGamepad() {
  if (renderer.xr.isPresenting) return null;
  const pads = navigator.getGamepads ? Array.from(navigator.getGamepads()).filter(Boolean) : [];
  if (!pads.length) return null;
  const pad = pads.find((p) => (p.axes && p.axes.length >= 2) || (p.buttons && p.buttons.length));
  if (!pad) return null;
  return {
    moveX: pad.axes?.[0] || 0,
    moveY: pad.axes?.[1] || 0,
    lookX: pad.axes?.[2] || 0,
    lookY: pad.axes?.[3] || 0,
    teleportPressed: !!pad.buttons?.[0]?.pressed,
    seatPressed: !!pad.buttons?.[1]?.pressed
  };
}

function updateWatch() {
  const now = new Date();
  watchTime.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
setInterval(updateWatch, 1000);
updateWatch();

function toggleRadio() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();
  if (radioNodes) {
    radioNodes.gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.2);
    setTimeout(() => {
      radioNodes.osc1.stop();
      radioNodes.osc2.stop();
      radioNodes.filter.disconnect();
      radioNodes.gain.disconnect();
      radioNodes = null;
    }, 260);
    radioBtn.classList.remove('active');
    radioBtn.textContent = 'Radio: Off';
    return;
  }
  const osc1 = audioCtx.createOscillator();
  const osc2 = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const filter = audioCtx.createBiquadFilter();
  osc1.type = 'sawtooth';
  osc2.type = 'triangle';
  osc1.frequency.value = 164.81;
  osc2.frequency.value = 220;
  filter.type = 'lowpass';
  filter.frequency.value = 920;
  gain.gain.value = 0.0001;
  osc1.connect(filter); osc2.connect(filter); filter.connect(gain); gain.connect(audioCtx.destination);
  osc1.start(); osc2.start();
  gain.gain.exponentialRampToValueAtTime(0.032, audioCtx.currentTime + 0.4);
  radioNodes = { osc1, osc2, filter, gain };
  radioBtn.classList.add('active');
  radioBtn.textContent = 'Radio: On';
}
radioBtn.addEventListener('click', toggleRadio);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

const clock = new THREE.Clock();
function updateXRControllers(dt) {
  const session = renderer.xr.getSession();
  if (!session) return;
  xrTurnCooldown = Math.max(0, xrTurnCooldown - dt);

  let moveX = 0;
  let moveY = 0;
  let turnX = 0;
  for (const source of session.inputSources) {
    const axes = source.gamepad?.axes;
    if (!axes || axes.length < 2) continue;
    if (moveX === 0 && moveY === 0) {
      moveX = axes[2] ?? axes[0] ?? 0;
      moveY = axes[3] ?? axes[1] ?? 0;
    } else {
      turnX = axes[2] ?? axes[0] ?? 0;
    }
  }

  if (!seated) {
    const xrMoveForward = -moveY;
    const xrMoveStrafe = moveX;
    if (Math.abs(xrMoveForward) > 0.12 || Math.abs(xrMoveStrafe) > 0.12) {
      const dir = new THREE.Vector3();
      camera.getWorldDirection(dir);
      dir.y = 0;
      dir.normalize();
      const xrRight = new THREE.Vector3().crossVectors(dir, up).normalize();
      player.pos.addScaledVector(dir, xrMoveForward * player.speed * dt * 1.2);
      player.pos.addScaledVector(xrRight, xrMoveStrafe * player.speed * dt * 1.2);
      clampInsideRoom(player.pos);
      updateCamera();
    }
  }

  if (Math.abs(turnX) > 0.72 && xrTurnCooldown <= 0) {
    player.yaw -= Math.sign(turnX) * Math.PI / 8;
    xrTurnCooldown = 0.22;
    updateCamera();
  }
}

function animate() {
  const dt = Math.min(clock.getDelta(), 0.033);
  const t = performance.now();
  teleportFlash = Math.max(0, teleportFlash - dt * 1.6);
  updateWorldOffsetForMode();

  if (performance.now() < enforceSpawnUntil && !renderer.xr.isPresenting) {
    ensureSpawnAwayFromTable();
  }
  moon.rotation.y += dt * 0.01;
  earth.rotation.y += dt * 0.04;

  if (embedMode && !renderer.xr.isPresenting) {
    const orbitRadius = Math.max(6.6, tableRadius + 3.0);
    const orbitAngle = t * 0.00012 + Math.PI * 0.12;
    camera.position.set(Math.sin(orbitAngle) * orbitRadius, tableTopY + 1.75, Math.cos(orbitAngle) * orbitRadius);
    camera.lookAt(0, tableTopY + 0.35, 0);
  } else if (!renderer.xr.isPresenting) {
    controllers.forEach((controller) => { controller.visible = false; const ray = controller.getObjectByName('ray'); if (ray) ray.visible = false; });
    controllerGrips.forEach((grip) => { grip.visible = false; });
    xrHands.forEach((hand) => { hand.visible = false; const ray = hand.userData?.ray || handGestureState[xrHands.indexOf(hand)]?.ray; if (ray) ray.visible = false; });
    if (!seated) {
      forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
      right.copy(forward).cross(up).normalize();
      velocity.set(0, 0, 0);
      if (keys.has('KeyW') || keys.has('ArrowUp')) velocity.add(forward);
      if (keys.has('KeyS') || keys.has('ArrowDown')) velocity.addScaledVector(forward, -1);
      if (keys.has('KeyD') || keys.has('ArrowRight')) velocity.add(right);
      if (keys.has('KeyA') || keys.has('ArrowLeft')) velocity.addScaledVector(right, -1);
      if (velocity.lengthSq() > 0) velocity.normalize().multiplyScalar(player.speed * dt);
      player.pos.add(velocity);
    } else {
      velocity.set(0, 0, 0);
    }

    if (!seated && stickState.move.active) {
      forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
      right.copy(forward).cross(up).normalize();
      const moveForward = -stickState.move.delta.y;
      const moveStrafe = stickState.move.delta.x;
      player.pos.addScaledVector(forward, moveForward * player.speed * dt);
      player.pos.addScaledVector(right, moveStrafe * player.speed * dt);
    }
    if (!seated && stickState.look.active) {
      player.yaw -= stickState.look.delta.x * 1.75 * dt;
      player.pitch -= stickState.look.delta.y * 1.25 * dt;
      player.pitch = THREE.MathUtils.clamp(player.pitch, -1.0, 1.0);
    }

    const pad = readStandardGamepad();
    if (pad) {
      const dead = 0.16;
      const moveX = Math.abs(pad.moveX) > dead ? pad.moveX : 0;
      const moveY = Math.abs(pad.moveY) > dead ? pad.moveY : 0;
      const lookX = Math.abs(pad.lookX) > dead ? pad.lookX : 0;
      const lookY = Math.abs(pad.lookY) > dead ? pad.lookY : 0;
      if (!seated && (moveX || moveY)) {
        forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
        right.copy(forward).cross(up).normalize();
        player.pos.addScaledVector(forward, -moveY * player.speed * dt);
        player.pos.addScaledVector(right, moveX * player.speed * dt);
      }
      if (!seated && (lookX || lookY)) {
        player.yaw -= lookX * 2.2 * dt;
        player.pitch -= lookY * 1.6 * dt;
        player.pitch = THREE.MathUtils.clamp(player.pitch, -1.0, 1.0);
      }
      if (pad.teleportPressed && !gamepadState.teleportLatch) {
        setTeleportMode(!player.teleportMode);
        gamepadState.teleportLatch = true;
      } else if (!pad.teleportPressed) {
        gamepadState.teleportLatch = false;
      }
      if (pad.seatPressed && !gamepadState.seatLatch) {
        toggleSeat();
        gamepadState.seatLatch = true;
      } else if (!pad.seatPressed) {
        gamepadState.seatLatch = false;
      }
    }

    clampInsideRoom(player.pos);
    updateCamera();
  } else {
    updateXRControllers(dt);
    updateHandTeleportGestures();
    const trackedHands = hasTrackedHands();
    controllerGrips.forEach((grip) => { grip.visible = !trackedHands; });
    for (const controller of controllers) {
      const ray = controller.getObjectByName('ray');
      const fist = controllerFists[controller.userData.index];
      if (fist) fist.visible = false;
      if (!ray) continue;
      const point = player.teleportMode && !trackedHands ? pickFloorFromXRController(controller) : null;
      ray.visible = !!point;
      if (point) {
        placeTeleportMarker(point);
        const dist = controller.getWorldPosition(new THREE.Vector3()).distanceTo(point);
        ray.scale.z = Math.max(0.2, dist / 10);
      }
    }
  }

  if (world.userData.skylineGroup) {
    world.userData.skylineGroup.traverse((obj) => {
      if (obj.material?.emissive && obj.material.emissive.getHex() === 0xff294d) {
        obj.material.emissiveIntensity = 0.45 + (Math.sin(t * 0.008 + (obj.userData.blink || 0)) * 0.5 + 0.5) * 1.25;
      }
    });
  }

  wallLightBand.material.emissiveIntensity = 0.86 + Math.sin(t * 0.0017) * 0.18;
  neonRing.material.opacity = 0.18 + Math.sin(t * 0.0014) * 0.03;
  seatRing.material.emissiveIntensity = 0.85 + Math.sin(t * 0.004) * 0.18;
  seatPad.material.opacity = seated ? 0.28 : 0.9;

  const teleportGlow = (player.teleportMode ? 0.52 : 0) + teleportFlash * 0.42;
  const pulse = 0.58 + 0.42 * Math.sin(t * 0.008);
  tpRing.material.color.setHex(0xffffff);
  tpRing.material.emissive.setHex(0x6c2bff);
  tpRing.material.emissiveIntensity = 0.9 + pulse * 0.28 + teleportFlash * 0.8;
  if (handRig.userData.leftGlow) handRig.userData.leftGlow.material.opacity = teleportGlow * (0.78 + pulse * 0.22);
  if (handRig.userData.rightGlow) handRig.userData.rightGlow.material.opacity = teleportGlow * (0.78 + (1 - pulse) * 0.22);
  const trackedHandsNow = hasTrackedHands();
  xrHands.forEach((hand, handIndex) => {
    const tracked = false;
    hand.visible = false;
    const glow = hand.userData.glow;
    if (!tracked) {
      if (glow) glow.material.opacity = 0;
      const ray = handGestureState[handIndex]?.ray;
      if (ray) ray.visible = false;
    } else if (glow && !player.teleportMode) {
      glow.material.opacity = Math.max(0, glow.material.opacity - dt * 2.4);
    }
  });
  controllerGlowMeshes.forEach((glow) => {
    glow.material.opacity = 0;
  });
  controllerGrips.forEach((grip) => { grip.visible = false; });
  controllers.forEach((controller) => { controller.visible = false; const ray = controller.getObjectByName('ray'); if (ray) ray.visible = false; });

  handRig.visible = renderer.xr.isPresenting;
  handRig.position.set(0, 0, 0);
  if (handRig.visible) {
    leftHand.position.set(-0.16, -0.20, -0.30);
    rightHand.position.set(0.16, -0.20, -0.30);
    const idle = Math.sin(t * 0.0022) * 0.018;
    leftHand.position.y += idle;
    rightHand.position.y -= idle;
    leftHand.rotation.x = -0.34 + Math.sin(t * 0.0018) * 0.05;
    rightHand.rotation.x = -0.34 - Math.sin(t * 0.0021) * 0.05;
    const moving = velocity.lengthSq() > 0.000001 || stickState.move.active;
    if (moving) {
      const swing = Math.sin(t * 0.01) * 0.08;
      leftHand.rotation.z = -0.06 + swing;
      rightHand.rotation.z = 0.06 - swing;
    } else {
      leftHand.rotation.z = -0.06;
      rightHand.rotation.z = 0.06;
    }
  }

  for (const sprite of spriteGroup.children) {
    sprite.position.y += sprite.userData.speed * dt;
    sprite.position.x += Math.sin(t * 0.00035 + sprite.userData.phase) * 0.0032;
    sprite.position.z += Math.cos(t * 0.00028 + sprite.userData.phase) * 0.0032;
    if (sprite.position.y > 12.5) {
      const radius = 5 + Math.random() * 16;
      const angle = Math.random() * Math.PI * 2;
      sprite.position.y = 0.12 + Math.random() * 1.6;
      sprite.position.x = Math.cos(angle) * radius;
      sprite.position.z = Math.sin(angle) * radius;
    }
  }

  for (const card of animatedCards) {
    if (!card?.position) continue;
    const baseY = card.userData.baseY ?? card.position.y;
    card.position.y = baseY + Math.sin(t * 0.0016 + (card.userData.phase || 0)) * 0.005;
  }

  if (tpGroup.visible) {
    tpGroup.rotation.y += dt * 1.8;
  }

  updateSeatHint();
  renderer.render(scene, camera);
}

statusEl.textContent = embedMode
  ? 'Embedded live preview active.'
  : 'Room loaded. Stable table, realistic moon/earth textures, wall store, and player-rig hands are active.';
if (isAndroid) {
  modeEl.textContent = 'Android: left stick moves • right stick looks • TP button arms tap-to-teleport • Seat button snaps into the player chair • Bluetooth gamepad sticks also work.';
}
renderer.setAnimationLoop(animate);


renderer.xr.addEventListener('sessionstart', () => {
  enforceSpawnUntil = performance.now() + 5000;
  placePlayerAtTableSpawn();
  vrHelp.textContent = 'VR active. Fist near your face toggles teleport, pinch confirms, and the player-rig hands stay with you while the marker uses your logo.';
  crosshair.classList.remove('active');
  seatHint.classList.add('hidden');
  updateCamera();
});
renderer.xr.addEventListener('sessionend', () => {
  vrHelp.textContent = 'Use the Enter VR button. In VR, left stick moves, right stick turns, and trigger teleports or seats when close.';
  updateSeatHint();
});
