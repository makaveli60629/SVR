import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createHands } from "./modules/hands.js";
import { createTeleportRig } from "./modules/teleport.js";
import { buildSkylineRoom } from "./modules/world_skyline.js";
import { assetUrls, loadFirstTexture } from "./modules/asset_base.js";
import { createWristWatch } from "./modules/watch.js";
import { createAudioPlaylist } from "./modules/audio.js";

const params = new URLSearchParams(location.search);
const EMBED = params.get("embed") === "1";
const AUTOCAM = params.get("autocam") === "1";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $err = document.getElementById("err");
const $toggleLog = document.getElementById("toggleLog");
const $toggleJoints = document.getElementById("toggleJoints");

function log(...args){
  const line = args.map(a => typeof a === "string" ? a : JSON.stringify(a, null, 2)).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}

$toggleLog.addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

const { scene, camera, renderer } = createCore({ containerId: "app" });
camera.position.set(0, 1.6, 5.8);
camera.lookAt(0, 1.15, 0);

if (EMBED){
  document.getElementById("hud")?.remove();
  $log?.remove();
  $err?.remove();
  const hideVr = ()=>document.querySelectorAll('.svr-vr-button').forEach(el=>el.style.display='none');
  hideVr();
  setTimeout(hideVr, 100);
}

window.addEventListener("error", (e)=>{
  if (!renderer.xr.isPresenting && $err) $err.style.display = "block";
  if ($err) $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  if (!renderer.xr.isPresenting && $err) $err.style.display = "block";
  if ($err) $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});

const desktop = AUTOCAM ? null : createDesktopControls({ camera, domElement: renderer.domElement });
$status.textContent = "Loading world…";
const world = await buildSkylineRoom(scene, { log });
const { roomClamp, seats, tableCenter, joinRadius, previewOrbitRadius } = world;

const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });

const audio = createAudioPlaylist({
  tracks: [
    { title: "Midnight Felt", url: "./audio/midnight_felt.wav" },
    { title: "Orbit Lounge", url: "./audio/orbit_lounge.wav" }
  ]
});

let seated = false;
let seatIndex = -1;
let cash = 50000;

function currentHeadXZ(){
  if (renderer.xr.isPresenting){
    const xrCam = renderer.xr.getCamera(camera);
    const p = new THREE.Vector3();
    xrCam.getWorldPosition(p);
    return p;
  }
  return camera.position.clone();
}

function inTableZone(){
  const p = currentHeadXZ();
  return new THREE.Vector2(p.x - tableCenter.x, p.z - tableCenter.z).length() <= joinRadius;
}

function seatLabel(){
  return seatIndex >= 0 ? seats[seatIndex]?.label || `Seat ${seatIndex + 1}` : "Standing";
}

function moveDesktopToSeat(seat){
  camera.position.set(seat.x, 1.26, seat.z);
  camera.lookAt(0, 1.0, 0);
}

function joinTable(){
  if (!inTableZone()) return false;
  const p = currentHeadXZ();
  let best = 0;
  let bestDist = Infinity;
  seats.forEach((seat, idx)=>{
    if (seat.label === "Dealer Side") return;
    const d = Math.hypot(p.x - seat.x, p.z - seat.z);
    if (d < bestDist){ bestDist = d; best = idx; }
  });
  seatIndex = best;
  seated = true;
  const seat = seats[best];
  if (renderer.xr.isPresenting){
    tp.setPlayerXZ(seat.x, seat.z);
  } else {
    moveDesktopToSeat(seat);
  }
  return true;
}

function leaveTable(){
  seated = false;
  seatIndex = -1;
  if (renderer.xr.isPresenting){
    tp.setPlayerXZ(0, 5.8);
  } else {
    camera.position.set(0, 1.6, 5.8);
    camera.lookAt(0, 1.15, 0);
  }
  return true;
}

const watch = createWristWatch({
  scene,
  getState: ()=>({
    cash,
    seated,
    seatLabel: seatLabel(),
    inTableZone: inTableZone(),
    audioEnabled: audio.getState().enabled,
    trackTitle: audio.getState().trackTitle
  }),
  actions: {
    toggleAudio: ()=>audio.toggle(),
    nextTrack: ()=>audio.next(),
    joinTable,
    leaveTable
  }
});

$toggleJoints.addEventListener("click", ()=>{
  const on = hands.toggleDebug();
  $toggleJoints.textContent = on ? "Joints On" : "Joints";
});

$status.textContent = "Loading logo…";
const logoTexture = await loadFirstTexture(assetUrls("ui/logo.png", "logo.png"), { colorSpace: THREE.SRGBColorSpace });
tp.setLogoTexture(logoTexture);

$status.textContent = AUTOCAM ? "Autocam Preview Live" : "Ready. Enter VR.";
$mode.textContent = AUTOCAM ? "Preview: camera 3 online" : "Hands: waiting…";

function setHudVisible(visible){
  const hud = document.getElementById("hud");
  if (hud) hud.style.display = visible ? "flex" : "none";
  if ($log) $log.style.display = "none";
  if ($err) $err.style.display = "none";
}

renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});
renderer.xr.addEventListener("sessionend", ()=>{
  setHudVisible(true);
});

let tPrev = performance.now();
const previewTarget = new THREE.Vector3(0, 1.25, 0);
const previewPos = new THREE.Vector3();
const previewShots = [
  { y: 9.5, r: previewOrbitRadius, speed: 0.1, lookY: 1.15 },
  { y: 13.0, r: previewOrbitRadius + 5.5, speed: -0.06, lookY: 1.35 },
  { y: 7.8, r: previewOrbitRadius - 1.2, speed: 0.14, lookY: 1.0 }
];

renderer.setAnimationLoop(()=>{
  const now = performance.now();
  const dt = Math.min((now - tPrev) / 1000, 0.033);
  tPrev = now;

  if (!renderer.xr.isPresenting){
    if (AUTOCAM){
      const t = now * 0.001;
      const shot = previewShots[Math.floor(t / 10) % previewShots.length];
      const ang = t * shot.speed;
      previewPos.set(Math.cos(ang) * shot.r, shot.y, Math.sin(ang) * shot.r);
      camera.position.lerp(previewPos, 0.035);
      previewTarget.y = shot.lookY;
      camera.lookAt(previewTarget);
    } else {
      desktop.update(dt);
    }
  }

  if (scene.userData._tickWorld) scene.userData._tickWorld(dt);

  const left = hands.getLeft();
  const right = hands.getRight();

  hands.updateDebug();
  watch.update(dt, left, right);

  if (!AUTOCAM || renderer.xr.isPresenting){
    tp.update({
      leftHand: left,
      rightHand: right,
      statusCb: (text)=>{ if ($status) $status.textContent = text; },
      modeCb: (text)=>{ if ($mode) $mode.textContent = text; }
    });
  }

  renderer.render(scene, camera);
});

const canvasEl = renderer.domElement;
canvasEl.addEventListener("webglcontextlost", (e)=>{
  e.preventDefault();
  log("[ERR] WebGL context lost. Reloading…");
  if ($status) $status.textContent = "WebGL context lost (reloading…)";
  setTimeout(()=>location.reload(), 500);
}, false);
