import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createXRInput } from "./modules/xr_input.js";
import { createPlayerRig } from "./modules/player_rig.js";
import { buildWorld } from "./modules/world.js";
import { createWatch } from "./modules/watch.js";
import { createTeleportSystem } from "./modules/teleport.js";
import { createInteractionSystem } from "./modules/interaction.js";
import { createPokerDemo } from "./modules/poker_demo.js";
import { CONFIG } from "./modules/config.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $handState = document.getElementById("handState");
const $log = document.getElementById("log");
const $toggleLog = document.getElementById("toggleLog");
const $buildPill = document.getElementById("buildPill");
const QUERY = new URLSearchParams(window.location.search);
const IN_IFRAME = window.self !== window.top;
const PREVIEW_ONLY = QUERY.get("preview") === "1" || (IN_IFRAME && QUERY.get("play") !== "1");
const CAM_MODE = QUERY.get("cam") || (PREVIEW_ONLY ? "director" : "off");
if (PREVIEW_ONLY) document.body.classList.add("preview-only");
if ($buildPill) $buildPill.textContent = `BUILD: ${CONFIG.BUILD}`;

function log(...args) {
  const line = args.map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" ");
  $log.textContent += `${line}\n`;
  $log.scrollTop = $log.scrollHeight;
  console.log(...args);
}

$toggleLog?.addEventListener("click", () => {
  $log.style.display = $log.style.display === "block" ? "none" : "block";
});

const { scene, camera, renderer, spectatorCamera, spectatorRenderer } = createCore({ containerId: "app", spectatorCanvasId: "spectatorCanvas" });
const desktop = createDesktopControls({ camera, domElement: renderer.domElement });
const xrInput = createXRInput({ scene, renderer, log });
$status.textContent = PREVIEW_ONLY ? "CAM 3 preview booting…" : "Rebuilding lobby refine pass…";
const world = await buildWorld(scene, { log });
desktop.setRoomClamp(world.roomClamp);
const playerRig = createPlayerRig({ renderer, camera, desktopControls: desktop, roomClamp: world.roomClamp, log });
playerRig.resetToSpawn();
const watch = createWatch({ scene, camera, renderer });
const teleport = createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp: world.roomClamp });
const interaction = createInteractionSystem({ scene, camera, renderer, playerRig, seats: world.seats, watch, teleport, tableProps: world.tableProps, log });
const poker = createPokerDemo({ scene, chairRings: world.chairRings, statusCb: (text) => { if ($handState) $handState.textContent = text; }, log });
watch.setState({ teleportEnabled: false, seated: false, mode: "DESKTOP" });

renderer.xr.addEventListener("sessionstart", async () => {
  await playerRig.onSessionStart();
  playerRig.resetToSpawn();
  watch.setState({ mode: "XR", teleportEnabled: false, seated: false });
  $mode.textContent = "Mode: XR";
  $status.textContent = PREVIEW_ONLY ? "CAM 3 preview live" : "XR ready • watch active";
});

renderer.xr.addEventListener("sessionend", () => {
  teleport.setEnabled(false);
  interaction.releaseHeldProp();
  watch.setState({ teleportEnabled: false, mode: "DESKTOP" });
  playerRig.resetToSpawn();
  $mode.textContent = "Mode: desktop";
  $status.textContent = PREVIEW_ONLY ? "CAM 3 preview live" : "Desktop ready";
});

let spectatorAngle = 0;
let last = performance.now();
let elapsedS = 0;
const spectatorTarget = new THREE.Vector3(world.tableCenter.x, 1.22, world.tableCenter.z + 0.02);
const spectatorLook = spectatorTarget.clone();
const headScratch = new THREE.Vector3();
const directorShots = [
  { pos: new THREE.Vector3(0.0, 3.95, 8.4), look: new THREE.Vector3(0, 1.18, 0.2) },
  { pos: new THREE.Vector3(-7.6, 3.35, 2.2), look: new THREE.Vector3(0, 1.18, -0.1) },
  { pos: new THREE.Vector3(7.1, 3.2, 1.9), look: new THREE.Vector3(0, 1.18, 0.05) },
  { pos: new THREE.Vector3(0.0, 5.1, -5.6), look: new THREE.Vector3(0, 1.2, 0.1) },
];

renderer.setAnimationLoop(() => {
  const now = performance.now();
  const dt = Math.min((now - last) / 1000, 0.05);
  last = now;
  elapsedS += dt;

  const xrPresenting = renderer.xr.isPresenting;
  const xrState = xrInput.getState();

  if (!xrPresenting && !PREVIEW_ONLY) {
    desktop.update(dt);
    watch.setState({ mode: "DESKTOP" });
  } else if (!xrPresenting && PREVIEW_ONLY) {
    watch.setState({ mode: "DESKTOP" });
  } else {
    watch.setState({ mode: xrState.leftHand?.joints?.wrist ? "HAND" : "CTRL" });
  }

  const gp = xrState.rightController?.userData?.gamepad;
  if (xrPresenting && gp?.axes?.length >= 4) {
    const axisX = gp.axes[2] ?? gp.axes[0] ?? 0;
    if (Math.abs(axisX) > CONFIG.SNAP_DEADZONE && !xrState.rightController.userData.snapLatch) {
      xrState.rightController.userData.snapLatch = true;
      playerRig.snapTurn(THREE.MathUtils.degToRad(axisX > 0 ? -CONFIG.SNAP_TURN_DEG : CONFIG.SNAP_TURN_DEG));
    }
    if (Math.abs(axisX) < 0.2) xrState.rightController.userData.snapLatch = false;
  }

  interaction.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand });
  watch.updatePose({ leftHand: xrState.leftHand, leftController: xrState.leftController, rightController: xrState.rightController, xrPresenting });
  teleport.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand, statusCb: (t) => { $status.textContent = t; } });
  scene.userData._tickWorld?.(now * 0.001);
  poker.update(now * 0.001, dt);
  if (!playerRig.isSeated()) playerRig.ensureSafePosition();

  const seated = playerRig.isSeated();
  watch.setState({ seated, teleportEnabled: teleport.isEnabled() });
  if (!PREVIEW_ONLY) {
    $mode.textContent = xrPresenting ? `Mode: XR • ${teleport.isEnabled() ? "TP ON" : "TP OFF"}` : `Mode: desktop • ${seated ? "seated" : "standing"}`;
  }

  if (!PREVIEW_ONLY) renderer.render(scene, camera);

  spectatorAngle += dt * 0.55;
  if (CAM_MODE === "director" || CAM_MODE === "broadcast") {
    const shotDuration = 5.5;
    const shotIndex = Math.floor(elapsedS / shotDuration) % directorShots.length;
    const nextIndex = (shotIndex + 1) % directorShots.length;
    const blend = (elapsedS % shotDuration) / shotDuration;
    const eased = blend * blend * (3 - 2 * blend);
    const shotA = directorShots[shotIndex];
    const shotB = directorShots[nextIndex];
    spectatorCamera.position.lerpVectors(shotA.pos, shotB.pos, eased);
    spectatorCamera.position.x += Math.sin(spectatorAngle) * 0.28;
    spectatorCamera.position.y += Math.sin(spectatorAngle * 0.7) * 0.09;
    spectatorCamera.position.z += Math.cos(spectatorAngle * 0.8) * 0.24;
    spectatorLook.lerpVectors(shotA.look, shotB.look, eased);
    spectatorLook.x += Math.sin(spectatorAngle * 0.45) * 0.08;
    spectatorLook.z += Math.cos(spectatorAngle * 0.5) * 0.12;
    spectatorCamera.lookAt(spectatorLook);
  } else if (CAM_MODE !== "off") {
    spectatorCamera.position.set(6.2, 3.5, 5.3);
    spectatorCamera.lookAt(spectatorTarget);
  }
  if (CAM_MODE !== "off" || PREVIEW_ONLY) spectatorRenderer.render(scene, spectatorCamera);
});

window.addEventListener("error", (e) => {
  log("RUNTIME ERROR", e?.error?.stack || e?.message || String(e));
  $status.textContent = "Runtime error • open Logs";
});
window.addEventListener("unhandledrejection", (e) => {
  log("PROMISE ERROR", e?.reason?.stack || e?.reason || String(e));
  $status.textContent = "Promise rejection • open Logs";
});

$status.textContent = PREVIEW_ONLY ? `CAM 3 preview live • ${CAM_MODE}` : "Phase 58 ready • lobby refine baseline";
if ($handState) $handState.textContent = "HAND 1 • real 52-card hold'em demo live";
window.addEventListener("keydown", (e) => { if (e.code === "KeyN") poker.forceNextHand(); });
log("SVR Poker phase 58 ready", { build: CONFIG.BUILD, camMode: CAM_MODE, previewOnly: PREVIEW_ONLY, inIframe: IN_IFRAME });
