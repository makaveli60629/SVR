import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";

const app = document.getElementById('app');
const statusEl = document.getElementById('status');
const modeEl = document.getElementById('mode');
const errorEl = document.getElementById('error');
const teleportBtn = document.getElementById('teleportBtn');
const radioBtn = document.getElementById('radioBtn');
const watchTime = document.getElementById('watchTime');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x03030a);
scene.fog = new THREE.FogExp2(0x060612, 0.018);

const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.05, 300);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
app.appendChild(renderer.domElement);

const world = new THREE.Group();
scene.add(world);

const player = {
  pos: new THREE.Vector3(0, 1.62, 4.9),
  yaw: Math.PI,
  pitch: -0.06,
  speed: 4.5,
  lookSpeed: 0.0024,
  teleportMode: false
};
const keys = new Set();
const velocity = new THREE.Vector3();
const up = new THREE.Vector3(0, 1, 0);
const forward = new THREE.Vector3();
const right = new THREE.Vector3();
const roomRadius = 26;
const safeRadius = roomRadius - 2.6;
let pointerLocked = false;

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
let floorMesh;
let audioCtx = null;
let radioNodes = null;

function showError(message) {
  errorEl.textContent = message;
  errorEl.classList.remove('hidden');
}
window.addEventListener('error', (event) => showError(event?.error?.stack || event.message || 'Runtime error'));
window.addEventListener('unhandledrejection', (event) => showError(String(event.reason || 'Promise rejection')));

function updateCamera() {
  camera.rotation.order = 'YXZ';
  camera.position.copy(player.pos);
  camera.rotation.y = player.yaw;
  camera.rotation.x = player.pitch;
}
updateCamera();

// lights
scene.add(new THREE.HemisphereLight(0xffffff, 0x080812, 1.6));
const ceiling = new THREE.PointLight(0xffffff, 2.4, 120);
ceiling.position.set(0, 13, 0);
scene.add(ceiling);
const magenta = new THREE.PointLight(0xbc56ff, 2.2, 46, 2.2);
magenta.position.set(-5, 5.5, 3);
scene.add(magenta);
const cyan = new THREE.PointLight(0x61e3ff, 1.8, 42, 2.0);
cyan.position.set(6, 5, -5);
scene.add(cyan);
const rimLight = new THREE.DirectionalLight(0xffffff, 0.8);
rimLight.position.set(6, 12, 6);
scene.add(rimLight);

// floor + room shell
floorMesh = new THREE.Mesh(
  new THREE.CircleGeometry(roomRadius + 20, 160),
  new THREE.MeshStandardMaterial({ color: 0x05050b, roughness: 0.95, metalness: 0.05 })
);
floorMesh.rotation.x = -Math.PI / 2;
world.add(floorMesh);

const wall = new THREE.Mesh(
  new THREE.CylinderGeometry(roomRadius, roomRadius, 16, 128, 1, true),
  new THREE.MeshStandardMaterial({
    color: 0x070711,
    roughness: 0.85,
    metalness: 0.08,
    emissive: 0x1f0d31,
    emissiveIntensity: 0.38,
    side: THREE.BackSide
  })
);
wall.position.y = 8;
world.add(wall);

const rim = new THREE.Mesh(
  new THREE.TorusGeometry(roomRadius - 0.45, 0.18, 16, 180),
  new THREE.MeshStandardMaterial({
    color: 0xb663ff,
    roughness: 0.24,
    metalness: 0.3,
    emissive: 0x5a28c8,
    emissiveIntensity: 1.25
  })
);
rim.rotation.x = Math.PI / 2;
rim.position.set(0, 15.2, 0);
world.add(rim);

// moon
const moon = new THREE.Mesh(
  new THREE.SphereGeometry(4.5, 32, 32),
  new THREE.MeshStandardMaterial({ color: 0xe9edff, emissive: 0x4450a8, emissiveIntensity: 0.25, roughness: 1 })
);
moon.position.set(-18, 18, -44);
world.add(moon);
const moonGlow = new THREE.PointLight(0xa4b3ff, 1.4, 130, 2.0);
moonGlow.position.copy(moon.position);
scene.add(moonGlow);

// stars
(function addStars() {
  const positions = [];
  for (let i = 0; i < 1600; i++) {
    const radius = 70 + Math.random() * 40;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.45;
    const x = Math.cos(theta) * Math.cos(phi) * radius;
    const y = 12 + Math.sin(phi) * radius * 0.25 + Math.random() * 18;
    const z = Math.sin(theta) * Math.cos(phi) * radius;
    positions.push(x, y, z);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  const material = new THREE.PointsMaterial({ color: 0xc8e7ff, size: 0.24, transparent: true, opacity: 0.85, depthWrite: false });
  const points = new THREE.Points(geometry, material);
  world.add(points);
})();

// skyline
(function buildSkyline() {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x0e0e18, roughness: 0.8, metalness: 0.12, emissive: 0x180d24, emissiveIntensity: 0.38 });
  const winMat = new THREE.MeshStandardMaterial({ color: 0x95dfff, emissive: 0x78b9ff, emissiveIntensity: 0.52, roughness: 0.25, metalness: 0.3 });
  const count = 160;
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2;
    const rr = roomRadius + 6 + Math.random() * 11;
    const h = 7 + Math.random() * 25;
    const w = 1.5 + Math.random() * 3.8;
    const d = 1.5 + Math.random() * 3.8;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;
    const building = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), bodyMat);
    building.position.set(x, h * 0.5, z);
    building.rotation.y = -a + Math.PI / 2;
    group.add(building);
    if (Math.random() > 0.2) {
      const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.16, d * 1.05), winMat);
      strip.position.set(x, 1.4 + Math.random() * Math.max(2, h - 2.2), z);
      strip.rotation.y = building.rotation.y;
      group.add(strip);
    }
  }
  world.add(group);
})();

// rising sprites
const spriteGroup = new THREE.Group();
world.add(spriteGroup);
const spriteTexture = (() => {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(size/2, size/2, 12, size/2, size/2, size/2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.25, 'rgba(97,227,255,0.8)');
  g.addColorStop(0.55, 'rgba(190,99,255,0.45)');
  g.addColorStop(1, 'rgba(190,99,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
})();
for (let i = 0; i < 56; i++) {
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: spriteTexture, color: 0xffffff, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }));
  sprite.position.set((Math.random() - 0.5) * 16, Math.random() * 10, (Math.random() - 0.5) * 16);
  const scale = 0.8 + Math.random() * 0.8;
  sprite.scale.setScalar(scale);
  sprite.userData.speed = 1 + Math.random() * 1.2;
  sprite.userData.phase = Math.random() * Math.PI * 2;
  spriteGroup.add(sprite);
}

// table
const texLoader = new THREE.TextureLoader();
const feltTexture = texLoader.load('./assets/logo-table.webp', () => {
  statusEl.textContent = 'Room loaded. Movement online.';
});
feltTexture.colorSpace = THREE.SRGBColorSpace;
feltTexture.wrapS = feltTexture.wrapT = THREE.ClampToEdgeWrapping;
const tableGroup = new THREE.Group();
world.add(tableGroup);

const tableEdge = new THREE.Mesh(
  new THREE.CylinderGeometry(2.25, 2.25, 0.38, 64),
  new THREE.MeshStandardMaterial({ color: 0x191628, roughness: 0.3, metalness: 0.38, emissive: 0x1b1028, emissiveIntensity: 0.35 })
);
tableEdge.position.y = 1.0;
tableGroup.add(tableEdge);

const felt = new THREE.Mesh(
  new THREE.CircleGeometry(1.98, 64),
  new THREE.MeshStandardMaterial({ map: feltTexture, roughness: 0.9, metalness: 0.02, emissive: 0x0b4534, emissiveIntensity: 0.16 })
);
felt.rotation.x = -Math.PI / 2;
felt.position.y = 1.2;
tableGroup.add(felt);

const trim = new THREE.Mesh(
  new THREE.TorusGeometry(2.02, 0.06, 16, 120),
  new THREE.MeshStandardMaterial({ color: 0x7b49ff, roughness: 0.28, metalness: 0.3, emissive: 0x5629d8, emissiveIntensity: 0.82 })
);
trim.rotation.x = Math.PI / 2;
trim.position.y = 1.21;
tableGroup.add(trim);

const tableStem = new THREE.Mesh(
  new THREE.CylinderGeometry(0.35, 0.45, 1.1, 24),
  new THREE.MeshStandardMaterial({ color: 0x140e20, roughness: 0.48, metalness: 0.22 })
);
tableStem.position.y = 0.46;
tableGroup.add(tableStem);
const basePlate = new THREE.Mesh(
  new THREE.CylinderGeometry(1.0, 1.0, 0.08, 40),
  new THREE.MeshStandardMaterial({ color: 0x171225, roughness: 0.5, metalness: 0.2 })
);
basePlate.position.y = 0.04;
tableGroup.add(basePlate);

function addChair(angle) {
  const group = new THREE.Group();
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.24, 0.9), new THREE.MeshStandardMaterial({ color: 0x2b1d40, roughness: 0.62 }));
  seat.position.y = 0.55;
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.95, 0.16), new THREE.MeshStandardMaterial({ color: 0x43255e, roughness: 0.62 }));
  back.position.set(0, 1.08, -0.34);
  const legs = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.52, 12), new THREE.MeshStandardMaterial({ color: 0x181321, roughness: 0.45 }));
  legs.position.set(0, 0.25, 0);
  group.add(seat, back, legs);
  const radius = 3.0;
  group.position.set(Math.sin(angle) * radius, 0, Math.cos(angle) * radius);
  group.rotation.y = angle + Math.PI;
  tableGroup.add(group);
}
for (let i = 0; i < 6; i++) addChair((i / 6) * Math.PI * 2);

// chips and cards
function chip(x, z, color) {
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.32, metalness: 0.06, emissive: color, emissiveIntensity: 0.1 });
  for (let i = 0; i < 4; i++) {
    const c = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.035, 24), mat);
    c.position.set(x, 1.23 + i * 0.035, z);
    tableGroup.add(c);
  }
}
chip(-0.9, 0.8, 0xff4f86);
chip(0.9, -0.8, 0x61e3ff);
chip(0.2, -0.35, 0xf7e37a);
for (const [x, z, rot] of [[0.2, 0.6, -0.2], [0.48, 0.62, 0.12]]) {
  const card = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.02, 0.62), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95 }));
  card.position.set(x, 1.225, z);
  card.rotation.y = rot;
  tableGroup.add(card);
}

// radio prop
const radio = new THREE.Group();
const radioBody = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.38, 0.28), new THREE.MeshStandardMaterial({ color: 0x171422, roughness: 0.55 }));
const radioScreen = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 0.03), new THREE.MeshStandardMaterial({ color: 0x59d7ff, emissive: 0x59d7ff, emissiveIntensity: 0.6 }));
radioScreen.position.set(0, 0.05, 0.145);
const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.5, 8), new THREE.MeshStandardMaterial({ color: 0xa8b8ff, roughness: 0.2 }));
antenna.position.set(0.26, 0.38, 0.02);
radio.add(radioBody, radioScreen, antenna);
radio.position.set(-5.6, 0.22, 5.6);
world.add(radio);

// teleport marker
const tpGroup = new THREE.Group();
const tpRing = new THREE.Mesh(new THREE.RingGeometry(0.32, 0.5, 48), new THREE.MeshStandardMaterial({ color: 0xb663ff, emissive: 0x5a28c8, emissiveIntensity: 1.0, side: THREE.DoubleSide }));
tpRing.rotation.x = -Math.PI / 2;
const tpDisc = new THREE.Mesh(new THREE.CircleGeometry(0.28, 40), new THREE.MeshBasicMaterial({ map: texLoader.load('./assets/logo.webp'), transparent: true, opacity: 0.9 }));
tpDisc.rotation.x = -Math.PI / 2;
tpDisc.position.y = 0.002;
tpGroup.add(tpRing, tpDisc);
tpGroup.visible = false;
world.add(tpGroup);

function clampInsideRoom(vec) {
  const len = Math.hypot(vec.x, vec.z);
  if (len > safeRadius) {
    const scale = safeRadius / len;
    vec.x *= scale;
    vec.z *= scale;
  }
  vec.y = 1.62;
}

function placeTeleportMarker(point) {
  const target = point.clone();
  target.y = 0.012;
  tpGroup.position.copy(target);
  tpGroup.visible = true;
}

function performTeleport(target) {
  const desired = new THREE.Vector3(target.x, 1.62, target.z);
  clampInsideRoom(desired);
  player.pos.copy(desired);
  updateCamera();
}

teleportBtn.addEventListener('click', () => {
  player.teleportMode = !player.teleportMode;
  teleportBtn.classList.toggle('active', player.teleportMode);
  teleportBtn.textContent = `Teleport: ${player.teleportMode ? 'On' : 'Off'}`;
  tpGroup.visible = false;
  modeEl.textContent = player.teleportMode ? 'Teleport enabled. Tap or click the floor to jump.' : 'Desktop: WASD + mouse • Mobile: dual sticks • Teleport: T';
});
window.addEventListener('keydown', (event) => {
  keys.add(event.code);
  if (event.code === 'KeyT') teleportBtn.click();
});
window.addEventListener('keyup', (event) => keys.delete(event.code));

renderer.domElement.addEventListener('click', () => {
  if (!pointerLocked && matchMedia('(hover:hover)').matches && !player.teleportMode) renderer.domElement.requestPointerLock?.();
});
document.addEventListener('pointerlockchange', () => {
  pointerLocked = document.pointerLockElement === renderer.domElement;
});
document.addEventListener('mousemove', (event) => {
  if (!pointerLocked) return;
  player.yaw -= event.movementX * player.lookSpeed;
  player.pitch -= event.movementY * player.lookSpeed;
  player.pitch = THREE.MathUtils.clamp(player.pitch, -1.1, 1.1);
});

function pickFloor(clientX, clientY) {
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const hit = raycaster.intersectObject(floorMesh, false)[0];
  return hit?.point || null;
}
renderer.domElement.addEventListener('pointerdown', (event) => {
  if (!player.teleportMode) return;
  const point = pickFloor(event.clientX, event.clientY);
  if (!point) return;
  placeTeleportMarker(point);
  performTeleport(point);
});

// mobile joysticks
const stickState = {
  move: { active: false, id: null, origin: new THREE.Vector2(), delta: new THREE.Vector2() },
  look: { active: false, id: null, origin: new THREE.Vector2(), delta: new THREE.Vector2() }
};
const moveZone = document.getElementById('moveZone');
const lookZone = document.getElementById('lookZone');
const moveKnob = document.getElementById('moveKnob');
const lookKnob = document.getElementById('lookKnob');

function setupStick(zone, knob, state) {
  const reset = () => {
    state.active = false;
    state.id = null;
    state.delta.set(0, 0);
    knob.style.transform = 'translate(0px, 0px)';
  };
  zone.addEventListener('pointerdown', (event) => {
    state.active = true;
    state.id = event.pointerId;
    state.origin.set(event.clientX, event.clientY);
    zone.setPointerCapture(event.pointerId);
  });
  zone.addEventListener('pointermove', (event) => {
    if (!state.active || event.pointerId !== state.id) return;
    const dx = event.clientX - state.origin.x;
    const dy = event.clientY - state.origin.y;
    const limit = 40;
    const len = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(limit, len);
    state.delta.set((dx / len) * (clamped / limit), (dy / len) * (clamped / limit));
    knob.style.transform = `translate(${state.delta.x * limit}px, ${state.delta.y * limit}px)`;
  });
  const end = (event) => {
    if (event.pointerId !== state.id) return;
    reset();
  };
  zone.addEventListener('pointerup', end);
  zone.addEventListener('pointercancel', end);
  return reset;
}
setupStick(moveZone, moveKnob, stickState.move);
setupStick(lookZone, lookKnob, stickState.look);

function buildFallbackEric() {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x7d72ff, roughness: 0.58, emissive: 0x2d1b52, emissiveIntensity: 0.35 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.9, 6, 12), mat);
  body.position.y = 1.02;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 24, 24), new THREE.MeshStandardMaterial({ color: 0xd8c2aa, roughness: 0.8 }));
  head.position.y = 1.76;
  group.add(body, head);
  group.position.set(0, 0, -3.0);
  group.rotation.y = Math.PI;
  tableGroup.add(group);
}

(async function loadEric() {
  try {
    const loader = new FBXLoader();
    const obj = await loader.loadAsync('./assets/eric.fbx');
    const diffuse = await new Promise((resolve) => texLoader.load('./assets/eric-diffuse.webp', resolve, undefined, () => resolve(null)));
    if (diffuse) diffuse.colorSpace = THREE.SRGBColorSpace;
    obj.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      child.material = new THREE.MeshStandardMaterial({
        map: diffuse || null,
        color: diffuse ? 0xffffff : 0x7d72ff,
        roughness: 0.7,
        metalness: 0.04,
        emissive: 0x140d21,
        emissiveIntensity: 0.12
      });
    });
    const box = new THREE.Box3().setFromObject(obj);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);
    const targetHeight = 1.72;
    const scale = targetHeight / Math.max(size.y, 0.001);
    obj.scale.setScalar(scale);
    obj.updateMatrixWorld(true);
    const scaledBox = new THREE.Box3().setFromObject(obj);
    const scaledSize = new THREE.Vector3();
    const scaledCenter = new THREE.Vector3();
    scaledBox.getSize(scaledSize);
    scaledBox.getCenter(scaledCenter);
    obj.position.set(0, scaledSize.y * 0.5 - scaledCenter.y, -3.0);
    obj.rotation.y = Math.PI;
    tableGroup.add(obj);
  } catch (error) {
    console.warn('Eric fallback', error);
    buildFallbackEric();
  }
})();

function updateWatch() {
  const now = new Date();
  watchTime.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
setInterval(updateWatch, 1000);
updateWatch();

function toggleRadio() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') audioCtx.resume();
  if (radioNodes) {
    radioNodes.gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.2);
    setTimeout(() => {
      radioNodes.osc1.stop();
      radioNodes.osc2.stop();
      radioNodes.filter.disconnect();
      radioNodes.gain.disconnect();
      radioNodes = null;
    }, 260);
    radioBtn.classList.remove('active');
    radioBtn.textContent = 'Radio: Off';
    return;
  }
  const osc1 = audioCtx.createOscillator();
  const osc2 = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const filter = audioCtx.createBiquadFilter();
  osc1.type = 'sawtooth';
  osc2.type = 'triangle';
  osc1.frequency.value = 164.81;
  osc2.frequency.value = 220;
  filter.type = 'lowpass';
  filter.frequency.value = 950;
  gain.gain.value = 0.0001;
  osc1.connect(filter);
  osc2.connect(filter);
  filter.connect(gain);
  gain.connect(audioCtx.destination);
  osc1.start();
  osc2.start();
  gain.gain.exponentialRampToValueAtTime(0.035, audioCtx.currentTime + 0.4);
  radioNodes = { osc1, osc2, filter, gain };
  radioBtn.classList.add('active');
  radioBtn.textContent = 'Radio: On';
}
radioBtn.addEventListener('click', toggleRadio);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

const clock = new THREE.Clock();
function animate() {
  const dt = Math.min(clock.getDelta(), 0.033);

  if (pointerLocked) {
    forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
    right.copy(forward).cross(up).normalize();
    velocity.set(0, 0, 0);
    if (keys.has('KeyW')) velocity.add(forward);
    if (keys.has('KeyS')) velocity.addScaledVector(forward, -1);
    if (keys.has('KeyD')) velocity.add(right);
    if (keys.has('KeyA')) velocity.addScaledVector(right, -1);
    if (velocity.lengthSq() > 0) velocity.normalize().multiplyScalar(player.speed * dt);
    player.pos.add(velocity);
  }

  if (stickState.move.active) {
    forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
    right.copy(forward).cross(up).normalize();
    const moveForward = -stickState.move.delta.y;
    const moveStrafe = stickState.move.delta.x;
    player.pos.addScaledVector(forward, moveForward * player.speed * dt);
    player.pos.addScaledVector(right, moveStrafe * player.speed * dt);
  }
  if (stickState.look.active) {
    player.yaw -= stickState.look.delta.x * 1.65 * dt;
    player.pitch -= stickState.look.delta.y * 1.25 * dt;
    player.pitch = THREE.MathUtils.clamp(player.pitch, -1.0, 1.0);
  }

  clampInsideRoom(player.pos);
  updateCamera();

  // table subtle pulse
  trim.material.emissiveIntensity = 0.74 + Math.sin(performance.now() * 0.0034) * 0.12;
  rim.material.emissiveIntensity = 1.18 + Math.sin(performance.now() * 0.0018) * 0.15;

  // rising sprites
  for (const sprite of spriteGroup.children) {
    sprite.position.y += sprite.userData.speed * dt;
    sprite.position.x += Math.sin(performance.now() * 0.0006 + sprite.userData.phase) * 0.003;
    sprite.position.z += Math.cos(performance.now() * 0.0005 + sprite.userData.phase) * 0.003;
    if (sprite.position.y > 14) {
      sprite.position.y = 0.15 + Math.random() * 2;
      sprite.position.x = (Math.random() - 0.5) * 16;
      sprite.position.z = (Math.random() - 0.5) * 16;
    }
  }

  // marker animation
  if (tpGroup.visible) {
    tpGroup.rotation.y += dt * 1.8;
    tpRing.material.emissiveIntensity = 0.9 + Math.sin(performance.now() * 0.006) * 0.16;
  }

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
statusEl.textContent = 'Room loaded. Spawn is set roughly 3 meters from table edge.';
requestAnimationFrame(animate);
