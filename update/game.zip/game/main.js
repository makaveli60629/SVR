import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createXRInput } from "./modules/xr_input.js";
import { createPlayerRig } from "./modules/player_rig.js";
import { buildWorld } from "./modules/world.js";
import { createWatch } from "./modules/watch.js";
import { createTeleportSystem } from "./modules/teleport.js";
import { createInteractionSystem } from "./modules/interaction.js";
import { CONFIG } from "./modules/config.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $toggleLog = document.getElementById("toggleLog");

function log(...args) {
  const line = args.map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" ");
  $log.textContent += `${line}
`;
  $log.scrollTop = $log.scrollHeight;
  console.log(...args);
}

$toggleLog.addEventListener("click", () => {
  $log.style.display = $log.style.display === "block" ? "none" : "block";
});

const { scene, camera, renderer, spectatorCamera, spectatorRenderer } = createCore({ containerId: "app", spectatorCanvasId: "spectatorCanvas" });
const desktop = createDesktopControls({ camera, domElement: renderer.domElement });
const xrInput = createXRInput({ scene, renderer, log });
const playerRig = createPlayerRig({ renderer, camera, desktopControls: desktop, log });

$status.textContent = "Building phase 43 world…";
const world = await buildWorld(scene, { log });
const watch = createWatch({ scene, camera, renderer });
const teleport = createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp: world.roomClamp });
const interaction = createInteractionSystem({ scene, camera, renderer, playerRig, seats: world.seats, watch, teleport, tableProps: world.tableProps, log });
watch.setState({ teleportEnabled: false, seated: false, mode: "DESKTOP" });

renderer.xr.addEventListener("sessionstart", async () => {
  await playerRig.onSessionStart();
  watch.setState({ mode: "XR" });
  $mode.textContent = "Mode: XR";
  $status.textContent = "XR ready • grab cards/chips or use watch";
});
renderer.xr.addEventListener("sessionend", () => {
  teleport.setEnabled(false);
  interaction.releaseHeldProp();
  watch.setState({ teleportEnabled: false, mode: "DESKTOP" });
  $mode.textContent = "Mode: desktop";
  $status.textContent = "Desktop ready";
});

let spectatorAngle = 0;
let last = performance.now();

renderer.setAnimationLoop(() => {
  const now = performance.now();
  const dt = Math.min((now - last) / 1000, 0.05);
  last = now;

  const xrPresenting = renderer.xr.isPresenting;
  const xrState = xrInput.getState();

  if (!xrPresenting) {
    desktop.update(dt);
    watch.setState({ mode: "DESKTOP" });
  } else {
    watch.setState({ mode: xrState.leftHand?.joints?.wrist ? "HAND" : "CTRL" });
  }

  const gp = xrState.rightController?.userData?.gamepad;
  if (xrPresenting && gp?.axes?.length >= 4) {
    const axisX = gp.axes[2] ?? gp.axes[0] ?? 0;
    if (Math.abs(axisX) > CONFIG.SNAP_DEADZONE && !xrState.rightController.userData.snapLatch) {
      xrState.rightController.userData.snapLatch = true;
      playerRig.snapTurn(THREE.MathUtils.degToRad(axisX > 0 ? -CONFIG.SNAP_TURN_DEG : CONFIG.SNAP_TURN_DEG));
    }
    if (Math.abs(axisX) < 0.2) xrState.rightController.userData.snapLatch = false;
  }

  interaction.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand });
  watch.updatePose({ leftHand: xrState.leftHand, leftController: xrState.leftController, rightController: xrState.rightController, xrPresenting });
  teleport.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand, statusCb: (t) => { $status.textContent = t; } });
  scene.userData._tickWorld?.(now * 0.001);

  const seated = playerRig.isSeated();
  watch.setState({ seated, teleportEnabled: teleport.isEnabled() });
  $mode.textContent = xrPresenting ? `Mode: XR • ${teleport.isEnabled() ? "TP ON" : "TP OFF"}` : `Mode: desktop • ${seated ? "seated" : "standing"}`;

  renderer.render(scene, camera);

  spectatorAngle += dt * 0.18;
  const specR = CONFIG.SPECTATOR_RADIUS;
  spectatorCamera.position.set(Math.cos(spectatorAngle) * specR, CONFIG.SPECTATOR_HEIGHT, Math.sin(spectatorAngle) * specR);
  spectatorCamera.lookAt(world.tableCenter.x, 1.2, world.tableCenter.z);
  spectatorRenderer.render(scene, spectatorCamera);
});

window.addEventListener("error", (e) => {
  log("RUNTIME ERROR", e?.error?.stack || e?.message || String(e));
  $status.textContent = "Runtime error • open Logs";
});
window.addEventListener("unhandledrejection", (e) => {
  log("PROMISE ERROR", e?.reason?.stack || e?.reason || String(e));
  $status.textContent = "Promise rejection • open Logs";
});

$status.textContent = "Phase 43 ready • table gameplay polish";
log("SVR Poker phase 43 ready", CONFIG.BUILD);
