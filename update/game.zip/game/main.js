import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createHands } from "./modules/hands.js";
import { createTeleportRig } from "./modules/teleport.js";
import { buildSkylineRoom } from "./modules/world_skyline.js";
import { urlsFor } from "./modules/asset_base.js";
import { createWristWatch } from "./modules/watch.js";
import { createDebugStats } from "./modules/debug_stats.js";
import { createJointDebug } from "./modules/hand_debug.js";
import { runModuleAudit } from "./modules/module_audit.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $stats = document.getElementById("stats");
const $err = document.getElementById("err");
const $toggleLog = document.getElementById("toggleLog");
const $toggleJoints = document.getElementById("toggleJoints");
const $toggleStats = document.getElementById("toggleStats");

function log(...args){
  const line = args.map(a => (typeof a === "string" ? a : JSON.stringify(a, null, 2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}

$toggleLog.addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

const { scene, camera, renderer } = createCore({ containerId:"app" });
camera.position.set(0, 1.6, 3);

window.addEventListener("error", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});

const desktop = createDesktopControls({ camera, domElement: renderer.domElement });

$status.textContent = "Loading skyline room…";
const { roomClamp } = await buildSkylineRoom(scene, { log });
log("[BOOT] Skyline room built.");

const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
const watch = createWristWatch({ scene, renderer, log });
const stats = createDebugStats({ renderer, scene, camera, el: $stats, label: "SKYLINE ROOM" });
const jointDebug = createJointDebug({ scene });
const audit = runModuleAudit({ scene, roomClamp, hands, tp, watch, stats, jointDebug, log });
if (audit.ok) {
  log(`[AUDIT] Lobby phase 1 ready. Storefronts: ${audit.storefronts}`);
} else {
  $err.style.display = "block";
  $err.textContent = "MODULE AUDIT FAILED\n" + audit.lines.join("\n");
}

$toggleJoints.addEventListener("click", ()=> jointDebug.toggle());
$toggleStats.addEventListener("click", ()=> stats.toggle());
window.addEventListener("keydown", (e)=>{
  if (e.code === "Digit1") jointDebug.toggle();
  if (e.code === "Digit2") stats.toggle();
});

function loadTexture(url){
  return new Promise((resolve)=>{
    const loader = new THREE.TextureLoader();
    loader.load(url, (t)=>{
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 8;
      resolve(t);
    }, undefined, ()=>resolve(null));
  });
}

$status.textContent = "Loading logo…";
let tex = null;
for (const url of urlsFor("ui/logo.png")){
  tex = await loadTexture(url);
  if (tex) break;
}
if (!tex) tex = await loadTexture(new URL("./logo_fallback.png", import.meta.url).toString());
tp.setLogoTexture(tex);

$status.textContent = "Ready. Enter VR or use desktop controls.";
$mode.textContent = "Hands: waiting…";

function setHudVisible(visible){
  const hud = document.getElementById("hud");
  if (hud) hud.style.display = visible ? "flex" : "none";
  $err.style.display = "none";
  if (!visible){
    $log.style.display = "none";
    $stats.style.display = "none";
  }
}

renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});
renderer.xr.addEventListener("sessionend", ()=>{
  setHudVisible(true);
});

let prev = performance.now();
renderer.setAnimationLoop(()=>{
  const now = performance.now();
  const dt = Math.min((now - prev) / 1000, 0.05);
  prev = now;

  if (!renderer.xr.isPresenting) desktop.update(dt);
  if (scene.userData._tickWorld){
    try {
      scene.userData._tickWorld(dt);
    } catch (err) {
      console.error("World tick failed", err);
      scene.userData._tickWorld = null;
      if (!renderer.xr.isPresenting) $err.style.display = "block";
      $err.textContent = "WORLD TICK ERROR:
" + (err?.stack || err?.message || String(err));
      log("[ERR] World tick disabled:", err?.message || String(err));
    }
  }

  const left = hands.getLeft();
  const right = hands.getRight();

  watch.update(dt, left, right);
  jointDebug.update(left, right);
  stats.update(dt, left, right);

  tp.update({
    leftHand: left,
    rightHand: right,
    statusCb: (t)=>{ $status.textContent = t; },
    modeCb: (t)=>{ $mode.textContent = t; },
  });

  renderer.render(scene, camera);
});

renderer.domElement.addEventListener("webglcontextlost", (e)=>{
  e.preventDefault();
  log("[ERR] WebGL context lost. Reloading…");
  $status.textContent = "WebGL context lost (reloading…)";
  setTimeout(()=>location.reload(), 500);
}, false);
