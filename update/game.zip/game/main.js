import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createHands } from "./modules/hands.js";
import { createTeleportRig } from "./modules/teleport.js";
import { buildSkylineRoom } from "./modules/world_skyline.js";
import { urlsFor } from "./modules/asset_base.js";
import { createWristWatch } from "./modules/watch.js";
import { createPlayerRig } from "./modules/camera_rig.js";

const $status=document.getElementById("status");
const $mode=document.getElementById("mode");
const $log=document.getElementById("log");
const $err=document.getElementById("err");
const $toggleLog=document.getElementById("toggleLog");
const $btnThird=document.getElementById("toggleThird");
const $btnRecenter=document.getElementById("recenter");
const $btnQuality=document.getElementById("quality");
const $fps=document.getElementById("fps");

function log(...args){
  const line=args.map(a=> (typeof a==="string"?a:JSON.stringify(a,null,2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}
$toggleLog.addEventListener("click", ()=>{ $log.style.display = ($log.style.display==="none"||!$log.style.display)?"block":"none"; });

const { scene, camera, renderer } = createCore({ containerId:"app" });

window.addEventListener("error",(e)=>{ if (!renderer.xr.isPresenting){ $err.style.display="block"; } $err.textContent="RUNTIME ERROR:\n"+(e?.error?.stack||e?.message||String(e)); });
window.addEventListener("unhandledrejection",(e)=>{ if (!renderer.xr.isPresenting){ $err.style.display="block"; } $err.textContent="UNHANDLED PROMISE REJECTION:\n"+(e?.reason?.stack||e?.reason||String(e)); });

// Player rig (desktop 1st/3rd person)
const rig = createPlayerRig({ camera });
scene.add(rig.player);
rig.applyCamera({ yaw: 0, pitch: 0 });

const desktop = createDesktopControls({ rig, domElement: renderer.domElement });
$btnThird?.addEventListener("click", ()=>{
  const on = rig.toggleThirdPerson();
  $btnThird.textContent = on ? "Camera: 3rd" : "Camera: 1st";
});

// Quality (caps DPR). High=1.25, Low=1.0
window.SVR_MAX_DPR = 1.25;
let _qualityHigh = true;
$btnQuality?.addEventListener("click", ()=>{
  _qualityHigh = !_qualityHigh;
  window.SVR_MAX_DPR = _qualityHigh ? 1.25 : 1.0;
  $btnQuality.textContent = _qualityHigh ? "Quality: High" : "Quality: Low";
  // Re-apply DPR immediately
  renderer.setPixelRatio(Math.max(1, Math.min(window.SVR_MAX_DPR, (window.devicePixelRatio||1))));
});

$btnRecenter?.addEventListener("click", ()=>{
  rig.recenter();
  rig.applyCamera({ yaw: 0, pitch: 0 });
  desktop.setYawPitch(0,0);
  log("[OK] Recenter -> spawn");
  log("[ASSETS] Base override:", (window.SVR_ASSET_BASE||"(none)"));
});

$status.textContent="Loading world…";
const { roomClamp } = await buildSkylineRoom(scene, { log });

function spawnNearTable(){
  const t = scene.userData.table;
  if (!t) return false;
  // Spawn 3m from table toward +Z (behind player facing origin)
  const pos = new THREE.Vector3();
  t.getWorldPosition(pos);
  rig.player.position.set(pos.x, 0, pos.z + 3.0);
  rig.applyCamera({ yaw: Math.PI, pitch: 0 });
  desktop.setYawPitch(Math.PI, 0);
  log("[OK] Spawned 3m from table");
  return true;
}

// try immediate, then retry a few times while assets stream
let _spawnTries=0; const _spawnTimer=setInterval(()=>{ if (spawnNearTable()||_spawnTries++>20) clearInterval(_spawnTimer); }, 350);


const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
const watch = createWristWatch({ scene, renderer, log });

// Logo texture (CDN first)
const loader=new THREE.TextureLoader();
const LOGO_URLS = [...urlsFor("logo.png"), ...urlsFor("ui/logo.png")];
function loadTexture(url){
  return new Promise((resolve)=> loader.load(url, (t)=>{ t.colorSpace=THREE.SRGBColorSpace; t.anisotropy=8; resolve(t); }, undefined, ()=>resolve(null)));
}

$status.textContent="Loading logo…";
let tex=null;
for (const u of LOGO_URLS){
  tex = await loadTexture(u);
  if (tex) break;
}
tp.setLogoTexture(tex);

$status.textContent="Ready. Enter VR.";
$mode.textContent="Hands: waiting…";

function setHudVisible(visible){
  const hud=document.getElementById("hud");
  if (hud) hud.style.display = visible ? "flex" : "none";
  $log.style.display="none";
  $err.style.display="none";
}
renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});
renderer.xr.addEventListener("sessionend", ()=>{ setHudVisible(true); });


let _fpsAcc = 0, _fpsFrames = 0, _fpsLast = performance.now();

let _tPrev=performance.now();
renderer.setAnimationLoop(()=>{
  const now=performance.now();
  const dt=Math.min((now-_tPrev)/1000,0.033);
  _tPrev=now;

  if (!renderer.xr.isPresenting){
    if (roomClamp) {
      if (typeof roomClamp === "function") {
        roomClamp(rig.player.position);
      } else if (typeof roomClamp === "number") {
        const r = roomClamp;
        const x = rig.player.position.x;
        const z = rig.player.position.z;
        const d = Math.hypot(x, z);
        if (d > r && d > 0.0001) {
          const s = r / d;
          rig.player.position.x = x * s;
          rig.player.position.z = z * s;
        }
      } else if (roomClamp && typeof roomClamp.clamp === "function") {
        roomClamp.clamp(rig.player.position);
      }
    }
    desktop.update(dt);
  }
  if (scene.userData._tickWorld) scene.userData._tickWorld(dt);
  const spr = scene.userData._sprites;
  if (spr){
    for (const s of spr){
      s.position.y += s.userData.v * dt;
      if (s.position.y > 22) s.position.y = 0.5;
    }
  }

  watch.update(dt, hands.getLeft(), hands.getRight());

  tp.update({
    leftHand: hands.getLeft(),
    rightHand: hands.getRight(),
    statusCb: (t)=>{ $status.textContent=t; },
    modeCb: (t)=>{ $mode.textContent=t; },
  });

  
  // FPS meter (updates ~2x/sec)
  _fpsAcc += dt; _fpsFrames += 1;
  if (now - _fpsLast > 500) {
    const fps = Math.round(_fpsFrames / _fpsAcc);
    if ($fps) $fps.textContent = "FPS: " + fps;
    _fpsAcc = 0; _fpsFrames = 0; _fpsLast = now;
  }

  renderer.render(scene, camera);
});

// Context loss guard
const canvasEl = renderer.domElement;
canvasEl.addEventListener("webglcontextlost", (e)=>{
  e.preventDefault();
  log("[ERR] WebGL context lost. Reloading…");
  const st=document.getElementById("status");
  if (st) st.textContent="WebGL context lost (reloading…)";
  setTimeout(()=>location.reload(), 500);
}, false);
