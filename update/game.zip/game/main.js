
import { initScene } from './modules/scene.js';
import { initPlayer } from './modules/player.js';
import { initTeleport } from './modules/teleport.js';
import { initEnvironment } from './modules/environment.js';

console.log("SVR Poker Engine Booting...");

initScene();
initEnvironment();
initPlayer();
initTeleport();
