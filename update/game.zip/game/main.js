import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

const app = document.getElementById('app');
const statusEl = document.getElementById('status');
const modeEl = document.getElementById('mode');
const errorEl = document.getElementById('error');
const teleportBtn = document.getElementById('teleportBtn');
const radioBtn = document.getElementById('radioBtn');
const watchTime = document.getElementById('watchTime');
const crosshair = document.getElementById('crosshair');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x03030a);
scene.fog = new THREE.FogExp2(0x05050d, 0.0135);

const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.05, 320);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
app.appendChild(renderer.domElement);

const world = new THREE.Group();
scene.add(world);

const player = {
  pos: new THREE.Vector3(0, 1.62, 5.3),
  yaw: Math.PI,
  pitch: -0.05,
  speed: 4.6,
  lookSpeed: 0.00235,
  teleportMode: false
};
const roomRadius = 28;
const safeRadius = roomRadius - 2.5;
const keys = new Set();
const velocity = new THREE.Vector3();
const forward = new THREE.Vector3();
const right = new THREE.Vector3();
const up = new THREE.Vector3(0, 1, 0);
let pointerLocked = false;
let floorMesh;
let wallLightBand;
let neonRing;

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const texLoader = new THREE.TextureLoader();
let audioCtx = null;
let radioNodes = null;

const tableAnchor = new THREE.Group();
world.add(tableAnchor);

function showError(message) {
  errorEl.textContent = message;
  errorEl.classList.remove('hidden');
}
window.addEventListener('error', (event) => showError(event?.error?.stack || event.message || 'Runtime error'));
window.addEventListener('unhandledrejection', (event) => showError(String(event.reason || 'Promise rejection')));

function updateCamera() {
  camera.rotation.order = 'YXZ';
  camera.position.copy(player.pos);
  camera.rotation.y = player.yaw;
  camera.rotation.x = player.pitch;
}
function clampInsideRoom(vec) {
  const len = Math.hypot(vec.x, vec.z);
  if (len > safeRadius) {
    const scale = safeRadius / len;
    vec.x *= scale;
    vec.z *= scale;
  }
  vec.y = 1.62;
}
updateCamera();

// lights
scene.add(new THREE.HemisphereLight(0xf2f6ff, 0x060713, 1.5));
const keyLight = new THREE.PointLight(0xffffff, 2.9, 140, 2.0);
keyLight.position.set(0, 13.5, 0);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(1024, 1024);
scene.add(keyLight);
const magenta = new THREE.PointLight(0xc66bff, 2.5, 56, 2.0);
magenta.position.set(-7, 5.5, 5);
scene.add(magenta);
const cyan = new THREE.PointLight(0x61e3ff, 2.2, 58, 2.0);
cyan.position.set(7, 5.6, -4);
scene.add(cyan);
const skylineGlow = new THREE.PointLight(0x88b8ff, 1.5, 180, 2.0);
skylineGlow.position.set(0, 9, -24);
scene.add(skylineGlow);
const rimLight = new THREE.DirectionalLight(0xcfe0ff, 0.9);
rimLight.position.set(10, 16, 8);
scene.add(rimLight);

// ground and room shell
floorMesh = new THREE.Mesh(
  new THREE.CircleGeometry(roomRadius + 18, 192),
  new THREE.MeshStandardMaterial({ color: 0x05050a, roughness: 0.94, metalness: 0.04 })
);
floorMesh.rotation.x = -Math.PI / 2;
floorMesh.receiveShadow = true;
world.add(floorMesh);

const wall = new THREE.Mesh(
  new THREE.CylinderGeometry(roomRadius, roomRadius, 18, 160, 1, true),
  new THREE.MeshStandardMaterial({
    color: 0x060610,
    roughness: 0.86,
    metalness: 0.08,
    emissive: 0x160b25,
    emissiveIntensity: 0.3,
    side: THREE.BackSide
  })
);
wall.position.y = 9;
world.add(wall);

wallLightBand = new THREE.Mesh(
  new THREE.TorusGeometry(roomRadius - 0.55, 0.16, 14, 220),
  new THREE.MeshStandardMaterial({ color: 0xc873ff, roughness: 0.22, metalness: 0.3, emissive: 0x6b31d7, emissiveIntensity: 0.8 })
);
wallLightBand.rotation.x = Math.PI / 2;
wallLightBand.position.y = 15.5;
world.add(wallLightBand);

neonRing = new THREE.Mesh(
  new THREE.RingGeometry(roomRadius - 6.4, roomRadius - 5.9, 128),
  new THREE.MeshBasicMaterial({ color: 0x411369, transparent: true, opacity: 0.22, side: THREE.DoubleSide })
);
neonRing.rotation.x = -Math.PI / 2;
neonRing.position.y = 0.012;
world.add(neonRing);

// moon + stars
const moon = new THREE.Mesh(
  new THREE.SphereGeometry(5.6, 40, 40),
  new THREE.MeshStandardMaterial({ color: 0xe6ecff, emissive: 0x4f5fb1, emissiveIntensity: 0.28, roughness: 1 })
);
moon.position.set(-20, 20, -46);
world.add(moon);
const moonGlow = new THREE.PointLight(0xb0bfff, 2.1, 160, 2.0);
moonGlow.position.copy(moon.position);
scene.add(moonGlow);

(function addStars() {
  const positions = [];
  for (let i = 0; i < 1900; i++) {
    const radius = 74 + Math.random() * 48;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.45;
    const x = Math.cos(theta) * Math.cos(phi) * radius;
    const y = 10 + Math.sin(phi) * radius * 0.28 + Math.random() * 16;
    const z = Math.sin(theta) * Math.cos(phi) * radius;
    positions.push(x, y, z);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  const m = new THREE.PointsMaterial({ color: 0xd9ebff, size: 0.18, transparent: true, opacity: 0.88, depthWrite: false });
  world.add(new THREE.Points(g, m));
})();

// skyline
(function buildSkyline() {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x0d0e17, roughness: 0.84, metalness: 0.12, emissive: 0x120a20, emissiveIntensity: 0.25 });
  const winMat = new THREE.MeshStandardMaterial({ color: 0xa8e8ff, emissive: 0x7ec8ff, emissiveIntensity: 0.6, roughness: 0.22, metalness: 0.34 });
  const count = 210;
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2;
    const rr = roomRadius + 8 + Math.random() * 14;
    const h = 7 + Math.random() * 29;
    const w = 1.2 + Math.random() * 3.6;
    const d = 1.2 + Math.random() * 3.6;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;
    const building = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), bodyMat);
    building.position.set(x, h * 0.5, z);
    building.rotation.y = -a + Math.PI / 2;
    group.add(building);
    if (Math.random() > 0.14) {
      const stripCount = 1 + Math.floor(Math.random() * 3);
      for (let s = 0; s < stripCount; s++) {
        const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.88, 0.12, d * 1.04), winMat);
        strip.position.set(x, 1.5 + (s + 1) * (h / (stripCount + 1)), z);
        strip.rotation.y = building.rotation.y;
        group.add(strip);
      }
    }
  }
  world.add(group);
})();

// atmosphere sprites - smaller and more spread out
const spriteGroup = new THREE.Group();
world.add(spriteGroup);
const spriteTexture = (() => {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.18, 'rgba(97,227,255,0.75)');
  g.addColorStop(0.45, 'rgba(190,99,255,0.25)');
  g.addColorStop(1, 'rgba(190,99,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
})();
for (let i = 0; i < 90; i++) {
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: spriteTexture, color: 0xffffff, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false }));
  const radius = 4 + Math.random() * 14;
  const angle = Math.random() * Math.PI * 2;
  sprite.position.set(Math.cos(angle) * radius, Math.random() * 9, Math.sin(angle) * radius);
  const scale = 0.18 + Math.random() * 0.34;
  sprite.scale.setScalar(scale);
  sprite.userData.speed = 0.32 + Math.random() * 0.8;
  sprite.userData.phase = Math.random() * Math.PI * 2;
  sprite.userData.radius = radius;
  spriteGroup.add(sprite);
}

// table placeholder until real asset loads
const placeholderGroup = new THREE.Group();
tableAnchor.add(placeholderGroup);
const placeholderEdge = new THREE.Mesh(
  new THREE.CylinderGeometry(2.2, 2.2, 0.34, 64),
  new THREE.MeshStandardMaterial({ color: 0x181528, roughness: 0.28, metalness: 0.32, emissive: 0x180f28, emissiveIntensity: 0.28 })
);
placeholderEdge.position.y = 0.96;
placeholderEdge.castShadow = true;
placeholderGroup.add(placeholderEdge);
const placeholderStem = new THREE.Mesh(
  new THREE.CylinderGeometry(0.35, 0.42, 1.08, 22),
  new THREE.MeshStandardMaterial({ color: 0x120f1e, roughness: 0.54, metalness: 0.16 })
);
placeholderStem.position.y = 0.44;
placeholderStem.castShadow = true;
placeholderGroup.add(placeholderStem);

let tableTopY = 1.18;
let tableRadius = 2.2;
const topDecor = new THREE.Group();
const chairGroup = new THREE.Group();
tableAnchor.add(topDecor);
tableAnchor.add(chairGroup);

function clearTopDecor() {
  while (topDecor.children.length) topDecor.remove(topDecor.children[0]);
}

function buildTopDecor() {
  clearTopDecor();
  const feltTexture = texLoader.load('./assets/tablefelt.png');
  feltTexture.colorSpace = THREE.SRGBColorSpace;
  feltTexture.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1;
  const felt = new THREE.Mesh(
    new THREE.PlaneGeometry(tableRadius * 2.1, tableRadius * 2.1),
    new THREE.MeshStandardMaterial({ map: feltTexture, roughness: 0.92, metalness: 0.02, emissive: 0x091c18, emissiveIntensity: 0.08 })
  );
  felt.rotation.x = -Math.PI / 2;
  felt.position.y = tableTopY + 0.012;
  topDecor.add(felt);

  const trim = new THREE.Mesh(
    new THREE.TorusGeometry(tableRadius * 0.86, 0.05, 12, 140),
    new THREE.MeshStandardMaterial({ color: 0xbf73ff, roughness: 0.25, metalness: 0.3, emissive: 0x612ad8, emissiveIntensity: 0.85 })
  );
  trim.rotation.x = Math.PI / 2;
  trim.position.y = tableTopY + 0.028;
  topDecor.add(trim);

  const chipColors = [0xff4f86, 0x61e3ff, 0xf5df7b, 0xffffff, 0x9f7cff];
  const makeChipStack = (x, z, count = 5) => {
    const color = chipColors[(Math.random() * chipColors.length) | 0];
    const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.3, metalness: 0.08, emissive: color, emissiveIntensity: 0.08 });
    for (let i = 0; i < count; i++) {
      const c = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.03, 24), mat);
      c.position.set(x, tableTopY + 0.03 + i * 0.03, z);
      c.castShadow = true;
      topDecor.add(c);
    }
  };

  makeChipStack(-0.82, 0.66, 4);
  makeChipStack(0.82, -0.66, 4);
  makeChipStack(0.26, -0.18, 5);

  for (const [x, z, rot] of [[0.18, 0.56, -0.18], [0.45, 0.58, 0.08]]) {
    const card = new THREE.Mesh(
      new THREE.BoxGeometry(0.42, 0.016, 0.62),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95 })
    );
    card.position.set(x, tableTopY + 0.018, z);
    card.rotation.y = rot;
    card.castShadow = true;
    topDecor.add(card);
  }
}

function rebuildSeating() {
  chairGroup.clear();
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const group = new THREE.Group();
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.2, 0.84), new THREE.MeshStandardMaterial({ color: 0x2a1d42, roughness: 0.62 }));
    seat.position.y = 0.52;
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.9, 0.14), new THREE.MeshStandardMaterial({ color: 0x41245f, roughness: 0.6 }));
    back.position.set(0, 1.02, -0.31);
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.54, 12), new THREE.MeshStandardMaterial({ color: 0x15111f, roughness: 0.45 }));
    leg.position.y = 0.23;
    group.add(seat, back, leg);
    const radius = tableRadius + 0.92;
    group.position.set(Math.sin(angle) * radius, 0, Math.cos(angle) * radius);
    group.rotation.y = angle + Math.PI;
    chairGroup.add(group);
  }
}
rebuildSeating();

async function loadTableModel() {
  const loader = new GLTFLoader();
  try {
    const gltf = await loader.loadAsync('./assets/table.glb');
    const model = gltf.scene;
    model.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      if (child.material) {
        child.material = child.material.clone();
        child.material.roughness = Math.min(1, child.material.roughness ?? 0.68);
        child.material.metalness = child.material.metalness ?? 0.08;
      }
    });

    const box = new THREE.Box3().setFromObject(model);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);
    const targetWidth = 5.8;
    const scale = targetWidth / Math.max(size.x, size.z, 0.001);
    model.scale.setScalar(scale);
    model.updateMatrixWorld(true);

    const scaledBox = new THREE.Box3().setFromObject(model);
    const scaledSize = new THREE.Vector3();
    const scaledCenter = new THREE.Vector3();
    scaledBox.getSize(scaledSize);
    scaledBox.getCenter(scaledCenter);
    model.position.set(-scaledCenter.x, -scaledBox.min.y, -scaledCenter.z);
    model.rotation.y = Math.PI;
    tableAnchor.add(model);

    tableRadius = Math.max(scaledSize.x, scaledSize.z) * 0.34;
    tableTopY = scaledSize.y + 0.01;
    rebuildSeating();
    buildTopDecor();
    placeholderGroup.visible = false;
    statusEl.textContent = 'Room loaded. Real table asset is online.';
  } catch (err) {
    console.warn('Table fallback', err);
    buildTopDecor();
    statusEl.textContent = 'Room loaded. Fallback table is active.';
  }
}
loadTableModel();

function buildFallbackEric() {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x7d72ff, roughness: 0.58, emissive: 0x2d1b52, emissiveIntensity: 0.35 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.9, 6, 12), mat);
  body.position.y = 1.02;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 24, 24), new THREE.MeshStandardMaterial({ color: 0xd8c2aa, roughness: 0.8 }));
  head.position.y = 1.76;
  group.add(body, head);
  group.position.set(-0.1, 0, -3.55);
  group.rotation.y = Math.PI;
  tableAnchor.add(group);
}

(async function loadEric() {
  try {
    const loader = new FBXLoader();
    const obj = await loader.loadAsync('./assets/eric.fbx');
    const diffuse = await new Promise((resolve) => texLoader.load('./assets/eric-diffuse.jpg', resolve, undefined, () => resolve(null)));
    if (diffuse) diffuse.colorSpace = THREE.SRGBColorSpace;
    obj.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      child.material = new THREE.MeshStandardMaterial({
        map: diffuse || null,
        color: diffuse ? 0xffffff : 0x7d72ff,
        roughness: 0.72,
        metalness: 0.03,
        emissive: 0x140d21,
        emissiveIntensity: 0.08
      });
    });
    const box = new THREE.Box3().setFromObject(obj);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);
    const targetHeight = 1.72;
    const scale = targetHeight / Math.max(size.y, 0.001);
    obj.scale.setScalar(scale);
    obj.updateMatrixWorld(true);
    const scaledBox = new THREE.Box3().setFromObject(obj);
    const scaledCenter = new THREE.Vector3();
    scaledBox.getCenter(scaledCenter);
    obj.position.set(-scaledCenter.x, -scaledBox.min.y, -3.55);
    obj.rotation.y = Math.PI;
    tableAnchor.add(obj);
  } catch (error) {
    console.warn('Eric fallback', error);
    buildFallbackEric();
  }
})();

// radio prop
const radio = new THREE.Group();
const radioBody = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.38, 0.28), new THREE.MeshStandardMaterial({ color: 0x171422, roughness: 0.55 }));
const radioScreen = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 0.03), new THREE.MeshStandardMaterial({ color: 0x59d7ff, emissive: 0x59d7ff, emissiveIntensity: 0.6 }));
radioScreen.position.set(0, 0.05, 0.145);
const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.5, 8), new THREE.MeshStandardMaterial({ color: 0xa8b8ff, roughness: 0.2 }));
antenna.position.set(0.26, 0.38, 0.02);
radio.add(radioBody, radioScreen, antenna);
radio.position.set(-6.2, 0.22, 6.1);
world.add(radio);

// teleport marker
const tpGroup = new THREE.Group();
const tpRing = new THREE.Mesh(new THREE.RingGeometry(0.32, 0.5, 48), new THREE.MeshStandardMaterial({ color: 0xb663ff, emissive: 0x5a28c8, emissiveIntensity: 1.0, side: THREE.DoubleSide }));
tpRing.rotation.x = -Math.PI / 2;
const tpDisc = new THREE.Mesh(new THREE.CircleGeometry(0.28, 40), new THREE.MeshBasicMaterial({ map: texLoader.load('./assets/logo.webp'), transparent: true, opacity: 0.92 }));
tpDisc.rotation.x = -Math.PI / 2;
tpDisc.position.y = 0.002;
tpGroup.add(tpRing, tpDisc);
tpGroup.visible = false;
world.add(tpGroup);

function placeTeleportMarker(point) {
  const target = point.clone();
  target.y = 0.012;
  tpGroup.position.copy(target);
  tpGroup.visible = true;
}
function performTeleport(target) {
  const desired = new THREE.Vector3(target.x, 1.62, target.z);
  clampInsideRoom(desired);
  player.pos.copy(desired);
  updateCamera();
}

teleportBtn.addEventListener('click', () => {
  player.teleportMode = !player.teleportMode;
  teleportBtn.classList.toggle('active', player.teleportMode);
  teleportBtn.textContent = `Teleport: ${player.teleportMode ? 'On' : 'Off'}`;
  tpGroup.visible = false;
  modeEl.textContent = player.teleportMode ? 'Teleport enabled. Tap or click the floor to jump.' : 'Desktop: click to lock • WASD move • Mouse look • T teleport • Mobile: dual sticks';
});
window.addEventListener('keydown', (event) => {
  keys.add(event.code);
  if (event.code === 'KeyT') teleportBtn.click();
});
window.addEventListener('keyup', (event) => keys.delete(event.code));

renderer.domElement.addEventListener('click', () => {
  if (!pointerLocked && matchMedia('(hover:hover)').matches && !player.teleportMode) renderer.domElement.requestPointerLock?.();
});
document.addEventListener('pointerlockchange', () => {
  pointerLocked = document.pointerLockElement === renderer.domElement;
  crosshair.classList.toggle('active', pointerLocked && !matchMedia('(hover:none)').matches);
});
document.addEventListener('mousemove', (event) => {
  if (!pointerLocked) return;
  player.yaw -= event.movementX * player.lookSpeed;
  player.pitch -= event.movementY * player.lookSpeed;
  player.pitch = THREE.MathUtils.clamp(player.pitch, -1.05, 1.05);
});

function pickFloor(clientX, clientY) {
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const hit = raycaster.intersectObject(floorMesh, false)[0];
  return hit?.point || null;
}
renderer.domElement.addEventListener('pointerdown', (event) => {
  if (!player.teleportMode) return;
  const point = pickFloor(event.clientX, event.clientY);
  if (!point) return;
  placeTeleportMarker(point);
  performTeleport(point);
});

// mobile joysticks
const stickState = {
  move: { active: false, id: null, origin: new THREE.Vector2(), delta: new THREE.Vector2() },
  look: { active: false, id: null, origin: new THREE.Vector2(), delta: new THREE.Vector2() }
};
const moveZone = document.getElementById('moveZone');
const lookZone = document.getElementById('lookZone');
const moveKnob = document.getElementById('moveKnob');
const lookKnob = document.getElementById('lookKnob');

function setupStick(zone, knob, state) {
  const reset = () => {
    state.active = false;
    state.id = null;
    state.delta.set(0, 0);
    knob.style.transform = 'translate(0px, 0px)';
  };
  zone.addEventListener('pointerdown', (event) => {
    state.active = true;
    state.id = event.pointerId;
    state.origin.set(event.clientX, event.clientY);
    zone.setPointerCapture(event.pointerId);
  });
  zone.addEventListener('pointermove', (event) => {
    if (!state.active || event.pointerId !== state.id) return;
    const dx = event.clientX - state.origin.x;
    const dy = event.clientY - state.origin.y;
    const limit = 40;
    const len = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(limit, len);
    state.delta.set((dx / len) * (clamped / limit), (dy / len) * (clamped / limit));
    knob.style.transform = `translate(${state.delta.x * limit}px, ${state.delta.y * limit}px)`;
  });
  const end = (event) => {
    if (event.pointerId !== state.id) return;
    reset();
  };
  zone.addEventListener('pointerup', end);
  zone.addEventListener('pointercancel', end);
}
setupStick(moveZone, moveKnob, stickState.move);
setupStick(lookZone, lookKnob, stickState.look);

function updateWatch() {
  const now = new Date();
  watchTime.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
setInterval(updateWatch, 1000);
updateWatch();

function toggleRadio() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();
  if (radioNodes) {
    radioNodes.gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.2);
    setTimeout(() => {
      radioNodes.osc1.stop();
      radioNodes.osc2.stop();
      radioNodes.filter.disconnect();
      radioNodes.gain.disconnect();
      radioNodes = null;
    }, 260);
    radioBtn.classList.remove('active');
    radioBtn.textContent = 'Radio: Off';
    return;
  }
  const osc1 = audioCtx.createOscillator();
  const osc2 = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const filter = audioCtx.createBiquadFilter();
  osc1.type = 'sawtooth';
  osc2.type = 'triangle';
  osc1.frequency.value = 164.81;
  osc2.frequency.value = 220;
  filter.type = 'lowpass';
  filter.frequency.value = 920;
  gain.gain.value = 0.0001;
  osc1.connect(filter); osc2.connect(filter); filter.connect(gain); gain.connect(audioCtx.destination);
  osc1.start(); osc2.start();
  gain.gain.exponentialRampToValueAtTime(0.032, audioCtx.currentTime + 0.4);
  radioNodes = { osc1, osc2, filter, gain };
  radioBtn.classList.add('active');
  radioBtn.textContent = 'Radio: On';
}
radioBtn.addEventListener('click', toggleRadio);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

const clock = new THREE.Clock();
function animate() {
  const dt = Math.min(clock.getDelta(), 0.033);

  if (pointerLocked) {
    forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
    right.copy(forward).cross(up).normalize();
    velocity.set(0, 0, 0);
    if (keys.has('KeyW')) velocity.add(forward);
    if (keys.has('KeyS')) velocity.addScaledVector(forward, -1);
    if (keys.has('KeyD')) velocity.add(right);
    if (keys.has('KeyA')) velocity.addScaledVector(right, -1);
    if (velocity.lengthSq() > 0) velocity.normalize().multiplyScalar(player.speed * dt);
    player.pos.add(velocity);
  }

  if (stickState.move.active) {
    forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
    right.copy(forward).cross(up).normalize();
    const moveForward = -stickState.move.delta.y;
    const moveStrafe = stickState.move.delta.x;
    player.pos.addScaledVector(forward, moveForward * player.speed * dt);
    player.pos.addScaledVector(right, moveStrafe * player.speed * dt);
  }
  if (stickState.look.active) {
    player.yaw -= stickState.look.delta.x * 1.75 * dt;
    player.pitch -= stickState.look.delta.y * 1.25 * dt;
    player.pitch = THREE.MathUtils.clamp(player.pitch, -1.0, 1.0);
  }

  clampInsideRoom(player.pos);
  updateCamera();

  const t = performance.now();
  wallLightBand.material.emissiveIntensity = 0.78 + Math.sin(t * 0.0017) * 0.14;
  neonRing.material.opacity = 0.18 + Math.sin(t * 0.0014) * 0.03;

  for (const sprite of spriteGroup.children) {
    sprite.position.y += sprite.userData.speed * dt;
    sprite.position.x += Math.sin(t * 0.00035 + sprite.userData.phase) * 0.0025;
    sprite.position.z += Math.cos(t * 0.00028 + sprite.userData.phase) * 0.0025;
    if (sprite.position.y > 12.5) {
      const radius = 4 + Math.random() * 14;
      const angle = Math.random() * Math.PI * 2;
      sprite.position.y = 0.12 + Math.random() * 1.8;
      sprite.position.x = Math.cos(angle) * radius;
      sprite.position.z = Math.sin(angle) * radius;
    }
  }

  if (tpGroup.visible) {
    tpGroup.rotation.y += dt * 1.8;
    tpRing.material.emissiveIntensity = 0.9 + Math.sin(t * 0.006) * 0.16;
  }

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}

statusEl.textContent = 'Room loaded. Spawn is set about 3 meters from the table edge.';
requestAnimationFrame(animate);
