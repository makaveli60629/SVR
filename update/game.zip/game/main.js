window.__SVR_BOOT_STARTED = true;
if (window.__SVR_BOOT_TIMER) clearTimeout(window.__SVR_BOOT_TIMER);
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createHands } from "./modules/hands.js";
import { createTeleportRig } from "./modules/teleport.js";
import { buildSkylineRoom } from "./modules/world_skyline.js";
import { urlsFor } from "./modules/asset_base.js";
import { createWristWatch } from "./modules/watch.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $err = document.getElementById("err");
const $toggleLog = document.getElementById("toggleLog");

function log(...args) {
  const line = args
    .map((a) => (typeof a === "string" ? a : JSON.stringify(a, null, 2)))
    .join(" ");
  if ($log) {
    $log.textContent += line + "\n";
    $log.scrollTop = $log.scrollHeight;
  }
  console.log("[SVR]", ...args);
}

function showError(title, detail) {
  const text = `${title}\n${detail ?? "Unknown error"}`;
  if ($status) $status.textContent = title;
  if ($err) {
    $err.style.display = "block";
    $err.textContent = text;
  }
  console.error(text);
}

if ($toggleLog && $log) {
  $toggleLog.addEventListener("click", () => {
    $log.style.display = $log.style.display === "block" ? "none" : "block";
  });
}

async function loadTexture(loader, url) {
  return await new Promise((resolve) => {
    loader.load(
      url,
      (t) => {
        t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = 8;
        resolve(t);
      },
      undefined,
      () => resolve(null)
    );
  });
}

async function boot() {
  const { scene, camera, renderer } = createCore({ containerId: "app" });
  camera.position.set(0, 1.6, 4.4);

  window.addEventListener("error", (e) => {
    if (!renderer.xr.isPresenting && (e?.error || e?.message)) {
      showError("Runtime error", e?.error?.stack || e?.message || String(e));
    }
  });

  window.addEventListener("unhandledrejection", (e) => {
    if (!renderer.xr.isPresenting) {
      showError(
        "Unhandled promise rejection",
        e?.reason?.stack || e?.reason || String(e)
      );
    }
  });

  const desktop = createDesktopControls({
    camera,
    domElement: renderer.domElement,
  });

  if ($status) $status.textContent = "Loading world…";
  const { roomClamp } = await buildSkylineRoom(scene, { log });

  const hands = createHands({ scene, renderer, log });
  const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
  const watch = createWristWatch({ scene, renderer, log });

  const loader = new THREE.TextureLoader();
  const logoUrls = [...urlsFor("logo.png"), ...urlsFor("ui/logo.png")];

  if ($status) $status.textContent = "Loading teleport decal…";
  let tex = null;
  for (const u of logoUrls) {
    tex = await loadTexture(loader, u);
    if (tex) {
      log("Loaded logo texture:", u);
      break;
    }
  }
  if (!tex) {
    tex = await loadTexture(
      loader,
      new URL("./logo_fallback.png", import.meta.url).toString()
    );
    log("Using fallback logo texture.");
  }
  tp.setLogoTexture(tex);

  if ($status) {
    $status.textContent =
      "Ready. Desktop: click to look / WASD to move. VR: Enter VR.";
  }
  if ($mode) $mode.textContent = "Hands: waiting…";

  function setHudVisible(visible) {
    const hud = document.getElementById("hud");
    if (hud) hud.style.display = visible ? "flex" : "none";
    if (!visible) {
      if ($log) $log.style.display = "none";
      if ($err) $err.style.display = "none";
    }
  }

  renderer.xr.addEventListener("sessionstart", async () => {
    setHudVisible(false);
    await tp.onSessionStart();
  });
  renderer.xr.addEventListener("sessionend", () => {
    setHudVisible(true);
  });

  let tPrev = performance.now();
  renderer.setAnimationLoop(() => {
    const now = performance.now();
    const dt = Math.min((now - tPrev) / 1000, 0.033);
    tPrev = now;

    if (!renderer.xr.isPresenting) desktop.update(dt);
    if (scene.userData._tickWorld) scene.userData._tickWorld(dt);

    watch.update(dt, hands.getLeft(), hands.getRight());

    tp.update({
      leftHand: hands.getLeft(),
      rightHand: hands.getRight(),
      statusCb: (t) => {
        if ($status) $status.textContent = t;
      },
      modeCb: (t) => {
        if ($mode) $mode.textContent = t;
      },
    });

    renderer.render(scene, camera);
  });

  const canvasEl = renderer.domElement;
  canvasEl.addEventListener(
    "webglcontextlost",
    (e) => {
      e.preventDefault();
      log("[ERR] WebGL context lost. Reloading…");
      if ($status) $status.textContent = "WebGL context lost (reloading…)";
      setTimeout(() => location.reload(), 500);
    },
    false
  );
}

boot().catch((err) => {
  showError("Boot failed", err?.stack || err?.message || String(err));
});
