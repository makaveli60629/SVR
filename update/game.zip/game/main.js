import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createXRInput } from "./modules/xr_input.js";
import { createPlayerRig } from "./modules/player_rig.js";
import { buildWorld } from "./modules/world.js";
import { createWatch } from "./modules/watch.js";
import { createTeleportSystem } from "./modules/teleport.js";
import { createInteractionSystem } from "./modules/interaction.js";
import { createPokerDemo } from "./modules/poker_demo.js";
import { CONFIG } from "./modules/config.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $handState = document.getElementById("handState");
const $log = document.getElementById("log");
const $toggleLog = document.getElementById("toggleLog");
const $buildPill = document.getElementById("buildPill");
const QUERY = new URLSearchParams(window.location.search);
const IN_IFRAME = window.self !== window.top;
const PREVIEW_ONLY = QUERY.get("preview") === "1" || (IN_IFRAME && QUERY.get("play") !== "1");
const CAM_MODE = QUERY.get("cam") || (PREVIEW_ONLY ? "director" : "off");
if (PREVIEW_ONLY) document.body.classList.add("preview-only");
if ($buildPill) $buildPill.textContent = `BUILD: ${CONFIG.BUILD}`;

function log(...args) {
  const line = args.map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" ");
  if ($log) {
    $log.textContent += `${line}\n`;
    $log.scrollTop = $log.scrollHeight;
  }
  console.log(...args);
}

$toggleLog?.addEventListener("click", () => {
  $log.style.display = $log.style.display === "block" ? "none" : "block";
});

const { scene, camera, renderer, spectatorCamera, spectatorRenderer } = createCore({
  containerId: "app",
  spectatorCanvasId: "spectatorCanvas",
  previewOnly: PREVIEW_ONLY,
});

$status.textContent = PREVIEW_ONLY ? "CAM 3 preview booting…" : "Restoring polished lobby…";
const world = await buildWorld(scene, { log });
const poker = createPokerDemo({
  scene,
  chairRings: world.chairRings,
  statusCb: (text) => { if ($handState) $handState.textContent = text; },
  log,
});

if (PREVIEW_ONLY) {
  const tableLook = new THREE.Vector3(world.tableCenter.x, 1.22, world.tableCenter.z);
  let last = performance.now();
  let elapsedS = 0;
  const orbitShots = [
    { radius: 6.4, height: 3.1, angle: 0.2 },
    { radius: 5.7, height: 3.5, angle: 1.55 },
    { radius: 6.2, height: 2.8, angle: 3.2 },
    { radius: 5.5, height: 3.25, angle: 4.6 },
  ];

  const animatePreview = () => {
    const now = performance.now();
    const dt = Math.min((now - last) / 1000, 0.05);
    last = now;
    elapsedS += dt;
    scene.userData._tickWorld?.(now * 0.001);
    poker.update(now * 0.001, dt);

    const shotDuration = 4.2;
    const shotIndex = Math.floor(elapsedS / shotDuration) % orbitShots.length;
    const nextIndex = (shotIndex + 1) % orbitShots.length;
    const blend = (elapsedS % shotDuration) / shotDuration;
    const eased = blend * blend * (3 - 2 * blend);
    const a = orbitShots[shotIndex];
    const b = orbitShots[nextIndex];
    const radius = THREE.MathUtils.lerp(a.radius, b.radius, eased);
    const height = THREE.MathUtils.lerp(a.height, b.height, eased);
    const angle = THREE.MathUtils.lerp(a.angle, b.angle, eased) + elapsedS * 0.08;
    spectatorCamera.position.set(Math.cos(angle) * radius, height, Math.sin(angle) * radius);
    spectatorCamera.lookAt(tableLook.x + Math.sin(elapsedS * 0.23) * 0.08, tableLook.y + Math.sin(elapsedS * 0.4) * 0.03, tableLook.z + Math.cos(elapsedS * 0.27) * 0.08);
    spectatorRenderer.render(scene, spectatorCamera);
    requestAnimationFrame(animatePreview);
  };

  $status.textContent = "CAM 3 preview live";
  if ($handState) $handState.textContent = "AUTO DIRECTOR • live lobby preview";
  animatePreview();
  window.addEventListener("keydown", (e) => { if (e.code === "KeyN") poker.forceNextHand(); });
  log("SVR Poker preview ready", { build: CONFIG.BUILD, camMode: CAM_MODE, previewOnly: PREVIEW_ONLY });
} else {
  const desktop = createDesktopControls({ camera, domElement: renderer.domElement });
  desktop.setRoomClamp(world.roomClamp);
  const xrInput = createXRInput({ scene, renderer, log });
  const playerRig = createPlayerRig({ renderer, camera, desktopControls: desktop, roomClamp: world.roomClamp, log });
  playerRig.resetToSpawn();
  const watch = createWatch({ scene, camera, renderer });
  const teleport = createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp: world.roomClamp });
  const interaction = createInteractionSystem({ scene, camera, renderer, playerRig, seats: world.seats, watch, teleport, tableProps: world.tableProps, log });
  watch.setState({ teleportEnabled: false, seated: false, mode: "DESKTOP" });

  renderer.xr.addEventListener("sessionstart", async () => {
    await playerRig.onSessionStart();
    playerRig.resetToSpawn();
    watch.setState({ mode: "XR", teleportEnabled: false, seated: false });
    $mode.textContent = "Mode: XR";
    $status.textContent = "XR ready • watch active";
  });

  renderer.xr.addEventListener("sessionend", () => {
    teleport.setEnabled(false);
    interaction.releaseHeldProp();
    watch.setState({ teleportEnabled: false, mode: "DESKTOP" });
    playerRig.resetToSpawn();
    $mode.textContent = "Mode: desktop";
    $status.textContent = "Desktop ready";
  });

  let last = performance.now();
  renderer.setAnimationLoop(() => {
    const now = performance.now();
    const dt = Math.min((now - last) / 1000, 0.05);
    last = now;

    const xrPresenting = renderer.xr.isPresenting;
    const xrState = xrInput.getState();

    if (!xrPresenting) {
      desktop.update(dt);
      watch.setState({ mode: "DESKTOP" });
    } else {
      watch.setState({ mode: xrState.leftHand?.joints?.wrist ? "HAND" : "CTRL" });
    }

    const gp = xrState.rightController?.userData?.gamepad;
    if (xrPresenting && gp?.axes?.length >= 4) {
      const axisX = gp.axes[2] ?? gp.axes[0] ?? 0;
      if (Math.abs(axisX) > CONFIG.SNAP_DEADZONE && !xrState.rightController.userData.snapLatch) {
        xrState.rightController.userData.snapLatch = true;
        playerRig.snapTurn(THREE.MathUtils.degToRad(axisX > 0 ? -CONFIG.SNAP_TURN_DEG : CONFIG.SNAP_TURN_DEG));
      }
      if (Math.abs(axisX) < 0.2) xrState.rightController.userData.snapLatch = false;
    }

    interaction.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand });
    watch.updatePose({ leftHand: xrState.leftHand, leftController: xrState.leftController, rightController: xrState.rightController, xrPresenting });
    teleport.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand, statusCb: (t) => { $status.textContent = t; } });
    scene.userData._tickWorld?.(now * 0.001);
    poker.update(now * 0.001, dt);
    if (!playerRig.isSeated()) playerRig.ensureSafePosition();

    const seated = playerRig.isSeated();
    watch.setState({ seated, teleportEnabled: teleport.isEnabled() });
    $mode.textContent = xrPresenting ? `Mode: XR • ${teleport.isEnabled() ? "TP ON" : "TP OFF"}` : `Mode: desktop • ${seated ? "seated" : "standing"}`;
    renderer.render(scene, camera);
  });

  window.addEventListener("keydown", (e) => { if (e.code === "KeyN") poker.forceNextHand(); });
  $status.textContent = "Phase 59 ready • restored lobby baseline";
  if ($handState) $handState.textContent = "HAND 1 • real 52-card hold'em demo live";
  log("SVR Poker phase 59 ready", { build: CONFIG.BUILD, camMode: CAM_MODE, previewOnly: PREVIEW_ONLY, inIframe: IN_IFRAME });
}

window.addEventListener("error", (e) => {
  log("RUNTIME ERROR", e?.error?.stack || e?.message || String(e));
  $status.textContent = "Runtime error • open Logs";
});
window.addEventListener("unhandledrejection", (e) => {
  log("PROMISE ERROR", e?.reason?.stack || e?.reason || String(e));
  $status.textContent = "Promise rejection • open Logs";
});
