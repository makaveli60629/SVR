
const scene = new THREE.Scene()

scene.fog = new THREE.Fog(0x000000,30,120)

const camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,0.1,1000)
camera.position.set(0,1.6,6)

const renderer = new THREE.WebGLRenderer({antialias:true})
renderer.setSize(window.innerWidth,window.innerHeight)
renderer.xr.enabled=true

document.body.appendChild(renderer.domElement)
document.body.appendChild(VRButton.createButton(renderer))

const floor = new THREE.Mesh(
 new THREE.PlaneGeometry(60,60),
 new THREE.MeshStandardMaterial({color:0x111111})
)

floor.rotation.x = -Math.PI/2
scene.add(floor)

const hemi = new THREE.HemisphereLight(0xffffff,0x444444,2)
scene.add(hemi)

const table = new THREE.Mesh(
 new THREE.CylinderGeometry(1.4,1.4,0.15,32),
 new THREE.MeshStandardMaterial({color:0x050505,metalness:0.9,roughness:0.2})
)

table.position.set(0,1,0)
scene.add(table)

const seats = [
{x:0,z:1.4},
{x:1.4,z:0.7},
{x:1.4,z:-0.7},
{x:0,z:-1.4},
{x:-1.4,z:-0.7},
{x:-1.4,z:0.7}
]

const seatMeshes=[]

seats.forEach(seat=>{

const ring = new THREE.Mesh(
 new THREE.RingGeometry(0.35,0.45,32),
 new THREE.MeshBasicMaterial({color:0x6a00ff})
)

ring.rotation.x=-Math.PI/2
ring.position.set(seat.x,0.02,seat.z)

ring.userData = seat

scene.add(ring)
seatMeshes.push(ring)

})

for(let i=0;i<80;i++){

const building = new THREE.Mesh(
 new THREE.BoxGeometry(
  Math.random()*3+1,
  Math.random()*15+5,
  Math.random()*3+1
 ),
 new THREE.MeshStandardMaterial({
  color:0x2200ff,
  emissive:0x4400ff
 })
)

building.position.set(
 (Math.random()-0.5)*80,
 building.geometry.parameters.height/2,
 (Math.random()-0.5)*80
)

scene.add(building)

}

const raycaster = new THREE.Raycaster()
const mouse = new THREE.Vector2()

window.addEventListener("click",(event)=>{

mouse.x = (event.clientX/window.innerWidth)*2-1
mouse.y = -(event.clientY/window.innerHeight)*2+1

raycaster.setFromCamera(mouse,camera)

const hit = raycaster.intersectObjects(seatMeshes)

if(hit.length>0){

const seat = hit[0].object.userData

camera.position.set(seat.x,1.2,seat.z+0.3)
camera.lookAt(0,1,0)

}

})

renderer.setAnimationLoop(()=>{
renderer.render(scene,camera)
})
