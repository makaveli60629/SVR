import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createHands } from "./modules/hands.js";
import { createTeleportRig } from "./modules/teleport.js";
import { buildSkylineRoom } from "./modules/world_skyline.js";
import { urlsFor } from "./modules/asset_base.js";
import { createWristWatch } from "./modules/watch.js";

const $status=document.getElementById("status");
const $mode=document.getElementById("mode");
const $log=document.getElementById("log");
const $err=document.getElementById("err");
const $toggleLog=document.getElementById("toggleLog");

function log(...args){
  const line=args.map(a=> (typeof a==="string"?a:JSON.stringify(a,null,2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}
$toggleLog.addEventListener("click", ()=>{ $log.style.display = ($log.style.display==="none"||!$log.style.display)?"block":"none"; });

const { scene, camera, renderer } = createCore({ containerId:"app" });
camera.position.set(0,1.6,3);

window.addEventListener("error",(e)=>{ if (!renderer.xr.isPresenting){ $err.style.display="block"; } $err.textContent="RUNTIME ERROR:\n"+(e?.error?.stack||e?.message||String(e)); });
window.addEventListener("unhandledrejection",(e)=>{ if (!renderer.xr.isPresenting){ $err.style.display="block"; } $err.textContent="UNHANDLED PROMISE REJECTION:\n"+(e?.reason?.stack||e?.reason||String(e)); });

const desktop = createDesktopControls({ camera, domElement: renderer.domElement });

$status.textContent="Loading world…";
const { roomClamp } = await buildSkylineRoom(scene, { log });

const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
const watch = createWristWatch({ scene, renderer, log });

const U=(rel)=>new URL(rel, import.meta.url).toString();
const LOGO1=U("../assets/logo.png");
const LOGO1B=U("../../assets/logo.png");        // present in this zip
const LOGO2=U("../assets/logo.png");       // repo root
const LOGO3=U("../assets/ui/logo.png");    // alternate
const LOGO4=U("./logo_fallback.png");

const loader=new THREE.TextureLoader();
var LOGO_URLS = [...urlsFor("logo.png"), ...urlsFor("ui/logo.png")];
var LOGO_URLS = LOGO_URLS;
function loadTexture(url){
  return new Promise((resolve)=> loader.load(url, (t)=>{ t.colorSpace=THREE.SRGBColorSpace; t.anisotropy=8; resolve(t); }, undefined, ()=>resolve(null)));
}

$status.textContent="Loading logo…";
let tex=null;
for (const u of LOGO_URLS){
  tex = await loadTexture(u);
  if (tex) break;
}
if (!tex) tex = await loadTexture(LOGO3);
tp.setLogoTexture(tex);

$status.textContent="Ready. Enter VR.";
$mode.textContent="Hands: waiting…";

function setHudVisible(visible){
  const hud=document.getElementById("hud");
  if (hud) hud.style.display = visible ? "flex" : "none";
  $log.style.display="none";
  $err.style.display="none";
}
renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});
renderer.xr.addEventListener("sessionend", ()=>{ setHudVisible(true); });

let _tPrev=performance.now();
renderer.setAnimationLoop(()=>{
  const now=performance.now();
  const dt=Math.min((now-_tPrev)/1000,0.033);
  _tPrev=now;

  if (!renderer.xr.isPresenting) desktop.update(dt);
  if (scene.userData._tickWorld) scene.userData._tickWorld(dt);

  watch.update(dt, hands.getLeft(), hands.getRight());

  tp.update({
    leftHand: hands.getLeft(),
    rightHand: hands.getRight(),
    statusCb: (t)=>{ $status.textContent=t; },
    modeCb: (t)=>{ $mode.textContent=t; },
  });

  renderer.render(scene, camera);
});


// === CONTEXT LOSS GUARD ===
const canvasEl = renderer.domElement;
canvasEl.addEventListener("webglcontextlost", (e)=>{
  e.preventDefault();
  log("[ERR] WebGL context lost. Reloading…");
  const st=document.getElementById("status");
  if (st) st.textContent="WebGL context lost (reloading…)";
  setTimeout(()=>location.reload(), 500);
}, false);
