import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { VRButton } from "three/addons/webxr/VRButton.js";
import { XRControllerModelFactory } from "three/addons/webxr/XRControllerModelFactory.js";

const app = document.getElementById('app');
const statusEl = document.getElementById('status');
const modeEl = document.getElementById('mode');
const errorEl = document.getElementById('error');
const teleportBtn = document.getElementById('teleportBtn');
const radioBtn = document.getElementById('radioBtn');
const seatBtn = document.getElementById('seatBtn');
const watchTime = document.getElementById('watchTime');
const crosshair = document.getElementById('crosshair');
const seatHint = document.getElementById('seatHint');
const vrHelp = document.getElementById('vrHelp');
const embedMode = new URLSearchParams(window.location.search).get('embed') === '1';
if (embedMode) document.body.classList.add('embed-mode');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x03030a);
scene.fog = new THREE.FogExp2(0x05050d, 0.0135);

const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.05, 320);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.18;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.xr.enabled = true;
app.appendChild(renderer.domElement);
const vrButton = VRButton.createButton(renderer, {
  optionalFeatures: ['local-floor', 'bounded-floor', 'hand-tracking'],
  requiredFeatures: []
});
document.body.appendChild(vrButton);
if (embedMode) vrButton.style.display = 'none';

const world = new THREE.Group();
scene.add(world);

const player = {
  pos: new THREE.Vector3(0, 1.62, 5.6),
  yaw: Math.PI,
  pitch: -0.05,
  speed: 4.6,
  lookSpeed: 0.00235,
  teleportMode: false
};
const roomRadius = 28;
const safeRadius = roomRadius - 2.5;
const keys = new Set();
const velocity = new THREE.Vector3();
const forward = new THREE.Vector3();
const right = new THREE.Vector3();
const up = new THREE.Vector3(0, 1, 0);
let pointerLocked = false;
let floorMesh;
let wallLightBand;
let neonRing;

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const texLoader = new THREE.TextureLoader();
let audioCtx = null;
let radioNodes = null;

const tableAnchor = new THREE.Group();
world.add(tableAnchor);

const controllerFactory = new XRControllerModelFactory();
const controllers = [];
const controllerGrips = [];
for (let i = 0; i < 2; i++) {
  const controller = renderer.xr.getController(i);
  controller.userData.index = i;
  scene.add(controller);
  controllers.push(controller);

  const grip = renderer.xr.getControllerGrip(i);
  grip.add(controllerFactory.createControllerModel(grip));
  scene.add(grip);
  controllerGrips.push(grip);
}

const seatTarget = new THREE.Group();
const seatPad = new THREE.Mesh(
  new THREE.CylinderGeometry(0.34, 0.34, 0.02, 48),
  new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.68, metalness: 0.08, transparent: true, opacity: 0.9 })
);
seatPad.position.y = 0.03;
seatTarget.add(seatPad);
const seatRing = new THREE.Mesh(
  new THREE.TorusGeometry(0.42, 0.028, 12, 96),
  new THREE.MeshStandardMaterial({ color: 0xc56eff, roughness: 0.22, metalness: 0.34, emissive: 0x6d2ce0, emissiveIntensity: 0.9 })
);
seatRing.rotation.x = Math.PI / 2;
seatRing.position.y = 0.045;
seatTarget.add(seatRing);
seatTarget.visible = true;
tableAnchor.add(seatTarget);

let seated = false;
let seatFacing = Math.PI;
const moveVec = new THREE.Vector2();
const lookVec = new THREE.Vector2();
let xrTurnCooldown = 0;
const animatedCards = [];
let tableTopY = 1.18;
let tableRadius = 2.2;

const handRig = new THREE.Group();
camera.add(handRig);
scene.add(camera);
const handMaterial = new THREE.MeshStandardMaterial({ color: 0xe8d6ff, roughness: 0.72, metalness: 0.08, emissive: 0x1b1129, emissiveIntensity: 0.14 });
const gloveMaterial = new THREE.MeshStandardMaterial({ color: 0x28163c, roughness: 0.54, metalness: 0.12, emissive: 0x391561, emissiveIntensity: 0.24 });
const watchMaterial = new THREE.MeshStandardMaterial({ color: 0x67e2ff, roughness: 0.28, metalness: 0.52, emissive: 0x4ad1ff, emissiveIntensity: 0.6 });
function buildHand(side = 1) {
  const g = new THREE.Group();
  const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.2, 6, 12), gloveMaterial);
  forearm.rotation.z = Math.PI / 2;
  forearm.position.set(0, 0, 0);
  const palm = new THREE.Mesh(new THREE.SphereGeometry(0.08, 16, 16), handMaterial);
  palm.scale.set(1.15, 0.72, 1.35);
  palm.position.set(side * 0.17, -0.06, -0.09);
  const thumb = new THREE.Mesh(new THREE.CapsuleGeometry(0.022, 0.06, 4, 8), handMaterial);
  thumb.position.set(side * 0.245, -0.05, -0.045);
  thumb.rotation.z = side * 0.9;
  thumb.rotation.x = -0.3;
  const watch = new THREE.Group();
  const strap = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.01, 0.11), gloveMaterial);
  const face = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.012, 0.066), watchMaterial);
  face.position.y = 0.008;
  watch.add(strap, face);
  watch.position.set(side * 0.05, 0.03, 0.01);
  watch.rotation.x = 0.6;
  g.add(forearm, palm, thumb);
  if (side < 0) g.add(watch);
  g.position.set(side * 0.28, -0.24, -0.38);
  g.rotation.set(-0.34, side * 0.22, side * 0.06);
  return g;
}
const leftHand = buildHand(-1);
const rightHand = buildHand(1);
handRig.add(leftHand, rightHand);

function showError(message) {
  errorEl.textContent = message;
  errorEl.classList.remove('hidden');
}
window.addEventListener('error', (event) => showError(event?.error?.stack || event.message || 'Runtime error'));
window.addEventListener('unhandledrejection', (event) => showError(String(event.reason || 'Promise rejection')));

function updateCamera() {
  camera.rotation.order = 'YXZ';
  camera.position.copy(player.pos);
  camera.rotation.y = player.yaw;
  camera.rotation.x = player.pitch;
}
function clampInsideRoom(vec) {
  const len = Math.hypot(vec.x, vec.z);
  if (len > safeRadius) {
    const scale = safeRadius / len;
    vec.x *= scale;
    vec.z *= scale;
  }
  vec.y = 1.62;
}
function updateSeatTarget() {
  const radius = tableRadius + 1.02;
  seatTarget.position.set(0, 0, radius);
  seatFacing = Math.PI;
}
function placePlayerAtTableSpawn() {
  player.pos.set(0, 1.62, tableRadius + 3.0);
  player.yaw = Math.PI;
  player.pitch = -0.045;
  clampInsideRoom(player.pos);
  updateCamera();
}

function canSeat() {
  return player.pos.distanceTo(new THREE.Vector3(seatTarget.position.x, 1.62, seatTarget.position.z + 0.38)) < 2.2;
}
function updateSeatHint() {
  const visible = !renderer.xr.isPresenting && !seated && canSeat();
  seatHint.classList.toggle('hidden', !visible);
}
function toggleSeat(force = null) {
  const next = force == null ? !seated : force;
  if (next && !canSeat()) return;
  seated = next;
  if (seated) {
    player.pos.set(seatTarget.position.x, 1.62, seatTarget.position.z + 0.36);
    player.yaw = seatFacing;
    player.pitch = -0.02;
    pointerLocked = false;
    document.exitPointerLock?.();
    seatBtn.classList.add('active');
    seatBtn.textContent = 'Seat: Taken';
  } else {
    player.pos.z += 0.68;
    clampInsideRoom(player.pos);
    seatBtn.classList.remove('active');
    seatBtn.textContent = 'Seat: Open';
  }
  updateCamera();
  updateSeatHint();
}
updateSeatTarget();
placePlayerAtTableSpawn();

// lights
scene.add(new THREE.HemisphereLight(0xf2f6ff, 0x080814, 1.8));
const keyLight = new THREE.PointLight(0xffffff, 2.9, 140, 2.0);
keyLight.position.set(0, 13.5, 0);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(1024, 1024);
scene.add(keyLight);
const magenta = new THREE.PointLight(0xc66bff, 2.5, 56, 2.0);
magenta.position.set(-7, 5.5, 5);
scene.add(magenta);
const cyan = new THREE.PointLight(0x61e3ff, 2.8, 72, 2.0);
cyan.position.set(7, 6.4, -4);
scene.add(cyan);
const moonFill = new THREE.DirectionalLight(0xdbe5ff, 1.45);
moonFill.position.set(-18, 24, -36);
scene.add(moonFill);
const tablePink = new THREE.PointLight(0xff77f1, 2.2, 26, 2.0);
tablePink.position.set(-3.2, 4.4, 2.2);
scene.add(tablePink);
const tableBlue = new THREE.PointLight(0x73dfff, 2.0, 28, 2.0);
tableBlue.position.set(3.6, 4.2, -2.4);
scene.add(tableBlue);
const skylineWash = new THREE.HemisphereLight(0xaebdff, 0x090911, 0.9);
scene.add(skylineWash);
const skylineGlow = new THREE.PointLight(0x88b8ff, 1.5, 180, 2.0);
skylineGlow.position.set(0, 9, -24);
scene.add(skylineGlow);
const rimLight = new THREE.DirectionalLight(0xcfe0ff, 0.9);
rimLight.position.set(10, 16, 8);
scene.add(rimLight);
const ceilingGlow = new THREE.PointLight(0xa76cff, 2.4, 120, 2.0);
ceilingGlow.position.set(0, 17, 0);
scene.add(ceilingGlow);
const loungeFillA = new THREE.PointLight(0xff87eb, 1.4, 44, 2.0);
loungeFillA.position.set(-10, 3.8, 10);
scene.add(loungeFillA);
const loungeFillB = new THREE.PointLight(0x7ddfff, 1.55, 44, 2.0);
loungeFillB.position.set(10, 3.8, 10);
scene.add(loungeFillB);

// ground and room shell
floorMesh = new THREE.Mesh(
  new THREE.CircleGeometry(roomRadius + 18, 192),
  new THREE.MeshStandardMaterial({ color: 0x05050a, roughness: 0.94, metalness: 0.04 })
);
floorMesh.rotation.x = -Math.PI / 2;
floorMesh.receiveShadow = true;
world.add(floorMesh);

const wall = new THREE.Mesh(
  new THREE.CylinderGeometry(roomRadius, roomRadius, 18, 160, 1, true),
  new THREE.MeshStandardMaterial({
    color: 0x060610,
    roughness: 0.86,
    metalness: 0.08,
    emissive: 0x160b25,
    emissiveIntensity: 0.3,
    side: THREE.BackSide
  })
);
wall.position.y = 9;
world.add(wall);

wallLightBand = new THREE.Mesh(
  new THREE.TorusGeometry(roomRadius - 0.55, 0.16, 14, 220),
  new THREE.MeshStandardMaterial({ color: 0xc873ff, roughness: 0.22, metalness: 0.3, emissive: 0x6b31d7, emissiveIntensity: 0.8 })
);
wallLightBand.rotation.x = Math.PI / 2;
wallLightBand.position.y = 15.5;
world.add(wallLightBand);

neonRing = new THREE.Mesh(
  new THREE.RingGeometry(roomRadius - 6.4, roomRadius - 5.9, 128),
  new THREE.MeshBasicMaterial({ color: 0x411369, transparent: true, opacity: 0.22, side: THREE.DoubleSide })
);
neonRing.rotation.x = -Math.PI / 2;
neonRing.position.y = 0.012;
world.add(neonRing);

// moon + stars
const moonTexture = texLoader.load('./assets/moon-diffuse.webp');
moonTexture.colorSpace = THREE.SRGBColorSpace;
const moonBump = texLoader.load('./assets/moon-bump.webp');
const moon = new THREE.Mesh(
  new THREE.SphereGeometry(7.8, 64, 64),
  new THREE.MeshStandardMaterial({
    map: moonTexture,
    bumpMap: moonBump,
    bumpScale: 0.08,
    color: 0xf4f6ff,
    emissive: 0x4d6dcb,
    emissiveIntensity: 0.2,
    roughness: 0.98
  })
);
moon.position.set(-21, 25.5, -46);
world.add(moon);
const moonGlow = new THREE.PointLight(0xbcc8ff, 4.6, 240, 2.0);
moonGlow.position.copy(moon.position);
scene.add(moonGlow);

(function addStars() {
  const positions = [];
  for (let i = 0; i < 1900; i++) {
    const radius = 74 + Math.random() * 48;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.45;
    const x = Math.cos(theta) * Math.cos(phi) * radius;
    const y = 10 + Math.sin(phi) * radius * 0.28 + Math.random() * 16;
    const z = Math.sin(theta) * Math.cos(phi) * radius;
    positions.push(x, y, z);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  const m = new THREE.PointsMaterial({ color: 0xd9ebff, size: 0.18, transparent: true, opacity: 0.88, depthWrite: false });
  world.add(new THREE.Points(g, m));
})();

// skyline
(function buildSkyline() {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x0b0c14, roughness: 0.84, metalness: 0.12, emissive: 0x1a1030, emissiveIntensity: 0.34 });
  const winMat = new THREE.MeshStandardMaterial({ color: 0xc2ecff, emissive: 0x8fd2ff, emissiveIntensity: 0.84, roughness: 0.22, metalness: 0.34 });
  const redMat = new THREE.MeshStandardMaterial({ color: 0xff6e89, emissive: 0xff294d, emissiveIntensity: 1.2, roughness: 0.3, metalness: 0.18 });
  const count = 220;
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2;
    const radius = roomRadius + 6 + Math.random() * 8;
    const w = 1 + Math.random() * 2.5;
    const h = 4 + Math.random() * 18;
    const d = 1 + Math.random() * 2.5;
    const x = Math.sin(a) * radius;
    const z = Math.cos(a) * radius;
    const building = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), bodyMat);
    building.position.set(x, h * 0.5, z);
    building.rotation.y = -a + Math.PI / 2;
    building.castShadow = false;
    building.receiveShadow = true;
    group.add(building);

    const stripCount = 1 + Math.floor(Math.random() * 4);
    for (let s = 0; s < stripCount; s++) {
      const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.12, d * 1.04), winMat);
      strip.position.set(x, 1.3 + (s + 1) * (h / (stripCount + 1)), z);
      strip.rotation.y = building.rotation.y;
      group.add(strip);
    }

    if (h > 14 && Math.random() > 0.35) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.4, 10), new THREE.MeshStandardMaterial({ color: 0x394053, roughness: 0.7 }));
      pole.position.set(x, h + 0.7, z);
      group.add(pole);
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 16), redMat.clone());
      bulb.position.set(x, h + 1.45, z);
      bulb.userData.blink = Math.random() * Math.PI * 2;
      group.add(bulb);
    }
  }
  world.add(group);
  world.userData.skylineGroup = group;
})();

// atmosphere sprites - smaller and more spread out
const spriteGroup = new THREE.Group();
world.add(spriteGroup);
const spriteTexture = (() => {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.18, 'rgba(97,227,255,0.75)');
  g.addColorStop(0.45, 'rgba(190,99,255,0.25)');
  g.addColorStop(1, 'rgba(190,99,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
})();
for (let i = 0; i < 90; i++) {
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: spriteTexture, color: 0xffffff, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false }));
  const radius = 4 + Math.random() * 14;
  const angle = Math.random() * Math.PI * 2;
  sprite.position.set(Math.cos(angle) * radius, Math.random() * 9, Math.sin(angle) * radius);
  const scale = 0.18 + Math.random() * 0.34;
  sprite.scale.setScalar(scale);
  sprite.userData.speed = 0.32 + Math.random() * 0.8;
  sprite.userData.phase = Math.random() * Math.PI * 2;
  sprite.userData.radius = radius;
  spriteGroup.add(sprite);
}

// table placeholder until real asset loads
const placeholderGroup = new THREE.Group();
tableAnchor.add(placeholderGroup);
const placeholderEdge = new THREE.Mesh(
  new THREE.CylinderGeometry(2.2, 2.2, 0.34, 64),
  new THREE.MeshStandardMaterial({ color: 0x181528, roughness: 0.28, metalness: 0.32, emissive: 0x180f28, emissiveIntensity: 0.28 })
);
placeholderEdge.position.y = 0.96;
placeholderEdge.castShadow = true;
placeholderGroup.add(placeholderEdge);
const placeholderStem = new THREE.Mesh(
  new THREE.CylinderGeometry(0.35, 0.42, 1.08, 22),
  new THREE.MeshStandardMaterial({ color: 0x120f1e, roughness: 0.54, metalness: 0.16 })
);
placeholderStem.position.y = 0.44;
placeholderStem.castShadow = true;
placeholderGroup.add(placeholderStem);

const topDecor = new THREE.Group();
const chairGroup = new THREE.Group();
tableAnchor.add(topDecor);
tableAnchor.add(chairGroup);

function clearTopDecor() {
  while (topDecor.children.length) topDecor.remove(topDecor.children[0]);
}

function buildTopDecor() {
  clearTopDecor();
  const feltTexture = texLoader.load('./assets/tablefelt.png');
  feltTexture.colorSpace = THREE.SRGBColorSpace;
  feltTexture.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1;
  const felt = new THREE.Mesh(
    new THREE.PlaneGeometry(tableRadius * 2.06, tableRadius * 2.06),
    new THREE.MeshStandardMaterial({ map: feltTexture, roughness: 0.92, metalness: 0.02, emissive: 0x091c18, emissiveIntensity: 0.08 })
  );
  felt.rotation.x = -Math.PI / 2;
  felt.position.y = tableTopY + 0.012;
  topDecor.add(felt);

  const trim = new THREE.Mesh(
    new THREE.TorusGeometry(tableRadius * 0.88, 0.06, 12, 140),
    new THREE.MeshStandardMaterial({ color: 0xbf73ff, roughness: 0.25, metalness: 0.3, emissive: 0x612ad8, emissiveIntensity: 0.85 })
  );
  trim.rotation.x = Math.PI / 2;
  trim.position.y = tableTopY + 0.028;
  topDecor.add(trim);

  const centerLogoTexture = texLoader.load('./assets/logo-table-top.png');
  centerLogoTexture.colorSpace = THREE.SRGBColorSpace;
  const centerLogo = new THREE.Mesh(
    new THREE.PlaneGeometry(tableRadius * 1.1, tableRadius * 1.1),
    new THREE.MeshBasicMaterial({ map: centerLogoTexture, transparent: true, opacity: 0.42, depthWrite: false })
  );
  centerLogo.rotation.x = -Math.PI / 2;
  centerLogo.position.y = tableTopY + 0.014;
  topDecor.add(centerLogo);

  const railGlow = new THREE.Mesh(
    new THREE.TorusGeometry(tableRadius * 0.98, 0.028, 10, 150),
    new THREE.MeshStandardMaterial({ color: 0x6fe3ff, roughness: 0.18, metalness: 0.55, emissive: 0x56d4ff, emissiveIntensity: 0.45 })
  );
  railGlow.rotation.x = Math.PI / 2;
  railGlow.position.y = tableTopY + 0.06;
  topDecor.add(railGlow);

  const chipColors = [0xff4f86, 0x61e3ff, 0xf5df7b, 0xffffff, 0x9f7cff];
  const makeChipStack = (x, z, count = 5) => {
    const color = chipColors[(Math.random() * chipColors.length) | 0];
    const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.3, metalness: 0.08, emissive: color, emissiveIntensity: 0.08 });
    for (let i = 0; i < count; i++) {
      const c = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.03, 24), mat);
      c.position.set(x, tableTopY + 0.03 + i * 0.03, z);
      c.castShadow = true;
      topDecor.add(c);
    }
  };

  makeChipStack(-0.82, 0.66, 4);
  makeChipStack(0.82, -0.66, 4);
  makeChipStack(0.26, -0.18, 5);
  makeChipStack(-0.12, -0.42, 6);
  makeChipStack(0.62, 0.18, 3);

  animatedCards.length = 0;
  for (const [x, z, rot] of [[0.18, 0.56, -0.18], [0.45, 0.58, 0.08], [-0.18, 0.5, 0.22]]) {
    const card = new THREE.Mesh(
      new THREE.BoxGeometry(0.42, 0.016, 0.62),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95, emissive: 0x0d101f, emissiveIntensity: 0.08 })
    );
    card.position.set(x, tableTopY + 0.018, z);
    card.rotation.y = rot;
    card.castShadow = true;
    card.userData.baseY = card.position.y;
    card.userData.phase = Math.random() * Math.PI * 2;
    animatedCards.push(card);
    topDecor.add(card);
  }
}

function rebuildSeating() {
  chairGroup.clear();
  const logoTex = texLoader.load('./assets/logo.webp');
  logoTex.colorSpace = THREE.SRGBColorSpace;
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const group = new THREE.Group();
    const isPlayerSeat = i === 0;
    const baseMat = new THREE.MeshStandardMaterial({ color: isPlayerSeat ? 0x35204f : 0x2a1d42, roughness: 0.58, metalness: 0.08, emissive: isPlayerSeat ? 0x1d0e31 : 0x130a24, emissiveIntensity: 0.2 });
    const accentMat = new THREE.MeshStandardMaterial({ color: isPlayerSeat ? 0xc56eff : 0x7c4bca, roughness: 0.26, metalness: 0.34, emissive: isPlayerSeat ? 0x7a2ae0 : 0x3f176e, emissiveIntensity: 0.58 });
    const metalMat = new THREE.MeshStandardMaterial({ color: 0x12121b, roughness: 0.35, metalness: 0.65 });
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.18, 0.92), baseMat);
    seat.position.y = 0.54;
    const cushion = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.07, 0.78), new THREE.MeshStandardMaterial({ color: isPlayerSeat ? 0x5f348f : 0x442768, roughness: 0.85, metalness: 0.03 }));
    cushion.position.set(0, 0.67, 0);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.86, 0.13), baseMat);
    back.position.set(0, 1.1, -0.34);
    const backGlow = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.08, 0.03), accentMat);
    backGlow.position.set(0, 1.24, -0.26);
    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.34, 0.66), baseMat);
    armL.position.set(-0.42, 0.82, -0.02);
    const armR = armL.clone();
    armR.position.x *= -1;
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.56, 12), metalMat);
    leg.position.y = 0.25;
    const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.24, 0.05, 16), metalMat);
    foot.position.y = -0.05;
    const trimRing = new THREE.Mesh(new THREE.TorusGeometry(0.39, 0.022, 8, 48), accentMat);
    trimRing.rotation.x = Math.PI / 2;
    trimRing.position.set(0, 0.64, 0);
    group.add(seat, cushion, back, backGlow, armL, armR, leg, foot, trimRing);

    if (isPlayerSeat) {
      const logo = new THREE.Mesh(
        new THREE.PlaneGeometry(0.48, 0.48),
        new THREE.MeshBasicMaterial({ map: logoTex, transparent: true, depthWrite: false })
      );
      logo.position.set(0, 0.735, 0.18);
      logo.rotation.x = -Math.PI / 2;
      group.add(logo);
    }

    const radius = tableRadius + 1.05;
    group.position.set(Math.sin(angle) * radius, 0, Math.cos(angle) * radius);
    group.rotation.y = angle + Math.PI;
    chairGroup.add(group);
  }
  updateSeatTarget();
}
rebuildSeating();

async function loadTableModel() {
  const loader = new GLTFLoader();
  try {
    const gltf = await loader.loadAsync('./assets/table.glb');
    const model = gltf.scene;
    model.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      if (child.material) {
        child.material = child.material.clone();
        child.material.roughness = Math.min(1, child.material.roughness ?? 0.68);
        child.material.metalness = child.material.metalness ?? 0.08;
      }
    });

    const box = new THREE.Box3().setFromObject(model);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);
    const targetWidth = 4.55;
    const scale = targetWidth / Math.max(size.x, size.z, 0.001);
    model.scale.setScalar(scale);
    model.updateMatrixWorld(true);

    const scaledBox = new THREE.Box3().setFromObject(model);
    const scaledSize = new THREE.Vector3();
    const scaledCenter = new THREE.Vector3();
    scaledBox.getSize(scaledSize);
    scaledBox.getCenter(scaledCenter);
    model.position.set(-scaledCenter.x, -scaledBox.min.y, -scaledCenter.z);
    model.rotation.y = Math.PI;
    tableAnchor.add(model);

    tableRadius = Math.max(scaledSize.x, scaledSize.z) * 0.32;
    tableTopY = scaledSize.y + 0.01;
    rebuildSeating();
    buildTopDecor();
    placePlayerAtTableSpawn();
    placeholderGroup.visible = false;
    statusEl.textContent = 'Room loaded. Real table asset is online.';
  } catch (err) {
    console.warn('Table fallback', err);
    buildTopDecor();
    placePlayerAtTableSpawn();
    statusEl.textContent = 'Room loaded. Fallback table is active.';
  }
}
loadTableModel();

function buildFallbackEric() {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x7d72ff, roughness: 0.58, emissive: 0x2d1b52, emissiveIntensity: 0.35 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.9, 6, 12), mat);
  body.position.y = 1.02;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 24, 24), new THREE.MeshStandardMaterial({ color: 0xd8c2aa, roughness: 0.8 }));
  head.position.y = 1.76;
  group.add(body, head);
  group.position.set(-0.1, 0, -3.55);
  group.rotation.y = Math.PI;
  tableAnchor.add(group);
}

(async function loadEric() {
  try {
    const loader = new FBXLoader();
    const obj = await loader.loadAsync('./assets/eric.fbx');
    const diffuse = await new Promise((resolve) => texLoader.load('./assets/eric-diffuse.jpg', resolve, undefined, () => resolve(null)));
    if (diffuse) diffuse.colorSpace = THREE.SRGBColorSpace;
    obj.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      child.material = new THREE.MeshStandardMaterial({
        map: diffuse || null,
        color: diffuse ? 0xffffff : 0x7d72ff,
        roughness: 0.72,
        metalness: 0.03,
        emissive: 0x140d21,
        emissiveIntensity: 0.08
      });
    });
    const box = new THREE.Box3().setFromObject(obj);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    box.getSize(size);
    box.getCenter(center);
    const targetHeight = 1.72;
    const scale = targetHeight / Math.max(size.y, 0.001);
    obj.scale.setScalar(scale);
    obj.updateMatrixWorld(true);
    const scaledBox = new THREE.Box3().setFromObject(obj);
    const scaledCenter = new THREE.Vector3();
    scaledBox.getCenter(scaledCenter);
    obj.position.set(1.7 - scaledCenter.x, -scaledBox.min.y, -1.55);
    obj.rotation.y = Math.PI * 0.82;
    tableAnchor.add(obj);
  } catch (error) {
    console.warn('Eric fallback', error);
    buildFallbackEric();
  }
})();

(async function loadDealerAndCards() {
  const loader = new FBXLoader();
  try {
    const [dealer, stool, cards] = await Promise.all([
      loader.loadAsync('./assets/claudia.fbx'),
      loader.loadAsync('./assets/dealer-stool.fbx').catch(() => null),
      loader.loadAsync('./assets/cards.fbx').catch(() => null)
    ]);
    const tex = await new Promise((resolve) => texLoader.load('./assets/claudia-diffuse.webp', resolve, undefined, () => resolve(null)));
    if (tex) tex.colorSpace = THREE.SRGBColorSpace;

    dealer.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = true;
      child.receiveShadow = true;
      child.material = new THREE.MeshStandardMaterial({
        map: tex || null,
        color: tex ? 0xffffff : 0xf5d8ff,
        roughness: 0.74,
        metalness: 0.04,
        emissive: 0x140b1f,
        emissiveIntensity: 0.05
      });
    });
    const dealerBox = new THREE.Box3().setFromObject(dealer);
    const dealerSize = new THREE.Vector3();
    const dealerCenter = new THREE.Vector3();
    dealerBox.getSize(dealerSize);
    dealerBox.getCenter(dealerCenter);
    const dealerScale = 1.68 / Math.max(dealerSize.y, 0.001);
    dealer.scale.setScalar(dealerScale);
    dealer.updateMatrixWorld(true);
    const dealerScaled = new THREE.Box3().setFromObject(dealer);
    dealerScaled.getCenter(dealerCenter);
    dealer.position.set(-dealerCenter.x, -dealerScaled.min.y + 0.02, -tableRadius - 0.95);
    dealer.rotation.y = 0;
    tableAnchor.add(dealer);

    if (stool) {
      stool.traverse((child) => {
        if (!child.isMesh) return;
        child.castShadow = true;
        child.receiveShadow = true;
        child.material = new THREE.MeshStandardMaterial({ color: 0x261a38, roughness: 0.62, metalness: 0.06 });
      });
      const stoolBox = new THREE.Box3().setFromObject(stool);
      const stoolSize = new THREE.Vector3();
      const stoolCenter = new THREE.Vector3();
      stoolBox.getSize(stoolSize);
      stoolBox.getCenter(stoolCenter);
      const stoolScale = 0.58 / Math.max(stoolSize.x, stoolSize.z, 0.001);
      stool.scale.setScalar(stoolScale);
      stool.updateMatrixWorld(true);
      const stoolScaled = new THREE.Box3().setFromObject(stool);
      stoolScaled.getCenter(stoolCenter);
      stool.position.set(-stoolCenter.x, -stoolScaled.min.y, -tableRadius - 0.66);
      stool.rotation.y = Math.PI;
      tableAnchor.add(stool);
    }

    if (cards) {
      cards.traverse((child) => {
        if (!child.isMesh) return;
        child.castShadow = true;
        child.receiveShadow = true;
        child.material = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.88, metalness: 0.04 });
      });
      const cardsBox = new THREE.Box3().setFromObject(cards);
      const cardsSize = new THREE.Vector3();
      const cardsCenter = new THREE.Vector3();
      cardsBox.getSize(cardsSize);
      cardsBox.getCenter(cardsCenter);
      const cardsScale = 0.55 / Math.max(cardsSize.x, cardsSize.z, cardsSize.y, 0.001);
      cards.scale.setScalar(cardsScale);
      cards.updateMatrixWorld(true);
      const scaled = new THREE.Box3().setFromObject(cards);
      scaled.getCenter(cardsCenter);
      cards.position.set(-cardsCenter.x, tableTopY + 0.045 - scaled.min.y, -cardsCenter.z);
      cards.rotation.y = Math.PI * 0.08;
      cards.userData.floatCards = true;
      topDecor.add(cards);
      animatedCards.push(cards);
    }
  } catch (error) {
    console.warn('Dealer/cards fallback', error);
  }
})();

// radio prop
const radio = new THREE.Group();
const radioBody = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.38, 0.28), new THREE.MeshStandardMaterial({ color: 0x171422, roughness: 0.55 }));
const radioScreen = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 0.03), new THREE.MeshStandardMaterial({ color: 0x59d7ff, emissive: 0x59d7ff, emissiveIntensity: 0.6 }));
radioScreen.position.set(0, 0.05, 0.145);
const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.5, 8), new THREE.MeshStandardMaterial({ color: 0xa8b8ff, roughness: 0.2 }));
antenna.position.set(0.26, 0.38, 0.02);
radio.add(radioBody, radioScreen, antenna);
radio.position.set(-6.2, 0.22, 6.1);
world.add(radio);

// teleport marker
const tpGroup = new THREE.Group();
const tpRing = new THREE.Mesh(new THREE.RingGeometry(0.32, 0.5, 48), new THREE.MeshStandardMaterial({ color: 0xb663ff, emissive: 0x5a28c8, emissiveIntensity: 1.0, side: THREE.DoubleSide }));
tpRing.rotation.x = -Math.PI / 2;
const tpDisc = new THREE.Mesh(new THREE.CircleGeometry(0.28, 40), new THREE.MeshBasicMaterial({ map: texLoader.load('./assets/logo.webp'), transparent: true, opacity: 0.92 }));
tpDisc.rotation.x = -Math.PI / 2;
tpDisc.position.y = 0.002;
tpGroup.add(tpRing, tpDisc);
tpGroup.visible = false;
world.add(tpGroup);

function placeTeleportMarker(point) {
  const target = point.clone();
  target.y = 0.012;
  tpGroup.position.copy(target);
  tpGroup.visible = true;
}
function performTeleport(target) {
  seated = false;
  seatBtn.classList.remove('active');
  seatBtn.textContent = 'Seat: Open';
  const desired = new THREE.Vector3(target.x, 1.62, target.z);
  clampInsideRoom(desired);
  player.pos.copy(desired);
  updateCamera();
  updateSeatHint();
}

teleportBtn.addEventListener('click', () => {
  player.teleportMode = !player.teleportMode;
  teleportBtn.classList.toggle('active', player.teleportMode);
  teleportBtn.textContent = `Teleport: ${player.teleportMode ? 'On' : 'Off'}`;
  tpGroup.visible = false;
  modeEl.textContent = player.teleportMode ? 'Teleport enabled. Tap or click the floor to jump.' : 'Desktop: WASD / arrows move • click to lock for mouse look • T teleport • Mobile: dual sticks';
});
window.addEventListener('keydown', (event) => {
  keys.add(event.code);
  if (event.code === 'KeyT') teleportBtn.click();
  if (event.code === 'KeyF') toggleSeat();
});
window.addEventListener('keyup', (event) => keys.delete(event.code));
seatBtn.addEventListener('click', () => toggleSeat());
for (const controller of controllers) {
  controller.addEventListener('selectstart', () => {
    if (canSeat()) toggleSeat();
  });
}

renderer.domElement.addEventListener('click', () => {
  if (!pointerLocked && matchMedia('(hover:hover)').matches && !player.teleportMode) renderer.domElement.requestPointerLock?.();
});
document.addEventListener('pointerlockchange', () => {
  pointerLocked = document.pointerLockElement === renderer.domElement;
  crosshair.classList.toggle('active', pointerLocked && !matchMedia('(hover:none)').matches);
});
document.addEventListener('mousemove', (event) => {
  if (!pointerLocked) return;
  player.yaw -= event.movementX * player.lookSpeed;
  player.pitch -= event.movementY * player.lookSpeed;
  player.pitch = THREE.MathUtils.clamp(player.pitch, -1.05, 1.05);
});

function pickFloor(clientX, clientY) {
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const hit = raycaster.intersectObject(floorMesh, false)[0];
  return hit?.point || null;
}
renderer.domElement.addEventListener('pointerdown', (event) => {
  if (!player.teleportMode) {
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const hitSeat = raycaster.intersectObject(seatPad, false)[0];
    if (hitSeat && canSeat()) toggleSeat();
    return;
  }
  const point = pickFloor(event.clientX, event.clientY);
  if (!point) return;
  placeTeleportMarker(point);
  performTeleport(point);
});

// mobile joysticks
const stickState = {
  move: { active: false, id: null, origin: new THREE.Vector2(), delta: new THREE.Vector2() },
  look: { active: false, id: null, origin: new THREE.Vector2(), delta: new THREE.Vector2() }
};
const moveZone = document.getElementById('moveZone');
const lookZone = document.getElementById('lookZone');
const moveKnob = document.getElementById('moveKnob');
const lookKnob = document.getElementById('lookKnob');

function setupStick(zone, knob, state) {
  const reset = () => {
    state.active = false;
    state.id = null;
    state.delta.set(0, 0);
    knob.style.transform = 'translate(0px, 0px)';
  };
  zone.addEventListener('pointerdown', (event) => {
    state.active = true;
    state.id = event.pointerId;
    state.origin.set(event.clientX, event.clientY);
    zone.setPointerCapture(event.pointerId);
  });
  zone.addEventListener('pointermove', (event) => {
    if (!state.active || event.pointerId !== state.id) return;
    const dx = event.clientX - state.origin.x;
    const dy = event.clientY - state.origin.y;
    const limit = 40;
    const len = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(limit, len);
    state.delta.set((dx / len) * (clamped / limit), (dy / len) * (clamped / limit));
    knob.style.transform = `translate(${state.delta.x * limit}px, ${state.delta.y * limit}px)`;
  });
  const end = (event) => {
    if (event.pointerId !== state.id) return;
    reset();
  };
  zone.addEventListener('pointerup', end);
  zone.addEventListener('pointercancel', end);
}
setupStick(moveZone, moveKnob, stickState.move);
setupStick(lookZone, lookKnob, stickState.look);

function updateWatch() {
  const now = new Date();
  watchTime.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
setInterval(updateWatch, 1000);
updateWatch();

function toggleRadio() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();
  if (radioNodes) {
    radioNodes.gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.2);
    setTimeout(() => {
      radioNodes.osc1.stop();
      radioNodes.osc2.stop();
      radioNodes.filter.disconnect();
      radioNodes.gain.disconnect();
      radioNodes = null;
    }, 260);
    radioBtn.classList.remove('active');
    radioBtn.textContent = 'Radio: Off';
    return;
  }
  const osc1 = audioCtx.createOscillator();
  const osc2 = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const filter = audioCtx.createBiquadFilter();
  osc1.type = 'sawtooth';
  osc2.type = 'triangle';
  osc1.frequency.value = 164.81;
  osc2.frequency.value = 220;
  filter.type = 'lowpass';
  filter.frequency.value = 920;
  gain.gain.value = 0.0001;
  osc1.connect(filter); osc2.connect(filter); filter.connect(gain); gain.connect(audioCtx.destination);
  osc1.start(); osc2.start();
  gain.gain.exponentialRampToValueAtTime(0.032, audioCtx.currentTime + 0.4);
  radioNodes = { osc1, osc2, filter, gain };
  radioBtn.classList.add('active');
  radioBtn.textContent = 'Radio: On';
}
radioBtn.addEventListener('click', toggleRadio);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

const clock = new THREE.Clock();
function updateXRControllers(dt) {
  const session = renderer.xr.getSession();
  if (!session) return;
  xrTurnCooldown = Math.max(0, xrTurnCooldown - dt);

  let moveX = 0;
  let moveY = 0;
  let turnX = 0;
  for (const source of session.inputSources) {
    const axes = source.gamepad?.axes;
    if (!axes || axes.length < 2) continue;
    if (moveX === 0 && moveY === 0) {
      moveX = axes[2] ?? axes[0] ?? 0;
      moveY = axes[3] ?? axes[1] ?? 0;
    } else {
      turnX = axes[2] ?? axes[0] ?? 0;
    }
  }

  if (!seated) {
    const xrMoveForward = -moveY;
    const xrMoveStrafe = moveX;
    if (Math.abs(xrMoveForward) > 0.12 || Math.abs(xrMoveStrafe) > 0.12) {
      const dir = new THREE.Vector3();
      camera.getWorldDirection(dir);
      dir.y = 0;
      dir.normalize();
      const xrRight = new THREE.Vector3().crossVectors(dir, up).normalize();
      player.pos.addScaledVector(dir, xrMoveForward * player.speed * dt * 1.2);
      player.pos.addScaledVector(xrRight, xrMoveStrafe * player.speed * dt * 1.2);
      clampInsideRoom(player.pos);
      updateCamera();
    }
  }

  if (Math.abs(turnX) > 0.72 && xrTurnCooldown <= 0) {
    player.yaw -= Math.sign(turnX) * Math.PI / 8;
    xrTurnCooldown = 0.22;
    updateCamera();
  }
}

function animate() {
  const dt = Math.min(clock.getDelta(), 0.033);
  const t = performance.now();

  if (embedMode && !renderer.xr.isPresenting) {
    const orbitRadius = Math.max(5.8, tableRadius + 2.8);
    const orbitAngle = t * 0.00012 + Math.PI * 0.12;
    camera.position.set(Math.sin(orbitAngle) * orbitRadius, tableTopY + 1.75, Math.cos(orbitAngle) * orbitRadius);
    camera.lookAt(0, tableTopY + 0.35, 0);
  } else if (!renderer.xr.isPresenting) {
    if (!seated) {
      forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
      right.copy(forward).cross(up).normalize();
      velocity.set(0, 0, 0);
      if (keys.has('KeyW') || keys.has('ArrowUp')) velocity.add(forward);
      if (keys.has('KeyS') || keys.has('ArrowDown')) velocity.addScaledVector(forward, -1);
      if (keys.has('KeyD') || keys.has('ArrowRight')) velocity.add(right);
      if (keys.has('KeyA') || keys.has('ArrowLeft')) velocity.addScaledVector(right, -1);
      if (velocity.lengthSq() > 0) velocity.normalize().multiplyScalar(player.speed * dt);
      player.pos.add(velocity);
    } else {
      velocity.set(0, 0, 0);
    }

    if (!seated && stickState.move.active) {
      forward.set(Math.sin(player.yaw), 0, Math.cos(player.yaw)).negate();
      right.copy(forward).cross(up).normalize();
      const moveForward = -stickState.move.delta.y;
      const moveStrafe = stickState.move.delta.x;
      player.pos.addScaledVector(forward, moveForward * player.speed * dt);
      player.pos.addScaledVector(right, moveStrafe * player.speed * dt);
    }
    if (!seated && stickState.look.active) {
      player.yaw -= stickState.look.delta.x * 1.75 * dt;
      player.pitch -= stickState.look.delta.y * 1.25 * dt;
      player.pitch = THREE.MathUtils.clamp(player.pitch, -1.0, 1.0);
    }

    clampInsideRoom(player.pos);
    updateCamera();
  } else {
    updateXRControllers(dt);
  }

  if (world.userData.skylineGroup) {
    world.userData.skylineGroup.traverse((obj) => {
      if (obj.material?.emissive && obj.material.emissive.getHex() === 0xff294d) {
        obj.material.emissiveIntensity = 0.45 + (Math.sin(t * 0.008 + (obj.userData.blink || 0)) * 0.5 + 0.5) * 1.25;
      }
    });
  }

  wallLightBand.material.emissiveIntensity = 0.86 + Math.sin(t * 0.0017) * 0.18;
  neonRing.material.opacity = 0.18 + Math.sin(t * 0.0014) * 0.03;
  seatRing.material.emissiveIntensity = 0.85 + Math.sin(t * 0.004) * 0.18;
  seatPad.material.opacity = seated ? 0.28 : 0.9;

  handRig.visible = !renderer.xr.isPresenting && !embedMode;
  if (handRig.visible) {
    const idle = Math.sin(t * 0.0022) * 0.018;
    leftHand.position.y = -0.02 + idle;
    rightHand.position.y = 0.02 - idle;
    leftHand.rotation.x = -0.34 + Math.sin(t * 0.0018) * 0.05;
    rightHand.rotation.x = -0.34 - Math.sin(t * 0.0021) * 0.05;
    const moving = velocity.lengthSq() > 0.000001 || stickState.move.active;
    if (moving) {
      const swing = Math.sin(t * 0.01) * 0.08;
      leftHand.rotation.z = -0.06 + swing;
      rightHand.rotation.z = 0.06 - swing;
    } else {
      leftHand.rotation.z = -0.06;
      rightHand.rotation.z = 0.06;
    }
  }

  for (const sprite of spriteGroup.children) {
    sprite.position.y += sprite.userData.speed * dt;
    sprite.position.x += Math.sin(t * 0.00035 + sprite.userData.phase) * 0.0032;
    sprite.position.z += Math.cos(t * 0.00028 + sprite.userData.phase) * 0.0032;
    if (sprite.position.y > 12.5) {
      const radius = 5 + Math.random() * 16;
      const angle = Math.random() * Math.PI * 2;
      sprite.position.y = 0.12 + Math.random() * 1.6;
      sprite.position.x = Math.cos(angle) * radius;
      sprite.position.z = Math.sin(angle) * radius;
    }
  }

  for (const card of animatedCards) {
    if (!card?.position) continue;
    const baseY = card.userData.baseY ?? card.position.y;
    card.position.y = baseY + Math.sin(t * 0.0016 + (card.userData.phase || 0)) * 0.012;
    card.rotation.y += dt * 0.08;
  }

  if (tpGroup.visible) {
    tpGroup.rotation.y += dt * 1.8;
    tpRing.material.emissiveIntensity = 0.9 + Math.sin(t * 0.006) * 0.16;
  }

  updateSeatHint();
  renderer.render(scene, camera);
}

statusEl.textContent = embedMode
  ? 'Embedded live preview active.'
  : 'Room loaded. Spawn is set about 3 meters from the table edge with desktop, mobile, and VR movement enabled.';
renderer.setAnimationLoop(animate);


renderer.xr.addEventListener('sessionstart', () => {
  vrHelp.textContent = 'VR active. Left stick moves and right stick turns when supported. Use trigger near the seat to sit.';
  crosshair.classList.remove('active');
  seatHint.classList.add('hidden');
});
renderer.xr.addEventListener('sessionend', () => {
  vrHelp.textContent = 'Use the Enter VR button. In VR, left stick moves and right stick turns when your headset/browser exposes controller axes.';
  updateSeatHint();
});
