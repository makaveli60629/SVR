import * as THREE from "three";
import { VRButton } from "three/addons/webxr/VRButton.js";
import { XRHandModelFactory } from "three/addons/webxr/XRHandModelFactory.js";

/**
 * Scorpion Room v2 (STABLE)
 * Fixes pinch flicker by NOT changing XR reference space every frame.
 * Instead, we move a "stage" group (floor + objects) for smooth movement,
 * and use a logo pointer for teleport.
 *
 * Why: Changing XR reference space continuously while also reading hand poses
 * can create a feedback loop/jitter. Using a movable scene group avoids that.
 *
 * Notes on transparency: to avoid WebXR transparency flicker, the logo uses
 * alphaTest (cutout) instead of full transparency and disables depthWrite.
 */

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $err = document.getElementById("err");
const $toggleLog = document.getElementById("toggleLog");

function log(...args){
  const line = args.map(a => (typeof a === "string" ? a : JSON.stringify(a, null, 2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}
window.addEventListener("error", (e)=>{
  $err.style.display = "block";
  $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  $err.style.display = "block";
  $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});
$toggleLog.addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

// GitHub Pages safe asset resolution (relative to /game/sandbox/main.js)
const U = (rel) => new URL(rel, import.meta.url).toString();
const LOGO_TEX = U("../assets/ui/logo.png"); // update if needed
const TP_FALLBACK = U("./tp_fallback.png");

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.01, 200);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.xr.enabled = true;

document.getElementById("app").appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer, {
  requiredFeatures: ["local-floor", "hand-tracking"],
  optionalFeatures: ["bounded-floor"]
}));

// Lighting (bright, stable)
scene.add(new THREE.HemisphereLight(0xffffff, 0x080810, 1.25));
const sun = new THREE.DirectionalLight(0xffffff, 1.35);
sun.position.set(6, 10, 5);
scene.add(sun);
const fill = new THREE.PointLight(0xb48cff, 2.8, 70);
fill.position.set(0, 5, -8);
scene.add(fill);

// STAGE: everything that "moves" (floor + props)
const stage = new THREE.Group();
scene.add(stage);

// Floor
const floor = new THREE.Mesh(
  new THREE.PlaneGeometry(60, 60),
  new THREE.MeshStandardMaterial({ color: 0x05050a, roughness: 0.96, metalness: 0.02 })
);
floor.rotation.x = -Math.PI/2;
stage.add(floor);

// A few “square” objects for reference
const boxMat = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.45, metalness: 0.15 });
for (let i=0;i<10;i++){
  const b = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), boxMat);
  b.position.set((i-4.5)*0.9, 0.18, -2.0 - (i%2)*1.1);
  stage.add(b);
}
const pillarMat = new THREE.MeshStandardMaterial({ color: 0x202030, roughness: 0.85, metalness: 0.05 });
for (let i=0;i<4;i++){
  const p = new THREE.Mesh(new THREE.CylinderGeometry(0.18,0.18,2.2,24), pillarMat);
  p.position.set((i-1.5)*3.2, 1.1, -6.2);
  stage.add(p);
}

// Logo pointer (teleport + spawn pad)
const texLoader = new THREE.TextureLoader();
let logoTex = null;

function makeLogo(size){
  const geo = new THREE.PlaneGeometry(size, size);
  const mat = new THREE.MeshBasicMaterial({
    map: logoTex,
    transparent: true,
    alphaTest: 0.55,     // cutout (reduces WebXR transparency artifacts)
    depthWrite: false,
    side: THREE.DoubleSide
  });
  const m = new THREE.Mesh(geo, mat);
  m.rotation.x = -Math.PI/2;
  m.renderOrder = 999;
  return m;
}

const spawnRing = new THREE.Mesh(
  new THREE.RingGeometry(0.35, 0.48, 64),
  new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.35, metalness: 0.2, emissive: 0x2a0d3a, emissiveIntensity: 0.9, side: THREE.DoubleSide })
);
spawnRing.rotation.x = -Math.PI/2;
spawnRing.position.set(0, 0.011, 0);
stage.add(spawnRing);

const teleportRing = new THREE.Mesh(
  new THREE.RingGeometry(0.12, 0.16, 40),
  new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.35, metalness: 0.2, emissive: 0x2a0d3a, emissiveIntensity: 0.95, side: THREE.DoubleSide })
);
teleportRing.rotation.x = -Math.PI/2;
teleportRing.visible = false;
teleportRing.renderOrder = 998;
stage.add(teleportRing);

let spawnLogo = null;
let teleportLogo = null;

async function loadLogo(){
  return new Promise((resolve)=>{
    const tryTex = (url, label) => {
      texLoader.load(
        url,
        (t)=>{
          t.colorSpace = THREE.SRGBColorSpace;
          t.anisotropy = 8;
          logoTex = t;

          // Spawn pad
          spawnLogo = makeLogo(0.8);
          spawnLogo.position.set(0, 0.012, 0);
          stage.add(spawnLogo);

          // Teleport pointer
          teleportLogo = makeLogo(0.6);
          teleportLogo.visible = false;
          stage.add(teleportLogo);

          log(label, "loaded:", url);
          $status.textContent = label === "LOGO" ? "Logo loaded" : "Fallback pointer loaded";
          resolve(true);
        },
        undefined,
        (err)=>{
          log(label, "missing:", url, err?.message || err);
          if (label === "LOGO"){
            // Try fallback pointer image
            tryTex(TP_FALLBACK, "FALLBACK");
          } else {
            resolve(false);
          }
        }
      );
    };
    tryTex(LOGO_TEX, "LOGO");
  });
}

function showTeleportAt(p){
  teleportRing.visible = true;
  teleportRing.position.set(p.x, 0.012, p.z);
  if (teleportLogo){
    teleportLogo.visible = true;
    teleportLogo.position.set(p.x, 0.013, p.z);
  }
}
function hideTeleport(){
  teleportRing.visible = false;
  if (teleportLogo) teleportLogo.visible = false;
}

// Hands
const handModelFactory = new XRHandModelFactory();
const hands = [];
for (let i=0;i<2;i++){
  const hand = renderer.xr.getHand(i);
  hand.add(handModelFactory.createHandModel(hand, "mesh"));
  scene.add(hand);
  hands.push(hand);
}

function isPinching(hand){
  const indexTip = hand.joints?.["index-finger-tip"];
  const thumbTip = hand.joints?.["thumb-tip"];
  if (!indexTip || !thumbTip) return false;
  return indexTip.position.distanceTo(thumbTip.position) < 0.025;
}

// Movement (left pinch-drag) — MOVE THE STAGE (NOT refspace)
const tmp = new THREE.Vector3();
const drag = { active:false, startHand:new THREE.Vector3(), startStage:new THREE.Vector3() };
const MOVE_GAIN = 1.15;

// Teleport pointer + ray
const ray = new THREE.Raycaster();
const down = new THREE.Vector3(0,-1,0);

function updateMovement(){
  const left = hands[0];
  if (left?.joints){
    const pinch = isPinching(left);
    const indexTip = left.joints["index-finger-tip"];
    if (indexTip) indexTip.getWorldPosition(tmp);

    if (pinch && !drag.active){
      drag.active = true;
      drag.startHand.copy(tmp);
      drag.startStage.copy(stage.position);
      $status.textContent = "Moving… (release pinch)";
    }
    if (!pinch && drag.active){
      drag.active = false;
      $status.textContent = "Scorpion Room ready • Left pinch-drag move | Right pinch teleport";
    }
    if (drag.active){
      const dx = (tmp.x - drag.startHand.x) * MOVE_GAIN;
      const dz = (tmp.z - drag.startHand.z) * MOVE_GAIN;
      // Move the world opposite your hand drag = feels like you're moving
      stage.position.x = drag.startStage.x - dx;
      stage.position.z = drag.startStage.z - dz;
    }
  }
}

function updateTeleport(){
  const right = hands[1];
  if (!right?.joints) return;

  const pinch = isPinching(right);
  const indexTip = right.joints["index-finger-tip"];
  if (!indexTip) return;

  // While pinching: show logo on floor under finger
  indexTip.getWorldPosition(tmp);
  ray.set(tmp, down);
  const hits = ray.intersectObject(floor, false);
  if (pinch && hits && hits[0]){
    showTeleportAt(hits[0].point);
  }

  if (right.userData._wasPinching === undefined) right.userData._wasPinching = false;

  // On release: teleport by moving the stage so head is over target
  if (right.userData._wasPinching && !pinch){
    if (hits && hits[0]){
      const target = hits[0].point.clone();

      // Current head position in world
      const xrCam = renderer.xr.getCamera(camera);
      const head = new THREE.Vector3();
      xrCam.getWorldPosition(head);

      // Compute delta on XZ plane
      const dx = target.x - head.x;
      const dz = target.z - head.z;

      // Move stage opposite so head ends up at target
      stage.position.x -= dx;
      stage.position.z -= dz;

      showTeleportAt(target);
      setTimeout(()=>hideTeleport(), 350);
    } else {
      hideTeleport();
    }
  }

  right.userData._wasPinching = pinch;
}

$status.textContent = "Loading Scorpion room…";
$mode.textContent = "Hands: waiting…";
await loadLogo();

renderer.xr.addEventListener("sessionstart", ()=>{
  $status.textContent = "Scorpion Room ready • Left pinch-drag move | Right pinch teleport";
  $mode.textContent = "Hands: ON";

  // Spawn: put a logo pad at world origin and move the stage so you're ~3m back from the props
  stage.position.set(0, 0, 3);
});
renderer.xr.addEventListener("sessionend", ()=>{
  $status.textContent = "Scorpion Room ready • XR ended";
  hideTeleport();
});

renderer.setAnimationLoop(()=>{
  updateMovement();
  updateTeleport();
  renderer.render(scene, camera);
});

window.addEventListener("resize", ()=>{
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
