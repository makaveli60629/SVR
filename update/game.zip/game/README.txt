SVR Poker modular lobby phase

This build removes the broken test-table focus and returns to a lobby-first scene.
Modules kept separate:
- forearm-device.js
- watch-ui.js
- meta-hand-materials.js
- moon-upgrade.js
- lobby-skyline.js
- lobby-sprites.js

This phase focuses on:
- watch + Meta hand modules
- lobby skyline framing
- floating lobby sprites
- higher moon and Mars in the lobby
