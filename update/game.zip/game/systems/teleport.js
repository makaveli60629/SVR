/*
  Teleport system.

  Exports a function that registers an A‑Frame system to toggle a
  boolean `teleport` state when the user presses the `f` key.  This
  demonstrates how to listen for global input within an A‑Frame system.
*/

export function registerTeleportSystem() {
  if (typeof AFRAME === 'undefined') {
    console.warn('AFRAME is not loaded; teleport-system will not be registered');
    return;
  }
  AFRAME.registerSystem('teleport-system', {
    init: function () {
      let teleport = false;
      window.addEventListener('keydown', (e) => {
        if (e.key === 'f' || e.key === 'F') {
          teleport = !teleport;
          console.log('Teleport', teleport);
        }
      });
    },
  });
}