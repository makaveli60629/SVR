
window.addEventListener("load",()=>{

SVR.initRenderer();

const light = new THREE.AmbientLight(0xffffff,2);
SVR.scene.add(light);

/* floor */

const floor = new THREE.Mesh(
new THREE.PlaneGeometry(200,200),
new THREE.MeshStandardMaterial({color:0x111111})
);

floor.rotation.x = -Math.PI/2;
SVR.scene.add(floor);

/* poker table */

const table = new THREE.Mesh(
new THREE.CylinderGeometry(3,3,.3,64),
new THREE.MeshStandardMaterial({color:0x004400})
);

table.position.set(0,1,0);
SVR.scene.add(table);

/* skyline */

for(let i=0;i<40;i++){

let h = Math.random()*20+10;

let b = new THREE.Mesh(
new THREE.BoxGeometry(2,h,2),
new THREE.MeshStandardMaterial({color:0x1a1a3a})
);

b.position.set((Math.random()*120)-60,h/2,-100);

SVR.scene.add(b);

}

/* moon */

SVR.moon = new THREE.Mesh(
new THREE.SphereGeometry(10,32,32),
new THREE.MeshBasicMaterial({color:0xffffff})
);

SVR.moon.position.set(-50,60,-150);
SVR.scene.add(SVR.moon);

animate();

});

function animate(){

SVR.renderer.setAnimationLoop(()=>{

SVR.moon.rotation.y += 0.0006;

SVR.renderer.render(SVR.scene,SVR.camera);

});

}
