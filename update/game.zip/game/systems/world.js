
window.addEventListener("load",()=>{

SVR.init();

document.getElementById("diag").innerHTML = "SVR VR World Running";

const ambient = new THREE.AmbientLight(0xffffff,1.5);
SVR.scene.add(ambient);

/* floor */

const floor = new THREE.Mesh(
new THREE.PlaneGeometry(500,500),
new THREE.MeshStandardMaterial({color:0x050505})
);

floor.rotation.x = -Math.PI/2;
SVR.scene.add(floor);

/* casino walls */

const wallMat = new THREE.MeshStandardMaterial({color:0x111133});

for(let i=0;i<4;i++){

let wall = new THREE.Mesh(
new THREE.BoxGeometry(200,20,1),
wallMat
);

if(i===0) wall.position.set(0,10,-100);
if(i===1) wall.position.set(0,10,100);
if(i===2){ wall.rotation.y=Math.PI/2; wall.position.set(100,10,0); }
if(i===3){ wall.rotation.y=Math.PI/2; wall.position.set(-100,10,0); }

SVR.scene.add(wall);

}

/* poker tables */

for(let i=-1;i<=1;i++){

const table = new THREE.Mesh(
new THREE.CylinderGeometry(3,3,.4,64),
new THREE.MeshStandardMaterial({color:0x004400})
);

table.position.set(i*8,1,0);
SVR.scene.add(table);

}

/* skyline */

for(let i=0;i<60;i++){

let h = Math.random()*30+10;

let b = new THREE.Mesh(
new THREE.BoxGeometry(3,h,3),
new THREE.MeshStandardMaterial({color:0x1a1a40})
);

b.position.set((Math.random()*200)-100,h/2,-150);
SVR.scene.add(b);

}

/* moon */

SVR.moon = new THREE.Mesh(
new THREE.SphereGeometry(12,32,32),
new THREE.MeshBasicMaterial({color:0xffffff})
);

SVR.moon.position.set(-80,70,-200);
SVR.scene.add(SVR.moon);

animate();

});

function animate(){

SVR.renderer.setAnimationLoop(()=>{

SVR.moon.rotation.y += 0.0005;

SVR.renderer.render(SVR.scene,SVR.camera);

});

}
