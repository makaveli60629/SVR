
export class PokerEngine{

constructor(){
this.players=[]
this.deck=[]
this.pot=0
}

createDeck(){

const suits=["H","D","C","S"]
const ranks=["A","K","Q","J","10","9","8","7","6","5","4","3","2"]

for(let s of suits){
for(let r of ranks){
this.deck.push(r+s)
}
}

}

shuffle(){

for(let i=this.deck.length-1;i>0;i--){

let j=Math.floor(Math.random()*(i+1))
let t=this.deck[i]
this.deck[i]=this.deck[j]
this.deck[j]=t

}

}

}
