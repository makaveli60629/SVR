
export class PokerEngine {

constructor(){
this.players = []
this.deck = []
this.pot = 0
this.community = []
this.stage = "waiting"
}

createDeck(){

const suits = ["H","D","C","S"]
const ranks = ["A","K","Q","J","10","9","8","7","6","5","4","3","2"]

this.deck = []

for(let s of suits){
for(let r of ranks){
this.deck.push(r+s)
}
}

}

shuffle(){

for(let i=this.deck.length-1;i>0;i--){

let j = Math.floor(Math.random()*(i+1))

let temp = this.deck[i]
this.deck[i] = this.deck[j]
this.deck[j] = temp

}

}

addPlayer(id,chips=1000){

this.players.push({
id:id,
chips:chips,
bet:0,
cards:[],
folded:false
})

}

dealCards(){

for(let r=0;r<2;r++){
for(let p of this.players){
p.cards.push(this.deck.pop())
}
}

}

flop(){

this.community.push(this.deck.pop())
this.community.push(this.deck.pop())
this.community.push(this.deck.pop())

}

turn(){
this.community.push(this.deck.pop())
}

river(){
this.community.push(this.deck.pop())
}

startHand(){

this.pot = 0
this.community = []

this.createDeck()
this.shuffle()

for(let p of this.players){
p.cards = []
p.folded = false
p.bet = 0
}

this.dealCards()
this.stage = "preflop"

}

nextStage(){

if(this.stage==="preflop"){
this.flop()
this.stage="flop"
}
else if(this.stage==="flop"){
this.turn()
this.stage="turn"
}
else if(this.stage==="turn"){
this.river()
this.stage="river"
}
else if(this.stage==="river"){
this.stage="showdown"
}

}

}
