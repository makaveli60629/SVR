
/* simple teleport with keyboard for desktop */

document.addEventListener("keydown",(e)=>{

if(!window.SVR) return;

if(e.key==="w") SVR.camera.position.z -= 1;
if(e.key==="s") SVR.camera.position.z += 1;
if(e.key==="a") SVR.camera.position.x -= 1;
if(e.key==="d") SVR.camera.position.x += 1;

});
