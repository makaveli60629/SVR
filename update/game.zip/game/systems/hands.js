/*
  VR hands component.

  This module exports a function that registers an A‑Frame component
  responsible for adding left and right VR hand controllers to the
  scene.  When invoked, it attaches itself to the scene entity and
  creates two child entities with `hand-controls` attributes.
*/

export function registerVrHands() {
  if (typeof AFRAME === 'undefined') {
    console.warn('AFRAME is not loaded; vr-hands component will not be registered');
    return;
  }
  AFRAME.registerComponent('vr-hands', {
    init: function () {
      const scene = this.el;
      const left = document.createElement('a-entity');
      left.setAttribute('hand-controls', 'left');
      scene.appendChild(left);
      const right = document.createElement('a-entity');
      right.setAttribute('hand-controls', 'right');
      scene.appendChild(right);
    },
  });
}