/*
  Poker table component.

  Exports a function that registers the `poker-table` A‑Frame component.
  The component constructs a deck of 52 cards on initialisation and logs
  the deck size to the console.  Keeping component registration in a
  function makes it possible to import and register only when A‑Frame is
  available.
*/

export function registerPokerTable() {
  if (typeof AFRAME === 'undefined') {
    console.warn('AFRAME is not loaded; poker-table component will not be registered');
    return;
  }
  AFRAME.registerComponent('poker-table', {
    init: function () {
      this.deck = [];
      const suits = ['H', 'D', 'S', 'C'];
      suits.forEach((s) => {
        for (let i = 1; i <= 13; i++) {
          this.deck.push({ suit: s, value: i });
        }
      });
      console.log('Deck ready', this.deck.length);
    },
  });
}