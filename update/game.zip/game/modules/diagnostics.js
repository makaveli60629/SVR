
export function initDiagnostics(){
 console.log("Diagnostics module active")
}
