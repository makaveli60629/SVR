(function () {
  const THREE = AFRAME.THREE;
  const LAYOUT = {
    room: 'test-room-only',
    moon: {
      position: { x: -10, y: 58, z: -145 },
      scale: { x: 2.05, y: 2.05, z: 2.05 },
      rotationYDeg: 18
    },
    mars: {
      position: { x: 42, y: 49, z: -160 },
      scale: { x: 4.4, y: 4.4, z: 4.4 }
    },
    lobbyCopyHint: {
      moonPosition: '-10 58 -145',
      moonScale: '2.05 2.05 2.05',
      moonRotation: '0 18 0',
      marsPosition: '42 49 -160',
      marsScale: '4.4 4.4 4.4'
    }
  };

  window.SVRCelestialLayout = LAYOUT;

  function buildStarField() {
    const geometry = new THREE.BufferGeometry();
    const starCount = 1100;
    const positions = new Float32Array(starCount * 3);
    const sizes = new Float32Array(starCount);
    const radiusMin = 90;
    const radiusMax = 200;

    for (let i = 0; i < starCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.82;
      const radius = radiusMin + Math.random() * (radiusMax - radiusMin);
      const x = Math.sin(phi) * Math.cos(theta) * radius;
      const y = 24 + Math.cos(phi) * radius * 0.68;
      const z = -Math.abs(Math.sin(phi) * Math.sin(theta) * radius) - 34;
      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;
      sizes[i] = Math.random();
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('sizeSeed', new THREE.BufferAttribute(sizes, 1));

    const material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.82,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.96,
      depthWrite: false
    });

    return new THREE.Points(geometry, material);
  }

  function makeMarsTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    const base = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    base.addColorStop(0, '#5e2714');
    base.addColorStop(0.35, '#94411f');
    base.addColorStop(0.7, '#b35b2a');
    base.addColorStop(1, '#6b2f1a');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    function blotches(count, minR, maxR, colors, alpha) {
      for (let i = 0; i < count; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const r = minR + Math.random() * (maxR - minR);
        const color = colors[(Math.random() * colors.length) | 0];
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, color);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalAlpha = alpha;
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    blotches(180, 15, 68, ['#cf7b47', '#cf8f58', '#7f331c', '#4d1d0e'], 0.38);
    blotches(50, 35, 120, ['#dea777', '#e4b990'], 0.18);

    ctx.strokeStyle = 'rgba(251,219,184,0.18)';
    ctx.lineWidth = 7;
    for (let i = 0; i < 9; i++) {
      ctx.beginPath();
      const y = 28 + i * 52 + Math.random() * 14;
      ctx.moveTo(0, y);
      for (let x = 0; x < canvas.width; x += 48) {
        ctx.lineTo(x, y + Math.sin((x / 60) + i) * 8 + (Math.random() - 0.5) * 7);
      }
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.needsUpdate = true;
    return tex;
  }

  function makeMoonDetailOverlay() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#7f7f84';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < 240; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      const r = 8 + Math.random() * 42;
      const g = ctx.createRadialGradient(x - r * 0.18, y - r * 0.18, 0, x, y, r);
      g.addColorStop(0, 'rgba(255,255,255,0.22)');
      g.addColorStop(0.38, 'rgba(168,168,173,0.18)');
      g.addColorStop(0.72, 'rgba(86,86,92,0.14)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.needsUpdate = true;
    return tex;
  }

  AFRAME.registerComponent('star-dome', {
    init: function () {
      const stars = buildStarField();
      this.el.object3D.add(stars);
      this.stars = stars;
    },

    tick: function (time) {
      if (!this.stars) return;
      this.stars.rotation.y = time * 0.000013;
    }
  });

  AFRAME.registerComponent('cinematic-moon', {
    init: function () {
      this.overlayTexture = makeMoonDetailOverlay();
      this.el.addEventListener('model-loaded', () => {
        const mesh = this.el.getObject3D('mesh');
        if (!mesh) return;

        mesh.traverse((obj) => {
          if (!obj.isMesh) return;
          const sourceMaterials = Array.isArray(obj.material) ? obj.material : [obj.material];
          const upgraded = sourceMaterials.map((mat) => {
            const next = new THREE.MeshStandardMaterial({
              color: '#d7d9de',
              roughness: 1,
              metalness: 0,
              map: (mat && mat.map) ? mat.map : this.overlayTexture,
              emissive: '#060606',
              emissiveIntensity: 0.15,
              bumpMap: this.overlayTexture,
              bumpScale: 0.03
            });
            if (next.map) {
              next.map.anisotropy = 8;
              next.map.needsUpdate = true;
            }
            next.needsUpdate = true;
            return next;
          });

          obj.material = Array.isArray(obj.material) ? upgraded : upgraded[0];
          obj.castShadow = false;
          obj.receiveShadow = false;
        });
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      obj.rotation.y = THREE.MathUtils.degToRad(LAYOUT.moon.rotationYDeg) + time * 0.000028;
      obj.position.x = LAYOUT.moon.position.x + Math.sin(time * 0.00006) * 1.8;
      obj.position.y = LAYOUT.moon.position.y + Math.sin(time * 0.00005) * 0.6;
    }
  });

  AFRAME.registerComponent('cinematic-mars', {
    init: function () {
      this.texture = makeMarsTexture();
      this.el.addEventListener('object3dset', () => this.applyMaterial());
      this.applyMaterial();
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: this.texture,
          roughness: 1,
          metalness: 0,
          emissive: '#120703',
          emissiveIntensity: 0.08
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      obj.rotation.y = time * 0.000045;
      obj.position.x = LAYOUT.mars.position.x + Math.sin(time * 0.00004) * 1.1;
      obj.position.y = LAYOUT.mars.position.y + Math.sin(time * 0.00003) * 0.5;
    }
  });
})();
