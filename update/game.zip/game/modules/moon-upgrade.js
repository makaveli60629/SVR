(function () {
  const THREE = AFRAME.THREE;
  const LAYOUT = {
    room: 'test-room-only',
    moon: {
      position: { x: -8, y: 92, z: -225 },
      scale: { x: 16.5, y: 16.5, z: 16.5 },
      rotationYDeg: 14
    },
    mars: {
      position: { x: 66, y: 102, z: -245 },
      scale: { x: 7.8, y: 7.8, z: 7.8 }
    }
  };

  window.SVRCelestialLayout = LAYOUT;

  function dirFromPosition(pos) {
    return new THREE.Vector3(pos.x, pos.y, pos.z).normalize();
  }

  function buildStarField() {
    const geometry = new THREE.BufferGeometry();
    const starCount = 1400;
    const positions = [];
    const moonDir = dirFromPosition(LAYOUT.moon.position);
    const marsDir = dirFromPosition(LAYOUT.mars.position);

    let tries = 0;
    while (positions.length < starCount * 3 && tries < starCount * 30) {
      tries += 1;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.62;
      const radius = 250 + Math.random() * 130;
      const x = Math.sin(phi) * Math.cos(theta) * radius;
      const y = 46 + Math.cos(phi) * radius * 0.84;
      const z = -Math.abs(Math.sin(phi) * Math.sin(theta) * radius) - 120;
      const d = new THREE.Vector3(x, y, z).normalize();

      if (d.dot(moonDir) > 0.985) continue;
      if (d.dot(marsDir) > 0.992) continue;

      positions.push(x, y, z);
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));

    const material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.78,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.95,
      depthWrite: false,
      depthTest: true
    });

    return new THREE.Points(geometry, material);
  }

  function makeMoonTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 2048;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');

    const base = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    base.addColorStop(0, '#6e7077');
    base.addColorStop(0.22, '#d9d7d3');
    base.addColorStop(0.48, '#8b8c92');
    base.addColorStop(0.72, '#e3e0dc');
    base.addColorStop(1, '#5d6068');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    function ringCrater(x, y, r, darkAlpha, lightAlpha) {
      const maria = ctx.createRadialGradient(x + r * 0.18, y + r * 0.16, 0, x, y, r);
      maria.addColorStop(0, 'rgba(42,43,50,0)');
      maria.addColorStop(0.55, 'rgba(34,35,42,' + darkAlpha + ')');
      maria.addColorStop(1, 'rgba(16,16,18,0)');
      ctx.fillStyle = maria;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();

      const rim = ctx.createRadialGradient(x - r * 0.22, y - r * 0.18, 0, x, y, r * 0.92);
      rim.addColorStop(0, 'rgba(255,250,245,' + lightAlpha + ')');
      rim.addColorStop(0.3, 'rgba(232,229,225,' + (lightAlpha * 0.52) + ')');
      rim.addColorStop(0.7, 'rgba(120,120,126,0)');
      rim.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rim;
      ctx.beginPath();
      ctx.arc(x, y, r * 0.82, 0, Math.PI * 2);
      ctx.fill();
    }

    for (let i = 0; i < 700; i++) {
      ringCrater(Math.random() * canvas.width, Math.random() * canvas.height, 5 + Math.random() * 24, 0.54, 0.42);
    }
    for (let i = 0; i < 180; i++) {
      ringCrater(Math.random() * canvas.width, Math.random() * canvas.height, 22 + Math.random() * 72, 0.46, 0.34);
    }
    for (let i = 0; i < 24; i++) {
      ringCrater(Math.random() * canvas.width, Math.random() * canvas.height, 70 + Math.random() * 140, 0.34, 0.28);
    }

    ctx.globalAlpha = 0.24;
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = i % 2 ? '#5a5b61' : '#f1ede8';
      ctx.beginPath();
      ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, 40 + Math.random() * 190, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.globalAlpha = 0.12;
    const warm = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    warm.addColorStop(0, '#ffe4d7');
    warm.addColorStop(0.4, '#ffffff');
    warm.addColorStop(1, '#dfe7ff');
    ctx.fillStyle = warm;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.globalAlpha = 1;

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.needsUpdate = true;
    return tex;
  }

  function makeMoonGlowTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');
    const g = ctx.createRadialGradient(512, 512, 0, 512, 512, 512);
    g.addColorStop(0, 'rgba(255,244,235,0.20)');
    g.addColorStop(0.38, 'rgba(255,232,216,0.14)');
    g.addColorStop(0.62, 'rgba(255,214,204,0.06)');
    g.addColorStop(1, 'rgba(255,200,190,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 1024, 1024);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.needsUpdate = true;
    return tex;
  }

  function makeMarsTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    const base = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    base.addColorStop(0, '#7d2f16');
    base.addColorStop(0.25, '#c45d30');
    base.addColorStop(0.55, '#f09359');
    base.addColorStop(0.8, '#a74520');
    base.addColorStop(1, '#742e18');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    function blotches(count, minR, maxR, colors, alpha) {
      for (let i = 0; i < count; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const r = minR + Math.random() * (maxR - minR);
        const color = colors[(Math.random() * colors.length) | 0];
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, color);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalAlpha = alpha;
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    blotches(240, 18, 82, ['#f1b078', '#ffcca1', '#7f331c', '#4d1d0e', '#ffd8b0'], 0.46);
    blotches(80, 35, 120, ['#ffe2c2', '#f9c39d'], 0.28);

    ctx.strokeStyle = 'rgba(255,220,185,0.27)';
    ctx.lineWidth = 7;
    for (let i = 0; i < 9; i++) {
      ctx.beginPath();
      const y = 28 + i * 52 + Math.random() * 14;
      ctx.moveTo(0, y);
      for (let x = 0; x < canvas.width; x += 48) {
        ctx.lineTo(x, y + Math.sin((x / 60) + i) * 8 + (Math.random() - 0.5) * 7);
      }
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.needsUpdate = true;
    return tex;
  }

  AFRAME.registerComponent('star-dome', {
    init: function () {
      const stars = buildStarField();
      this.el.object3D.add(stars);
      this.stars = stars;
    },

    tick: function (time) {
      if (!this.stars) return;
      this.stars.rotation.y = time * 0.000010;
    }
  });

  AFRAME.registerComponent('cinematic-moon', {
    init: function () {
      this.texture = makeMoonTexture();
      this.glowTexture = makeMoonGlowTexture();
      this.applyMaterial = this.applyMaterial.bind(this);
      this.el.addEventListener('object3dset', this.applyMaterial);
      this.applyMaterial();
      this.ensureGlow();
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.applyMaterial);
    },

    ensureGlow: function () {
      if (this.glowMesh) return;
      const geometry = new THREE.SphereGeometry(1.12, 48, 36);
      const material = new THREE.MeshBasicMaterial({
        map: this.glowTexture,
        color: '#ffe4da',
        transparent: true,
        opacity: 0.34,
        depthWrite: false,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending
      });
      this.glowMesh = new THREE.Mesh(geometry, material);
      this.el.object3D.add(this.glowMesh);
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.renderOrder = 3;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: this.texture,
          roughness: 1,
          metalness: 0,
          emissive: '#2f2930',
          emissiveIntensity: 0.12,
          bumpMap: this.texture,
          bumpScale: 0.12
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
        obj.renderOrder = 3;
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      obj.rotation.y = THREE.MathUtils.degToRad(LAYOUT.moon.rotationYDeg) + time * 0.000016;
      obj.position.x = LAYOUT.moon.position.x + Math.sin(time * 0.00003) * 0.9;
      obj.position.y = LAYOUT.moon.position.y + Math.sin(time * 0.000025) * 0.5;
    }
  });

  AFRAME.registerComponent('cinematic-mars', {
    init: function () {
      this.texture = makeMarsTexture();
      this.applyMaterial = this.applyMaterial.bind(this);
      this.el.addEventListener('object3dset', this.applyMaterial);
      this.applyMaterial();
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.applyMaterial);
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.renderOrder = 2;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: this.texture,
          roughness: 0.95,
          metalness: 0,
          emissive: '#6e2b16',
          emissiveIntensity: 0.22
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
        obj.renderOrder = 2;
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      obj.rotation.y = time * 0.000035;
      obj.position.x = LAYOUT.mars.position.x + Math.sin(time * 0.00003) * 0.8;
      obj.position.y = LAYOUT.mars.position.y + Math.sin(time * 0.00002) * 0.35;
    }
  });
})();
