(function () {
  const THREE = AFRAME.THREE;
  const LAYOUT = {
    room: 'test-room-only',
    moon: {
      position: { x: -18, y: 78, z: -150 },
      scale: { x: 11.5, y: 11.5, z: 11.5 },
      rotationYDeg: 18
    },
    mars: {
      position: { x: 54, y: 86, z: -165 },
      scale: { x: 6.5, y: 6.5, z: 6.5 }
    }
  };

  window.SVRCelestialLayout = LAYOUT;

  function buildStarField() {
    const geometry = new THREE.BufferGeometry();
    const starCount = 1100;
    const positions = new Float32Array(starCount * 3);
    const radiusMin = 90;
    const radiusMax = 200;

    for (let i = 0; i < starCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.82;
      const radius = radiusMin + Math.random() * (radiusMax - radiusMin);
      const x = Math.sin(phi) * Math.cos(theta) * radius;
      const y = 24 + Math.cos(phi) * radius * 0.68;
      const z = -Math.abs(Math.sin(phi) * Math.sin(theta) * radius) - 34;
      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.82,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.96,
      depthWrite: false
    });

    return new THREE.Points(geometry, material);
  }

  function makeMoonTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 2048;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');

    const base = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    base.addColorStop(0, '#90939a');
    base.addColorStop(0.25, '#c7c8cd');
    base.addColorStop(0.45, '#8d8f95');
    base.addColorStop(0.75, '#d5d6da');
    base.addColorStop(1, '#767980');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    function crater(count, minR, maxR, alpha) {
      for (let i = 0; i < count; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const r = minR + Math.random() * (maxR - minR);

        const shadow = ctx.createRadialGradient(x + r * 0.12, y + r * 0.12, 0, x, y, r);
        shadow.addColorStop(0, 'rgba(40,42,48,0.0)');
        shadow.addColorStop(0.55, 'rgba(64,66,72,' + (alpha * 0.55) + ')');
        shadow.addColorStop(1, 'rgba(20,22,28,0)');
        ctx.fillStyle = shadow;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();

        const rim = ctx.createRadialGradient(x - r * 0.18, y - r * 0.18, 0, x, y, r * 0.95);
        rim.addColorStop(0, 'rgba(255,255,255,' + (alpha * 0.45) + ')');
        rim.addColorStop(0.25, 'rgba(225,226,232,' + (alpha * 0.26) + ')');
        rim.addColorStop(0.7, 'rgba(110,112,118,0.0)');
        rim.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = rim;
        ctx.beginPath();
        ctx.arc(x, y, r * 0.78, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    crater(420, 6, 28, 0.5);
    crater(140, 24, 80, 0.42);
    crater(26, 70, 150, 0.34);

    ctx.globalAlpha = 0.09;
    for (let i = 0; i < 18; i++) {
      ctx.fillStyle = i % 2 ? '#f3f4f7' : '#5e6168';
      ctx.beginPath();
      ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, 90 + Math.random() * 220, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.needsUpdate = true;
    return tex;
  }

  function makeMarsTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    const base = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    base.addColorStop(0, '#7d2f16');
    base.addColorStop(0.25, '#b94f26');
    base.addColorStop(0.55, '#d87840');
    base.addColorStop(0.8, '#9f431e');
    base.addColorStop(1, '#742e18');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    function blotches(count, minR, maxR, colors, alpha) {
      for (let i = 0; i < count; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const r = minR + Math.random() * (maxR - minR);
        const color = colors[(Math.random() * colors.length) | 0];
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, color);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalAlpha = alpha;
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    blotches(220, 18, 80, ['#e89a63', '#ffb27d', '#7f331c', '#4d1d0e'], 0.44);
    blotches(60, 35, 120, ['#ffd1ae', '#f3bc90'], 0.24);

    ctx.strokeStyle = 'rgba(255,220,185,0.24)';
    ctx.lineWidth = 7;
    for (let i = 0; i < 9; i++) {
      ctx.beginPath();
      const y = 28 + i * 52 + Math.random() * 14;
      ctx.moveTo(0, y);
      for (let x = 0; x < canvas.width; x += 48) {
        ctx.lineTo(x, y + Math.sin((x / 60) + i) * 8 + (Math.random() - 0.5) * 7);
      }
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.needsUpdate = true;
    return tex;
  }

  AFRAME.registerComponent('star-dome', {
    init: function () {
      const stars = buildStarField();
      this.el.object3D.add(stars);
      this.stars = stars;
    },

    tick: function (time) {
      if (!this.stars) return;
      this.stars.rotation.y = time * 0.000013;
    }
  });

  AFRAME.registerComponent('cinematic-moon', {
    init: function () {
      this.texture = makeMoonTexture();
      this.applyMaterial = this.applyMaterial.bind(this);
      this.el.addEventListener('object3dset', this.applyMaterial);
      this.applyMaterial();
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.applyMaterial);
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#f6f7fb',
          map: this.texture,
          roughness: 1,
          metalness: 0,
          emissive: '#1a1a1f',
          emissiveIntensity: 0.08,
          bumpMap: this.texture,
          bumpScale: 0.065
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      obj.rotation.y = THREE.MathUtils.degToRad(LAYOUT.moon.rotationYDeg) + time * 0.00002;
      obj.position.x = LAYOUT.moon.position.x + Math.sin(time * 0.00005) * 1.2;
      obj.position.y = LAYOUT.moon.position.y + Math.sin(time * 0.00004) * 0.8;
    }
  });

  AFRAME.registerComponent('cinematic-mars', {
    init: function () {
      this.texture = makeMarsTexture();
      this.applyMaterial = this.applyMaterial.bind(this);
      this.el.addEventListener('object3dset', this.applyMaterial);
      this.applyMaterial();
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.applyMaterial);
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: this.texture,
          roughness: 0.95,
          metalness: 0,
          emissive: '#522113',
          emissiveIntensity: 0.18
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      obj.rotation.y = time * 0.000045;
      obj.position.x = LAYOUT.mars.position.x + Math.sin(time * 0.00004) * 1.1;
      obj.position.y = LAYOUT.mars.position.y + Math.sin(time * 0.00003) * 0.5;
    }
  });
})();
