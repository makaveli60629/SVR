(function () {
  const THREE = AFRAME.THREE;
  const textureLoader = new THREE.TextureLoader();

  const LAYOUT = {
    room: 'test-room-only',
    moon: {
      basePosition: { x: -28, y: 146, z: -430 },
      scale: { x: 19.5, y: 19.5, z: 19.5 },
      orbitRadiusX: 14,
      orbitRadiusY: 4,
      orbitRadiusZ: 10,
      orbitSpeed: 0.000022,
      rotationSpeed: 0.00006
    },
    mars: {
      basePosition: { x: 112, y: 156, z: -470 },
      scale: { x: 8.8, y: 8.8, z: 8.8 },
      orbitRadiusX: 12,
      orbitRadiusY: 6,
      orbitRadiusZ: 9,
      orbitSpeed: 0.000028,
      rotationSpeed: 0.000075
    }
  };

  window.SVRCelestialLayout = LAYOUT;

  function dirFromPosition(pos) {
    return new THREE.Vector3(pos.x, pos.y, pos.z).normalize();
  }

  function loadMoonTextures() {
    const diffuse = textureLoader.load('assets/textures/moon_final_diffuse.png');
    const bump = textureLoader.load('assets/textures/moon_final_bump.png');
    [diffuse, bump].forEach(function (tex) {
      tex.colorSpace = tex === diffuse ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      tex.wrapS = THREE.ClampToEdgeWrapping;
      tex.wrapT = THREE.ClampToEdgeWrapping;
      tex.anisotropy = 4;
      tex.needsUpdate = true;
    });
    return { diffuse, bump };
  }

  function buildStarField() {
    const geometry = new THREE.BufferGeometry();
    const positions = [];
    const starCount = 950;
    const moonDir = dirFromPosition(LAYOUT.moon.basePosition);
    const marsDir = dirFromPosition(LAYOUT.mars.basePosition);

    let tries = 0;
    while (positions.length < starCount * 3 && tries < starCount * 24) {
      tries += 1;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.55;
      const radius = 620 + Math.random() * 180;
      const x = Math.sin(phi) * Math.cos(theta) * radius;
      const y = 80 + Math.cos(phi) * radius * 0.86;
      const z = -Math.abs(Math.sin(phi) * Math.sin(theta) * radius) - 260;
      const d = new THREE.Vector3(x, y, z).normalize();

      if (d.dot(moonDir) > 0.992) continue;
      if (d.dot(marsDir) > 0.995) continue;
      positions.push(x, y, z);
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 1.0,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.96,
      depthWrite: false,
      depthTest: true
    });

    return new THREE.Points(geometry, material);
  }

  function makeMarsTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    const base = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    base.addColorStop(0, '#7a2f16');
    base.addColorStop(0.25, '#b64d25');
    base.addColorStop(0.6, '#dd7443');
    base.addColorStop(1, '#8a381a');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    function blotch(count, minR, maxR, colors, alpha) {
      for (let i = 0; i < count; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const r = minR + Math.random() * (maxR - minR);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        const c = colors[(Math.random() * colors.length) | 0];
        g.addColorStop(0, c);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalAlpha = alpha;
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    blotch(220, 14, 82, ['#ffcb9e', '#f29a66', '#5d210f', '#9a411f'], 0.42);
    blotch(90, 24, 120, ['#ffd8b8', '#f6b88f'], 0.18);

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    return tex;
  }

  AFRAME.registerComponent('star-dome', {
    init: function () {
      this.stars = buildStarField();
      this.el.object3D.add(this.stars);
    },
    tick: function (time) {
      if (!this.stars) return;
      this.stars.rotation.y = time * 0.000004;
    }
  });

  AFRAME.registerComponent('cinematic-moon', {
    init: function () {
      const loaded = loadMoonTextures();
      this.diffuse = loaded.diffuse;
      this.bump = loaded.bump;
      this.applyMaterial = this.applyMaterial.bind(this);
      this.el.addEventListener('object3dset', this.applyMaterial);
      this.applyMaterial();
      this.ensureGlow();
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.applyMaterial);
    },

    ensureGlow: function () {
      if (this.glowMesh) return;
      const geometry = new THREE.SphereGeometry(1.10, 28, 20);
      const material = new THREE.MeshBasicMaterial({
        color: '#fff0e5',
        transparent: true,
        opacity: 0.10,
        depthWrite: false,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending
      });
      this.glowMesh = new THREE.Mesh(geometry, material);
      this.el.object3D.add(this.glowMesh);
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: this.diffuse,
          bumpMap: this.bump,
          bumpScale: 0.16,
          roughness: 1.0,
          metalness: 0.0,
          emissive: '#18171a',
          emissiveIntensity: 0.06
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
        obj.renderOrder = 4;
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      const m = LAYOUT.moon;
      const orbitT = time * m.orbitSpeed;
      obj.position.set(
        m.basePosition.x + Math.cos(orbitT) * m.orbitRadiusX,
        m.basePosition.y + Math.sin(orbitT * 0.9) * m.orbitRadiusY,
        m.basePosition.z + Math.sin(orbitT) * m.orbitRadiusZ
      );
      obj.rotation.y += m.rotationSpeed;
      obj.rotation.z = Math.sin(orbitT * 0.55) * 0.03;
    }
  });

  AFRAME.registerComponent('cinematic-mars', {
    init: function () {
      this.texture = makeMarsTexture();
      this.applyMaterial = this.applyMaterial.bind(this);
      this.el.addEventListener('object3dset', this.applyMaterial);
      this.applyMaterial();
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.applyMaterial);
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: this.texture,
          roughness: 0.96,
          metalness: 0.0,
          emissive: '#5d2612',
          emissiveIntensity: 0.18
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
        obj.renderOrder = 3;
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      const m = LAYOUT.mars;
      const orbitT = time * m.orbitSpeed;
      obj.position.set(
        m.basePosition.x + Math.cos(orbitT) * m.orbitRadiusX,
        m.basePosition.y + Math.sin(orbitT * 1.1) * m.orbitRadiusY,
        m.basePosition.z + Math.sin(orbitT) * m.orbitRadiusZ
      );
      obj.rotation.y += m.rotationSpeed;
      obj.rotation.x = Math.sin(orbitT * 0.7) * 0.05;
    }
  });
})();
