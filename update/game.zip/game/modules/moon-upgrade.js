(function () {
  const THREE = AFRAME.THREE;
  const textureLoader = new THREE.TextureLoader();

  const LAYOUT = {
    room: 'test-room-only',
    moon: {
      basePosition: { x: -34, y: 176, z: -390 },
      scale: { x: 21, y: 21, z: 21 },
      orbitRadiusX: 34,
      orbitRadiusY: 12,
      orbitRadiusZ: 26,
      orbitSpeed: 0.00018,
      rotationSpeed: 0.0012
    },
    mars: {
      basePosition: { x: 138, y: 194, z: -450 },
      scale: { x: 10.8, y: 10.8, z: 10.8 },
      orbitRadiusX: 26,
      orbitRadiusY: 10,
      orbitRadiusZ: 20,
      orbitSpeed: 0.00022,
      rotationSpeed: 0.0016
    }
  };

  window.SVRCelestialLayout = LAYOUT;

  function dirFromPosition(pos) {
    return new THREE.Vector3(pos.x, pos.y, pos.z).normalize();
  }

  function loadMoonTextures() {
    const diffuse = textureLoader.load('assets/textures/moon_final_diffuse.png');
    const bump = textureLoader.load('assets/textures/moon_final_bump.png');
    [diffuse, bump].forEach(function (tex) {
      tex.colorSpace = tex === diffuse ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      tex.wrapS = THREE.ClampToEdgeWrapping;
      tex.wrapT = THREE.ClampToEdgeWrapping;
      tex.anisotropy = 4;
      tex.needsUpdate = true;
    });
    return { diffuse, bump };
  }

  function buildStarField() {
    const geometry = new THREE.BufferGeometry();
    const positions = [];
    const starCount = 800;
    const moonDir = dirFromPosition(LAYOUT.moon.basePosition);
    const marsDir = dirFromPosition(LAYOUT.mars.basePosition);

    let tries = 0;
    while (positions.length < starCount * 3 && tries < starCount * 28) {
      tries += 1;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.6;
      const radius = 760 + Math.random() * 240;
      const x = Math.sin(phi) * Math.cos(theta) * radius;
      const y = 110 + Math.cos(phi) * radius * 0.90;
      const z = -Math.abs(Math.sin(phi) * Math.sin(theta) * radius) - 280;
      const d = new THREE.Vector3(x, y, z).normalize();

      if (d.dot(moonDir) > 0.989) continue;
      if (d.dot(marsDir) > 0.992) continue;
      positions.push(x, y, z);
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 1.0,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.92,
      depthWrite: false,
      depthTest: true
    });

    return new THREE.Points(geometry, material);
  }

  function makeMarsTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    const base = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    base.addColorStop(0, '#7a2f16');
    base.addColorStop(0.25, '#b64d25');
    base.addColorStop(0.6, '#dd7443');
    base.addColorStop(1, '#8a381a');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    function blotch(count, minR, maxR, colors, alpha) {
      for (let i = 0; i < count; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const r = minR + Math.random() * (maxR - minR);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        const c = colors[(Math.random() * colors.length) | 0];
        g.addColorStop(0, c);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalAlpha = alpha;
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    blotch(220, 14, 82, ['#ffcb9e', '#f29a66', '#5d210f', '#9a411f'], 0.42);
    blotch(90, 24, 120, ['#ffd8b8', '#f6b88f'], 0.18);

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    return tex;
  }

  AFRAME.registerComponent('star-dome', {
    init: function () {
      this.stars = buildStarField();
      this.el.object3D.add(this.stars);
    },
    tick: function (time, dt) {
      if (!this.stars) return;
      this.stars.rotation.y += (dt || 16) * 0.0000025;
    }
  });

  AFRAME.registerComponent('cinematic-moon', {
    init: function () {
      const loaded = loadMoonTextures();
      this.diffuse = loaded.diffuse;
      this.bump = loaded.bump;
      this.applyMaterial = this.applyMaterial.bind(this);
      this.el.addEventListener('object3dset', this.applyMaterial);
      this.applyMaterial();
      this.ensureGlow();
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.applyMaterial);
    },

    ensureGlow: function () {
      if (this.glowMesh) return;
      const geometry = new THREE.SphereGeometry(1.10, 28, 20);
      const material = new THREE.MeshBasicMaterial({
        color: '#fff0e5',
        transparent: true,
        opacity: 0.08,
        depthWrite: false,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending
      });
      this.glowMesh = new THREE.Mesh(geometry, material);
      this.el.object3D.add(this.glowMesh);
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: this.diffuse,
          bumpMap: this.bump,
          bumpScale: 0.18,
          roughness: 1.0,
          metalness: 0.0,
          emissive: '#171619',
          emissiveIntensity: 0.05
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
        obj.renderOrder = 4;
      });
    },

    tick: function (time, dt) {
      const obj = this.el.object3D;
      const m = LAYOUT.moon;
      const orbitT = time * m.orbitSpeed;
      obj.position.set(
        m.basePosition.x + Math.cos(orbitT) * m.orbitRadiusX,
        m.basePosition.y + Math.sin(orbitT * 0.9) * m.orbitRadiusY,
        m.basePosition.z + Math.sin(orbitT) * m.orbitRadiusZ
      );
      obj.rotation.y += (dt || 16) * m.rotationSpeed;
      obj.rotation.z = Math.sin(orbitT * 0.55) * 0.05;
    }
  });

  AFRAME.registerComponent('cinematic-mars', {
    init: function () {
      this.texture = makeMarsTexture();
      this.applyMaterial = this.applyMaterial.bind(this);
      this.el.addEventListener('object3dset', this.applyMaterial);
      this.applyMaterial();
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.applyMaterial);
    },

    applyMaterial: function () {
      const mesh = this.el.getObject3D('mesh');
      if (!mesh) return;
      mesh.traverse((obj) => {
        if (!obj.isMesh) return;
        obj.material = new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: this.texture,
          roughness: 0.94,
          metalness: 0.0,
          emissive: '#5d2612',
          emissiveIntensity: 0.18
        });
        obj.castShadow = false;
        obj.receiveShadow = false;
        obj.renderOrder = 3;
      });
    },

    tick: function (time, dt) {
      const obj = this.el.object3D;
      const m = LAYOUT.mars;
      const orbitT = time * m.orbitSpeed;
      obj.position.set(
        m.basePosition.x + Math.cos(orbitT) * m.orbitRadiusX,
        m.basePosition.y + Math.sin(orbitT * 1.1) * m.orbitRadiusY,
        m.basePosition.z + Math.sin(orbitT) * m.orbitRadiusZ
      );
      obj.rotation.y += (dt || 16) * m.rotationSpeed;
      obj.rotation.x = Math.sin(orbitT * 0.7) * 0.08;
    }
  });
})();
