(function () {
  const THREE = AFRAME.THREE;
  const LAYOUT = {
    room: 'test-room-only',
    moon: {
      position: { x: -34, y: 132, z: -390 },
      radius: 31
    },
    mars: {
      position: { x: 70, y: 126, z: -360 },
      radius: 13
    }
  };

  window.SVRCelestialLayout = LAYOUT;

  function makeSkyTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 2048;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');

    const bg = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bg.addColorStop(0, '#010205');
    bg.addColorStop(0.55, '#03040a');
    bg.addColorStop(1, '#05060b');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < 1400; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      const r = Math.random() < 0.12 ? 2.2 : (0.5 + Math.random() * 1.4);
      const a = 0.30 + Math.random() * 0.70;
      ctx.fillStyle = `rgba(255,255,255,${a})`;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    for (let i = 0; i < 180; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height * 0.85;
      const g = ctx.createRadialGradient(x, y, 0, x, y, 10 + Math.random() * 20);
      g.addColorStop(0, 'rgba(255,255,255,0.28)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, 10 + Math.random() * 20, 0, Math.PI * 2);
      ctx.fill();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.needsUpdate = true;
    return texture;
  }

  function makeGlowTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');
    const g = ctx.createRadialGradient(512, 512, 0, 512, 512, 512);
    g.addColorStop(0, 'rgba(255,247,236,0.18)');
    g.addColorStop(0.32, 'rgba(255,237,224,0.12)');
    g.addColorStop(0.64, 'rgba(255,220,205,0.05)');
    g.addColorStop(1, 'rgba(255,220,205,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 1024, 1024);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.needsUpdate = true;
    return texture;
  }

  function makeMarsTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    const base = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    base.addColorStop(0, '#7d2f16');
    base.addColorStop(0.25, '#c45d30');
    base.addColorStop(0.55, '#f09359');
    base.addColorStop(0.8, '#a74520');
    base.addColorStop(1, '#742e18');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    function blotches(count, minR, maxR, colors, alpha) {
      for (let i = 0; i < count; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const r = minR + Math.random() * (maxR - minR);
        const color = colors[(Math.random() * colors.length) | 0];
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, color);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalAlpha = alpha;
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    blotches(240, 18, 82, ['#f1b078', '#ffcca1', '#7f331c', '#4d1d0e', '#ffd8b0'], 0.46);
    blotches(80, 35, 120, ['#ffe2c2', '#f9c39d'], 0.28);

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.needsUpdate = true;
    return texture;
  }

  AFRAME.registerComponent('romantic-sky', {
    init: function () {
      const geo = new THREE.SphereGeometry(4200, 28, 20);
      const mat = new THREE.MeshBasicMaterial({
        map: makeSkyTexture(),
        side: THREE.BackSide,
        fog: false,
        depthWrite: false
      });
      this.mesh = new THREE.Mesh(geo, mat);
      this.el.object3D.add(this.mesh);
    },
    tick: function (time) {
      if (this.mesh) this.mesh.rotation.y = time * 0.000003;
    }
  });

  AFRAME.registerComponent('hero-moon', {
    init: function () {
      const scene = this.el.sceneEl;
      const diffuseImg = document.getElementById('moonDiffuse');
      const bumpImg = document.getElementById('moonBump');
      const diffuse = new THREE.Texture(diffuseImg);
      diffuse.colorSpace = THREE.SRGBColorSpace;
      diffuse.needsUpdate = true;
      const bump = new THREE.Texture(bumpImg);
      bump.needsUpdate = true;

      const disc = new THREE.CircleGeometry(LAYOUT.moon.radius, 72);
      const mat = new THREE.MeshStandardMaterial({
        color: '#ffffff',
        map: diffuse,
        bumpMap: bump,
        bumpScale: 1.0,
        roughness: 1,
        metalness: 0,
        emissive: '#2a2320',
        emissiveIntensity: 0.16,
        fog: false
      });
      this.moon = new THREE.Mesh(disc, mat);
      this.moon.renderOrder = 3;
      this.el.object3D.add(this.moon);

      const glowGeo = new THREE.CircleGeometry(LAYOUT.moon.radius * 1.22, 72);
      const glowMat = new THREE.MeshBasicMaterial({
        map: makeGlowTexture(),
        transparent: true,
        opacity: 0.92,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        fog: false
      });
      this.glow = new THREE.Mesh(glowGeo, glowMat);
      this.glow.position.z = -0.6;
      this.glow.renderOrder = 2;
      this.el.object3D.add(this.glow);
      this.spin = 0;
    },

    tick: function (time) {
      const cam = this.el.sceneEl.camera;
      if (!cam || !this.moon) return;
      const camPos = new THREE.Vector3();
      cam.getWorldPosition(camPos);
      this.el.object3D.lookAt(camPos);
      this.spin += 0.00008;
      this.moon.rotation.z = this.spin;
      if (this.glow) this.glow.rotation.z = -this.spin * 0.35;
      this.el.object3D.position.set(
        LAYOUT.moon.position.x,
        LAYOUT.moon.position.y + Math.sin(time * 0.00002) * 0.5,
        LAYOUT.moon.position.z
      );
    }
  });

  AFRAME.registerComponent('hero-mars', {
    init: function () {
      const geo = new THREE.SphereGeometry(LAYOUT.mars.radius, 32, 24);
      const mat = new THREE.MeshStandardMaterial({
        color: '#ffffff',
        map: makeMarsTexture(),
        roughness: 0.96,
        metalness: 0,
        emissive: '#83351b',
        emissiveIntensity: 0.32,
        fog: false
      });
      this.mesh = new THREE.Mesh(geo, mat);
      this.mesh.renderOrder = 3;
      this.el.object3D.add(this.mesh);
    },
    tick: function (time) {
      if (!this.mesh) return;
      this.mesh.rotation.y = time * 0.00004;
      this.el.object3D.position.set(
        LAYOUT.mars.position.x + Math.sin(time * 0.00002) * 0.6,
        LAYOUT.mars.position.y + Math.sin(time * 0.000018) * 0.35,
        LAYOUT.mars.position.z
      );
    }
  });
})();
