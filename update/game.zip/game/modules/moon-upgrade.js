(function () {
  const THREE = AFRAME.THREE;

  function buildStarField() {
    const geometry = new THREE.BufferGeometry();
    const starCount = 700;
    const positions = new Float32Array(starCount * 3);
    const radiusMin = 90;
    const radiusMax = 170;

    for (let i = 0; i < starCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.72;
      const radius = radiusMin + Math.random() * (radiusMax - radiusMin);
      const x = Math.sin(phi) * Math.cos(theta) * radius;
      const y = 18 + Math.cos(phi) * radius * 0.62;
      const z = -Math.abs(Math.sin(phi) * Math.sin(theta) * radius) - 30;
      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.9,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.92,
      depthWrite: false
    });

    return new THREE.Points(geometry, material);
  }

  AFRAME.registerComponent('star-dome', {
    init: function () {
      const stars = buildStarField();
      this.el.object3D.add(stars);
      this.stars = stars;
    },

    tick: function (time) {
      if (!this.stars) return;
      this.stars.rotation.y = time * 0.000015;
    }
  });

  AFRAME.registerComponent('cinematic-moon', {
    init: function () {
      this.loaded = false;
      this.el.addEventListener('model-loaded', () => {
        const mesh = this.el.getObject3D('mesh');
        if (!mesh) return;

        mesh.traverse((obj) => {
          if (!obj.isMesh) return;

          const sourceMaterials = Array.isArray(obj.material) ? obj.material : [obj.material];
          const upgraded = sourceMaterials.map((mat) => {
            const next = mat && mat.clone ? mat.clone() : new THREE.MeshStandardMaterial({ color: '#cfd3dc' });
            next.color = new THREE.Color('#d2d6de');
            next.roughness = 1;
            next.metalness = 0;
            next.envMapIntensity = 0.15;
            next.emissive = new THREE.Color('#090909');
            next.emissiveIntensity = 0.18;
            if (next.normalScale && next.normalScale.set) next.normalScale.set(1.05, 1.05);
            if (next.map) {
              next.map.anisotropy = 8;
              next.map.needsUpdate = true;
            }
            next.needsUpdate = true;
            return next;
          });

          obj.material = Array.isArray(obj.material) ? upgraded : upgraded[0];
          obj.castShadow = false;
          obj.receiveShadow = false;
        });

        this.loaded = true;
      });
    },

    tick: function (time) {
      const obj = this.el.object3D;
      obj.rotation.y = THREE.MathUtils.degToRad(16) + time * 0.00003;
      obj.position.x = Math.sin(time * 0.00008) * 2.5;
      obj.position.y = 52 + Math.sin(time * 0.00005) * 0.8;
    }
  });
})();
