Phase H module: upgraded poker evaluator, showdown, side-pots, and legal raise foundation.
