
export function initScene(){
 console.log("Scene system ready")
}
