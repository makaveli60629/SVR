import * as THREE from "three";
import { CONFIG } from "./config.js";

const a = new THREE.Vector3();
const b = new THREE.Vector3();
const c = new THREE.Vector3();

export function isPinching(hand) {
  const index = hand?.joints?.["index-finger-tip"];
  const thumb = hand?.joints?.["thumb-tip"];
  if (!index || !thumb) return false;
  index.getWorldPosition(a);
  thumb.getWorldPosition(b);
  return a.distanceTo(b) < CONFIG.PINCH_DIST;
}

export function getIndexTipWorld(hand, target = new THREE.Vector3()) {
  const tip = hand?.joints?.["index-finger-tip"];
  if (!tip) return null;
  tip.getWorldPosition(target);
  return target;
}

export function getWristWorld(hand, target = new THREE.Vector3()) {
  const wrist = hand?.joints?.wrist;
  if (!wrist) return null;
  wrist.getWorldPosition(target);
  return target;
}

export function getHandAimPoint(hand, maxDistance = 18) {
  const wrist = hand?.joints?.wrist;
  const tip = hand?.joints?.["index-finger-tip"];
  if (!wrist || !tip) return null;
  wrist.getWorldPosition(a);
  tip.getWorldPosition(b);
  c.copy(b).sub(a).normalize();
  if (c.y > -0.08) c.y = -0.08;
  c.normalize();
  const t = b.y / -c.y;
  if (!isFinite(t) || t < 0.15) return null;
  return new THREE.Vector3(
    b.x + c.x * Math.min(t, maxDistance),
    0,
    b.z + c.z * Math.min(t, maxDistance)
  );
}
