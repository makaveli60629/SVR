export function runModuleAudit({ scene, roomClamp, hands, tp, watch, stats, jointDebug, log = console.log }) {
  const checks = [
    ["scene tick", typeof scene?.userData?._tickWorld === "function"],
    ["room clamp", Number.isFinite(roomClamp) && roomClamp > 1],
    ["hands api", typeof hands?.getLeft === "function" && typeof hands?.getRight === "function"],
    ["teleport api", typeof tp?.update === "function" && typeof tp?.onSessionStart === "function" && typeof tp?.setLogoTexture === "function"],
    ["watch api", typeof watch?.update === "function"],
    ["stats api", typeof stats?.update === "function" && typeof stats?.toggle === "function"],
    ["joint debug api", typeof jointDebug?.update === "function" && typeof jointDebug?.toggle === "function"],
  ];

  const lines = checks.map(([label, ok]) => `${ok ? "PASS" : "FAIL"} • ${label}`);
  const failed = checks.filter(([, ok]) => !ok).map(([label]) => label);
  const storefronts = scene?.userData?._storefronts?.length || 0;
  const report = {
    ok: failed.length === 0,
    storefronts,
    lines: [
      ...lines,
      `INFO • storefront shells: ${storefronts}`,
      `INFO • juan feature: ${scene?.userData?._juanFeature ? "present" : "missing"}`,
    ],
  };

  for (const line of report.lines) log(`[AUDIT] ${line}`);
  if (failed.length) log(`[AUDIT] Failed checks: ${failed.join(", ")}`);
  return report;
}
