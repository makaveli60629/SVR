
export function initEnvironment(){
    console.log("Cyber casino environment loaded");
}
