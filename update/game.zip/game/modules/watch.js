import * as THREE from "three";

export function createWristWatch({ scene }){
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext("2d");

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;

  const mat = new THREE.MeshStandardMaterial({
    map: tex,
    transparent: true,
    emissive: new THREE.Color(0xb48cff),
    emissiveIntensity: 0.75
  });

  const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.08), mat);
  plate.renderOrder = 10;
  plate.visible = false;

  const back = new THREE.Mesh(
    new THREE.PlaneGeometry(0.17, 0.09),
    new THREE.MeshStandardMaterial({
      color: 0x0a0a14,
      roughness: 0.6,
      metalness: 0.2,
      emissive: 0x120a20,
      emissiveIntensity: 0.35,
      transparent: true,
      opacity: 0.9
    })
  );
  back.position.z = -0.001;
  plate.add(back);
  scene.add(plate);

  function roundRect(c, x, y, w, h, r){
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }

  function draw(){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(0,0,0,0.65)";
    roundRect(ctx, 12, 12, 488, 232, 28);
    ctx.fill();

    ctx.strokeStyle = "rgba(180,140,255,0.55)";
    ctx.lineWidth = 6;
    roundRect(ctx, 12, 12, 488, 232, 28);
    ctx.stroke();

    const now = new Date();
    const t = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    const d = now.toLocaleDateString();

    ctx.fillStyle = "#e9e9ff";
    ctx.font = "bold 64px system-ui, Arial";
    ctx.fillText(t, 26, 110);

    ctx.font = "24px system-ui, Arial";
    ctx.fillStyle = "rgba(233,233,255,0.9)";
    ctx.fillText(d, 28, 155);

    ctx.fillStyle = "rgba(180,140,255,0.95)";
    ctx.font = "bold 26px system-ui, Arial";
    ctx.fillText("SVR WATCH ONLINE", 28, 200);

    tex.needsUpdate = true;
  }

  let accum = 0;

  function update(dt, leftHand, rightHand){
    accum += dt;
    if (accum > 0.5){
      draw();
      accum = 0;
    }

    const wrist = leftHand?.joints?.["wrist"] || rightHand?.joints?.["wrist"];
    if (!wrist){
      plate.visible = false;
      return;
    }

    plate.visible = true;
    wrist.updateWorldMatrix(true, false);
    wrist.getWorldPosition(plate.position);
    wrist.getWorldQuaternion(plate.quaternion);
    plate.translateY(0.03);
    plate.translateZ(0.02);
    plate.rotateX(-Math.PI / 2.2);
  }

  draw();
  return { update };
}
