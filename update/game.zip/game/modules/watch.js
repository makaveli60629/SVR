import * as THREE from "three";
import { CONFIG } from "./config.js";
import { makeCanvasLabel, roundRect, makeTextPlane } from "./utils.js";

export function createWatch({ scene, camera, renderer }) {
  const root = new THREE.Group();
  root.visible = false;
  scene.add(root);

  const { canvas, ctx, texture } = makeCanvasLabel({
    width: 1024,
    height: 512,
    draw(drawCtx, w, h) {
      drawCtx.clearRect(0, 0, w, h);
      drawCtx.fillStyle = "rgba(4,6,12,0.88)";
      roundRect(drawCtx, 18, 18, w - 36, h - 36, 48);
      drawCtx.fill();
      drawCtx.strokeStyle = "rgba(180,140,255,0.72)";
      drawCtx.lineWidth = 10;
      roundRect(drawCtx, 18, 18, w - 36, h - 36, 48);
      drawCtx.stroke();
    }
  });

  const frame = new THREE.Mesh(
    new THREE.PlaneGeometry(0.2, 0.112),
    new THREE.MeshStandardMaterial({ map: texture, transparent: true, emissive: 0x451363, emissiveIntensity: 0.92, metalness: 0.22, roughness: 0.3 })
  );
  root.add(frame);

  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(0.206, 0.118),
    new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.08, transmission: 0.22, roughness: 0.08, metalness: 0.1 })
  );
  glass.position.z = 0.001;
  root.add(glass);

  const buttons = [];
  const buttonDefs = [
    { id: "teleport", label: "TP", x: -0.058 },
    { id: "seat", label: "SEAT", x: 0 },
    { id: "reset", label: "RST", x: 0.058 },
  ];

  for (const def of buttonDefs) {
    const tex = makeTextPlane(def.label, { width: 256, height: 128, font: "bold 54px system-ui" });
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(def.id === "seat" ? 0.056 : 0.046, 0.022),
      new THREE.MeshStandardMaterial({ map: tex, transparent: true, emissive: 0x2f1144, emissiveIntensity: 1.0, roughness: 0.28, metalness: 0.12 })
    );
    mesh.position.set(def.x, -0.037, 0.003);
    mesh.userData.action = def.id;
    buttons.push(mesh);
    root.add(mesh);
  }

  const led = new THREE.Mesh(
    new THREE.CircleGeometry(0.006, 20),
    new THREE.MeshBasicMaterial({ color: 0x36ff9d })
  );
  led.position.set(0.083, 0.042, 0.003);
  root.add(led);

  let lastRefresh = 0;
  let state = {
    teleportEnabled: false,
    seated: false,
    mode: "HAND",
  };

  const worldWrist = new THREE.Vector3();
  const worldCamera = new THREE.Vector3();
  const offset = new THREE.Vector3();

  function redraw(force = false) {
    const now = performance.now() * 0.001;
    if (!force && now - lastRefresh < CONFIG.WATCH_REFRESH_S) return;
    lastRefresh = now;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(4,6,12,0.88)";
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 48);
    ctx.fill();
    ctx.strokeStyle = "rgba(180,140,255,0.72)";
    ctx.lineWidth = 10;
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 48);
    ctx.stroke();

    const nowDate = new Date();
    const time = nowDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });

    ctx.fillStyle = "#f5f0ff";
    ctx.font = "bold 122px system-ui";
    ctx.fillText(time, 42, 150);

    ctx.font = "36px system-ui";
    ctx.fillStyle = "rgba(240,236,255,0.92)";
    ctx.fillText(`MODE ${state.mode}`, 48, 218);
    ctx.fillText(`TP ${state.teleportEnabled ? "ARMED" : "OFF"}`, 48, 262);
    ctx.fillText(`SEAT ${state.seated ? "LOCKED" : "FREE"}`, 48, 306);

    ctx.fillStyle = state.teleportEnabled ? "rgba(95,255,164,0.95)" : "rgba(255,92,122,0.95)";
    ctx.font = "bold 40px system-ui";
    ctx.fillText(state.teleportEnabled ? "ARC READY" : "WATCH READY", 48, 386);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 44px system-ui";
    ctx.fillText("SVR POKER", 742, 74);

    ctx.font = "30px system-ui";
    ctx.fillStyle = "rgba(232,230,255,0.78)";
    ctx.fillText("TP    SEAT    RST", 640, 450);

    texture.needsUpdate = true;
    led.material.color.set(state.teleportEnabled ? 0x36ff9d : 0xff627b);
  }

  function setState(next) {
    const merged = { ...state, ...next };
    const changed = merged.teleportEnabled !== state.teleportEnabled || merged.seated !== state.seated || merged.mode !== state.mode;
    state = merged;
    if (changed) redraw(true);
  }

  function updatePose({ leftHand, leftController, rightController, xrPresenting }) {
    const wrist = leftHand?.joints?.wrist || leftController || rightController;
    if (!xrPresenting || !wrist) {
      root.visible = false;
      return;
    }

    root.visible = true;
    wrist.updateWorldMatrix?.(true, false);
    wrist.getWorldPosition(worldWrist);
    renderer.xr.getCamera(camera).getWorldPosition(worldCamera);

    offset.set(-0.045, 0.02, 0.02);
    if (wrist.userData?.handedness === "left" || wrist === leftController || leftHand?.joints?.wrist === wrist) {
      // keep left-side watch close to forearm
      offset.set(-0.045, 0.02, 0.022);
    } else {
      offset.set(0.045, 0.02, 0.022);
    }

    root.position.copy(worldWrist).add(offset);
    root.lookAt(worldCamera);
  }

  redraw(true);

  return {
    root,
    buttons,
    setState,
    updatePose,
  };
}
