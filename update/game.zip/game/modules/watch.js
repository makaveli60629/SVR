import * as THREE from "three";
import { isPinching } from "./gestures.js";

export function createWristWatch({ scene, getState = ()=>({}), actions = {} }){
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const mat = new THREE.MeshStandardMaterial({
    map: tex,
    transparent: true,
    emissive: new THREE.Color(0xb48cff),
    emissiveIntensity: 0.85,
    roughness: 0.45,
    metalness: 0.18
  });

  const plateW = 0.24;
  const plateH = 0.115;
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(plateW, plateH), mat);
  plate.renderOrder = 20;
  plate.visible = false;

  const back = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 1.04, plateH * 1.06, 0.006),
    new THREE.MeshStandardMaterial({
      color: 0x070812,
      roughness: 0.58,
      metalness: 0.22,
      emissive: 0x130a1f,
      emissiveIntensity: 0.35
    })
  );
  back.position.z = -0.004;
  plate.add(back);

  const strap = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 0.28, plateH * 1.7, 0.004),
    new THREE.MeshStandardMaterial({
      color: 0x141523,
      roughness: 0.82,
      metalness: 0.05,
      emissive: 0x100a18,
      emissiveIntensity: 0.12
    })
  );
  strap.position.z = -0.006;
  plate.add(strap);

  scene.add(plate);

  function rr(c, x, y, w, h, r){
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }

  function drawButton(btn, hovered){
    ctx.save();
    ctx.fillStyle = hovered ? "rgba(180,140,255,0.28)" : "rgba(255,255,255,0.08)";
    ctx.strokeStyle = hovered ? "rgba(180,140,255,0.95)" : "rgba(180,140,255,0.35)";
    ctx.lineWidth = hovered ? 5 : 3;
    rr(ctx, btn.x, btn.y, btn.w, btn.h, 18);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = hovered ? "#ffffff" : "#e8e8ff";
    ctx.font = `bold ${btn.font || 28}px system-ui, Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2 + 1);
    ctx.restore();
  }

  let hoveredId = null;
  let pressed = false;
  let lastSig = "";

  function buildButtons(state){
    const buttons = [
      { id: "audio", label: state.audioEnabled ? "Music: On" : "Music: Off", x: 30, y: 345, w: 210, h: 58 },
      { id: "next", label: "Next Track", x: 258, y: 345, w: 190, h: 58 },
    ];

    if (state.seated){
      buttons.push({ id: "leave", label: "Leave Table", x: 466, y: 345, w: 240, h: 58 });
    } else if (state.inTableZone){
      buttons.push({ id: "join", label: "Join Table", x: 466, y: 345, w: 240, h: 58 });
    }

    return buttons;
  }

  function draw(force = false){
    const state = getState();
    const sig = JSON.stringify({
      h: hoveredId,
      t: state.trackTitle,
      ae: state.audioEnabled,
      c: state.cash,
      s: state.seated,
      z: state.inTableZone,
      seat: state.seatLabel,
      time: new Date().getSeconds()
    });
    if (!force && sig === lastSig) return;
    lastSig = sig;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, "rgba(5,8,16,0.90)");
    grad.addColorStop(1, "rgba(18,10,32,0.94)");
    ctx.fillStyle = grad;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.fill();

    ctx.strokeStyle = "rgba(180,140,255,0.6)";
    ctx.lineWidth = 6;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.stroke();

    const stateBand = ctx.createLinearGradient(0, 0, canvas.width, 0);
    stateBand.addColorStop(0, "rgba(120,70,200,0.35)");
    stateBand.addColorStop(1, "rgba(50,16,92,0.15)");
    ctx.fillStyle = stateBand;
    rr(ctx, 24, 24, 976, 86, 26);
    ctx.fill();

    const now = new Date();
    const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 60px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(timeText, 42, 68);

    ctx.textAlign = "right";
    ctx.fillStyle = "#7ff5c7";
    ctx.font = "bold 40px system-ui, Arial";
    ctx.fillText(`$${Number(state.cash || 0).toLocaleString()}`, 972, 68);

    ctx.textAlign = "left";
    ctx.fillStyle = "rgba(233,233,255,0.95)";
    ctx.font = "bold 30px system-ui, Arial";
    ctx.fillText("SVR INNER WRIST CONSOLE", 34, 150);

    ctx.fillStyle = "rgba(233,233,255,0.78)";
    ctx.font = "25px system-ui, Arial";
    ctx.fillText(`Seat: ${state.seated ? state.seatLabel : "Standing"}`, 36, 205);
    ctx.fillText(`Music: ${state.audioEnabled ? state.trackTitle : "Muted"}`, 36, 243);
    ctx.fillText(`Table Zone: ${state.inTableZone ? "Ready" : "Walk closer"}`, 36, 281);

    ctx.textAlign = "right";
    ctx.fillStyle = state.seated ? "#7ff5c7" : state.inTableZone ? "#f6e27f" : "rgba(233,233,255,0.72)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText(state.seated ? "AT TABLE" : (state.inTableZone ? "JOIN READY" : "LOBBY"), 970, 148);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 22px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.fillText("Tap with your other hand while pinching", 36, 315);

    for (const btn of buildButtons(state)) drawButton(btn, hoveredId === btn.id);

    tex.needsUpdate = true;
  }

  function localHit(local){
    const state = getState();
    const x = ((local.x / plateW) + 0.5) * canvas.width;
    const y = ((-local.y / plateH) + 0.5) * canvas.height;
    for (const btn of buildButtons(state)){
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return btn.id;
    }
    return null;
  }

  function activate(id){
    if (!id) return;
    if (id === "audio") actions.toggleAudio?.();
    if (id === "next") actions.nextTrack?.();
    if (id === "join") actions.joinTable?.();
    if (id === "leave") actions.leaveTable?.();
  }

  let accum = 0;

  function update(dt, leftHand, rightHand){
    accum += dt;

    const anchor = leftHand?.joints?.wrist ? leftHand : rightHand?.joints?.wrist ? rightHand : null;
    if (!anchor?.joints?.wrist){
      plate.visible = false;
      hoveredId = null;
      draw(true);
      return;
    }

    const watchOnLeft = anchor === leftHand;
    const otherHand = watchOnLeft ? rightHand : leftHand;
    const wrist = anchor.joints.wrist;

    plate.visible = true;
    wrist.updateWorldMatrix(true, false);
    wrist.getWorldPosition(plate.position);
    wrist.getWorldQuaternion(plate.quaternion);

    const side = watchOnLeft ? 1 : -1;
    plate.translateX(0.048 * side);
    plate.translateY(-0.01);
    plate.translateZ(0.055);
    plate.rotateZ(side * -Math.PI * 0.52);
    plate.rotateX(-Math.PI * 0.60);

    let nextHovered = null;
    const tip = otherHand?.joints?.["index-finger-tip"];
    if (tip){
      const tipPos = new THREE.Vector3();
      tip.getWorldPosition(tipPos);
      const local = plate.worldToLocal(tipPos.clone());
      if (Math.abs(local.z) < 0.04 && Math.abs(local.x) < plateW * 0.52 && Math.abs(local.y) < plateH * 0.52){
        nextHovered = localHit(local);
      }
    }
    hoveredId = nextHovered;

    const pinching = !!otherHand && isPinching(otherHand);
    if (hoveredId && pinching && !pressed){
      pressed = true;
      activate(hoveredId);
    }
    if (!pinching) pressed = false;

    if (accum > 0.12 || hoveredId !== nextHovered){
      draw();
      accum = 0;
    } else {
      draw();
    }
  }

  draw(true);
  return { update, redraw: ()=>draw(true) };
}
