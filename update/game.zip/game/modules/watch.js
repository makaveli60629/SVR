import * as THREE from "three";
import { isPinching } from "./gestures.js";

export function createWristWatch({ scene, getState = ()=>({}), actions = {} }){
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const mat = new THREE.MeshStandardMaterial({
    map: tex,
    transparent: true,
    emissive: new THREE.Color(0xb48cff),
    emissiveIntensity: 0.9,
    roughness: 0.42,
    metalness: 0.22,
    side: THREE.DoubleSide
  });

  const plateW = 0.30;
  const plateH = 0.128;
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(plateW, plateH), mat);
  plate.renderOrder = 20;
  plate.visible = false;

  const shell = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 1.06, plateH * 1.08, 0.012),
    new THREE.MeshStandardMaterial({
      color: 0x090c14,
      roughness: 0.5,
      metalness: 0.4,
      emissive: 0x130a1f,
      emissiveIntensity: 0.3,
      side: THREE.DoubleSide
    })
  );
  shell.position.z = -0.006;
  plate.add(shell);

  const bezel = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 1.02, plateH * 1.02, 0.006),
    new THREE.MeshStandardMaterial({
      color: 0x2b2336,
      roughness: 0.35,
      metalness: 0.6,
      emissive: 0x1c1030,
      emissiveIntensity: 0.25,
      side: THREE.DoubleSide
    })
  );
  bezel.position.z = -0.0025;
  plate.add(bezel);

  const strap = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 0.24, plateH * 2.45, 0.005),
    new THREE.MeshStandardMaterial({
      color: 0x131521,
      roughness: 0.82,
      metalness: 0.06,
      emissive: 0x0f0c16,
      emissiveIntensity: 0.12,
      side: THREE.DoubleSide
    })
  );
  strap.position.z = -0.01;
  plate.add(strap);

  scene.add(plate);

  function rr(c, x, y, w, h, r){
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }

  function drawButton(btn, hovered){
    ctx.save();
    ctx.fillStyle = hovered ? "rgba(180,140,255,0.30)" : "rgba(255,255,255,0.08)";
    ctx.strokeStyle = hovered ? "rgba(180,140,255,0.98)" : "rgba(180,140,255,0.35)";
    ctx.lineWidth = hovered ? 5 : 3;
    rr(ctx, btn.x, btn.y, btn.w, btn.h, 18);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = hovered ? "#ffffff" : "#e8e8ff";
    ctx.font = `bold ${btn.font || 28}px system-ui, Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2 + 1);
    ctx.restore();
  }

  let hoveredId = null;
  let pressed = false;
  let lastSig = "";

  function buildButtons(state){
    const buttons = [
      { id: "audio", label: state.audioEnabled ? "Music: On" : "Music: Off", x: 30, y: 360, w: 210, h: 58 },
      { id: "next", label: "Next Track", x: 258, y: 360, w: 210, h: 58 },
    ];

    if (state.seated){
      buttons.push({ id: "leave", label: "Leave Table", x: 486, y: 360, w: 240, h: 58 });
    } else if (state.inTableZone){
      buttons.push({ id: "join", label: "Join Table", x: 486, y: 360, w: 240, h: 58 });
    }

    return buttons;
  }

  function draw(force = false){
    const state = getState();
    const sig = JSON.stringify({
      h: hoveredId,
      t: state.trackTitle,
      ae: state.audioEnabled,
      c: state.cash,
      s: state.seated,
      z: state.inTableZone,
      seat: state.seatLabel,
      p: state.audioPrimed,
      err: state.audioError || "",
      sec: Math.floor(performance.now() / 1000)
    });
    if (!force && sig === lastSig) return;
    lastSig = sig;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, "rgba(5,8,16,0.94)");
    grad.addColorStop(1, "rgba(20,10,36,0.98)");
    ctx.fillStyle = grad;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.fill();

    ctx.strokeStyle = "rgba(180,140,255,0.6)";
    ctx.lineWidth = 6;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.stroke();

    const band = ctx.createLinearGradient(0, 0, canvas.width, 0);
    band.addColorStop(0, "rgba(120,70,200,0.35)");
    band.addColorStop(1, "rgba(50,16,92,0.12)");
    ctx.fillStyle = band;
    rr(ctx, 24, 24, 976, 86, 26);
    ctx.fill();

    ctx.fillStyle = "rgba(180,140,255,0.12)";
    rr(ctx, 24, 118, 976, 220, 26);
    ctx.fill();

    const now = new Date();
    const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 60px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(timeText, 42, 68);

    ctx.textAlign = "right";
    ctx.fillStyle = "#7ff5c7";
    ctx.font = "bold 40px system-ui, Arial";
    ctx.fillText(`$${Number(state.cash || 0).toLocaleString()}`, 972, 68);

    ctx.textAlign = "left";
    ctx.fillStyle = "rgba(233,233,255,0.96)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText("SVR PREDATOR WRIST CONSOLE", 34, 148);

    ctx.fillStyle = "rgba(233,233,255,0.78)";
    ctx.font = "24px system-ui, Arial";
    ctx.fillText(`Seat: ${state.seated ? state.seatLabel : "Standing"}`, 36, 202);
    ctx.fillText(`Zone: ${state.inTableZone ? "Ready to join" : "Walk closer to table"}`, 36, 236);

    ctx.fillStyle = "rgba(180,140,255,0.94)";
    ctx.font = "bold 22px system-ui, Arial";
    ctx.fillText("NOW PLAYING", 36, 278);
    ctx.fillStyle = state.audioEnabled ? "#ffffff" : "rgba(233,233,255,0.70)";
    ctx.font = "bold 28px system-ui, Arial";
    const line2 = state.audioEnabled ? state.trackTitle : (state.audioPrimed ? `Paused • ${state.trackTitle}` : `Tap Music On • ${state.trackTitle}`);
    ctx.fillText(line2, 36, 312);
    if (state.audioError){
      ctx.fillStyle = "#f6e27f";
      ctx.font = "bold 18px system-ui, Arial";
      ctx.fillText(state.audioError, 36, 334);
    }

    ctx.textAlign = "right";
    ctx.fillStyle = state.seated ? "#7ff5c7" : state.inTableZone ? "#f6e27f" : "rgba(233,233,255,0.72)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText(state.seated ? "AT TABLE" : (state.inTableZone ? "JOIN READY" : "LOBBY"), 970, 148);

    ctx.textAlign = "left";
    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 22px system-ui, Arial";
    ctx.fillText("Pinch with your free hand to press a button", 36, 344);

    for (const btn of buildButtons(state)) drawButton(btn, hoveredId === btn.id);

    tex.needsUpdate = true;
  }

  function localHit(local){
    const state = getState();
    const x = ((local.x / plateW) + 0.5) * canvas.width;
    const y = ((-local.y / plateH) + 0.5) * canvas.height;
    for (const btn of buildButtons(state)){
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return btn.id;
    }
    return null;
  }

  function activate(id){
    if (!id) return;
    if (id === "audio") actions.toggleAudio?.();
    if (id === "next") actions.nextTrack?.();
    if (id === "join") actions.joinTable?.();
    if (id === "leave") actions.leaveTable?.();
  }

  let accum = 0;

  function update(dt, leftHand, rightHand){
    accum += dt;

    const anchor = leftHand?.joints?.wrist ? leftHand : rightHand?.joints?.wrist ? rightHand : null;
    if (!anchor?.joints?.wrist){
      plate.visible = false;
      hoveredId = null;
      draw(true);
      return;
    }

    const watchOnLeft = anchor === leftHand;
    const otherHand = watchOnLeft ? rightHand : leftHand;
    const wrist = anchor.joints.wrist;

    plate.visible = true;
    wrist.updateWorldMatrix(true, false);
    wrist.getWorldPosition(plate.position);
    wrist.getWorldQuaternion(plate.quaternion);

    const side = watchOnLeft ? 1 : -1;
    plate.translateX(0.010 * side);
    plate.translateY(-0.084);
    plate.translateZ(0.052);
    plate.rotateY(Math.PI);
    plate.rotateZ(side * -Math.PI * 0.5);
    plate.rotateX(-Math.PI * 0.16);

    let nextHovered = null;
    const tip = otherHand?.joints?.["index-finger-tip"];
    if (tip){
      const tipPos = new THREE.Vector3();
      tip.getWorldPosition(tipPos);
      const local = plate.worldToLocal(tipPos.clone());
      if (Math.abs(local.z) < 0.05 && Math.abs(local.x) < plateW * 0.52 && Math.abs(local.y) < plateH * 0.52){
        nextHovered = localHit(local);
      }
    }

    const hoverChanged = hoveredId !== nextHovered;
    hoveredId = nextHovered;

    const pinching = !!otherHand && isPinching(otherHand);
    if (hoveredId && pinching && !pressed){
      pressed = true;
      activate(hoveredId);
    }
    if (!pinching) pressed = false;

    if (accum > 0.12 || hoverChanged) {
      draw(true);
      accum = 0;
    } else {
      draw();
    }
  }

  draw(true);
  return { update, redraw: ()=>draw(true) };
}
