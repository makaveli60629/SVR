import * as THREE from "three";
import { CONFIG } from "./config.js";
import { makeCanvasLabel, roundRect, makeTextPlane } from "./utils.js";

export function createWatch({ scene, camera, renderer }) {
  const root = new THREE.Group();
  root.visible = false;
  root.scale.setScalar(0.96);
  scene.add(root);

  const { canvas, ctx, texture } = makeCanvasLabel({
    width: 1024,
    height: 512,
    draw(drawCtx, w, h) {
      drawCtx.clearRect(0, 0, w, h);
      drawCtx.fillStyle = "rgba(5,7,11,0.94)";
      roundRect(drawCtx, 18, 18, w - 36, h - 36, 54);
      drawCtx.fill();
      drawCtx.strokeStyle = "rgba(120,214,184,0.40)";
      drawCtx.lineWidth = 8;
      roundRect(drawCtx, 18, 18, w - 36, h - 36, 54);
      drawCtx.stroke();
    }
  });

  const frame = new THREE.Mesh(
    new THREE.PlaneGeometry(0.178, 0.098),
    new THREE.MeshStandardMaterial({ map: texture, transparent: true, emissive: 0x10271f, emissiveIntensity: 0.22, metalness: 0.12, roughness: 0.42 })
  );
  root.add(frame);

  const rim = new THREE.Mesh(
    new THREE.PlaneGeometry(0.188, 0.108),
    new THREE.MeshStandardMaterial({ color: 0x0d0f12, emissive: 0x111917, emissiveIntensity: 0.12, metalness: 0.18, roughness: 0.36 })
  );
  rim.position.z = -0.0016;
  root.add(rim);

  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(0.182, 0.102),
    new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.04, transmission: 0.1, roughness: 0.16, metalness: 0.02 })
  );
  glass.position.z = 0.001;
  root.add(glass);

  const buttons = [];
  const buttonDefs = [
    { id: "teleport", label: "TP", x: -0.056, w: 0.058 },
    { id: "seat", label: "SEAT", x: 0, w: 0.074 },
    { id: "reset", label: "RST", x: 0.056, w: 0.058 },
  ];

  for (const def of buttonDefs) {
    const tex = makeTextPlane(def.label, {
      width: 384,
      height: 144,
      font: def.label === "SEAT" ? "bold 56px system-ui" : "bold 60px system-ui",
      bg: "rgba(10,18,18,0.95)",
      border: "rgba(126,240,208,0.72)",
      fg: "#f2fffb"
    });
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(def.w, 0.028),
      new THREE.MeshStandardMaterial({ map: tex, transparent: true, emissive: 0x123128, emissiveIntensity: 0.4, roughness: 0.4, metalness: 0.06 })
    );
    mesh.position.set(def.x, -0.031, 0.0034);
    mesh.userData.action = def.id;
    buttons.push(mesh);
    root.add(mesh);
  }

  const led = new THREE.Mesh(
    new THREE.CircleGeometry(0.0046, 20),
    new THREE.MeshBasicMaterial({ color: 0x63ffd2 })
  );
  led.position.set(0.072, 0.034, 0.003);
  root.add(led);

  let lastRefresh = 0;
  let state = {
    teleportEnabled: false,
    seated: false,
    mode: "HAND",
  };

  const worldWrist = new THREE.Vector3();
  const targetPos = new THREE.Vector3();
  const wristQuat = new THREE.Quaternion();
  const localQuat = new THREE.Quaternion();
  const desiredQuat = new THREE.Quaternion();
  const tempOffset = new THREE.Vector3();

  function redraw(force = false) {
    const now = performance.now() * 0.001;
    if (!force && now - lastRefresh < CONFIG.WATCH_REFRESH_S) return;
    lastRefresh = now;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(5,7,11,0.94)";
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 54);
    ctx.fill();
    ctx.strokeStyle = "rgba(120,214,184,0.40)";
    ctx.lineWidth = 8;
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 54);
    ctx.stroke();

    const nowDate = new Date();
    const time = nowDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    ctx.fillStyle = "#f1fffb";
    ctx.font = "bold 122px system-ui";
    ctx.fillText(time, 40, 144);

    ctx.font = "34px system-ui";
    ctx.fillStyle = "rgba(238,255,247,0.92)";
    ctx.fillText(`MODE ${state.mode}`, 44, 214);
    ctx.fillText(`TP ${state.teleportEnabled ? "ARMED" : "OFF"}`, 44, 252);
    ctx.fillText(`SEAT ${state.seated ? "LOCKED" : "FREE"}`, 44, 290);

    ctx.fillStyle = state.teleportEnabled ? "rgba(99,255,210,0.95)" : "rgba(255,140,158,0.95)";
    ctx.font = "bold 36px system-ui";
    ctx.fillText(state.teleportEnabled ? "RELEASE TRIGGER TO TELEPORT" : "WATCH READY", 44, 366);

    ctx.fillStyle = "rgba(126,240,208,0.92)";
    ctx.font = "bold 40px system-ui";
    ctx.fillText("SVR POKER", 760, 72);

    ctx.font = "30px system-ui";
    ctx.fillStyle = "rgba(232,255,247,0.76)";
    ctx.fillText("TP    SEAT    RST", 658, 446);

    texture.needsUpdate = true;
    led.material.color.set(state.teleportEnabled ? 0x63ffd2 : 0xff8ca0);
  }

  function setState(next) {
    const merged = { ...state, ...next };
    const changed = merged.teleportEnabled !== state.teleportEnabled || merged.seated !== state.seated || merged.mode !== state.mode;
    state = merged;
    if (changed) redraw(true);
  }

  function updatePose({ leftHand, leftController, rightController, xrPresenting }) {
    const wrist = leftHand?.joints?.wrist || leftController || rightController;
    if (!xrPresenting || !wrist) {
      root.visible = false;
      return;
    }

    root.visible = true;
    wrist.updateWorldMatrix?.(true, false);
    wrist.getWorldPosition(worldWrist);
    wrist.getWorldQuaternion(wristQuat);

    const isLeft = wrist === leftController || leftHand?.joints?.wrist === wrist || wrist.userData?.handedness === "left";
    tempOffset.set(isLeft ? -0.035 : 0.035, 0.016, -0.014).applyQuaternion(wristQuat);
    targetPos.copy(worldWrist).add(tempOffset);
    root.position.lerp(targetPos, CONFIG.WATCH_SMOOTHING);

    const euler = new THREE.Euler(-1.36, isLeft ? 0.02 : -0.02, isLeft ? 1.58 : -1.58, "XYZ");
    localQuat.setFromEuler(euler);
    desiredQuat.copy(wristQuat).multiply(localQuat);
    root.quaternion.slerp(desiredQuat, 0.26);

    redraw();
  }

  redraw(true);

  return {
    root,
    buttons,
    setState,
    updatePose,
  };
}
