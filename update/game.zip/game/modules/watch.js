import * as THREE from "three";
import { CONFIG } from "./config.js";
import { makeCanvasLabel, roundRect, makeTextPlane } from "./utils.js";

export function createWatch({ scene, camera, renderer }) {
  const root = new THREE.Group();
  root.visible = false;
  scene.add(root);

  const { canvas, ctx, texture } = makeCanvasLabel({
    width: 1024,
    height: 512,
    draw(drawCtx, w, h) {
      drawCtx.clearRect(0, 0, w, h);
      drawCtx.fillStyle = "rgba(4,6,12,0.94)";
      roundRect(drawCtx, 16, 16, w - 32, h - 32, 52);
      drawCtx.fill();
      drawCtx.strokeStyle = "rgba(180,140,255,0.6)";
      drawCtx.lineWidth = 8;
      roundRect(drawCtx, 16, 16, w - 32, h - 32, 52);
      drawCtx.stroke();
    },
  });

  const body = new THREE.Mesh(
    new THREE.BoxGeometry(0.18, 0.105, 0.014),
    new THREE.MeshStandardMaterial({ color: 0x0d0e13, roughness: 0.42, metalness: 0.18, emissive: 0x120b1c, emissiveIntensity: 0.08 })
  );
  root.add(body);

  const frame = new THREE.Mesh(
    new THREE.PlaneGeometry(0.172, 0.098),
    new THREE.MeshStandardMaterial({ map: texture, transparent: true, emissive: 0x2a113f, emissiveIntensity: 0.18, metalness: 0.12, roughness: 0.36 })
  );
  frame.position.z = 0.0075;
  root.add(frame);

  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(0.173, 0.099),
    new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.04, transmission: 0.05, roughness: 0.1, metalness: 0.02 })
  );
  glass.position.z = 0.0086;
  root.add(glass);

  const buttons = [];
  const buttonDefs = [
    { id: "teleport", label: "TP", x: -0.052, w: 0.05 },
    { id: "seat", label: "SEAT", x: 0, w: 0.072 },
    { id: "reset", label: "RST", x: 0.052, w: 0.05 },
  ];

  for (const def of buttonDefs) {
    const tex = makeTextPlane(def.label, { width: 320, height: 132, font: "bold 58px system-ui" });
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(def.w, 0.024),
      new THREE.MeshStandardMaterial({ map: tex, transparent: true, emissive: 0x2f1144, emissiveIntensity: 0.25, roughness: 0.3, metalness: 0.08 })
    );
    mesh.position.set(def.x, -0.03, 0.0094);
    mesh.userData.action = def.id;
    buttons.push(mesh);
    root.add(mesh);
  }

  const led = new THREE.Mesh(
    new THREE.CircleGeometry(0.0046, 16),
    new THREE.MeshBasicMaterial({ color: 0x36ff9d })
  );
  led.position.set(0.066, 0.034, 0.0094);
  root.add(led);

  const strapGeo = new THREE.BoxGeometry(0.048, 0.11, 0.008);
  const strapMat = new THREE.MeshStandardMaterial({ color: 0x101116, roughness: 0.78, metalness: 0.04 });
  const strapL = new THREE.Mesh(strapGeo, strapMat);
  strapL.position.set(-0.11, 0, -0.005);
  root.add(strapL);
  const strapR = strapL.clone();
  strapR.position.x = 0.11;
  root.add(strapR);

  let lastRefresh = 0;
  let state = {
    teleportEnabled: false,
    seated: false,
    mode: "HAND",
  };

  const worldWrist = new THREE.Vector3();
  const worldCamera = new THREE.Vector3();
  const targetPos = new THREE.Vector3();
  const wristQuat = new THREE.Quaternion();
  const cameraQuat = new THREE.Quaternion();
  const desiredQuat = new THREE.Quaternion();
  const correction = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, Math.PI, 0));
  const tilt = new THREE.Quaternion().setFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(-26), 0, THREE.MathUtils.degToRad(-8)));
  const wristRight = new THREE.Vector3();
  const wristUp = new THREE.Vector3();

  function redraw(force = false) {
    const now = performance.now() * 0.001;
    if (!force && now - lastRefresh < CONFIG.WATCH_REFRESH_S) return;
    lastRefresh = now;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(4,6,12,0.94)";
    roundRect(ctx, 16, 16, canvas.width - 32, canvas.height - 32, 52);
    ctx.fill();
    ctx.strokeStyle = "rgba(180,140,255,0.6)";
    ctx.lineWidth = 8;
    roundRect(ctx, 16, 16, canvas.width - 32, canvas.height - 32, 52);
    ctx.stroke();

    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    ctx.fillStyle = "#f5f0ff";
    ctx.font = "bold 112px system-ui";
    ctx.fillText(time, 42, 144);

    ctx.font = "34px system-ui";
    ctx.fillStyle = "rgba(240,236,255,0.92)";
    ctx.fillText(`MODE ${state.mode}`, 44, 214);
    ctx.fillText(`TP ${state.teleportEnabled ? "ARMED" : "OFF"}`, 44, 252);
    ctx.fillText(`SEAT ${state.seated ? "LOCKED" : "FREE"}`, 44, 290);

    ctx.fillStyle = state.teleportEnabled ? "rgba(95,255,164,0.95)" : "rgba(255,92,122,0.95)";
    ctx.font = "bold 36px system-ui";
    ctx.fillText(state.teleportEnabled ? "RELEASE TRIGGER TO TELEPORT" : "WATCH READY", 44, 372);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 42px system-ui";
    ctx.fillText("SVR POKER", 738, 72);
    ctx.font = "28px system-ui";
    ctx.fillStyle = "rgba(232,230,255,0.78)";
    ctx.fillText("TP   SEAT   RST", 700, 442);

    texture.needsUpdate = true;
    led.material.color.set(state.teleportEnabled ? 0x36ff9d : 0xff627b);
  }

  function setState(next) {
    const merged = { ...state, ...next };
    const changed = merged.teleportEnabled !== state.teleportEnabled || merged.seated !== state.seated || merged.mode !== state.mode;
    state = merged;
    if (changed) redraw(true);
  }

  function updatePose({ leftHand, leftController, rightController, xrPresenting }) {
    const wrist = leftHand?.joints?.wrist || leftController || rightController;
    if (!xrPresenting || !wrist) {
      root.visible = false;
      return;
    }

    root.visible = true;
    wrist.updateWorldMatrix?.(true, false);
    wrist.getWorldPosition(worldWrist);
    wrist.getWorldQuaternion(wristQuat);
    renderer.xr.getCamera(camera).getWorldPosition(worldCamera);
    renderer.xr.getCamera(camera).getWorldQuaternion(cameraQuat);

    const isLeft = wrist === leftController || leftHand?.joints?.wrist === wrist || wrist.userData?.handedness === "left";
    wristRight.set(isLeft ? -1 : 1, 0, 0).applyQuaternion(wristQuat).normalize();
    wristUp.set(0, 1, 0).applyQuaternion(wristQuat).normalize();

    targetPos.copy(worldWrist)
      .addScaledVector(wristRight, isLeft ? -0.032 : 0.032)
      .addScaledVector(wristUp, 0.014);

    root.position.lerp(targetPos, 0.42);

    desiredQuat.copy(wristQuat).multiply(correction).multiply(tilt);
    if (!isLeft) desiredQuat.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(0, Math.PI, 0)));
    root.quaternion.slerp(desiredQuat, 0.38);
  }

  redraw(true);

  return {
    root,
    buttons,
    setState,
    updatePose,
  };
}
