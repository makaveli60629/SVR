import * as THREE from "three";
import { CONFIG } from "./config.js";
import { makeCanvasLabel, roundRect, makeTextPlane } from "./utils.js";

export function createWatch({ scene, camera, renderer }) {
  const root = new THREE.Group();
  root.visible = false;
  scene.add(root);

  const { canvas, ctx, texture } = makeCanvasLabel({
    width: 1024,
    height: 512,
    draw(drawCtx, w, h) {
      drawCtx.clearRect(0, 0, w, h);
      drawCtx.fillStyle = "rgba(4,6,12,0.92)";
      roundRect(drawCtx, 18, 18, w - 36, h - 36, 52);
      drawCtx.fill();
      drawCtx.strokeStyle = "rgba(180,140,255,0.72)";
      drawCtx.lineWidth = 10;
      roundRect(drawCtx, 18, 18, w - 36, h - 36, 52);
      drawCtx.stroke();
    }
  });

  const frame = new THREE.Mesh(
    new THREE.PlaneGeometry(0.198, 0.11),
    new THREE.MeshStandardMaterial({ map: texture, transparent: true, emissive: 0x391252, emissiveIntensity: 0.82, metalness: 0.18, roughness: 0.34 })
  );
  root.add(frame);

  const rim = new THREE.Mesh(
    new THREE.PlaneGeometry(0.206, 0.118),
    new THREE.MeshStandardMaterial({ color: 0x0d0d12, emissive: 0x1d1227, emissiveIntensity: 0.18, metalness: 0.2, roughness: 0.3 })
  );
  rim.position.z = -0.0016;
  root.add(rim);

  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(0.202, 0.114),
    new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.08, transmission: 0.16, roughness: 0.08, metalness: 0.04 })
  );
  glass.position.z = 0.001;
  root.add(glass);

  const buttons = [];
  const buttonDefs = [
    { id: "teleport", label: "TP", x: -0.058, w: 0.058 },
    { id: "seat", label: "SEAT", x: 0, w: 0.074 },
    { id: "reset", label: "RST", x: 0.058, w: 0.058 },
  ];

  for (const def of buttonDefs) {
    const tex = makeTextPlane(def.label, { width: 256, height: 128, font: "bold 54px system-ui" });
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(def.w, 0.028),
      new THREE.MeshStandardMaterial({ map: tex, transparent: true, emissive: 0x2f1144, emissiveIntensity: 0.92, roughness: 0.3, metalness: 0.08 })
    );
    mesh.position.set(def.x, -0.032, 0.003);
    mesh.userData.action = def.id;
    buttons.push(mesh);
    root.add(mesh);
  }

  const led = new THREE.Mesh(
    new THREE.CircleGeometry(0.0055, 20),
    new THREE.MeshBasicMaterial({ color: 0x36ff9d })
  );
  led.position.set(0.076, 0.038, 0.003);
  root.add(led);

  let lastRefresh = 0;
  let state = {
    teleportEnabled: false,
    seated: false,
    mode: "HAND",
  };

  const worldWrist = new THREE.Vector3();
  const worldCamera = new THREE.Vector3();
  const targetPos = new THREE.Vector3();
  const wristQuat = new THREE.Quaternion();
  const toCam = new THREE.Vector3();
  const right = new THREE.Vector3();
  const up = new THREE.Vector3();
  const forward = new THREE.Vector3();
  const desiredQuat = new THREE.Quaternion();
  const cameraQuat = new THREE.Quaternion();

  function redraw(force = false) {
    const now = performance.now() * 0.001;
    if (!force && now - lastRefresh < CONFIG.WATCH_REFRESH_S) return;
    lastRefresh = now;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(4,6,12,0.92)";
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 52);
    ctx.fill();
    ctx.strokeStyle = "rgba(180,140,255,0.72)";
    ctx.lineWidth = 10;
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 52);
    ctx.stroke();

    const nowDate = new Date();
    const time = nowDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });

    ctx.fillStyle = "#f5f0ff";
    ctx.font = "bold 118px system-ui";
    ctx.fillText(time, 42, 146);

    ctx.font = "34px system-ui";
    ctx.fillStyle = "rgba(240,236,255,0.92)";
    ctx.fillText(`MODE ${state.mode}`, 46, 214);
    ctx.fillText(`TP ${state.teleportEnabled ? "ARMED" : "OFF"}`, 46, 254);
    ctx.fillText(`SEAT ${state.seated ? "LOCKED" : "FREE"}`, 46, 294);

    ctx.fillStyle = state.teleportEnabled ? "rgba(95,255,164,0.95)" : "rgba(255,92,122,0.95)";
    ctx.font = "bold 38px system-ui";
    ctx.fillText(state.teleportEnabled ? "TRIGGER RELEASE = TELEPORT" : "WATCH READY", 46, 376);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 42px system-ui";
    ctx.fillText("SVR POKER", 746, 72);

    ctx.font = "30px system-ui";
    ctx.fillStyle = "rgba(232,230,255,0.78)";
    ctx.fillText("TP    SEAT    RST", 646, 446);

    texture.needsUpdate = true;
    led.material.color.set(state.teleportEnabled ? 0x36ff9d : 0xff627b);
  }

  function setState(next) {
    const merged = { ...state, ...next };
    const changed = merged.teleportEnabled !== state.teleportEnabled || merged.seated !== state.seated || merged.mode !== state.mode;
    state = merged;
    if (changed) redraw(true);
  }

  function updatePose({ leftHand, leftController, rightController, xrPresenting }) {
    const wrist = leftHand?.joints?.wrist || leftController || rightController;
    if (!xrPresenting || !wrist) {
      root.visible = false;
      return;
    }

    root.visible = true;
    wrist.updateWorldMatrix?.(true, false);
    wrist.getWorldPosition(worldWrist);
    wrist.getWorldQuaternion(wristQuat);
    renderer.xr.getCamera(camera).getWorldPosition(worldCamera);

    const isLeft = wrist === leftController || leftHand?.joints?.wrist === wrist || wrist.userData?.handedness === "left";
    right.set(isLeft ? -1 : 1, 0, 0).applyQuaternion(wristQuat).normalize();
    up.set(0, 1, 0).applyQuaternion(wristQuat).normalize();

    targetPos.copy(worldWrist)
      .addScaledVector(right, isLeft ? -0.052 : 0.052)
      .addScaledVector(up, 0.015);

    root.position.lerp(targetPos, CONFIG.WATCH_SMOOTHING);

    toCam.copy(worldCamera).sub(root.position).normalize();
    look.copy(toCam);
    right.crossVectors(up, look).normalize();
    if (right.lengthSq() < 0.0001) right.set(1, 0, 0);
    up.crossVectors(look, right).normalize();
    m.makeBasis(right, up, look.negate());
    desiredQuat.setFromRotationMatrix(m);
    root.quaternion.slerp(desiredQuat, 0.28);
  }

  redraw(true);

  return {
    root,
    buttons,
    setState,
    updatePose,
  };
}
