
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160/build/three.module.js";
import { GLTFLoader } from "https://cdn.jsdelivr.net/npm/three@0.160/examples/jsm/loaders/GLTFLoader.js";

const scene=new THREE.Scene();
scene.background=new THREE.Color(0x000000);

const camera=new THREE.PerspectiveCamera(70,window.innerWidth/window.innerHeight,0.1,1000);
camera.position.set(0,1.6,3);

const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
document.body.appendChild(renderer.domElement);

const light=new THREE.HemisphereLight(0xffffff,0x444444,1);
scene.add(light);

const loader=new GLTFLoader();
loader.load("./assets/models/table.glb",(gltf)=>{

const table=gltf.scene;
table.scale.set(0.8,0.8,0.8);
table.position.set(0,0,-3);

scene.add(table);

});

function animate(){
requestAnimationFrame(animate);
renderer.render(scene,camera);
}

animate();
