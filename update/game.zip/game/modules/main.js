
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160/build/three.module.js";
import { GLTFLoader } from "https://cdn.jsdelivr.net/npm/three@0.160/examples/jsm/loaders/GLTFLoader.js";

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(
70,
window.innerWidth/window.innerHeight,
0.1,
1000
);

camera.position.set(0,1.6,3);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.xr.enabled = true;

document.body.appendChild(renderer.domElement);

/* Lighting */

const light = new THREE.HemisphereLight(0xffffff,0x444444,1);
scene.add(light);

const dirLight = new THREE.DirectionalLight(0xffffff,0.8);
dirLight.position.set(5,10,7);
scene.add(dirLight);

/* Simple skyline */

const skyGeo = new THREE.SphereGeometry(100,32,32);
const skyMat = new THREE.MeshBasicMaterial({
color:0x050510,
side:THREE.BackSide
});
const sky = new THREE.Mesh(skyGeo,skyMat);
scene.add(sky);

/* Table */

const loader = new GLTFLoader();

loader.load("./assets/models/table.glb",(gltf)=>{

const table = gltf.scene;

table.scale.set(0.8,0.8,0.8);
table.position.set(0,0,-3);

scene.add(table);

});

/* VR controllers */

const controller1 = renderer.xr.getController(0);
const controller2 = renderer.xr.getController(1);

scene.add(controller1);
scene.add(controller2);

/* render loop */

function animate(){

renderer.setAnimationLoop(()=>{

renderer.render(scene,camera);

});

}

animate();
