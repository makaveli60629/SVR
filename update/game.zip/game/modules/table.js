
export function initTable(){
 console.log("Poker table system ready")
}
