Phase L: controller grab/drop, desktop pickup/drop, seat/teleport preserved, Eric idle hand scaffold.
