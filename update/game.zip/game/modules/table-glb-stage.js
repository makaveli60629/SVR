(function () {
  function make(el, tag, attrs) {
    const node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      node.setAttribute(key, attrs[key]);
    });
    el.appendChild(node);
    return node;
  }

  function makeCard(parent, opts) {
    const card = make(parent, 'a-entity', {
      position: opts.position,
      rotation: opts.rotation || '-90 0 0'
    });

    make(card, 'a-plane', {
      width: opts.width || '0.17',
      height: opts.height || '0.24',
      color: '#fbfdff',
      material: 'roughness:0.98; metalness:0.0; shader:standard'
    });

    make(card, 'a-plane', {
      width: (parseFloat(opts.width || '0.17') - 0.01).toString(),
      height: (parseFloat(opts.height || '0.24') - 0.01).toString(),
      position: '0 0 0.0012',
      color: '#ffffff',
      material: 'shader:flat'
    });

    make(card, 'a-entity', {
      text: 'value:' + opts.rank + '; align:center; anchor:center; width:1.0; color:' + opts.color,
      position: '0 0.045 0.0024'
    });

    make(card, 'a-entity', {
      text: 'value:' + opts.suit + '; align:center; anchor:center; width:1.1; color:' + opts.color,
      position: '0 -0.03 0.0024'
    });

    return card;
  }

  AFRAME.registerComponent('svr-table-glb-overlay', {
    init: function () {
      const root = this.el;
      root.innerHTML = '';

      const topY = 0.806;
      make(root, 'a-ring', {
        'radius-inner': '0.78',
        'radius-outer': '0.82',
        rotation: '-90 0 0',
        position: '0 ' + (topY + 0.004) + ' 0.02',
        scale: '1.52 1 0.84',
        color: '#d2aa58',
        material: 'roughness:0.54; metalness:0.26; opacity:0.95; transparent:true; shader:standard'
      });

      make(root, 'a-circle', {
        radius: '0.72',
        rotation: '-90 0 0',
        position: '0 ' + (topY + 0.003) + ' 0.02',
        scale: '1.48 1 0.80',
        color: '#0f6b3c',
        material: 'roughness:0.98; metalness:0.02; opacity:0.22; transparent:true; shader:standard'
      });

      make(root, 'a-plane', {
        width: '0.96',
        height: '0.23',
        rotation: '-90 0 0',
        position: '0 ' + (topY + 0.005) + ' -0.03',
        color: '#0b1720',
        material: 'roughness:0.94; metalness:0.04; opacity:0.78; transparent:true; shader:standard'
      });

      const board = [
        {x: -0.38, rank: 'A', suit: '♠', color: '#111111'},
        {x: -0.19, rank: 'K', suit: '♥', color: '#cc1d1d'},
        {x: 0.00, rank: '10', suit: '♦', color: '#cc1d1d'},
        {x: 0.19, rank: '8', suit: '♣', color: '#111111'},
        {x: 0.38, rank: '2', suit: '♠', color: '#111111'}
      ];

      board.forEach(function (card) {
        makeCard(root, {
          position: card.x + ' ' + (topY + 0.008) + ' -0.03',
          rank: card.rank,
          suit: card.suit,
          color: card.color
        });
      });

      makeCard(root, { position: '-0.10 ' + (topY + 0.008) + ' 0.50', rank: 'Q', suit: '♠', color: '#111111' });
      makeCard(root, { position: '0.10 ' + (topY + 0.008) + ' 0.50', rank: 'Q', suit: '♥', color: '#cc1d1d' });

      const spots = [
        {x: 0, z: 0.52, sx: 1.32, sz: 0.88},
        {x: -0.68, z: 0.20, sx: 1.00, sz: 0.78},
        {x: 0.68, z: 0.20, sx: 1.00, sz: 0.78},
        {x: -0.76, z: -0.32, sx: 0.92, sz: 0.70},
        {x: 0.76, z: -0.32, sx: 0.92, sz: 0.70},
        {x: 0, z: -0.54, sx: 1.16, sz: 0.68}
      ];

      spots.forEach(function (spot) {
        make(root, 'a-ring', {
          'radius-inner': '0.11',
          'radius-outer': '0.14',
          rotation: '-90 0 0',
          position: spot.x + ' ' + (topY + 0.006) + ' ' + spot.z,
          scale: spot.sx + ' 1 ' + spot.sz,
          color: '#e7cb7f',
          material: 'roughness:0.55; metalness:0.22; opacity:0.94; transparent:true; shader:standard'
        });
      });
    }
  });

  AFRAME.registerComponent('glb-table-finish', {
    init: function () {
      this.el.addEventListener('model-loaded', () => {
        const obj = this.el.getObject3D('mesh');
        if (!obj) return;
        obj.traverse((child) => {
          if (!child.isMesh || !child.material) return;
          child.castShadow = false;
          child.receiveShadow = true;
          if (Array.isArray(child.material)) {
            child.material.forEach((mat) => {
              if ('roughness' in mat) mat.roughness = Math.min(mat.roughness ?? 1, 0.95);
              if ('metalness' in mat) mat.metalness = Math.min(mat.metalness ?? 0, 0.12);
            });
          } else {
            if ('roughness' in child.material) child.material.roughness = Math.min(child.material.roughness ?? 1, 0.95);
            if ('metalness' in child.material) child.material.metalness = Math.min(child.material.metalness ?? 0, 0.12);
          }
        });
      });
    }
  });
})();