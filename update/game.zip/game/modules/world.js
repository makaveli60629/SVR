import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { CONFIG } from "./config.js";
import { faceYaw, makeCanvasLabel, makeTextPlane, roundRect } from "./utils.js";

export async function buildWorld(scene, { log = console.log } = {}) {
  const group = new THREE.Group();
  scene.add(group);

  const roomRadius = CONFIG.ROOM_RADIUS;
  const wallHeight = CONFIG.WALL_HEIGHT;

  addSkyShell(group, roomRadius, wallHeight);
  addFloor(group, roomRadius);
  addLobbyShell(group, roomRadius, wallHeight);
  addCeiling(group, roomRadius, wallHeight);
  addRedCarpet(group);
  addSouthEntry(group, roomRadius);
  addPromenade(group);
  addNorthWall(group, roomRadius);
  const features = addFeatureWalls(group, roomRadius);
  addStoreFront(group, roomRadius);
  addReikiLounge(group, roomRadius);
  const planets = await addPlanets(group, roomRadius);
  const matrixRain = createMatrixRainPanel(768, 1152);
  if (features.matrixScreen?.material?.map) features.matrixScreen.material.map = matrixRain.texture;

  const table = await createTable();
  group.add(table.group);

  const chairs = createChairs();
  chairs.groups.forEach((chair) => group.add(chair));

  const dealer = createDealer();
  group.add(dealer);

  scene.userData._tickWorld = (t) => {
    dealer.userData.sway += 0.0042;
    dealer.rotation.z = Math.sin(dealer.userData.sway) * 0.0012;
    if (planets.moon) planets.moon.rotation.y += 0.0002;
    if (planets.earth) planets.earth.rotation.y += 0.00035;
    if (planets.earthClouds) planets.earthClouds.rotation.y += 0.00044;
    updateMatrixRain(matrixRain, t);
  };

  log("World rebuilt from backup + repo assets", {
    chairs: chairs.seats.length,
    props: table.props.length,
    hasGlbTable: table.usedGlb,
    roomRadius,
  });

  return {
    roomClamp: roomRadius - 1.8,
    seats: chairs.seats,
    chairRings: chairs.rings,
    tableCenter: new THREE.Vector3(0, 0, 0),
    tableProps: table.props,
  };
}

function addSkyShell(group, roomRadius, wallHeight) {
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(roomRadius + 50, 36, 24),
    new THREE.MeshBasicMaterial({ color: 0x020208, side: THREE.BackSide })
  );
  sky.position.y = wallHeight * 0.35;
  group.add(sky);
}

function addFloor(group, roomRadius) {
  const base = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius + 8, 96),
    new THREE.MeshStandardMaterial({ color: 0x0b0d12, roughness: 0.98, metalness: 0.02 })
  );
  base.rotation.x = -Math.PI / 2;
  group.add(base);

  const inner = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius - 0.85, 96),
    new THREE.MeshStandardMaterial({ color: 0x10131a, roughness: 0.96, metalness: 0.03 })
  );
  inner.rotation.x = -Math.PI / 2;
  inner.position.y = 0.002;
  group.add(inner);
}

function addLobbyShell(group, roomRadius, wallHeight) {
  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(roomRadius, roomRadius, wallHeight, 84, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x11141a, roughness: 0.94, metalness: 0.06, side: THREE.BackSide })
  );
  wall.position.y = wallHeight / 2;
  group.add(wall);

  const lowerTrim = new THREE.Mesh(
    new THREE.TorusGeometry(roomRadius - 0.45, 0.14, 12, 128),
    new THREE.MeshStandardMaterial({ color: 0x1a1f28, roughness: 0.62, metalness: 0.12 })
  );
  lowerTrim.rotation.x = Math.PI / 2;
  lowerTrim.position.y = 1.2;
  group.add(lowerTrim);

  const upperTrim = lowerTrim.clone();
  upperTrim.position.y = wallHeight - 0.55;
  group.add(upperTrim);
}

function addCeiling(group, roomRadius, wallHeight) {
  const crown = new THREE.Mesh(
    new THREE.TorusGeometry(roomRadius - 1.2, 0.11, 12, 120),
    new THREE.MeshStandardMaterial({ color: 0x4a2f83, roughness: 0.42, metalness: 0.12, emissive: 0x13081f, emissiveIntensity: 0.08 })
  );
  crown.rotation.x = Math.PI / 2;
  crown.position.y = wallHeight - 0.9;
  group.add(crown);

  const inner = crown.clone();
  inner.scale.setScalar(0.93);
  inner.material = inner.material.clone();
  inner.material.color = new THREE.Color(0x241d39);
  inner.material.emissiveIntensity = 0.04;
  inner.position.y = wallHeight - 1.15;
  group.add(inner);
}

function addSouthEntry(group, roomRadius) {
  const root = new THREE.Group();
  root.position.set(0, 0, roomRadius - 1.1);
  group.add(root);

  const frameMat = new THREE.MeshStandardMaterial({ color: 0x1a1d25, roughness: 0.76, metalness: 0.12 });
  const top = new THREE.Mesh(new THREE.BoxGeometry(7.4, 0.4, 0.64), frameMat);
  top.position.set(0, 3.25, 0);
  root.add(top);

  const sideGeo = new THREE.BoxGeometry(0.46, 4.2, 0.64);
  const left = new THREE.Mesh(sideGeo, frameMat);
  left.position.set(-3.45, 2.06, 0);
  root.add(left);
  const right = left.clone();
  right.position.x = 3.45;
  root.add(right);

  const title = new THREE.Mesh(
    new THREE.PlaneGeometry(4.8, 0.76),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("SVR POKER • RED CARPET", { width: 1500, height: 240, font: "bold 86px system-ui" }), transparent: true })
  );
  title.position.set(0, 4.0, -0.18);
  root.add(title);
}

function addRedCarpet(group) {
  const carpet = new THREE.Mesh(
    new THREE.BoxGeometry(3.2, 0.03, 13.8),
    new THREE.MeshStandardMaterial({ color: 0x5a1020, roughness: 0.97, metalness: 0.01 })
  );
  carpet.position.set(0, 0.02, 4.8);
  group.add(carpet);

  const stripe = new THREE.Mesh(
    new THREE.PlaneGeometry(0.58, 13.4),
    new THREE.MeshBasicMaterial({ color: 0x92364b, transparent: true, opacity: 0.22, side: THREE.DoubleSide })
  );
  stripe.rotation.x = -Math.PI / 2;
  stripe.position.set(0, 0.04, 4.8);
  group.add(stripe);
}

function addPromenade(group) {
  const potMat = new THREE.MeshStandardMaterial({ color: 0x171a20, roughness: 0.84, metalness: 0.06 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x56bfa8, roughness: 0.92, metalness: 0.02, emissive: 0x08211b, emissiveIntensity: 0.04 });
  for (let i = 0; i < 5; i += 1) {
    for (const side of [-1, 1]) {
      const x = side * 2.5;
      const z = 8.2 - i * 1.7;
      const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 0.34, 18), potMat);
      pot.position.set(x, 0.18, z);
      group.add(pot);
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.46, 12), leafMat);
      stem.position.set(x, 0.54, z);
      group.add(stem);
      for (let j = 0; j < 3; j += 1) {
        const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.11 + j * 0.025, 12, 10), leafMat);
        leaf.scale.set(1.25, 0.48, 1.0);
        leaf.position.set(x + (j - 1) * 0.03, 0.74 + j * 0.08, z + (j - 1) * 0.015);
        group.add(leaf);
      }
    }
  }
}

function addNorthWall(group, roomRadius) {
  const frame = new THREE.Group();
  frame.position.set(0, 0, -(roomRadius - 0.95));
  group.add(frame);

  const frameMat = new THREE.MeshStandardMaterial({ color: 0x1a2029, roughness: 0.6, metalness: 0.2 });
  const bottom = new THREE.Mesh(new THREE.BoxGeometry(17.5, 0.4, 0.42), frameMat);
  bottom.position.set(0, 1.18, 0);
  frame.add(bottom);
  const top = bottom.clone();
  top.position.y = 6.35;
  frame.add(top);
  const side = new THREE.Mesh(new THREE.BoxGeometry(0.42, 5.57, 0.42), frameMat);
  side.position.set(-8.55, 3.76, 0);
  frame.add(side);
  const sideR = side.clone();
  sideR.position.x = 8.55;
  frame.add(sideR);

  [-4.2, 0, 4.2].forEach((x) => {
    const mullion = new THREE.Mesh(new THREE.BoxGeometry(0.18, 5.42, 0.24), frameMat);
    mullion.position.set(x, 3.76, -0.06);
    frame.add(mullion);
  });

  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(16.7, 4.9),
    new THREE.MeshPhysicalMaterial({ color: 0xb5cff8, roughness: 0.07, metalness: 0, transmission: 0.78, transparent: true, opacity: 0.15 })
  );
  glass.position.set(0, 3.76, -0.08);
  frame.add(glass);

  const skyline = new THREE.Group();
  skyline.position.set(0, 0.4, -7.8);
  frame.add(skyline);
  const towerMat = new THREE.MeshStandardMaterial({ color: 0x0b0f17, roughness: 0.84, metalness: 0.07, emissive: 0x090d1b, emissiveIntensity: 0.18 });
  for (let i = 0; i < 18; i += 1) {
    const width = 0.65 + (i % 4) * 0.15;
    const depth = 0.7 + (i % 3) * 0.2;
    const height = 1.6 + (i % 7) * 0.55;
    const tower = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), towerMat);
    tower.position.set(-7.2 + i * 0.85, height * 0.5, -(i % 3) * 0.9);
    skyline.add(tower);
    const band = new THREE.Mesh(
      new THREE.BoxGeometry(width * 0.88, 0.06, depth * 1.02),
      new THREE.MeshBasicMaterial({ color: i % 2 === 0 ? 0x6b5cff : 0x49aaff, transparent: true, opacity: 0.18 })
    );
    band.position.copy(tower.position);
    band.position.y = Math.max(0.9, height * 0.58);
    skyline.add(band);
  }

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(5.4, 0.82),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("SVR POKER • ALL IN", { width: 1400, height: 220, font: "bold 92px system-ui" }), transparent: true })
  );
  sign.position.set(0, 6.95, 0.12);
  frame.add(sign);
}

function addFeatureWalls(group, roomRadius) {
  const matrixRoot = new THREE.Group();
  matrixRoot.position.set(-7.6, 0, -1.25);
  matrixRoot.rotation.y = Math.PI / 2;
  group.add(matrixRoot);

  const matrixFrame = new THREE.Mesh(
    new THREE.BoxGeometry(5.3, 4.3, 0.24),
    new THREE.MeshStandardMaterial({ color: 0x0f1312, roughness: 0.82, metalness: 0.06 })
  );
  matrixFrame.position.y = 2.4;
  matrixRoot.add(matrixFrame);

  const matrixScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(4.82, 3.78),
    new THREE.MeshBasicMaterial({ color: 0x2fe36b, transparent: true, toneMapped: false })
  );
  matrixScreen.position.set(0, 2.4, 0.125);
  matrixRoot.add(matrixScreen);

  const legend = new THREE.Mesh(
    new THREE.PlaneGeometry(5.9, 0.84),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("LEGEND WALL", { width: 1200, height: 180, font: "bold 90px system-ui" }), transparent: true })
  );
  legend.position.set(7.6, 2.45, -1.25);
  legend.rotation.y = -Math.PI / 2;
  group.add(legend);

  const mission = new THREE.Mesh(
    new THREE.PlaneGeometry(5.8, 0.78),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("SPONSOR MISSION", { width: 1200, height: 180, font: "bold 82px system-ui" }), transparent: true })
  );
  mission.position.set(7.45, 4.05, -1.25);
  mission.rotation.y = -Math.PI / 2;
  group.add(mission);

  return { matrixScreen };
}

function addStoreFront(group, roomRadius) {
  const root = new THREE.Group();
  root.position.set(7.9, 0, -7.5);
  root.rotation.y = -Math.PI / 4;
  group.add(root);

  const baseMat = new THREE.MeshStandardMaterial({ color: 0x161b24, roughness: 0.78, metalness: 0.08 });
  const front = new THREE.Mesh(new THREE.BoxGeometry(5.6, 3.8, 0.22), baseMat);
  front.position.y = 1.95;
  root.add(front);

  const door = new THREE.Mesh(
    new THREE.PlaneGeometry(1.1, 2.3),
    new THREE.MeshPhysicalMaterial({ color: 0xc8e4ff, transparent: true, opacity: 0.12, transmission: 0.75, roughness: 0.04 })
  );
  door.position.set(0, 1.55, 0.13);
  root.add(door);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(3.9, 0.72),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("STORE", { width: 900, height: 180, font: "bold 98px system-ui" }), transparent: true })
  );
  sign.position.set(0, 3.25, 0.13);
  root.add(sign);
}

function addReikiLounge(group, roomRadius) {
  const root = new THREE.Group();
  root.position.set(-8.1, 0, -7.3);
  root.rotation.y = Math.PI / 4;
  group.add(root);

  const frameMat = new THREE.MeshStandardMaterial({ color: 0x171b23, roughness: 0.72, metalness: 0.12 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xd6e8ff, transparent: true, opacity: 0.1, transmission: 0.72, roughness: 0.05 });

  const box = new THREE.Mesh(new THREE.BoxGeometry(5.2, 3.1, 5.2), frameMat);
  box.position.y = 1.55;
  root.add(box);
  const glass = new THREE.Mesh(new THREE.BoxGeometry(4.8, 2.7, 4.8), glassMat);
  glass.position.y = 1.55;
  root.add(glass);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(3.8, 0.7),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("REIKI LOUNGE", { width: 1100, height: 180, font: "bold 90px system-ui" }), transparent: true })
  );
  sign.position.set(0, 3.28, 0.1);
  root.add(sign);
}

async function addPlanets(group, roomRadius) {
  const moonTex = await loadTextureSafe("./assets/texture/moon_diffuse.png");
  const moonBump = await loadTextureSafe("./assets/texture/moon_bump.png");

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(1.55, 40, 30),
    new THREE.MeshStandardMaterial({ color: 0xffffff, map: moonTex || null, bumpMap: moonBump || null, bumpScale: moonBump ? 0.05 : 0, roughness: 1 })
  );
  moon.position.set(-9.5, 7.8, -(roomRadius + 6.5));
  group.add(moon);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(0.95, 36, 24),
    new THREE.MeshStandardMaterial({ color: 0x5270ff, roughness: 0.92, metalness: 0.02, emissive: 0x08134e, emissiveIntensity: 0.08 })
  );
  earth.position.set(8.9, 6.8, -(roomRadius + 4.4));
  group.add(earth);

  const earthClouds = new THREE.Mesh(
    new THREE.SphereGeometry(0.98, 36, 24),
    new THREE.MeshPhysicalMaterial({ color: 0xe9f4ff, transparent: true, opacity: 0.12, roughness: 0.18, transmission: 0.12 })
  );
  earthClouds.position.copy(earth.position);
  group.add(earthClouds);

  return { moon, earth, earthClouds };
}

function createMatrixRainPanel(width, height) {
  const { canvas, ctx, texture } = makeCanvasLabel({
    width,
    height,
    draw(drawCtx, w, h) {
      drawCtx.fillStyle = "#001106";
      drawCtx.fillRect(0, 0, w, h);
    },
  });
  const cols = Array.from({ length: Math.floor(width / 26) }, () => -Math.random() * height);
  return { canvas, ctx, texture, cols, lastStep: 0 };
}

function updateMatrixRain(panel, t) {
  if (t - panel.lastStep < 0.24) return;
  panel.lastStep = t;
  const { ctx, canvas, cols, texture } = panel;
  ctx.fillStyle = "rgba(0, 12, 0, 0.16)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.font = "bold 24px monospace";
  ctx.textAlign = "center";
  const chars = "01ABCDEFGHIJKLMNOPQRSTUVWXYZ#$%*+-/\\";
  for (let i = 0; i < cols.length; i += 1) {
    const x = i * 26 + 13;
    const y = cols[i];
    const char = chars[Math.floor(Math.random() * chars.length)];
    ctx.fillStyle = i % 8 === 0 ? "#a2ffc0" : "#29d65f";
    ctx.fillText(char, x, y);
    cols[i] += 22 + ((i % 5) * 3);
    if (cols[i] > canvas.height + 40) cols[i] = -80 - ((i % 7) * 40);
  }
  texture.needsUpdate = true;
}

async function createTable() {
  const group = new THREE.Group();
  const props = [];
  let usedGlb = false;

  try {
    const loader = new GLTFLoader();
    const gltf = await loader.loadAsync("./assets/models/table.glb");
    const feltTexture = await loadTextureSafe("./assets/texture/tablefelt.png");
    gltf.scene.traverse((child) => {
      if (!child.isMesh) return;
      child.castShadow = false;
      child.receiveShadow = true;
      child.material = child.material?.clone?.() || child.material;
      if (child.material) {
        child.material.roughness = Math.min(1, (child.material.roughness ?? 0.8) + 0.12);
        child.material.metalness = Math.min(0.3, child.material.metalness ?? 0.04);
      }
      if (feltTexture && /table|felt|cloth|mat/i.test(child.name || "")) {
        child.material.map = feltTexture;
        child.material.needsUpdate = true;
      }
    });
    gltf.scene.scale.set(0.01, 0.01, 0.01);
    gltf.scene.position.set(0, 0.02, 0);
    group.add(gltf.scene);
    usedGlb = true;
  } catch (err) {
    group.add(createFallbackTable());
  }

  const logoTexture = await loadTextureSafe("./assets/logo_table.png");
  const feltOverlay = new THREE.Mesh(
    new THREE.CircleGeometry(1.82, 72),
    new THREE.MeshStandardMaterial({ color: 0x132118, map: logoTexture || null, roughness: 0.98, metalness: 0.01, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 })
  );
  feltOverlay.rotation.x = -Math.PI / 2;
  feltOverlay.scale.y = 0.68;
  feltOverlay.position.y = CONFIG.TABLE_TOP_Y + 0.004;
  group.add(feltOverlay);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(1.6, 0.22),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("ALL IN", { width: 720, height: 140, font: "bold 68px system-ui" }), transparent: true, depthWrite: false })
  );
  sign.rotation.x = -Math.PI / 2;
  sign.position.set(0, CONFIG.TABLE_TOP_Y + 0.01, -0.92);
  group.add(sign);

  props.push(createChipStack({ color: 0xd03975, x: -0.62, z: 0.58, height: 0.06, label: "chip-pink" }));
  props.push(createChipStack({ color: 0x4ca8ff, x: -0.32, z: 0.53, height: 0.065, label: "chip-blue" }));
  props.push(createChipStack({ color: 0x78d9c2, x: 0.32, z: 0.53, height: 0.055, label: "chip-green" }));
  props.push(createChipStack({ color: 0xf1d27a, x: 0.62, z: 0.58, height: 0.05, label: "chip-gold" }));
  props.push(createCard({ x: -0.46, z: 0.3, ry: -0.18, label: "card-a" }));
  props.push(createCard({ x: -0.16, z: 0.24, ry: -0.08, label: "card-b" }));
  props.push(createCard({ x: 0.16, z: 0.24, ry: 0.08, label: "card-c" }));
  props.push(createCard({ x: 0.46, z: 0.3, ry: 0.18, label: "card-d" }));
  props.forEach((prop) => group.add(prop));

  return { group, props, usedGlb };
}

function createFallbackTable() {
  const group = new THREE.Group();
  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(0.72, 0.92, 1.04, 28),
    new THREE.MeshStandardMaterial({ color: 0x171a22, roughness: 0.62, metalness: 0.18 })
  );
  base.position.y = 0.52;
  group.add(base);

  const top = new THREE.Mesh(
    new THREE.CylinderGeometry(2.2, 2.26, 0.18, 64),
    new THREE.MeshStandardMaterial({ color: 0x1f232b, roughness: 0.6, metalness: 0.16 })
  );
  top.scale.z = 0.68;
  top.position.y = 1.02;
  group.add(top);

  const rail = new THREE.Mesh(
    new THREE.TorusGeometry(1.84, 0.18, 20, 88),
    new THREE.MeshStandardMaterial({ color: 0x14151b, roughness: 0.44, metalness: 0.22 })
  );
  rail.rotation.x = Math.PI / 2;
  rail.scale.y = 0.7;
  rail.position.y = 1.12;
  group.add(rail);
  return group;
}

function createChipStack({ color, x, z, height = 0.06, label }) {
  const material = new THREE.MeshStandardMaterial({ color, roughness: 0.38, metalness: 0.2, emissive: color, emissiveIntensity: 0.09 });
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, height, 32), material);
  mesh.position.set(x, CONFIG.TABLE_TOP_Y + (height * 0.5), z);
  mesh.userData.type = "table-prop";
  mesh.userData.kind = "chip";
  mesh.userData.label = label;
  mesh.userData.basePosition = mesh.position.clone();
  mesh.userData.baseQuaternion = mesh.quaternion.clone();
  mesh.userData.lastTablePosition = mesh.position.clone();
  mesh.userData.lastTableQuaternion = mesh.quaternion.clone();
  mesh.userData.baseEmissive = 0.09;
  return mesh;
}

function createCard({ x, z, ry = 0, label }) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.16, 0.01, 0.24),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.86, metalness: 0.03, emissive: 0x140c0d, emissiveIntensity: 0.03 })
  );
  mesh.position.set(x, CONFIG.TABLE_TOP_Y + 0.04, z);
  mesh.rotation.y = ry;
  mesh.userData.type = "table-prop";
  mesh.userData.kind = "card";
  mesh.userData.label = label;
  mesh.userData.basePosition = mesh.position.clone();
  mesh.userData.baseQuaternion = mesh.quaternion.clone();
  mesh.userData.lastTablePosition = mesh.position.clone();
  mesh.userData.lastTableQuaternion = mesh.quaternion.clone();
  mesh.userData.baseEmissive = 0.03;
  return mesh;
}

function createChairs() {
  const groups = [];
  const seats = [];
  const rings = [];

  for (let i = 0; i < CONFIG.CHAIR_COUNT; i += 1) {
    const a = (i / CONFIG.CHAIR_COUNT) * Math.PI * 2 + Math.PI;
    const chair = new THREE.Group();
    const x = Math.cos(a) * CONFIG.SEAT_RADIUS;
    const z = Math.sin(a) * CONFIG.SEAT_RADIUS;
    chair.position.set(x, 0, z);
    chair.rotation.y = faceYaw(new THREE.Vector3(x, 0, z), new THREE.Vector3(0, 0, 0));

    const frameMat = new THREE.MeshStandardMaterial({ color: 0x161920, roughness: 0.76, metalness: 0.12 });
    const cushionMat = new THREE.MeshStandardMaterial({ color: 0x20242d, roughness: 0.82, metalness: 0.08 });

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.12, 0.74), cushionMat);
    seat.position.y = 0.48;
    chair.add(seat);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.88, 0.1), frameMat);
    back.position.set(0, 0.94, -0.28);
    chair.add(back);
    const armGeo = new THREE.BoxGeometry(0.1, 0.28, 0.62);
    const armL = new THREE.Mesh(armGeo, frameMat);
    armL.position.set(-0.37, 0.67, 0);
    chair.add(armL);
    const armR = armL.clone();
    armR.position.x = 0.37;
    chair.add(armR);
    [-0.24, 0.24].forEach((lx) => {
      [-0.22, 0.22].forEach((lz) => {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.45, 0.08), frameMat);
        leg.position.set(lx, 0.22, lz);
        chair.add(leg);
      });
    });

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.46, 0.62, 48),
      new THREE.MeshStandardMaterial({ color: 0xa97eff, emissive: 0x2b0d3a, emissiveIntensity: 0.18, transparent: true, opacity: 0.2, side: THREE.DoubleSide })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.022;
    chair.add(ring);
    rings.push(ring);

    const tag = new THREE.Mesh(
      new THREE.PlaneGeometry(0.68, 0.2),
      new THREE.MeshBasicMaterial({ map: makeTextPlane(`BOT ${i + 1}`, { width: 480, height: 150, font: "bold 66px system-ui", bg: "rgba(6,8,14,0.84)", border: "rgba(140,210,255,0.45)", fg: "#ecf8ff" }), transparent: true, depthWrite: false, side: THREE.DoubleSide })
    );
    tag.position.set(0, 1.42, 0.24);
    tag.rotation.y = Math.PI;
    chair.add(tag);

    const hit = new THREE.Mesh(
      new THREE.CylinderGeometry(0.52, 0.52, 1.6, 16),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.001 })
    );
    hit.position.y = 0.82;
    hit.userData.type = "seat";
    hit.userData.index = i;
    chair.add(hit);

    const anchorDir = new THREE.Vector3(-x, 0, -z).normalize();
    const anchor = new THREE.Vector3(x, CONFIG.SEATED_EYE_HEIGHT, z).add(anchorDir.multiplyScalar(CONFIG.SEAT_ANCHOR_INSET));
    seats.push({ index: i, anchor, yaw: faceYaw(anchor, new THREE.Vector3(0, CONFIG.SEATED_EYE_HEIGHT, 0)), hit });
    groups.push(chair);
  }

  return { groups, seats, rings };
}

function createDealer() {
  const dealer = new THREE.Group();
  dealer.position.set(0, 0, -2.12);

  const suit = new THREE.MeshStandardMaterial({ color: 0x22252d, roughness: 0.76, metalness: 0.08 });
  const accent = new THREE.MeshStandardMaterial({ color: 0x7f63ff, roughness: 0.28, metalness: 0.18, emissive: 0x2b1655, emissiveIntensity: 0.22 });
  const skin = new THREE.MeshStandardMaterial({ color: 0xcba789, roughness: 0.9, metalness: 0.02 });

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.58, 8, 16), suit);
  torso.position.y = 1.1;
  dealer.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 24, 24), skin);
  head.position.set(0, 1.72, 0.02);
  dealer.add(head);
  const visor = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.02, 10, 30, Math.PI), accent);
  visor.position.set(0, 1.72, 0.13);
  visor.rotation.z = Math.PI;
  dealer.add(visor);

  const armGeo = new THREE.CapsuleGeometry(0.06, 0.48, 6, 12);
  const armL = new THREE.Mesh(armGeo, suit);
  armL.position.set(-0.26, 1.1, 0.12);
  armL.rotation.z = 0.75;
  armL.rotation.x = -0.45;
  dealer.add(armL);
  const armR = armL.clone();
  armR.position.x = 0.26;
  armR.rotation.z = -0.75;
  dealer.add(armR);

  const holo = new THREE.Mesh(
    new THREE.PlaneGeometry(1.35, 0.38),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("ERIC • DEALER", { width: 860, height: 180, font: "bold 76px system-ui" }), transparent: true })
  );
  holo.position.set(0, 2.14, 0);
  dealer.add(holo);

  dealer.userData.sway = 0;
  return dealer;
}

async function loadTextureSafe(url) {
  try {
    const loader = new THREE.TextureLoader();
    const texture = await new Promise((resolve, reject) => loader.load(url, resolve, undefined, reject));
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 4;
    return texture;
  } catch {
    return null;
  }
}
