import * as THREE from "three";
import { CONFIG } from "./config.js";
import { faceYaw, makeTextPlane, pulse } from "./utils.js";

export async function buildWorld(scene, { log=console.log } = {}) {
  const group = new THREE.Group();
  scene.add(group);

  const roomRadius = CONFIG.ROOM_RADIUS;
  const wallHeight = CONFIG.WALL_HEIGHT;

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius + 12, 120),
    new THREE.MeshStandardMaterial({ color: 0x06060a, roughness: 0.96, metalness: 0.02 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  group.add(floor);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(roomRadius, roomRadius, wallHeight, 96, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x080712, roughness: 0.9, metalness: 0.12, emissive: 0x1b0b2e, emissiveIntensity: 0.4, side: THREE.BackSide })
  );
  wall.position.y = wallHeight / 2;
  group.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(roomRadius - 0.5, 0.24, 12, 180),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.24, metalness: 0.24, emissive: 0x3b1552, emissiveIntensity: 1.7 })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.y = wallHeight - 0.3;
  group.add(rim);

  addStars(group, roomRadius);
  addMoonAndEarth(group, roomRadius);
  addSkyline(group, roomRadius);
  addNorthMarker(group);

  const table = await createTable();
  group.add(table.group);

  const chairs = createChairs();
  chairs.groups.forEach((c) => group.add(c));

  const dealer = createDealer();
  group.add(dealer);

  scene.userData._tickWorld = (t) => {
    chairs.rings.forEach((ring, i) => {
      const v = pulse(t + i * 0.35, 2.8, 0.45, 1.15);
      ring.material.emissiveIntensity = v;
      ring.material.opacity = THREE.MathUtils.lerp(0.36, 0.86, (v - 0.45) / 0.7);
      ring.scale.setScalar(1 + Math.sin((t * 2.1) + i) * 0.01);
    });
    dealer.userData.idle += 0.02;
    dealer.rotation.z = Math.sin(dealer.userData.idle) * 0.02;
  };

  log("World ready", { chairs: chairs.seats.length });

  return {
    roomClamp: roomRadius - 2,
    seats: chairs.seats,
    seatInteractables: chairs.hitMeshes,
    tableCenter: new THREE.Vector3(0, 0, 0),
  };
}

function addStars(group, roomRadius) {
  const starGeo = new THREE.BufferGeometry();
  const count = 850;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    const r = roomRadius + 18 + Math.random() * 34;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.6;
    positions[i * 3] = Math.cos(theta) * Math.sin(phi) * r;
    positions[i * 3 + 1] = 8 + Math.cos(phi) * r * 0.24;
    positions[i * 3 + 2] = Math.sin(theta) * Math.sin(phi) * r;
  }
  starGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 0.12, transparent: true, opacity: 0.92 }));
  group.add(stars);
}

function addMoonAndEarth(group, roomRadius) {
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(5.4, 36, 36),
    new THREE.MeshStandardMaterial({ color: 0xe7e4ff, roughness: 0.96, emissive: 0x1d1930, emissiveIntensity: 0.35 })
  );
  moon.position.set(-20, 11, -(roomRadius + 26));
  group.add(moon);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(3.2, 32, 32),
    new THREE.MeshStandardMaterial({ color: 0x4a88ff, roughness: 0.84, emissive: 0x0a193a, emissiveIntensity: 0.45 })
  );
  earth.position.set(18, 8.5, -(roomRadius + 22));
  group.add(earth);
}

function addSkyline(group, roomRadius) {
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x0d0d18, roughness: 0.78, metalness: 0.14, emissive: 0x160a24, emissiveIntensity: 0.5 });
  const glowMat = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.28, metalness: 0.2, emissive: 0x35114a, emissiveIntensity: 1.35 });

  for (let i = 0; i < 120; i += 1) {
    const a = (i / 120) * Math.PI * 2;
    const radius = roomRadius + 5 + Math.random() * 8;
    const w = 1.3 + Math.random() * 3.1;
    const d = 1.3 + Math.random() * 3.1;
    const h = 3 + Math.random() * 18;
    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), baseMat);
    body.position.set(Math.cos(a) * radius, h / 2, Math.sin(a) * radius);
    body.rotation.y = -a + Math.PI / 2;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);
    if (Math.random() < 0.8) {
      const band = new THREE.Mesh(new THREE.BoxGeometry(w * 0.88, 0.16, d * 1.05), glowMat);
      band.position.set(body.position.x, 1.4 + Math.random() * (h - 2), body.position.z);
      band.rotation.y = body.rotation.y;
      group.add(band);
    }
  }
}

function addNorthMarker(group) {
  const tex = makeTextPlane("NORTH / DEALER SIDE", { width: 1024, height: 160, font: "bold 68px system-ui" });
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(7, 1.1),
    new THREE.MeshBasicMaterial({ map: tex, transparent: true })
  );
  sign.position.set(0, 4.2, -8.8);
  group.add(sign);
}

async function createTable() {
  const group = new THREE.Group();

  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(0.72, 0.92, 1.04, 28),
    new THREE.MeshStandardMaterial({ color: 0x14131a, roughness: 0.58, metalness: 0.24 })
  );
  base.position.y = 0.52;
  base.castShadow = true;
  base.receiveShadow = true;
  group.add(base);

  const top = new THREE.Mesh(
    new THREE.CylinderGeometry(2.2, 2.26, 0.18, 64),
    new THREE.MeshStandardMaterial({ color: 0x19161f, roughness: 0.56, metalness: 0.22 })
  );
  top.scale.z = 0.68;
  top.position.y = 1.02;
  top.castShadow = true;
  top.receiveShadow = true;
  group.add(top);

  const rail = new THREE.Mesh(
    new THREE.TorusGeometry(1.84, 0.18, 20, 88),
    new THREE.MeshStandardMaterial({ color: 0x0e0d12, roughness: 0.42, metalness: 0.26, emissive: 0x120915, emissiveIntensity: 0.35 })
  );
  rail.rotation.x = Math.PI / 2;
  rail.scale.y = 0.7;
  rail.position.y = 1.12;
  rail.castShadow = true;
  group.add(rail);

  const feltMat = new THREE.MeshStandardMaterial({ color: 0x101410, roughness: 0.92, metalness: 0.02, emissive: 0x040804, emissiveIntensity: 0.12 });
  try {
    const loader = new THREE.TextureLoader();
    const texture = await new Promise((resolve, reject) => loader.load("./assets/logo_table.png", resolve, undefined, reject));
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 8;
    texture.wrapS = THREE.ClampToEdgeWrapping;
    texture.wrapT = THREE.ClampToEdgeWrapping;
    feltMat.map = texture;
    feltMat.needsUpdate = true;
  } catch (err) {
    console.warn("logo_table texture missing, using fallback felt", err);
  }

  const felt = new THREE.Mesh(
    new THREE.CircleGeometry(1.82, 72),
    feltMat
  );
  felt.rotation.x = -Math.PI / 2;
  felt.scale.y = 0.68;
  felt.position.y = 1.118;
  felt.receiveShadow = true;
  group.add(felt);

  const glow = new THREE.Mesh(
    new THREE.RingGeometry(1.55, 1.72, 72),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.2, side: THREE.DoubleSide })
  );
  glow.rotation.x = -Math.PI / 2;
  glow.scale.y = 0.68;
  glow.position.y = 1.119;
  group.add(glow);

  return { group };
}

function createChairs() {
  const groups = [];
  const seats = [];
  const rings = [];
  const hitMeshes = [];
  const tableCenter = new THREE.Vector3(0, 0, 0);

  for (let i = 0; i < CONFIG.CHAIR_COUNT; i += 1) {
    const angle = (i / CONFIG.CHAIR_COUNT) * Math.PI * 2 + Math.PI;
    const x = Math.sin(angle) * CONFIG.SEAT_RADIUS;
    const z = Math.cos(angle) * CONFIG.SEAT_RADIUS;
    const yaw = faceYaw(new THREE.Vector3(x, 0, z), tableCenter);

    const chair = new THREE.Group();
    chair.position.set(x, 0, z);
    chair.rotation.y = yaw;

    const seatBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.32, 0.1, 20),
      new THREE.MeshStandardMaterial({ color: 0x16131a, roughness: 0.6, metalness: 0.22 })
    );
    seatBase.position.y = 0.48;
    seatBase.castShadow = true;
    chair.add(seatBase);

    const seatPad = new THREE.Mesh(
      new THREE.CylinderGeometry(0.34, 0.34, 0.08, 24),
      new THREE.MeshStandardMaterial({ color: 0x221529, roughness: 0.78, metalness: 0.05, emissive: 0x13081a, emissiveIntensity: 0.3 })
    );
    seatPad.position.y = 0.56;
    seatPad.castShadow = true;
    chair.add(seatPad);

    const back = new THREE.Mesh(
      new THREE.BoxGeometry(0.62, 0.75, 0.12),
      new THREE.MeshStandardMaterial({ color: 0x201527, roughness: 0.72, metalness: 0.12, emissive: 0x12081a, emissiveIntensity: 0.42 })
    );
    back.position.set(0, 0.95, -0.22);
    back.castShadow = true;
    chair.add(back);

    const legs = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.08, 0.58, 12),
      new THREE.MeshStandardMaterial({ color: 0x0c0c12, roughness: 0.45, metalness: 0.38 })
    );
    legs.position.y = 0.24;
    legs.castShadow = true;
    chair.add(legs);

    const glowRing = new THREE.Mesh(
      new THREE.RingGeometry(0.48, 0.66, 48),
      new THREE.MeshStandardMaterial({ color: 0xb48cff, transparent: true, opacity: 0.65, side: THREE.DoubleSide, emissive: 0x4a1a6b, emissiveIntensity: 0.8 })
    );
    glowRing.rotation.x = -Math.PI / 2;
    glowRing.position.y = 0.011;
    chair.add(glowRing);
    rings.push(glowRing);

    const hit = new THREE.Mesh(
      new THREE.CylinderGeometry(0.72, 0.72, 1.1, 18),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.001 })
    );
    hit.position.y = 0.55;
    hit.userData.type = "seat";
    hit.userData.index = i;
    chair.add(hit);
    hitMeshes.push(hit);

    const seatAnchor = { x, y: CONFIG.SEATED_EYE_HEIGHT, z, yaw, index: i };
    seats.push({ index: i, anchor: seatAnchor, yaw, ring: glowRing, hit });

    groups.push(chair);
  }

  return { groups, seats, rings, hitMeshes };
}

function createDealer() {
  const dealer = new THREE.Group();
  dealer.position.set(0, 0, -2.08);
  dealer.userData.idle = 0;

  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x0f1118, roughness: 0.64, metalness: 0.14, emissive: 0x0b1224, emissiveIntensity: 0.45 });
  const accentMat = new THREE.MeshStandardMaterial({ color: 0x7ab8ff, roughness: 0.22, metalness: 0.2, emissive: 0x163d66, emissiveIntensity: 0.8 });

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.88, 10, 18), bodyMat);
  torso.position.y = 1.08;
  torso.castShadow = true;
  dealer.add(torso);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 18, 18), accentMat);
  head.position.y = 1.78;
  head.castShadow = true;
  dealer.add(head);

  const arms = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.12, 0.12), bodyMat);
  arms.position.set(0, 1.22, 0.08);
  arms.rotation.z = 0.08;
  arms.castShadow = true;
  dealer.add(arms);

  const signTex = makeTextPlane("ERIC DEALER", { width: 512, height: 120, font: "bold 50px system-ui" });
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.42), new THREE.MeshBasicMaterial({ map: signTex, transparent: true }));
  sign.position.set(0, 2.22, 0);
  dealer.add(sign);

  return dealer;
}
