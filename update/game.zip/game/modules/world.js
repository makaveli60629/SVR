import * as THREE from "three";
import { CONFIG } from "./config.js";
import { faceYaw, makeCanvasLabel, makeTextPlane, roundRect } from "./utils.js";

export async function buildWorld(scene, { log = console.log } = {}) {
  const group = new THREE.Group();
  scene.add(group);

  const roomRadius = CONFIG.ROOM_RADIUS;
  const wallHeight = CONFIG.WALL_HEIGHT;

  addSkyShell(group, roomRadius, wallHeight);
  const floor = addFloor(group, roomRadius);
  const shell = addLobbyShell(group, roomRadius, wallHeight);
  const carpet = addRedCarpet(group);
  const southEntry = addSouthEntryPortal(group, roomRadius, wallHeight);
  const promenade = addPromenadePlanters(group);
  const windows = addNorthWindowAndSkyline(group, roomRadius);
  const signage = addFeatureWalls(group, roomRadius);
  const store = addStoreFront(group, roomRadius);
  const lounge = addReikiLounge(group, roomRadius);
  const ceiling = addCeiling(group, roomRadius, wallHeight);
  const planets = addPlanets(group, roomRadius);
  const matrixRain = createMatrixRainPanel(1024, 1024);

  if (signage.matrix?.material?.map) signage.matrix.material.map = matrixRain.texture;

  const table = await createTable();
  group.add(table.group);

  const chairs = createChairs();
  chairs.groups.forEach((c) => group.add(c));

  const dealer = createDealer();
  group.add(dealer);

  scene.userData._tickWorld = (t) => {
    planets.moon.rotation.y += 0.00018;
    planets.earth.rotation.y += 0.00032;
    planets.earthClouds.rotation.y += 0.00038;
    windows.skyline.rotation.y += 0.00002;
    dealer.userData.sway += 0.004;
    dealer.rotation.z = Math.sin(dealer.userData.sway) * 0.0016;
    updateMatrixRain(matrixRain, t);
    chairs.rings.forEach((ring, i) => {
      ring.material.emissiveIntensity = 0.44 + Math.sin(t * 0.18 + i * 0.2) * 0.008;
      ring.material.opacity = 0.28 + Math.sin(t * 0.16 + i * 0.12) * 0.004;
    });
  };

  log("World rebuilt from backup references", {
    chairs: chairs.seats.length,
    props: table.props.length,
    roomRadius,
  });

  return {
    roomClamp: roomRadius - 1.7,
    seats: chairs.seats,
    chairRings: chairs.rings,
    tableCenter: new THREE.Vector3(0, 0, 0),
    tableProps: table.props,
  };
}

function addSkyShell(group, roomRadius, wallHeight) {
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(roomRadius + 44, 36, 26),
    new THREE.MeshBasicMaterial({ color: 0x03030a, side: THREE.BackSide })
  );
  sky.position.y = wallHeight * 0.28;
  group.add(sky);
}

function addFloor(group, roomRadius) {
  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius + 8, 96),
    new THREE.MeshStandardMaterial({ color: 0x0d0f14, roughness: 0.98, metalness: 0.02 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  group.add(floor);

  const inner = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius - 1.1, 96),
    new THREE.MeshStandardMaterial({ color: 0x13161d, roughness: 0.96, metalness: 0.03 })
  );
  inner.rotation.x = -Math.PI / 2;
  inner.position.y = 0.001;
  inner.receiveShadow = true;
  group.add(inner);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(roomRadius - 1.8, roomRadius - 1.35, 96),
    new THREE.MeshBasicMaterial({ color: 0x6f1b33, transparent: true, opacity: 0.1, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.015;
  group.add(ring);

  return { floor, ring };
}

function addLobbyShell(group, roomRadius, wallHeight) {
  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(roomRadius, roomRadius, wallHeight, 72, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x11141b, roughness: 0.92, metalness: 0.08, side: THREE.BackSide })
  );
  wall.position.y = wallHeight / 2;
  group.add(wall);

  const trim = new THREE.Mesh(
    new THREE.TorusGeometry(roomRadius - 0.25, 0.16, 10, 120),
    new THREE.MeshStandardMaterial({ color: 0x222833, roughness: 0.48, metalness: 0.18, emissive: 0x120b14, emissiveIntensity: 0.2 })
  );
  trim.rotation.x = Math.PI / 2;
  trim.position.y = wallHeight - 0.42;
  group.add(trim);

  return { wall, trim };
}

function addRedCarpet(group) {
  const carpet = new THREE.Mesh(
    new THREE.BoxGeometry(3.1, 0.03, 11.8),
    new THREE.MeshStandardMaterial({ color: 0x5e1020, roughness: 0.97, metalness: 0.01, emissive: 0x1f040a, emissiveIntensity: 0.12 })
  );
  carpet.position.set(0, 0.02, 4.4);
  carpet.receiveShadow = true;
  group.add(carpet);

  const centerLine = new THREE.Mesh(
    new THREE.PlaneGeometry(0.7, 11.3),
    new THREE.MeshBasicMaterial({ color: 0xa8465c, transparent: true, opacity: 0.18, side: THREE.DoubleSide })
  );
  centerLine.rotation.x = -Math.PI / 2;
  centerLine.position.set(0, 0.041, 4.4);
  group.add(centerLine);

  return { carpet, centerLine };
}

function addSouthEntryPortal(group, roomRadius, wallHeight) {
  const root = new THREE.Group();
  root.position.set(0, 0, roomRadius - 1.1);
  group.add(root);

  const portalMat = new THREE.MeshStandardMaterial({ color: 0x1a1c26, roughness: 0.72, metalness: 0.12 });
  const top = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.45, 0.7), portalMat);
  top.position.set(0, 3.1, 0);
  root.add(top);
  const left = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.8, 0.7), portalMat);
  left.position.set(-2.55, 1.9, 0);
  root.add(left);
  const right = left.clone();
  right.position.x = 2.55;
  root.add(right);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(3.1, 0.5),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("SVR POKER • RED CARPET", { width: 1200, height: 180, font: "bold 76px system-ui" }), transparent: true })
  );
  sign.position.set(0, 3.65, -0.22);
  root.add(sign);

  return { root };
}

function addPromenadePlanters(group) {
  const planters = new THREE.Group();
  const potMat = new THREE.MeshStandardMaterial({ color: 0x171a20, roughness: 0.84, metalness: 0.06 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x59b8a8, roughness: 0.92, metalness: 0.02, emissive: 0x0d2d28, emissiveIntensity: 0.1 });
  for (let i = 0; i < 5; i += 1) {
    for (const side of [-1, 1]) {
      const z = 7.6 - i * 1.6;
      const x = side * 2.45;
      const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 0.34, 18), potMat);
      pot.position.set(x, 0.18, z);
      planters.add(pot);
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.42, 10), leafMat);
      stem.position.set(x, 0.52, z);
      planters.add(stem);
      for (let j = 0; j < 3; j += 1) {
        const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.12 + j * 0.025, 14, 12), leafMat);
        leaf.scale.set(1.2, 0.5, 1.0);
        leaf.position.set(x + (j - 1) * 0.03, 0.72 + j * 0.08, z + (j - 1) * 0.01);
        planters.add(leaf);
      }
    }
  }
  group.add(planters);
  return { planters };
}

function addNorthWindowAndSkyline(group, roomRadius) {
  const frame = new THREE.Group();
  frame.position.set(0, 0, -(roomRadius - 0.8));
  group.add(frame);

  const mat = new THREE.MeshStandardMaterial({ color: 0x1a2029, roughness: 0.58, metalness: 0.2 });
  const bottom = new THREE.Mesh(new THREE.BoxGeometry(16, 0.35, 0.45), mat);
  bottom.position.set(0, 1.1, 0);
  frame.add(bottom);
  const top = bottom.clone();
  top.position.y = 6.2;
  frame.add(top);
  const left = new THREE.Mesh(new THREE.BoxGeometry(0.4, 5.4, 0.45), mat);
  left.position.set(-7.8, 3.65, 0);
  frame.add(left);
  const right = left.clone();
  right.position.x = 7.8;
  frame.add(right);
  for (let i = -2; i <= 2; i += 2) {
    const mullion = new THREE.Mesh(new THREE.BoxGeometry(0.24, 5.2, 0.28), mat);
    mullion.position.set(i * 1.6, 3.65, -0.05);
    frame.add(mullion);
  }

  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(15.2, 4.8),
    new THREE.MeshPhysicalMaterial({ color: 0xbfd8ff, roughness: 0.04, metalness: 0, transmission: 0.76, transparent: true, opacity: 0.16 })
  );
  glass.position.set(0, 3.65, -0.08);
  frame.add(glass);

  const skyline = new THREE.Group();
  skyline.position.set(0, 0, -6.5);
  frame.add(skyline);
  const bMat = new THREE.MeshStandardMaterial({ color: 0x0c0f17, roughness: 0.82, metalness: 0.08, emissive: 0x141122, emissiveIntensity: 0.34 });
  for (let i = 0; i < 18; i += 1) {
    const h = 1.6 + Math.random() * 5.6;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.75 + Math.random() * 0.8, h, 0.75 + Math.random() * 1.1), bMat);
    mesh.position.set(-6.8 + i * 0.8, h * 0.5, -Math.random() * 3.4);
    skyline.add(mesh);
    if (Math.random() > 0.42) {
      const band = new THREE.Mesh(
        new THREE.BoxGeometry(mesh.geometry.parameters.width * 0.86, 0.08, mesh.geometry.parameters.depth * 1.02),
        new THREE.MeshBasicMaterial({ color: Math.random() > 0.5 ? 0x7c6cff : 0x63c2ff, transparent: true, opacity: 0.3 })
      );
      band.position.copy(mesh.position);
      band.position.y = Math.min(h - 0.25, 1 + Math.random() * Math.max(1, h - 1.2));
      skyline.add(band);
    }
  }

  const signTex = makeTextPlane("SVR POKER • LIVE DEMO", { width: 1280, height: 180, font: "bold 84px system-ui" });
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(5.6, 0.8),
    new THREE.MeshBasicMaterial({ map: signTex, transparent: true })
  );
  sign.position.set(0, 6.9, 0.12);
  frame.add(sign);

  return { frame, skyline, glass };
}

function addFeatureWalls(group, roomRadius) {
  const sideOffset = roomRadius - 1.4;

  const matrixRoot = new THREE.Group();
  matrixRoot.position.set(-sideOffset, 0, 5.2);
  matrixRoot.rotation.y = Math.PI / 2;
  group.add(matrixRoot);

  const matrixFrame = new THREE.Mesh(
    new THREE.BoxGeometry(4.8, 4.0, 0.22),
    new THREE.MeshStandardMaterial({ color: 0x101412, roughness: 0.82, metalness: 0.06 })
  );
  matrixFrame.position.y = 2.2;
  matrixRoot.add(matrixFrame);

  const matrixScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(4.3, 3.45),
    new THREE.MeshBasicMaterial({ color: 0x6dff9a, transparent: true, opacity: 0.96 })
  );
  matrixScreen.position.set(0, 2.2, 0.115);
  matrixRoot.add(matrixScreen);

  const legendRoot = new THREE.Group();
  legendRoot.position.set(sideOffset, 0, 5.2);
  legendRoot.rotation.y = -Math.PI / 2;
  group.add(legendRoot);

  const legendFrame = new THREE.Mesh(
    new THREE.BoxGeometry(4.8, 4.0, 0.22),
    new THREE.MeshStandardMaterial({ color: 0x161822, roughness: 0.8, metalness: 0.08 })
  );
  legendFrame.position.y = 2.2;
  legendRoot.add(legendFrame);

  const legendTex = makeTextPlane("LEGEND WALL • ALL IN • SPONSOR WINS • DONOR NATION", {
    width: 1440,
    height: 860,
    font: "bold 72px system-ui",
    bg: "rgba(7,8,16,0.9)",
    border: "rgba(186,145,255,0.74)",
    fg: "#f7f2ff"
  });
  const legendScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(4.25, 3.45),
    new THREE.MeshBasicMaterial({ map: legendTex, transparent: true, opacity: 0.96 })
  );
  legendScreen.position.set(0, 2.2, 0.115);
  legendRoot.add(legendScreen);

  return { matrix: matrixScreen, legend: legendScreen };
}

function addStoreFront(group, roomRadius) {
  const root = new THREE.Group();
  root.position.set(-10.6, 0, -8.8);
  root.rotation.y = THREE.MathUtils.degToRad(26);
  group.add(root);

  const base = new THREE.Mesh(
    new THREE.BoxGeometry(6.4, 3.9, 2.6),
    new THREE.MeshStandardMaterial({ color: 0x181c22, roughness: 0.76, metalness: 0.1 })
  );
  base.position.set(0, 1.95, 0);
  root.add(base);

  const window = new THREE.Mesh(
    new THREE.PlaneGeometry(4.8, 1.9),
    new THREE.MeshPhysicalMaterial({ color: 0xadd3ff, roughness: 0.08, metalness: 0, transmission: 0.68, transparent: true, opacity: 0.18 })
  );
  window.position.set(0, 2.05, 1.31);
  root.add(window);

  const counter = new THREE.Mesh(
    new THREE.BoxGeometry(5.1, 0.84, 0.7),
    new THREE.MeshStandardMaterial({ color: 0x202733, roughness: 0.56, metalness: 0.12 })
  );
  counter.position.set(0, 0.78, 0.84);
  root.add(counter);

  const signTex = makeTextPlane("STORE", {
    width: 700,
    height: 180,
    font: "bold 92px system-ui",
    bg: "rgba(8,10,18,0.82)",
    border: "rgba(98,193,255,0.82)",
    fg: "#e9f5ff"
  });
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(2.4, 0.58),
    new THREE.MeshBasicMaterial({ map: signTex, transparent: true })
  );
  sign.position.set(0, 3.24, 1.34);
  root.add(sign);

  const posterTex = makeTextPlane("COMING SOON • TABLES • MERCH • SPONSORS", {
    width: 900,
    height: 300,
    font: "bold 54px system-ui",
    bg: "rgba(10,12,20,0.86)",
    border: "rgba(180,140,255,0.72)",
    fg: "#f7f1ff"
  });
  const poster = new THREE.Mesh(
    new THREE.PlaneGeometry(1.95, 0.84),
    new THREE.MeshBasicMaterial({ map: posterTex, transparent: true })
  );
  poster.position.set(0, 1.96, 1.33);
  root.add(poster);

  return { root };
}

function addReikiLounge(group, roomRadius) {
  const root = new THREE.Group();
  const yaw = THREE.MathUtils.degToRad(42);
  const r = roomRadius - 4.5;
  root.position.set(Math.cos(yaw) * r, 0, Math.sin(yaw) * r);
  root.rotation.y = -yaw + Math.PI / 2;
  group.add(root);

  const floor = new THREE.Mesh(
    new THREE.BoxGeometry(4.4, 0.06, 3.5),
    new THREE.MeshStandardMaterial({ color: 0x241b2b, roughness: 0.9, metalness: 0.04 })
  );
  floor.position.y = 0.03;
  root.add(floor);

  const carpet = new THREE.Mesh(
    new THREE.BoxGeometry(2.2, 0.02, 2.8),
    new THREE.MeshStandardMaterial({ color: 0x612241, roughness: 0.98, metalness: 0.01 })
  );
  carpet.position.y = 0.06;
  root.add(carpet);

  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xa9daff, roughness: 0.03, metalness: 0, transmission: 0.92, transparent: true, opacity: 0.2 });
  const wall1 = new THREE.Mesh(new THREE.BoxGeometry(4.4, 2.5, 0.04), glassMat);
  wall1.position.set(0, 1.25, -1.75);
  root.add(wall1);
  const wall2 = wall1.clone();
  wall2.position.z = 1.75;
  root.add(wall2);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.5, 3.45), glassMat);
  back.position.set(-2.2, 1.25, 0);
  root.add(back);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(2.2, 0.45),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("REIKI LOUNGE", { width: 860, height: 180, font: "bold 82px system-ui" }), transparent: true })
  );
  sign.position.set(0.1, 2.45, -1.77);
  root.add(sign);

  return { root };
}

function addCeiling(group, roomRadius, wallHeight) {
  const crown = new THREE.Mesh(
    new THREE.TorusGeometry(roomRadius - 1.5, 0.13, 10, 120),
    new THREE.MeshStandardMaterial({ color: 0x222531, roughness: 0.38, metalness: 0.18, emissive: 0x251024, emissiveIntensity: 0.16 })
  );
  crown.rotation.x = Math.PI / 2;
  crown.position.y = wallHeight - 0.7;
  group.add(crown);

  const center = new THREE.Mesh(
    new THREE.CircleGeometry(5.5, 48),
    new THREE.MeshStandardMaterial({ color: 0x10131a, roughness: 0.82, metalness: 0.08 })
  );
  center.rotation.x = Math.PI / 2;
  center.position.y = wallHeight - 0.32;
  group.add(center);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(2.5, 4.8, 64),
    new THREE.MeshBasicMaterial({ color: 0x6d1e32, transparent: true, opacity: 0.08, side: THREE.DoubleSide })
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.y = wallHeight - 0.31;
  group.add(ring);

  return { crown, center, ring };
}

function addPlanets(group, roomRadius) {
  const moonTex = makePlanetTexture("moon");
  const earthTex = makePlanetTexture("earth");
  const cloudTex = makePlanetTexture("clouds");

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(4.9, 34, 34),
    new THREE.MeshStandardMaterial({ map: moonTex, roughness: 0.94, emissive: 0x131420, emissiveIntensity: 0.12 })
  );
  moon.position.set(-18, 11, -(roomRadius + 20));
  group.add(moon);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(3, 30, 30),
    new THREE.MeshStandardMaterial({ map: earthTex, roughness: 0.86, emissive: 0x0a1e38, emissiveIntensity: 0.12 })
  );
  earth.position.set(16, 8.8, -(roomRadius + 17));
  group.add(earth);

  const earthClouds = new THREE.Mesh(
    new THREE.SphereGeometry(3.06, 30, 30),
    new THREE.MeshStandardMaterial({ map: cloudTex, transparent: true, opacity: 0.22, roughness: 1, metalness: 0, depthWrite: false })
  );
  earthClouds.position.copy(earth.position);
  group.add(earthClouds);

  return { moon, earth, earthClouds };
}

function makePlanetTexture(kind) {
  const size = 1024;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");

  if (kind === "moon") {
    const grad = ctx.createRadialGradient(size * 0.36, size * 0.32, size * 0.1, size * 0.5, size * 0.5, size * 0.62);
    grad.addColorStop(0, "#efedf6");
    grad.addColorStop(1, "#8f92a6");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 140; i += 1) {
      const r = 6 + Math.random() * 42;
      const x = Math.random() * size;
      const y = Math.random() * size;
      ctx.fillStyle = `rgba(86,88,102,${0.06 + Math.random() * 0.12})`;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (kind === "earth") {
    const sea = ctx.createLinearGradient(0, 0, size, size);
    sea.addColorStop(0, "#2e78ff");
    sea.addColorStop(1, "#062346");
    ctx.fillStyle = sea;
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = "rgba(78,184,104,0.98)";
    for (let i = 0; i < 20; i += 1) {
      ctx.beginPath();
      ctx.ellipse(Math.random() * size, Math.random() * size, 70 + Math.random() * 120, 26 + Math.random() * 68, Math.random() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = "rgba(255,255,255,0.2)";
    for (let i = 0; i < 100; i += 1) {
      ctx.beginPath();
      ctx.ellipse(Math.random() * size, Math.random() * size, 18 + Math.random() * 80, 8 + Math.random() * 22, Math.random() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

function createMatrixRainPanel(width, height) {
  const { canvas, ctx, texture } = makeCanvasLabel({ width, height, draw(drawCtx, w, h) {
    drawCtx.fillStyle = "#001405";
    drawCtx.fillRect(0, 0, w, h);
  }});
  const cols = Array.from({ length: Math.floor(width / 24) }, () => Math.random() * height);
  return { canvas, ctx, texture, cols, lastStep: 0 };
}

function updateMatrixRain(panel, t) {
  if (t - panel.lastStep < 0.14) return;
  panel.lastStep = t;
  const { ctx, canvas, cols, texture } = panel;
  ctx.fillStyle = "rgba(0, 10, 0, 0.12)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.font = "bold 24px monospace";
  ctx.textAlign = "center";
  const chars = "アカサタナハマヤラワ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for (let i = 0; i < cols.length; i += 1) {
    const x = i * 24 + 12;
    const y = cols[i];
    const char = chars[Math.floor(Math.random() * chars.length)];
    ctx.fillStyle = i % 9 === 0 ? "#9affb0" : "#2de36b";
    ctx.fillText(char, x, y);
    cols[i] += 18 + Math.random() * 16;
    if (cols[i] > canvas.height + 24 && Math.random() > 0.92) cols[i] = -24;
  }
  texture.needsUpdate = true;
}

async function createTable() {
  const group = new THREE.Group();
  const props = [];

  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(0.72, 0.92, 1.04, 28),
    new THREE.MeshStandardMaterial({ color: 0x171a22, roughness: 0.62, metalness: 0.18 })
  );
  base.position.y = 0.52;
  base.castShadow = true;
  base.receiveShadow = true;
  group.add(base);

  const top = new THREE.Mesh(
    new THREE.CylinderGeometry(2.2, 2.26, 0.18, 64),
    new THREE.MeshStandardMaterial({ color: 0x1f232b, roughness: 0.6, metalness: 0.16 })
  );
  top.scale.z = 0.68;
  top.position.y = 1.02;
  top.castShadow = true;
  top.receiveShadow = true;
  group.add(top);

  const rail = new THREE.Mesh(
    new THREE.TorusGeometry(1.84, 0.18, 20, 88),
    new THREE.MeshStandardMaterial({ color: 0x14151b, roughness: 0.44, metalness: 0.22, emissive: 0x11070c, emissiveIntensity: 0.14 })
  );
  rail.rotation.x = Math.PI / 2;
  rail.scale.y = 0.7;
  rail.position.y = 1.12;
  rail.castShadow = true;
  group.add(rail);

  const feltMat = new THREE.MeshStandardMaterial({ color: 0x112017, roughness: 0.98, metalness: 0.01, emissive: 0x050a06, emissiveIntensity: 0.03, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
  try {
    const loader = new THREE.TextureLoader();
    const texture = await new Promise((resolve, reject) => loader.load("./assets/logo_table.png", resolve, undefined, reject));
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 8;
    texture.wrapS = THREE.ClampToEdgeWrapping;
    texture.wrapT = THREE.ClampToEdgeWrapping;
    feltMat.map = texture;
    feltMat.needsUpdate = true;
  } catch (err) {
    console.warn("logo_table texture missing, using fallback felt", err);
  }

  const felt = new THREE.Mesh(
    new THREE.CircleGeometry(1.82, 72),
    feltMat
  );
  felt.rotation.x = -Math.PI / 2;
  felt.scale.y = 0.68;
  felt.position.y = 1.112;
  felt.receiveShadow = true;
  group.add(felt);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(2.2, 0.26),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("LIVE TEXAS HOLD'EM DEMO", { width: 1200, height: 160, font: "bold 62px system-ui" }), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 })
  );
  sign.rotation.x = -Math.PI / 2;
  sign.rotation.z = Math.PI;
  sign.position.set(0, 1.138, 0.76);
  group.add(sign);

  props.push(createChipStack({ color: 0xd03975, x: -0.62, z: 0.58, height: 0.06, label: "chip-pink" }));
  props.push(createChipStack({ color: 0x4ca8ff, x: -0.32, z: 0.53, height: 0.065, label: "chip-blue" }));
  props.push(createChipStack({ color: 0x78d9c2, x: 0.32, z: 0.53, height: 0.055, label: "chip-green" }));
  props.push(createChipStack({ color: 0xf1d27a, x: 0.62, z: 0.58, height: 0.05, label: "chip-gold" }));
  props.push(createCard({ x: -0.46, z: 0.28, ry: -0.22, label: "card-a" }));
  props.push(createCard({ x: -0.16, z: 0.22, ry: -0.1, label: "card-b" }));
  props.push(createCard({ x: 0.16, z: 0.22, ry: 0.08, label: "card-c" }));
  props.push(createCard({ x: 0.46, z: 0.28, ry: 0.22, label: "card-d" }));

  props.forEach((prop) => group.add(prop));

  return { group, props };
}

function createChipStack({ color, x, z, height = 0.06, label }) {
  const material = new THREE.MeshStandardMaterial({ color, roughness: 0.38, metalness: 0.2, emissive: color, emissiveIntensity: 0.16 });
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, height, 32), material);
  mesh.position.set(x, CONFIG.TABLE_TOP_Y + (height * 0.5), z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.type = "table-prop";
  mesh.userData.kind = "chip";
  mesh.userData.label = label;
  mesh.userData.basePosition = mesh.position.clone();
  mesh.userData.baseQuaternion = mesh.quaternion.clone();
  mesh.userData.lastTablePosition = mesh.position.clone();
  mesh.userData.lastTableQuaternion = mesh.quaternion.clone();
  mesh.userData.baseEmissive = 0.16;
  return mesh;
}

function createCard({ x, z, ry = 0, label }) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.16, 0.01, 0.24),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.86, metalness: 0.03, emissive: 0x190f10, emissiveIntensity: 0.04 })
  );
  mesh.position.set(x, CONFIG.TABLE_TOP_Y + 0.028, z);
  mesh.rotation.y = ry;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.type = "table-prop";
  mesh.userData.kind = "card";
  mesh.userData.label = label;
  mesh.userData.basePosition = mesh.position.clone();
  mesh.userData.baseQuaternion = mesh.quaternion.clone();
  mesh.userData.lastTablePosition = mesh.position.clone();
  mesh.userData.lastTableQuaternion = mesh.quaternion.clone();
  mesh.userData.baseEmissive = 0.04;
  return mesh;
}

function createChairs() {
  const groups = [];
  const seats = [];
  const rings = [];

  for (let i = 0; i < CONFIG.CHAIR_COUNT; i += 1) {
    const a = (i / CONFIG.CHAIR_COUNT) * Math.PI * 2 + Math.PI;
    const chair = new THREE.Group();
    const x = Math.cos(a) * CONFIG.SEAT_RADIUS;
    const z = Math.sin(a) * CONFIG.SEAT_RADIUS;
    chair.position.set(x, 0, z);
    chair.rotation.y = faceYaw(new THREE.Vector3(x, 0, z), new THREE.Vector3(0, 0, 0));

    const frameMat = new THREE.MeshStandardMaterial({ color: 0x161920, roughness: 0.76, metalness: 0.12 });
    const cushionMat = new THREE.MeshStandardMaterial({ color: 0x20242d, roughness: 0.82, metalness: 0.08 });

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.12, 0.72), cushionMat);
    seat.position.y = 0.48;
    chair.add(seat);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.86, 0.1), frameMat);
    back.position.set(0, 0.94, -0.28);
    chair.add(back);
    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.28, 0.6), frameMat);
    armL.position.set(-0.36, 0.67, 0);
    chair.add(armL);
    const armR = armL.clone();
    armR.position.x = 0.36;
    chair.add(armR);
    const legs = [-0.24, 0.24].flatMap((lx) => [-0.22, 0.22].map((lz) => ({ lx, lz })));
    legs.forEach(({ lx, lz }) => {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.45, 0.08), frameMat);
      leg.position.set(lx, 0.22, lz);
      chair.add(leg);
    });

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.46, 0.62, 48),
      new THREE.MeshStandardMaterial({ color: 0xa97eff, emissive: 0x2b0d3a, emissiveIntensity: 0.44, transparent: true, opacity: 0.28, side: THREE.DoubleSide })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.022;
    chair.add(ring);
    rings.push(ring);

    const tagTex = makeTextPlane(`BOT ${i + 1}`, { width: 480, height: 150, font: "bold 66px system-ui", bg: "rgba(6,8,14,0.84)", border: "rgba(140,210,255,0.45)", fg: "#ecf8ff" });
    const tag = new THREE.Mesh(
      new THREE.PlaneGeometry(0.68, 0.2),
      new THREE.MeshBasicMaterial({ map: tagTex, transparent: true, depthWrite: false, side: THREE.DoubleSide })
    );
    tag.position.set(0, 1.42, 0.24);
    tag.rotation.y = Math.PI;
    chair.add(tag);

    const hit = new THREE.Mesh(
      new THREE.CylinderGeometry(0.52, 0.52, 1.6, 16),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.001 })
    );
    hit.position.y = 0.82;
    hit.userData.type = "seat";
    hit.userData.index = i;
    chair.add(hit);

    const anchorDir = new THREE.Vector3(-x, 0, -z).normalize();
    const anchor = new THREE.Vector3(x, CONFIG.SEATED_EYE_HEIGHT, z).add(anchorDir.multiplyScalar(CONFIG.SEAT_ANCHOR_INSET));
    seats.push({ index: i, anchor, yaw: faceYaw(anchor, new THREE.Vector3(0, CONFIG.SEATED_EYE_HEIGHT, 0)), hit });
    groups.push(chair);
  }

  return { groups, seats, rings };
}

function createDealer() {
  const dealer = new THREE.Group();
  dealer.position.set(0, 0, -2.12);

  const suit = new THREE.MeshStandardMaterial({ color: 0x22252d, roughness: 0.76, metalness: 0.08 });
  const accent = new THREE.MeshStandardMaterial({ color: 0x7f63ff, roughness: 0.28, metalness: 0.18, emissive: 0x2b1655, emissiveIntensity: 0.42 });
  const skin = new THREE.MeshStandardMaterial({ color: 0xcba789, roughness: 0.9, metalness: 0.02 });

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.58, 8, 16), suit);
  torso.position.y = 1.1;
  dealer.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 24, 24), skin);
  head.position.set(0, 1.72, 0.02);
  dealer.add(head);
  const visor = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.02, 10, 30, Math.PI), accent);
  visor.position.set(0, 1.72, 0.13);
  visor.rotation.z = Math.PI;
  dealer.add(visor);
  const armGeo = new THREE.CapsuleGeometry(0.06, 0.48, 6, 12);
  const armL = new THREE.Mesh(armGeo, suit);
  armL.position.set(-0.26, 1.1, 0.12);
  armL.rotation.z = 0.75;
  armL.rotation.x = -0.45;
  dealer.add(armL);
  const armR = armL.clone();
  armR.position.x = 0.26;
  armR.rotation.z = -0.75;
  dealer.add(armR);

  const holo = new THREE.Mesh(
    new THREE.PlaneGeometry(1.35, 0.38),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("ERIC • DEALER", { width: 860, height: 180, font: "bold 76px system-ui" }), transparent: true })
  );
  holo.position.set(0, 2.14, 0);
  dealer.add(holo);

  dealer.userData.sway = 0;
  return dealer;
}
