import * as THREE from "three";
import { CONFIG } from "./config.js";
import { faceYaw, makeTextPlane, pulse } from "./utils.js";

export async function buildWorld(scene, { log=console.log } = {}) {
  const group = new THREE.Group();
  scene.add(group);

  const roomRadius = CONFIG.ROOM_RADIUS;
  const wallHeight = CONFIG.WALL_HEIGHT;

  addSkyDome(group, roomRadius, wallHeight);

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius + 12, 120),
    new THREE.MeshStandardMaterial({ color: 0x05050a, roughness: 0.97, metalness: 0.02, emissive: 0x060410, emissiveIntensity: 0.18 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  group.add(floor);

  const floorRing = new THREE.Mesh(
    new THREE.RingGeometry(roomRadius - 2.8, roomRadius - 1.9, 140),
    new THREE.MeshBasicMaterial({ color: 0x7d4dff, transparent: true, opacity: 0.11, side: THREE.DoubleSide })
  );
  floorRing.rotation.x = -Math.PI / 2;
  floorRing.position.y = 0.015;
  group.add(floorRing);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(roomRadius, roomRadius, wallHeight, 96, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x080712, roughness: 0.9, metalness: 0.12, emissive: 0x1b0b2e, emissiveIntensity: 0.48, side: THREE.BackSide, transparent: true, opacity: 0.95 })
  );
  wall.position.y = wallHeight / 2;
  group.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(roomRadius - 0.5, 0.24, 12, 180),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.24, metalness: 0.24, emissive: 0x3b1552, emissiveIntensity: 2.0 })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.y = wallHeight - 0.35;
  group.add(rim);

  const ceilingGlow = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius - 0.9, 120),
    new THREE.MeshBasicMaterial({ color: 0x1f1032, transparent: true, opacity: 0.18, side: THREE.DoubleSide })
  );
  ceilingGlow.rotation.x = Math.PI / 2;
  ceilingGlow.position.y = wallHeight - 0.2;
  group.add(ceilingGlow);

  const stars = addStars(group, roomRadius);
  const planets = addMoonAndEarth(group, roomRadius);
  const skyline = addSkyline(group, roomRadius);
  const aurora = addAuroraBands(group, roomRadius, wallHeight);
  const promenade = addPromenade(group, roomRadius);
  const sponsorWalls = addSponsorWalls(group, roomRadius);
  const entryPortal = addEntryPortal(group, roomRadius);
  const worldRings = addWorldRings(group, roomRadius, wallHeight);
  const planters = addPlanters(group, roomRadius);
  const sponsorWing = addReikiSuite(group, roomRadius);
  const kiosks = addInfoKiosks(group, roomRadius);
  addNorthMarker(group);

  const table = await createTable();
  group.add(table.group);

  const chairs = createChairs();
  chairs.groups.forEach((c) => group.add(c));

  const dealer = createDealer();
  group.add(dealer);

  scene.userData._tickWorld = (t) => {
    chairs.rings.forEach((ring, i) => {
      const v = pulse(t + i * 0.22, 1.2, 0.6, 0.8);
      ring.material.emissiveIntensity = v;
      ring.material.opacity = 0.48 + Math.sin(t * 0.35 + i * 0.25) * 0.03;
    });

    table.props.forEach((prop, i) => {
      if (prop.userData.held) return;
      const baseY = prop.userData.basePosition.y;
      prop.position.y = baseY + Math.sin((t * 0.55) + i * 0.55) * 0.001;
      if (prop.material?.emissiveIntensity !== undefined) {
        prop.material.emissiveIntensity = prop.userData.hovered ? (prop.userData.baseEmissive + 0.24) : prop.userData.baseEmissive;
      }
    });

    dealer.userData.idle += 0.006;
    dealer.rotation.z = Math.sin(dealer.userData.idle) * 0.006;

    planets.moon.rotation.y += 0.00035;
    planets.earth.rotation.y += 0.00065;
    planets.earthClouds.rotation.y += 0.00082;
    planets.moonGlow.material.opacity = 0.14 + Math.sin(t * 0.16) * 0.01;
    planets.earthGlow.material.opacity = 0.18 + Math.sin(t * 0.18 + 1.4) * 0.012;

    skyline.bands.forEach((band, i) => {
      band.material.emissiveIntensity = 0.92 + Math.sin(t * 0.3 + i * 0.15) * 0.05;
      band.material.opacity = 0.62 + Math.sin(t * 0.28 + i * 0.13) * 0.02;
    });
    skyline.billboards.forEach((billboard, i) => {
      billboard.material.opacity = 0.92 + Math.sin(t * 0.18 + i * 0.4) * 0.015;
    });

    aurora.forEach((band, i) => {
      band.rotation.z += 0.00004 + i * 0.00001;
      band.material.opacity = 0.06 + Math.sin(t * 0.12 + i * 0.55) * 0.01;
    });

    if (promenade?.pathGlow) {
      promenade.pathGlow.material.opacity = 0.2 + Math.sin(t * 0.16) * 0.015;
    }
    sponsorWalls.forEach((wall, i) => {
      wall.screen.material.opacity = 0.96;
      wall.glow.material.opacity = 0.16 + Math.sin(t * 0.18 + i * 0.7) * 0.015;
    });
    entryPortal.beam.material.opacity = 0.11 + Math.sin(t * 0.15) * 0.012;
    worldRings.forEach((ring, i) => {
      ring.rotation.z += 0.00002 + i * 0.00001;
      ring.material.opacity = ring.userData.baseOpacity + Math.sin(t * 0.1 + i * 0.6) * 0.008;
    });
    planters.forEach((planter, i) => {
      planter.holo.material.opacity = 0.1 + Math.sin(t * 0.2 + i * 0.3) * 0.01;
    });

    stars.twinkles.forEach((star, i) => {
      star.material.opacity = 0.82 + Math.sin(t * 0.3 + i * 0.22) * 0.04;
      star.scale.setScalar(1 + Math.sin(t * 0.25 + i) * 0.015);
    });

    sponsorWing.beacon.material.opacity = 0.22 + Math.sin(t * 0.15) * 0.015;
    sponsorWing.sign.material.opacity = 0.9;
    sponsorWing.room.rotation.y = Math.sin(t * 0.05) * 0.004;

    kiosks.forEach((kiosk, i) => {
      kiosk.glow.material.opacity = 0.15 + Math.sin(t * 0.18 + i * 0.4) * 0.015;
      kiosk.screen.material.opacity = 0.95;
    });

    rim.material.emissiveIntensity = 1.35 + Math.sin(t * 0.16) * 0.05;
    ceilingGlow.material.opacity = 0.16 + Math.sin(t * 0.1) * 0.01;
    floorRing.material.opacity = 0.1 + Math.sin(t * 0.12) * 0.01;
  };

  log("World ready", { chairs: chairs.seats.length, props: table.props.length, kiosks: kiosks.length });

  return {
    roomClamp: roomRadius - 2,
    seats: chairs.seats,
    seatInteractables: chairs.hitMeshes,
    chairRings: chairs.rings,
    tableCenter: new THREE.Vector3(0, 0, 0),
    tableProps: table.props,
  };
}

function addSkyDome(group, roomRadius, wallHeight) {
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(roomRadius + 44, 48, 32),
    new THREE.MeshBasicMaterial({ color: 0x04030a, side: THREE.BackSide })
  );
  sky.position.y = wallHeight * 0.28;
  group.add(sky);
}

function addStars(group, roomRadius) {
  const starGeo = new THREE.BufferGeometry();
  const count = 520;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    const r = roomRadius + 18 + Math.random() * 34;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.62;
    positions[i * 3] = Math.cos(theta) * Math.sin(phi) * r;
    positions[i * 3 + 1] = 8 + Math.cos(phi) * r * 0.24;
    positions[i * 3 + 2] = Math.sin(theta) * Math.sin(phi) * r;
  }
  starGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 0.12, transparent: true, opacity: 0.9 }));
  group.add(stars);

  const twinkles = [];
  for (let i = 0; i < 14; i += 1) {
    const glow = new THREE.Mesh(
      new THREE.PlaneGeometry(0.8, 0.8),
      new THREE.MeshBasicMaterial({ color: 0xe7e0ff, transparent: true, opacity: 0.82, side: THREE.DoubleSide })
    );
    const a = (i / 14) * Math.PI * 2 + (Math.random() - 0.5) * 0.18;
    glow.position.set(Math.cos(a) * (roomRadius + 25 + Math.random() * 8), 10 + Math.random() * 10, Math.sin(a) * (roomRadius + 25 + Math.random() * 8));
    group.add(glow);
    twinkles.push(glow);
  }

  return { twinkles };
}

function addMoonAndEarth(group, roomRadius) {
  const moonTex = makePlanetTexture("moon");
  const earthTex = makePlanetTexture("earth");
  const cloudTex = makePlanetTexture("clouds");

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(5.6, 40, 40),
    new THREE.MeshStandardMaterial({ map: moonTex, roughness: 0.96, emissive: 0x1d1930, emissiveIntensity: 0.34 })
  );
  moon.position.set(-20, 11.5, -(roomRadius + 27));
  group.add(moon);

  const moonGlow = new THREE.Mesh(
    new THREE.SphereGeometry(6.4, 28, 28),
    new THREE.MeshBasicMaterial({ color: 0xe5ddff, transparent: true, opacity: 0.18, side: THREE.BackSide })
  );
  moonGlow.position.copy(moon.position);
  group.add(moonGlow);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(3.5, 36, 36),
    new THREE.MeshStandardMaterial({ map: earthTex, roughness: 0.84, emissive: 0x0a193a, emissiveIntensity: 0.28 })
  );
  earth.position.set(19, 9.4, -(roomRadius + 23));
  group.add(earth);

  const earthClouds = new THREE.Mesh(
    new THREE.SphereGeometry(3.58, 36, 36),
    new THREE.MeshStandardMaterial({ map: cloudTex, transparent: true, opacity: 0.28, roughness: 1, metalness: 0, depthWrite: false })
  );
  earthClouds.position.copy(earth.position);
  group.add(earthClouds);

  const earthGlow = new THREE.Mesh(
    new THREE.SphereGeometry(4.1, 24, 24),
    new THREE.MeshBasicMaterial({ color: 0x62b9ff, transparent: true, opacity: 0.24, side: THREE.BackSide })
  );
  earthGlow.position.copy(earth.position);
  group.add(earthGlow);

  return { moon, moonGlow, earth, earthClouds, earthGlow };
}

function addSkyline(group, roomRadius) {
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x0d0d18, roughness: 0.78, metalness: 0.14, emissive: 0x160a24, emissiveIntensity: 0.54 });
  const glowMat = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.28, metalness: 0.2, emissive: 0x35114a, emissiveIntensity: 1.25, transparent: true, opacity: 0.66 });
  const billboardMat = new THREE.MeshBasicMaterial({ color: 0xe7ddff, transparent: true, opacity: 0.94 });
  const bands = [];
  const billboards = [];

  for (let i = 0; i < 120; i += 1) {
    const a = (i / 120) * Math.PI * 2;
    const radius = roomRadius + 5 + Math.random() * 8;
    const w = 1.3 + Math.random() * 3.1;
    const d = 1.3 + Math.random() * 3.1;
    const h = 3 + Math.random() * 18;
    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), baseMat);
    body.position.set(Math.cos(a) * radius, h / 2, Math.sin(a) * radius);
    body.rotation.y = -a + Math.PI / 2;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    if (Math.random() < 0.85) {
      const band = new THREE.Mesh(new THREE.BoxGeometry(w * 0.88, 0.16, d * 1.05), glowMat.clone());
      band.position.set(body.position.x, 1.4 + Math.random() * Math.max(1, h - 2), body.position.z);
      band.rotation.y = body.rotation.y;
      group.add(band);
      bands.push(band);
    }

    if (Math.random() < 0.16 && h > 7) {
      const text = makeTextPlane(Math.random() < 0.5 ? "ALL IN" : "SVR", {
        width: 512,
        height: 160,
        font: "bold 74px system-ui",
        bg: "rgba(6,8,18,0.58)",
        border: "rgba(180,140,255,0.72)",
      });
      const billboard = new THREE.Mesh(
        new THREE.PlaneGeometry(1.9, 0.6),
        billboardMat.clone()
      );
      billboard.material.map = text;
      billboard.position.set(body.position.x, Math.min(h - 1.2, 8 + Math.random() * 5), body.position.z + Math.sign(body.position.z || 1) * 0.02);
      billboard.lookAt(0, billboard.position.y, 0);
      group.add(billboard);
      billboards.push(billboard);
    }
  }

  return { bands, billboards };
}

function addAuroraBands(group, roomRadius, wallHeight) {
  const bands = [];
  const specs = [
    { r: roomRadius - 4.4, tube: 0.22, opacity: 0.08, color: 0x7cf3d6 },
    { r: roomRadius - 6.2, tube: 0.18, opacity: 0.06, color: 0xb48cff },
    { r: roomRadius - 8.3, tube: 0.16, opacity: 0.05, color: 0x5db2ff },
  ];
  specs.forEach((spec, i) => {
    const band = new THREE.Mesh(
      new THREE.TorusGeometry(spec.r, spec.tube, 12, 160),
      new THREE.MeshBasicMaterial({ color: spec.color, transparent: true, opacity: spec.opacity, side: THREE.DoubleSide })
    );
    band.rotation.x = Math.PI / 2 + 0.08 + i * 0.04;
    band.position.y = wallHeight - 1.7 - i * 0.7;
    group.add(band);
    bands.push(band);
  });
  return bands;
}


function addPromenade(group, roomRadius) {
  const root = new THREE.Group();
  group.add(root);

  const path = new THREE.Mesh(
    new THREE.BoxGeometry(2.8, 0.035, 13.5),
    new THREE.MeshStandardMaterial({ color: 0x40111e, roughness: 0.96, metalness: 0.02, emissive: 0x220710, emissiveIntensity: 0.12 })
  );
  path.position.set(0, 0.02, roomRadius * 0.28);
  root.add(path);

  const pathGlow = new THREE.Mesh(
    new THREE.PlaneGeometry(2.18, 12.9),
    new THREE.MeshBasicMaterial({ color: 0xa94567, transparent: true, opacity: 0.2, side: THREE.DoubleSide })
  );
  pathGlow.rotation.x = -Math.PI / 2;
  pathGlow.position.set(0, 0.041, roomRadius * 0.28);
  root.add(pathGlow);

  const infoLeft = new THREE.Mesh(
    new THREE.PlaneGeometry(2.8, 0.72),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("SVR POKER • REAL LOBBY", { width: 1024, height: 200, font: "bold 78px system-ui" }), transparent: true })
  );
  infoLeft.position.set(-3.4, 2.1, roomRadius * 0.16);
  infoLeft.rotation.y = THREE.MathUtils.degToRad(24);
  root.add(infoLeft);

  const infoRight = new THREE.Mesh(
    new THREE.PlaneGeometry(2.8, 0.72),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("ALL IN • DEMO IN PROGRESS", { width: 1024, height: 200, font: "bold 70px system-ui" }), transparent: true })
  );
  infoRight.position.set(3.4, 2.1, roomRadius * 0.16);
  infoRight.rotation.y = THREE.MathUtils.degToRad(-24);
  root.add(infoRight);

  return { root, pathGlow };
}

function addSponsorWalls(group, roomRadius) {
  const entries = [
    { x: -7.2, z: roomRadius - 4.8, yaw: THREE.MathUtils.degToRad(186), title: "WHAT WE ARE BUILDING", subtitle: "VR poker • sponsor wins • donor nation" },
    { x: 7.2, z: roomRadius - 4.8, yaw: THREE.MathUtils.degToRad(174), title: "CURRENT DEMO GOAL", subtitle: "stable lobby • real cards • clean preview" },
  ];
  return entries.map((entry) => {
    const root = new THREE.Group();
    root.position.set(entry.x, 0, entry.z);
    root.rotation.y = entry.yaw;
    group.add(root);

    const wall = new THREE.Mesh(
      new THREE.BoxGeometry(4.6, 2.6, 0.28),
      new THREE.MeshStandardMaterial({ color: 0x11121b, roughness: 0.72, metalness: 0.18, emissive: 0x0f0a1a, emissiveIntensity: 0.3 })
    );
    wall.position.y = 1.8;
    root.add(wall);

    const screen = new THREE.Mesh(
      new THREE.PlaneGeometry(4.1, 2.1),
      new THREE.MeshBasicMaterial({
        map: makeTextPlane(`${entry.title} • ${entry.subtitle}`, {
          width: 1280,
          height: 512,
          font: "bold 68px system-ui",
          bg: "rgba(6,8,18,0.82)",
          border: "rgba(180,140,255,0.84)",
          fg: "#f5f0ff"
        }),
        transparent: true,
        opacity: 0.96
      })
    );
    screen.position.set(0, 1.8, 0.16);
    root.add(screen);

    const glow = new THREE.Mesh(
      new THREE.PlaneGeometry(4.4, 2.35),
      new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.16 })
    );
    glow.position.set(0, 1.8, 0.17);
    root.add(glow);

    return { root, wall, screen, glow };
  });
}

function addEntryPortal(group, roomRadius) {
  const root = new THREE.Group();
  root.position.set(0, 0, roomRadius - 5.4);
  group.add(root);

  const archMat = new THREE.MeshStandardMaterial({ color: 0x1a1722, roughness: 0.58, metalness: 0.22, emissive: 0x150f22, emissiveIntensity: 0.34 });
  const left = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.4, 0.5), archMat);
  left.position.set(-1.55, 1.7, 0);
  root.add(left);
  const right = left.clone();
  right.position.x = 1.55;
  root.add(right);
  const top = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.42, 0.5), archMat);
  top.position.set(0, 3.2, 0);
  root.add(top);

  const beam = new THREE.Mesh(
    new THREE.PlaneGeometry(2.45, 2.6),
    new THREE.MeshBasicMaterial({ color: 0x79f3da, transparent: true, opacity: 0.11, side: THREE.DoubleSide })
  );
  beam.position.set(0, 1.45, -0.12);
  root.add(beam);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(3.5, 0.62),
    new THREE.MeshBasicMaterial({
      map: makeTextPlane("SVR POKER • LOBBY LOCK", { width: 1280, height: 220, font: "bold 88px system-ui" }),
      transparent: true
    })
  );
  sign.position.set(0, 3.18, 0.28);
  root.add(sign);

  return { root, beam, sign };
}

function addWorldRings(group, roomRadius, wallHeight) {
  const specs = [
    { r: roomRadius + 10, tube: 0.11, opacity: 0.05, color: 0x67b9ff, y: wallHeight - 3.5 },
    { r: roomRadius + 14, tube: 0.14, opacity: 0.04, color: 0xb48cff, y: wallHeight - 1.8 },
  ];
  return specs.map((spec, i) => {
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(spec.r, spec.tube, 12, 180),
      new THREE.MeshBasicMaterial({ color: spec.color, transparent: true, opacity: spec.opacity, side: THREE.DoubleSide })
    );
    ring.rotation.x = Math.PI / 2 + 0.22 + i * 0.06;
    ring.position.y = spec.y;
    ring.userData.baseOpacity = spec.opacity;
    group.add(ring);
    return ring;
  });
}

function addPlanters(group, roomRadius) {
  const planters = [];
  [-1, 1].forEach((side) => {
    for (let i = 0; i < 4; i += 1) {
      const z = roomRadius * 0.05 + i * 2.2;
      const root = new THREE.Group();
      root.position.set(side * 2.05, 0, z);
      group.add(root);

      const pot = new THREE.Mesh(
        new THREE.CylinderGeometry(0.22, 0.28, 0.34, 18),
        new THREE.MeshStandardMaterial({ color: 0x171620, roughness: 0.84, metalness: 0.08 })
      );
      pot.position.y = 0.17;
      root.add(pot);

      const stalk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.05, 0.55, 10),
        new THREE.MeshStandardMaterial({ color: 0x2d6b52, roughness: 0.9, metalness: 0.03 })
      );
      stalk.position.y = 0.56;
      root.add(stalk);

      for (let j = 0; j < 4; j += 1) {
        const leaf = new THREE.Mesh(
          new THREE.SphereGeometry(0.12 + j * 0.01, 10, 10),
          new THREE.MeshStandardMaterial({ color: 0x4ecc9e, roughness: 0.9, metalness: 0.02, emissive: 0x103526, emissiveIntensity: 0.08 })
        );
        leaf.scale.set(1.2, 0.6, 0.5);
        leaf.position.set((j - 1.5) * 0.07, 0.77 + j * 0.09, (j % 2 === 0 ? -1 : 1) * 0.06);
        root.add(leaf);
      }

      const holo = new THREE.Mesh(
        new THREE.PlaneGeometry(0.52, 0.52),
        new THREE.MeshBasicMaterial({ color: 0x79f3da, transparent: true, opacity: 0.1, side: THREE.DoubleSide })
      );
      holo.rotation.x = -Math.PI / 2;
      holo.position.y = 0.015;
      root.add(holo);
      planters.push({ root, holo });
    }
  });
  return planters;
}

function addNorthMarker(group) {
  const tex = makeTextPlane("NORTH / DEALER SIDE", { width: 1024, height: 160, font: "bold 68px system-ui" });
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(7, 1.1),
    new THREE.MeshBasicMaterial({ map: tex, transparent: true })
  );
  sign.position.set(0, 4.2, -8.8);
  group.add(sign);
}

function addReikiSuite(group, roomRadius) {
  const root = new THREE.Group();
  const yaw = Math.PI * 0.72;
  const radius = roomRadius - 4.8;
  root.position.set(Math.cos(yaw) * radius, 0, Math.sin(yaw) * radius);
  root.rotation.y = -yaw + Math.PI * 0.15;
  group.add(root);

  const floor = new THREE.Mesh(
    new THREE.BoxGeometry(5.2, 0.08, 4.1),
    new THREE.MeshStandardMaterial({ color: 0x261831, roughness: 0.86, metalness: 0.06, emissive: 0x1a0f26, emissiveIntensity: 0.28 })
  );
  floor.position.y = 0.04;
  root.add(floor);

  const carpet = new THREE.Mesh(
    new THREE.BoxGeometry(2.6, 0.02, 3.2),
    new THREE.MeshStandardMaterial({ color: 0x5a1230, roughness: 0.95, emissive: 0x300814, emissiveIntensity: 0.18 })
  );
  carpet.position.set(0, 0.06, 0);
  root.add(carpet);

  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0x9ad7ff, roughness: 0.03, metalness: 0, transparent: true, transmission: 0.9, opacity: 0.28, thickness: 0.08 });
  const side1 = new THREE.Mesh(new THREE.BoxGeometry(5.1, 2.5, 0.05), glassMat);
  side1.position.set(0, 1.25, -2.0);
  root.add(side1);
  const side2 = side1.clone();
  side2.position.z = 2.0;
  root.add(side2);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.05, 2.5, 4.0), glassMat);
  back.position.set(-2.55, 1.25, 0);
  root.add(back);
  const frontL = new THREE.Mesh(new THREE.BoxGeometry(0.05, 2.5, 1.4), glassMat);
  frontL.position.set(2.55, 1.25, -1.3);
  root.add(frontL);
  const frontR = frontL.clone();
  frontR.position.z = 1.3;
  root.add(frontR);
  const door = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.3, 1.1), glassMat.clone());
  door.position.set(2.57, 1.15, 0);
  root.add(door);

  const signTex = makeTextPlane("REIKI LOUNGE", {
    width: 768,
    height: 160,
    font: "bold 80px system-ui",
    bg: "rgba(8,8,16,0.46)",
    border: "rgba(126,240,208,0.7)",
    fg: "#efffff"
  });
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(2.6, 0.54),
    new THREE.MeshBasicMaterial({ map: signTex, transparent: true, opacity: 0.92 })
  );
  sign.position.set(0.2, 2.5, -2.03);
  root.add(sign);

  const beacon = new THREE.Mesh(
    new THREE.CylinderGeometry(1.1, 1.1, 2.7, 32, 1, true),
    new THREE.MeshBasicMaterial({ color: 0x79f3da, transparent: true, opacity: 0.26, side: THREE.DoubleSide })
  );
  beacon.position.set(0, 1.35, 0);
  root.add(beacon);

  const orb = new THREE.Mesh(
    new THREE.SphereGeometry(0.36, 24, 24),
    new THREE.MeshStandardMaterial({ color: 0xbdf7ff, emissive: 0x67ffd7, emissiveIntensity: 1.4, roughness: 0.18, metalness: 0.04 })
  );
  orb.position.set(0, 1.15, 0);
  root.add(orb);

  const benchMat = new THREE.MeshStandardMaterial({ color: 0x1a1822, roughness: 0.8, metalness: 0.08 });
  const bench = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.18, 0.45), benchMat);
  bench.position.set(-0.4, 0.45, 0);
  root.add(bench);
  const legGeo = new THREE.BoxGeometry(0.08, 0.45, 0.08);
  [-0.6, -0.2].forEach((x) => {
    [-0.16, 0.16].forEach((z) => {
      const leg = new THREE.Mesh(legGeo, benchMat);
      leg.position.set(x, 0.22, z);
      root.add(leg);
    });
  });

  return { room: root, beacon, sign };
}

function addInfoKiosks(group, roomRadius) {
  const entries = [
    { yaw: Math.PI * 0.15, title: "PUBLIC DEMO", subtitle: "Watch • Teleport • Sit" },
    { yaw: Math.PI * 1.85, title: "ALL IN", subtitle: "Sponsor wins • donor nation" },
  ];
  return entries.map((entry) => {
    const root = new THREE.Group();
    const radius = roomRadius - 4.1;
    root.position.set(Math.cos(entry.yaw) * radius, 0, Math.sin(entry.yaw) * radius);
    root.rotation.y = -entry.yaw + Math.PI / 2;
    group.add(root);

    const body = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 2.8, 0.28),
      new THREE.MeshStandardMaterial({ color: 0x11121a, roughness: 0.5, metalness: 0.26, emissive: 0x10091a, emissiveIntensity: 0.48 })
    );
    body.position.y = 1.4;
    root.add(body);

    const screenTex = makeTextPlane(`${entry.title} • ${entry.subtitle}`, {
      width: 768,
      height: 256,
      font: "bold 58px system-ui",
      bg: "rgba(6,8,18,0.78)",
      border: "rgba(180,140,255,0.84)",
      fg: "#f4efff"
    });
    const screen = new THREE.Mesh(
      new THREE.PlaneGeometry(0.86, 1.3),
      new THREE.MeshBasicMaterial({ map: screenTex, transparent: true, opacity: 0.96 })
    );
    screen.position.set(0, 1.48, 0.145);
    root.add(screen);

    const glow = new THREE.Mesh(
      new THREE.PlaneGeometry(1.15, 2.2),
      new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.2 })
    );
    glow.position.set(0, 1.45, 0.16);
    root.add(glow);

    return { root, body, screen, glow };
  });
}

function makePlanetTexture(kind) {
  const size = 1024;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");

  if (kind === "moon") {
    const grad = ctx.createRadialGradient(size * 0.36, size * 0.32, size * 0.1, size * 0.5, size * 0.5, size * 0.6);
    grad.addColorStop(0, "#f1efff");
    grad.addColorStop(1, "#9c9bb0");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 160; i += 1) {
      const r = 6 + Math.random() * 50;
      const x = Math.random() * size;
      const y = Math.random() * size;
      ctx.fillStyle = `rgba(88,88,106,${0.05 + Math.random() * 0.14})`;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.06)";
      ctx.lineWidth = Math.max(1, r * 0.06);
      ctx.beginPath();
      ctx.arc(x - r * 0.12, y - r * 0.12, r * 0.78, 0, Math.PI * 2);
      ctx.stroke();
    }
  } else if (kind === "earth") {
    const sea = ctx.createLinearGradient(0, 0, size, size);
    sea.addColorStop(0, "#1d5fdc");
    sea.addColorStop(1, "#08264f");
    ctx.fillStyle = sea;
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = "rgba(76,190,104,0.96)";
    for (let i = 0; i < 18; i += 1) {
      ctx.beginPath();
      const x = Math.random() * size;
      const y = Math.random() * size;
      ctx.ellipse(x, y, 70 + Math.random() * 120, 30 + Math.random() * 80, Math.random() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    for (let i = 0; i < 90; i += 1) {
      ctx.beginPath();
      const x = Math.random() * size;
      const y = Math.random() * size;
      ctx.ellipse(x, y, 18 + Math.random() * 50, 8 + Math.random() * 18, Math.random() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (kind === "clouds") {
    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = "rgba(255,255,255,0.0)";
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = "rgba(255,255,255,0.22)";
    for (let i = 0; i < 110; i += 1) {
      ctx.beginPath();
      const x = Math.random() * size;
      const y = Math.random() * size;
      ctx.ellipse(x, y, 24 + Math.random() * 90, 8 + Math.random() * 28, Math.random() * Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

async function createTable() {
  const group = new THREE.Group();
  const props = [];

  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(0.72, 0.92, 1.04, 28),
    new THREE.MeshStandardMaterial({ color: 0x14131a, roughness: 0.58, metalness: 0.24 })
  );
  base.position.y = 0.52;
  base.castShadow = true;
  base.receiveShadow = true;
  group.add(base);

  const top = new THREE.Mesh(
    new THREE.CylinderGeometry(2.2, 2.26, 0.18, 64),
    new THREE.MeshStandardMaterial({ color: 0x19161f, roughness: 0.56, metalness: 0.22 })
  );
  top.scale.z = 0.68;
  top.position.y = 1.02;
  top.castShadow = true;
  top.receiveShadow = true;
  group.add(top);

  const rail = new THREE.Mesh(
    new THREE.TorusGeometry(1.84, 0.18, 20, 88),
    new THREE.MeshStandardMaterial({ color: 0x0e0d12, roughness: 0.42, metalness: 0.26, emissive: 0x120915, emissiveIntensity: 0.35 })
  );
  rail.rotation.x = Math.PI / 2;
  rail.scale.y = 0.7;
  rail.position.y = 1.12;
  rail.castShadow = true;
  group.add(rail);

  const feltMat = new THREE.MeshStandardMaterial({ color: 0x101410, roughness: 0.92, metalness: 0.02, emissive: 0x040804, emissiveIntensity: 0.1, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
  try {
    const loader = new THREE.TextureLoader();
    const texture = await new Promise((resolve, reject) => loader.load("./assets/logo_table.png", resolve, undefined, reject));
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 8;
    texture.wrapS = THREE.ClampToEdgeWrapping;
    texture.wrapT = THREE.ClampToEdgeWrapping;
    feltMat.map = texture;
    feltMat.needsUpdate = true;
  } catch (err) {
    console.warn("logo_table texture missing, using fallback felt", err);
  }

  const felt = new THREE.Mesh(
    new THREE.CircleGeometry(1.82, 72),
    feltMat
  );
  felt.rotation.x = -Math.PI / 2;
  felt.scale.y = 0.68;
  felt.position.y = 1.112;
  felt.receiveShadow = true;
  group.add(felt);

  const glow = new THREE.Mesh(
    new THREE.RingGeometry(1.55, 1.72, 72),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.16, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 })
  );
  glow.rotation.x = -Math.PI / 2;
  glow.scale.y = 0.68;
  glow.position.y = 1.123;
  group.add(glow);

  const betText = makeTextPlane("LIVE DEMO • TEXAS HOLDEM", { width: 1024, height: 128, font: "bold 58px system-ui" });
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(2.3, 0.28),
    new THREE.MeshBasicMaterial({ map: betText, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 })
  );
  sign.rotation.x = -Math.PI / 2;
  sign.position.set(0, 1.138, 0.78);
  group.add(sign);

  props.push(createChipStack({ color: 0xc92d6f, x: -0.62, z: 0.58, height: 0.06, label: "chip-pink" }));
  props.push(createChipStack({ color: 0x44a7ff, x: -0.32, z: 0.53, height: 0.065, label: "chip-blue" }));
  props.push(createChipStack({ color: 0x7af0c8, x: 0.32, z: 0.53, height: 0.055, label: "chip-green" }));
  props.push(createChipStack({ color: 0xf4f0c2, x: 0.62, z: 0.58, height: 0.05, label: "chip-gold" }));

  props.forEach((prop) => group.add(prop));

  return { group, props };
}

function createChipStack({ color, x, z, height=0.06, label }) {
  const material = new THREE.MeshStandardMaterial({ color, roughness: 0.38, metalness: 0.26, emissive: color, emissiveIntensity: 0.28 });
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, height, 32), material);
  mesh.position.set(x, CONFIG.TABLE_TOP_Y + (height * 0.5), z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.type = "table-prop";
  mesh.userData.kind = "chip";
  mesh.userData.label = label;
  mesh.userData.basePosition = mesh.position.clone();
  mesh.userData.baseQuaternion = mesh.quaternion.clone();
  mesh.userData.lastTablePosition = mesh.position.clone();
  mesh.userData.lastTableQuaternion = mesh.quaternion.clone();
  mesh.userData.baseEmissive = 0.28;
  return mesh;
}

function createCard({ x, z, ry=0, label }) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.16, 0.01, 0.24),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.82, metalness: 0.04, emissive: 0x3a1d1d, emissiveIntensity: 0.08 })
  );
  mesh.position.set(x, CONFIG.TABLE_TOP_Y + 0.007, z);
  mesh.rotation.y = ry;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.type = "table-prop";
  mesh.userData.kind = "card";
  mesh.userData.label = label;
  mesh.userData.basePosition = mesh.position.clone();
  mesh.userData.baseQuaternion = mesh.quaternion.clone();
  mesh.userData.lastTablePosition = mesh.position.clone();
  mesh.userData.lastTableQuaternion = mesh.quaternion.clone();
  mesh.userData.baseEmissive = 0.08;
  return mesh;
}

function createChairs() {
  const groups = [];
  const seats = [];
  const rings = [];
  const hitMeshes = [];

  for (let i = 0; i < CONFIG.CHAIR_COUNT; i += 1) {
    const a = (i / CONFIG.CHAIR_COUNT) * Math.PI * 2 + Math.PI;
    const chair = new THREE.Group();
    const x = Math.cos(a) * CONFIG.SEAT_RADIUS;
    const z = Math.sin(a) * CONFIG.SEAT_RADIUS;
    chair.position.set(x, 0, z);
    chair.rotation.y = faceYaw(new THREE.Vector3(x, 0, z), new THREE.Vector3(0, 0, 0));

    const seat = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.12, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x18171f, roughness: 0.74, metalness: 0.14 })
    );
    seat.position.y = 0.48;
    chair.add(seat);

    const back = new THREE.Mesh(
      new THREE.BoxGeometry(0.74, 0.82, 0.1),
      new THREE.MeshStandardMaterial({ color: 0x1f1d26, roughness: 0.72, metalness: 0.15 })
    );
    back.position.set(0, 0.92, -0.28);
    chair.add(back);

    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.3, 0.58), new THREE.MeshStandardMaterial({ color: 0x14131a, roughness: 0.8, metalness: 0.1 }));
    armL.position.set(-0.36, 0.67, 0);
    chair.add(armL);
    const armR = armL.clone();
    armR.position.x = 0.36;
    chair.add(armR);

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.46, 0.63, 48),
      new THREE.MeshStandardMaterial({ color: 0xb48cff, emissive: 0x50166f, emissiveIntensity: 0.9, transparent: true, opacity: 0.58, side: THREE.DoubleSide })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.022;
    chair.add(ring);
    rings.push(ring);

    const hit = new THREE.Mesh(
      new THREE.CylinderGeometry(0.52, 0.52, 1.6, 16),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.001 })
    );
    hit.position.y = 0.82;
    hit.userData.type = "seat";
    hit.userData.index = i;
    chair.add(hit);
    hitMeshes.push(hit);

    const anchorDir = new THREE.Vector3(-x, 0, -z).normalize();
    const anchor = new THREE.Vector3(x, CONFIG.SEATED_EYE_HEIGHT, z).add(anchorDir.multiplyScalar(CONFIG.SEAT_ANCHOR_INSET));
    seats.push({ index: i, anchor, yaw: faceYaw(anchor, new THREE.Vector3(0, CONFIG.SEATED_EYE_HEIGHT, 0)), hit });

    groups.push(chair);
  }

  return { groups, seats, rings, hitMeshes };
}

function createDealer() {
  const dealer = new THREE.Group();
  dealer.position.set(0, 0, -2.12);

  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x1e2028, roughness: 0.72, metalness: 0.08 });
  const accentMat = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.26, metalness: 0.18, emissive: 0x451563, emissiveIntensity: 0.86 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xcfa586, roughness: 0.88, metalness: 0.02 });

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.58, 8, 16), bodyMat);
  torso.position.y = 1.1;
  dealer.add(torso);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 24, 24), skinMat);
  head.position.set(0, 1.72, 0.02);
  dealer.add(head);

  const visor = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.02, 10, 30, Math.PI), accentMat);
  visor.position.set(0, 1.72, 0.13);
  visor.rotation.z = Math.PI;
  dealer.add(visor);

  const armGeo = new THREE.CapsuleGeometry(0.06, 0.48, 6, 12);
  const armL = new THREE.Mesh(armGeo, bodyMat);
  armL.position.set(-0.26, 1.1, 0.12);
  armL.rotation.z = 0.75;
  armL.rotation.x = -0.45;
  dealer.add(armL);

  const armR = armL.clone();
  armR.position.x = 0.26;
  armR.rotation.z = -0.75;
  dealer.add(armR);

  const holo = new THREE.Mesh(
    new THREE.PlaneGeometry(1.2, 0.36),
    new THREE.MeshBasicMaterial({ map: makeTextPlane("ERIC • DEALER", { width: 768, height: 160, font: "bold 72px system-ui" }), transparent: true })
  );
  holo.position.set(0, 2.15, 0);
  dealer.add(holo);

  dealer.userData.idle = 0;
  return dealer;
}
