export const ERIC_RIG_SLOT={
  id:"eric-dealer-rig-slot",
  status:"anchor-ready",
  position:{x:0,y:0,z:-3.95},
  targetPose:"seated dealer / card reach",
  next:"replace placeholder body with eric.fbx or optimized GLB inside update/game.zip"
};
