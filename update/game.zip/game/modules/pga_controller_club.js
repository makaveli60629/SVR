import * as THREE from "three";
import { makeCanvasLabel, roundRect } from "./utils.js";

const DRIVE_CENTER = new THREE.Vector3(0, 0, -118.0);
const CHIP_CENTER = new THREE.Vector3(18.5, 0, -118.0);
const DRIVE_TEE_LOCAL = new THREE.Vector3(0, 0.065, 14.2);
const BALL_RADIUS = 0.085;

function clamp(v, lo, hi){ return Math.max(lo, Math.min(hi, v)); }
function fmt(n){ return Number.isFinite(n) ? String(Math.round(n)) : "0"; }

function makeTextBoard({ title = "PGA", lines = [], w = 1024, h = 512, accent = "#86ffb8" } = {}){
  const { texture, canvas, ctx } = makeCanvasLabel({ width: w, height: h, draw(c, cw, ch){ c.clearRect(0,0,cw,ch); } });
  function draw(nextTitle = title, nextLines = lines){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const g = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    g.addColorStop(0, "rgba(4,18,12,0.94)");
    g.addColorStop(1, "rgba(0,0,0,0.90)");
    ctx.fillStyle = g;
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 38);
    ctx.fill();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 7;
    roundRect(ctx, 22, 22, canvas.width - 44, canvas.height - 44, 34);
    ctx.stroke();
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    ctx.font = "900 58px system-ui, Arial";
    ctx.fillText(nextTitle, canvas.width / 2, 48);
    ctx.textAlign = "left";
    ctx.font = "700 34px system-ui, Arial";
    ctx.fillStyle = "#eafff4";
    nextLines.slice(0, 8).forEach((line, i)=> ctx.fillText(line, 62, 138 + i * 43));
    texture.needsUpdate = true;
  }
  draw(title, lines);
  return { texture, draw };
}

function makeClub(){
  const club = new THREE.Group();
  club.name = "PGA_CONTROLLER_CLUB";
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.04, 0.22, 16), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.72, metalness: 0.12 }));
  grip.position.set(0, -0.10, -0.01);
  club.add(grip);
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.96, 14), new THREE.MeshStandardMaterial({ color: 0xd6e0e5, roughness: 0.27, metalness: 0.78 }));
  shaft.position.set(0, -0.64, -0.055);
  shaft.rotation.x = 0.12;
  club.add(shaft);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.09, 0.14), new THREE.MeshStandardMaterial({ color: 0xbec9d4, roughness: 0.30, metalness: 0.72, emissive: 0x1a2530, emissiveIntensity: 0.10 }));
  head.position.set(0, -1.13, -0.12);
  head.rotation.z = 0.08;
  head.userData.isClubHead = true;
  club.add(head);
  const glow = new THREE.PointLight(0x86ffb8, 0.0, 2.4, 2.0);
  glow.position.copy(head.position);
  club.add(glow);
  club.userData.head = head;
  club.userData.glow = glow;
  club.visible = false;
  return club;
}

function addRoomShell(root, { title="ROOM", width=14, depth=28, accent=0x86ffb8, wallColor=0x07161a } = {}){
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(width, depth), new THREE.MeshStandardMaterial({ color: 0x10231a, roughness: 0.92, metalness: 0.02, emissive: 0x03110b, emissiveIntensity: 0.08 }));
  floor.rotation.x = -Math.PI/2;
  floor.position.set(0, 0.003, 0);
  root.add(floor);
  const wallMat = new THREE.MeshStandardMaterial({ color: wallColor, roughness: 0.78, metalness: 0.06, emissive: wallColor, emissiveIntensity: 0.18 });
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(width, 4.4, 0.18), wallMat);
  backWall.position.set(0, 2.2, -depth/2);
  root.add(backWall);
  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.18, 4.4, depth), wallMat);
  leftWall.position.set(-width/2, 2.2, 0);
  root.add(leftWall);
  const rightWall = leftWall.clone(); rightWall.position.x = width/2; root.add(rightWall);
  const glass = new THREE.Mesh(new THREE.PlaneGeometry(width*0.74, 3.5), new THREE.MeshPhysicalMaterial({ color: accent, transparent: true, opacity: 0.14, roughness: 0.18, metalness: 0.08, transmission: 0.24, side: THREE.DoubleSide }));
  glass.position.set(0, 1.9, depth/2 - 0.12);
  glass.rotation.y = Math.PI;
  root.add(glass);
  const boardTex = makeTextBoard({ title, lines:["Private PGA module", "Lobby contains storefront only", "Use watch or bottom buttons", "Drive and Chip/Putt are separate rooms"], accent:'#86ffb8' });
  const board = new THREE.Mesh(new THREE.PlaneGeometry(4.8, 2.25), new THREE.MeshBasicMaterial({ map: boardTex.texture, transparent:true, side:THREE.DoubleSide, depthWrite:false }));
  board.position.set(-width/2 + 2.65, 2.35, depth/2 - 0.22);
  board.rotation.y = 0.18;
  root.add(board);
  return { floor, board, boardTex };
}

function addDriveRoom(root){
  const shell = addRoomShell(root, { title:'PGA DRIVE RANGE', width:16, depth:36, accent:0x86ffb8, wallColor:0x071820 });
  const turfMat = new THREE.MeshStandardMaterial({ color: 0x184b2a, roughness: 0.9, metalness: 0.02, emissive: 0x05200f, emissiveIntensity: 0.05 });
  const fairwayMat = new THREE.MeshStandardMaterial({ color: 0x237840, roughness:0.93, metalness:0.01, emissive:0x063817, emissiveIntensity:0.07 });
  const mat = new THREE.Mesh(new THREE.PlaneGeometry(13.2, 31.0), turfMat);
  mat.rotation.x = -Math.PI/2; mat.position.set(0,0.014,-1.0); root.add(mat);
  const lane = new THREE.Mesh(new THREE.PlaneGeometry(4.8, 27.5), fairwayMat);
  lane.rotation.x = -Math.PI/2; lane.position.set(0,0.022,-2.1); root.add(lane);
  const teeMat = new THREE.Mesh(new THREE.BoxGeometry(3.2,0.055,2.1), new THREE.MeshStandardMaterial({ color:0x0b2616, roughness:0.84, metalness:0.04, emissive:0x05180f, emissiveIntensity:0.12 }));
  teeMat.position.set(0,0.040,14.2); root.add(teeMat);
  const railMat = new THREE.MeshStandardMaterial({ color:0x78ffc4, roughness:0.4, metalness:0.15, emissive:0x0b5c36, emissiveIntensity:0.42 });
  [-2.55, 2.55].forEach((x)=>{ const rail=new THREE.Mesh(new THREE.BoxGeometry(0.06,0.045,27.0), railMat); rail.position.set(x,0.065,-1.7); root.add(rail); });
  const lineMat = new THREE.MeshBasicMaterial({ color:0xb6ffd0, transparent:true, opacity:0.42, depthWrite:false });
  [5,10,15,20,25].forEach((dist,i)=>{ const ring=new THREE.Mesh(new THREE.RingGeometry(0.78+i*0.18,0.82+i*0.18,96), lineMat.clone()); ring.rotation.x=-Math.PI/2; ring.position.set(0,0.038,14.2-dist); root.add(ring); });
  const netMat = new THREE.MeshBasicMaterial({ color:0x89ffd5, transparent:true, opacity:0.16, wireframe:true, side:THREE.DoubleSide });
  const net = new THREE.Mesh(new THREE.PlaneGeometry(11.5,4.0,8,4), netMat); net.position.set(0,2.35,-17.7); root.add(net);
  const flagPole = new THREE.Mesh(new THREE.CylinderGeometry(0.025,0.025,2.25,12), new THREE.MeshStandardMaterial({ color:0xf2f5ff, roughness:0.45, metalness:0.2 })); flagPole.position.set(0,1.13,-12.6); root.add(flagPole);
  const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.85,0.48), new THREE.MeshBasicMaterial({ color:0xff365c, side:THREE.DoubleSide })); flag.position.set(0.42,1.96,-12.6); root.add(flag);
  const monitorTex = makeTextBoard({ title:'SHOT BOARD', lines:['Hold right trigger to grip club','Swing through the ball','Desktop: B demo swing','Carry: 0 yd','Total: 0 yd','Status: ready'], accent:'#86ffb8' });
  const monitor = new THREE.Mesh(new THREE.PlaneGeometry(4.4,2.15), new THREE.MeshBasicMaterial({ map:monitorTex.texture, transparent:true, side:THREE.DoubleSide, depthWrite:false }));
  monitor.position.set(4.55,1.65,12.05); monitor.rotation.y=-0.72; root.add(monitor);
  return { boardTex: monitorTex };
}

function addChipPuttRoom(root){
  addRoomShell(root, { title:'PGA CHIP + PUTT ROOM', width:14, depth:22, accent:0xc6ff86, wallColor:0x08180e });
  const greenMat = new THREE.MeshStandardMaterial({ color:0x1e7a35, roughness:0.96, metalness:0.0, emissive:0x05210d, emissiveIntensity:0.08 });
  const green = new THREE.Mesh(new THREE.CircleGeometry(4.8,96), greenMat); green.rotation.x=-Math.PI/2; green.scale.set(1.12,0.72,1); green.position.set(0,0.026,-1.3); root.add(green);
  const fringe = new THREE.Mesh(new THREE.CircleGeometry(5.55,96), new THREE.MeshBasicMaterial({ color:0x0f461e, transparent:true, opacity:0.62, depthWrite:false })); fringe.rotation.x=-Math.PI/2; fringe.scale.set(1.16,0.76,1); fringe.position.set(0,0.018,-1.3); root.add(fringe);
  const hole = new THREE.Mesh(new THREE.CylinderGeometry(0.15,0.15,0.024,36), new THREE.MeshStandardMaterial({ color:0x050505, roughness:0.65, metalness:0.0 })); hole.position.set(1.45,0.043,-3.8); root.add(hole);
  const cupRing = new THREE.Mesh(new THREE.RingGeometry(0.17,0.22,48), new THREE.MeshBasicMaterial({ color:0xf7fff1, side:THREE.DoubleSide })); cupRing.rotation.x=-Math.PI/2; cupRing.position.set(1.45,0.057,-3.8); root.add(cupRing);
  const flagPole = new THREE.Mesh(new THREE.CylinderGeometry(0.018,0.018,1.35,12), new THREE.MeshStandardMaterial({ color:0xf4fff1 })); flagPole.position.set(1.45,0.72,-3.8); root.add(flagPole);
  const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.55,0.32), new THREE.MeshBasicMaterial({ color:0xffe45a, side:THREE.DoubleSide })); flag.position.set(1.74,1.22,-3.8); root.add(flag);
  const bunker = new THREE.Mesh(new THREE.CircleGeometry(1.25,48), new THREE.MeshStandardMaterial({ color:0xcab37b, roughness:1.0, metalness:0.0 })); bunker.rotation.x=-Math.PI/2; bunker.scale.set(1.5,0.62,1); bunker.position.set(-3.0,0.030,-2.8); root.add(bunker);
  const chipMat = new THREE.Mesh(new THREE.BoxGeometry(2.3,0.05,1.45), new THREE.MeshStandardMaterial({ color:0x13301b, roughness:0.88, emissive:0x06170d, emissiveIntensity:0.10 })); chipMat.position.set(-2.5,0.05,6.8); root.add(chipMat);
  const puttMat = new THREE.Mesh(new THREE.BoxGeometry(2.6,0.04,1.10), new THREE.MeshStandardMaterial({ color:0x12381c, roughness:0.88, emissive:0x06170d, emissiveIntensity:0.10 })); puttMat.position.set(2.5,0.045,6.8); root.add(puttMat);
  const labelTex = makeTextBoard({ title:'SHORT GAME', lines:['Private chip + putt room','Chipping mat on left','Putting mat on right','Bunker and green targets','Future: club lofts + putt stroke'], accent:'#d7ff86' });
  const label = new THREE.Mesh(new THREE.PlaneGeometry(4.5,2.1), new THREE.MeshBasicMaterial({ map:labelTex.texture, transparent:true, side:THREE.DoubleSide, depthWrite:false }));
  label.position.set(3.65,1.75,8.1); label.rotation.y=-0.48; root.add(label);
  for (let i=0;i<9;i++){
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.055,16,12), new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.42 }));
    b.position.set(-3.05 + (i%3)*0.17, 0.108, 6.8 + Math.floor(i/3)*0.15);
    root.add(b);
  }
}

function getRightController(hands){ return hands?.getRightController?.() || null; }

export function createPgaControllerClub({ scene, camera, renderer, hands, sceneTargets = {}, log = console.log } = {}){
  const driveRoot = new THREE.Group();
  driveRoot.name = "PGA_DRIVE_PRIVATE_ROOM_PHASE32";
  driveRoot.position.copy(DRIVE_CENTER);
  scene.add(driveRoot);
  const driveUi = addDriveRoom(driveRoot);

  const chipRoot = new THREE.Group();
  chipRoot.name = "PGA_CHIP_PUTT_PRIVATE_ROOM_PHASE32";
  chipRoot.position.copy(CHIP_CENTER);
  scene.add(chipRoot);
  addChipPuttRoom(chipRoot);

  const ball = new THREE.Mesh(new THREE.SphereGeometry(BALL_RADIUS,24,18), new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.36, metalness:0.02, emissive:0x182820, emissiveIntensity:0.06 }));
  driveRoot.add(ball);
  const ballShadow = new THREE.Mesh(new THREE.CircleGeometry(BALL_RADIUS*1.28,24), new THREE.MeshBasicMaterial({ color:0x000000, transparent:true, opacity:0.26, depthWrite:false }));
  ballShadow.rotation.x=-Math.PI/2; driveRoot.add(ballShadow);
  const club = makeClub(); scene.add(club);

  const velocity = new THREE.Vector3();
  const lastBallXZ = new THREE.Vector3();
  const localBallStart = DRIVE_TEE_LOCAL.clone();
  const clubHead = new THREE.Vector3();
  const lastClubHead = new THREE.Vector3();
  const clubVelocity = new THREE.Vector3();
  const controllerPos = new THREE.Vector3();
  const controllerQuat = new THREE.Quaternion();
  let flying=false, rolling=false, totalDistance=0, carryDistance=0, lastImpactAt=0;

  function setBallLocal(v){ ball.position.copy(v); ballShadow.position.set(v.x,0.026,v.z); ballShadow.scale.setScalar(clamp(1.5-v.y*0.35,0.45,1.35)); }
  function updateBoard(status='ready'){
    const ydTotal=totalDistance*1.09361, ydCarry=carryDistance*1.09361, speed=velocity.length();
    driveUi.boardTex.draw('PGA DRIVE RANGE', ['Private high-swing room','Right trigger grips club','Swing through the ball','Desktop: B demo swing',`Carry: ${fmt(ydCarry)} yd`, `Total: ${fmt(ydTotal)} yd`, `Ball speed: ${fmt(speed*18)} mph`, `Status: ${status}`]);
  }
  function resetBall(){ flying=false; rolling=false; totalDistance=0; carryDistance=0; velocity.set(0,0,0); setBallLocal(localBallStart); lastBallXZ.set(localBallStart.x,0,localBallStart.z); updateBoard('ready'); }
  resetBall();
  function launchFromClub(power, dir){
    const p=clamp(power,3.0,22.0); const aim=dir.clone(); if(aim.lengthSq()<0.001) aim.set(0,0,-1); aim.y=0; aim.normalize();
    velocity.set(aim.x*p, clamp(p*0.32,1.5,7.2), aim.z*p);
    flying=true; rolling=false; totalDistance=0; carryDistance=0; lastBallXZ.set(ball.position.x,0,ball.position.z); lastImpactAt=performance.now();
    if(window.SVR_PLAY_SFX) window.SVR_PLAY_SFX('chip'); updateBoard('launched');
  }
  function demoShot(){ launchFromClub(15.0 + Math.random()*3.0, new THREE.Vector3((Math.random()-0.5)*0.18,0,-1)); }

  function update(dt){
    const rc=getRightController(hands);
    const gripping=!!(rc?.gamepad?.buttons?.[0]?.pressed || rc?.gamepad?.buttons?.[1]?.pressed);
    if (rc){
      rc.getWorldPosition(controllerPos); rc.getWorldQuaternion(controllerQuat);
      club.visible=gripping; club.position.copy(controllerPos); club.quaternion.copy(controllerQuat); club.rotateX(-0.38); club.updateMatrixWorld(true);
      club.userData.head.getWorldPosition(clubHead); clubVelocity.copy(clubHead).sub(lastClubHead).divideScalar(Math.max(dt,0.001)); lastClubHead.copy(clubHead);
      club.userData.glow.intensity=gripping?0.9:0.0;
      if(gripping && !flying && performance.now()-lastImpactAt>450){
        const ballWorld=ball.getWorldPosition(new THREE.Vector3());
        if(clubHead.distanceTo(ballWorld)<0.20 && clubVelocity.length()>1.2){ launchFromClub(clubVelocity.length()*2.5, clubVelocity); }
      }
    } else { club.visible=false; }
    if(flying || rolling){
      const prevXZ=lastBallXZ.clone();
      if(flying){ velocity.y -= 9.2*dt; ball.position.addScaledVector(velocity,dt); if(ball.position.y<=BALL_RADIUS+0.045){ ball.position.y=BALL_RADIUS+0.045; carryDistance=Math.max(carryDistance, Math.hypot(ball.position.x-localBallStart.x, ball.position.z-localBallStart.z)); velocity.y=0; velocity.x*=0.74; velocity.z*=0.74; flying=false; rolling=true; updateBoard('rolling'); } }
      else { ball.position.addScaledVector(velocity,dt); velocity.multiplyScalar(Math.pow(0.22,dt)); if(velocity.length()<0.12){ rolling=false; updateBoard('stopped'); } }
      const curXZ=new THREE.Vector3(ball.position.x,0,ball.position.z); totalDistance += curXZ.distanceTo(prevXZ); lastBallXZ.copy(curXZ); ballShadow.position.set(ball.position.x,0.026,ball.position.z); ballShadow.scale.setScalar(clamp(1.5-ball.position.y*0.35,0.45,1.35));
      if(ball.position.z < -17.0 || Math.abs(ball.position.x)>7.0) { rolling=false; flying=false; updateBoard('net'); }
    }
  }

  sceneTargets.pgaDrive = { pos: DRIVE_CENTER.clone().add(new THREE.Vector3(0,0,16.0)), look: DRIVE_CENTER.clone().add(new THREE.Vector3(0,1.45,2.0)) };
  sceneTargets.pgaChipPutt = { pos: CHIP_CENTER.clone().add(new THREE.Vector3(0,0,9.5)), look: CHIP_CENTER.clone().add(new THREE.Vector3(0,1.35,-2.4)) };
  scene.userData._pgaClub = { driveRoot, chipRoot, update, demoShot, resetBall };
  log?.('[pga_controller_club] Phase 32 split Drive and Chip/Putt private rooms loaded');
  return { root:driveRoot, driveRoot, chipRoot, update, demoShot, resetBall, targets:{ pgaDrive:sceneTargets.pgaDrive, pgaChipPutt:sceneTargets.pgaChipPutt } };
}
