import * as THREE from "three";
import { makeCanvasLabel, roundRect } from "./utils.js";

const RANGE_CENTER = new THREE.Vector3(0, 0, -92.0);
const TEE_LOCAL = new THREE.Vector3(0, 0.058, 4.35);
const BALL_RADIUS = 0.085;

function clamp(v, lo, hi){ return Math.max(lo, Math.min(hi, v)); }
function horizontal(v){ return new THREE.Vector3(v.x, 0, v.z); }
function fmt(n){ return Number.isFinite(n) ? String(Math.round(n)) : "0"; }

function makeTextBoard({ title = "PGA", lines = [], w = 1024, h = 512, accent = "#86ffb8" } = {}){
  const { texture, canvas, ctx } = makeCanvasLabel({
    width: w,
    height: h,
    draw(c, cw, ch){
      c.clearRect(0, 0, cw, ch);
    }
  });
  function draw(nextTitle = title, nextLines = lines){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const g = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    g.addColorStop(0, "rgba(4,18,12,0.92)");
    g.addColorStop(1, "rgba(0,0,0,0.88)");
    ctx.fillStyle = g;
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 38);
    ctx.fill();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 7;
    roundRect(ctx, 22, 22, canvas.width - 44, canvas.height - 44, 34);
    ctx.stroke();
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    ctx.font = "900 64px system-ui, Arial";
    ctx.fillText(nextTitle, canvas.width / 2, 54);
    ctx.textAlign = "left";
    ctx.font = "700 38px system-ui, Arial";
    ctx.fillStyle = "#eafff4";
    nextLines.slice(0, 7).forEach((line, i)=> ctx.fillText(line, 68, 154 + i * 48));
    texture.needsUpdate = true;
  }
  draw(title, lines);
  return { texture, draw };
}

function makeClub(){
  const club = new THREE.Group();
  club.name = "PGA_CONTROLLER_CLUB";
  const grip = new THREE.Mesh(
    new THREE.CylinderGeometry(0.032, 0.04, 0.22, 16),
    new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.72, metalness: 0.12 })
  );
  grip.position.set(0, -0.10, -0.01);
  club.add(grip);

  const shaft = new THREE.Mesh(
    new THREE.CylinderGeometry(0.012, 0.012, 0.86, 14),
    new THREE.MeshStandardMaterial({ color: 0xd6e0e5, roughness: 0.27, metalness: 0.78 })
  );
  shaft.position.set(0, -0.58, -0.055);
  shaft.rotation.x = 0.12;
  club.add(shaft);

  const head = new THREE.Mesh(
    new THREE.BoxGeometry(0.34, 0.09, 0.13),
    new THREE.MeshStandardMaterial({ color: 0xbec9d4, roughness: 0.30, metalness: 0.72, emissive: 0x1a2530, emissiveIntensity: 0.10 })
  );
  head.position.set(0, -1.02, -0.12);
  head.rotation.z = 0.08;
  head.userData.isClubHead = true;
  club.add(head);

  const glow = new THREE.PointLight(0x86ffb8, 0.0, 2.4, 2.0);
  glow.position.copy(head.position);
  club.add(glow);
  club.userData.head = head;
  club.userData.glow = glow;
  club.visible = false;
  return club;
}

export function createPgaControllerClub({ scene, camera, renderer, hands, sceneTargets = {}, log = console.log } = {}){
  const root = new THREE.Group();
  root.name = "PGA_PRIVATE_ROOM_CONTROLLER_RANGE_PHASE31";
  root.position.copy(RANGE_CENTER);
  scene.add(root);

  const turfMat = new THREE.MeshStandardMaterial({ color: 0x184b2a, roughness: 0.88, metalness: 0.02, emissive: 0x05200f, emissiveIntensity: 0.05 });
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x09161c, roughness: 0.78, metalness: 0.06, emissive: 0x061c16, emissiveIntensity: 0.18 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0x86ffd0, transparent: true, opacity: 0.16, roughness: 0.18, metalness: 0.08, transmission: 0.22, side: THREE.DoubleSide });

  const privateFloor = new THREE.Mesh(
    new THREE.PlaneGeometry(12.5, 22.0),
    new THREE.MeshStandardMaterial({ color: 0x0b2118, roughness: 0.9, metalness: 0.02, emissive: 0x03110b, emissiveIntensity: 0.09 })
  );
  privateFloor.rotation.x = -Math.PI / 2;
  privateFloor.position.set(0, 0.004, -1.6);
  privateFloor.name = "PGA_PRIVATE_ROOM_FLOOR";
  root.add(privateFloor);

  const backWall = new THREE.Mesh(new THREE.BoxGeometry(12.7, 3.6, 0.18), wallMat);
  backWall.position.set(0, 1.8, -11.2);
  backWall.name = "PGA_PRIVATE_ROOM_BACK_WALL";
  root.add(backWall);
  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.18, 3.6, 22.0), wallMat);
  leftWall.position.set(-6.35, 1.8, -1.6);
  leftWall.name = "PGA_PRIVATE_ROOM_LEFT_WALL";
  root.add(leftWall);
  const rightWall = leftWall.clone();
  rightWall.position.x = 6.35;
  rightWall.name = "PGA_PRIVATE_ROOM_RIGHT_WALL";
  root.add(rightWall);
  const entryGlass = new THREE.Mesh(new THREE.PlaneGeometry(8.8, 3.2), glassMat);
  entryGlass.position.set(0, 1.8, 8.95);
  entryGlass.rotation.y = Math.PI;
  entryGlass.name = "PGA_PRIVATE_ROOM_ENTRY_GLASS";
  root.add(entryGlass);
  const fairwayMat = new THREE.MeshStandardMaterial({ color: 0x22753e, roughness: 0.90, metalness: 0.01, emissive: 0x063817, emissiveIntensity: 0.07 });
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xb6ffd0, transparent: true, opacity: 0.42, depthWrite: false });
  const mat = new THREE.Mesh(new THREE.PlaneGeometry(9.6, 16.5), turfMat);
  mat.rotation.x = -Math.PI / 2;
  mat.position.set(0, 0.012, -1.6);
  root.add(mat);

  const fairway = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 13.2), fairwayMat);
  fairway.rotation.x = -Math.PI / 2;
  fairway.position.set(0, 0.018, -2.0);
  root.add(fairway);

  const teeMat = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.045, 1.65), new THREE.MeshStandardMaterial({ color: 0x0c2418, roughness: 0.82, metalness: 0.04, emissive: 0x05180f, emissiveIntensity: 0.12 }));
  teeMat.position.set(0, 0.035, 4.3);
  root.add(teeMat);

  const railMat = new THREE.MeshStandardMaterial({ color: 0x78ffc4, roughness: 0.4, metalness: 0.15, emissive: 0x0b5c36, emissiveIntensity: 0.4 });
  [-1.9, 1.9].forEach((x)=>{
    const rail = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.035, 13.0), railMat);
    rail.position.set(x, 0.06, -1.9);
    root.add(rail);
  });

  [2.5, 5.0, 7.5, 10.0].forEach((dist, i)=>{
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.56 + i * 0.18, 0.59 + i * 0.18, 80), lineMat.clone());
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(0, 0.032 + i * 0.002, 4.35 - dist);
    root.add(ring);
  });

  const flagPole = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.85, 12), new THREE.MeshStandardMaterial({ color: 0xf2f5ff, roughness: 0.45, metalness: 0.2 }));
  flagPole.position.set(0, 0.95, -7.2);
  root.add(flagPole);
  const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.75, 0.42), new THREE.MeshBasicMaterial({ color: 0xff365c, side: THREE.DoubleSide }));
  flag.position.set(0.37, 1.62, -7.2);
  root.add(flag);

  const boardTex = makeTextBoard({
    title: "PRIVATE PGA DRIVE ROOM",
    lines: [
      "Private golf module • Phase 31",
      "Hold right trigger to grip club",
      "Swing through the ball",
      "Desktop test: press B",
      "Carry: 0 yd   Roll: 0 yd",
      "Status: ready"
    ]
  });
  const board = new THREE.Mesh(new THREE.PlaneGeometry(3.9, 1.95), new THREE.MeshBasicMaterial({ map: boardTex.texture, transparent: true, depthWrite: false, side: THREE.DoubleSide }));
  board.position.set(2.95, 1.45, 2.35);
  board.rotation.y = -0.58;
  root.add(board);

  const ball = new THREE.Mesh(
    new THREE.SphereGeometry(BALL_RADIUS, 24, 18),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.36, metalness: 0.02, emissive: 0x182820, emissiveIntensity: 0.06 })
  );
  root.add(ball);

  const ballShadow = new THREE.Mesh(new THREE.CircleGeometry(BALL_RADIUS * 1.28, 24), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.26, depthWrite: false }));
  ballShadow.rotation.x = -Math.PI / 2;
  root.add(ballShadow);

  const club = makeClub();
  scene.add(club);

  const localBallStart = TEE_LOCAL.clone();
  const ballWorld = new THREE.Vector3();
  const ballLocal = new THREE.Vector3();
  const velocity = new THREE.Vector3();
  const clubHead = new THREE.Vector3();
  const lastClubHead = new THREE.Vector3();
  const clubVelocity = new THREE.Vector3();
  const controllerPos = new THREE.Vector3();
  const controllerQuat = new THREE.Quaternion();
  const lastImpactAt = { value: 0 };
  let flying = false;
  let rolling = false;
  let totalDistance = 0;
  let carryDistance = 0;
  let lastBallXZ = new THREE.Vector3();
  let lastBoardAt = 0;

  function setBallLocal(v){
    ball.position.copy(v);
    ballShadow.position.set(v.x, 0.024, v.z);
    ballShadow.scale.setScalar(clamp(1.5 - v.y * 0.35, 0.45, 1.35));
  }
  setBallLocal(localBallStart);
  lastBallXZ.set(localBallStart.x, 0, localBallStart.z);

  function updateBoard(status = "ready"){
    const ydTotal = totalDistance * 1.09361;
    const ydCarry = carryDistance * 1.09361;
    const speed = velocity.length();
    boardTex.draw("PRIVATE PGA DRIVE ROOM", [
      "Private golf module • Phase 31",
      "Right trigger grips the club",
      "Swing through the ball to launch",
      `Carry: ${fmt(ydCarry)} yd   Total: ${fmt(ydTotal)} yd`,
      `Ball speed: ${fmt(speed * 18)} mph`,
      `Status: ${status}`
    ]);
  }
  updateBoard("ready");

  function resetBall(){
    flying = false;
    rolling = false;
    totalDistance = 0;
    carryDistance = 0;
    velocity.set(0,0,0);
    setBallLocal(localBallStart);
    lastBallXZ.set(localBallStart.x, 0, localBallStart.z);
    updateBoard("ready");
  }

  function launchFromClub(power, dir){
    const p = clamp(power, 2.6, 18.0);
    const aim = dir.clone();
    if (aim.lengthSq() < 0.001) aim.set(0, 0, -1);
    aim.y = 0;
    aim.normalize();
    velocity.set(aim.x * p, clamp(p * 0.28, 1.3, 5.6), aim.z * p);
    flying = true;
    rolling = false;
    totalDistance = 0;
    carryDistance = 0;
    lastBallXZ.set(ball.position.x, 0, ball.position.z);
    lastImpactAt.value = performance.now();
    if (window.SVR_PLAY_SFX) window.SVR_PLAY_SFX("chip");
    updateBoard("launched");
  }

  function demoShot(){
    const spread = (Math.random() - 0.5) * 0.22;
    launchFromClub(8.8 + Math.random() * 3.5, new THREE.Vector3(spread, 0, -1));
  }

  function triggerValue(proxy){
    return proxy?.userData?.trigger || proxy?.userData?.gamepad?.buttons?.[0]?.value || 0;
  }

  function getViewerWorldPosition(){
    const p = new THREE.Vector3();
    try {
      if (renderer?.xr?.isPresenting) renderer.xr.getCamera(camera).getWorldPosition(p);
      else p.copy(camera.position);
    } catch(_err) {
      p.copy(camera.position);
    }
    return p;
  }

  function isInsidePrivateRange(){
    const p = getViewerWorldPosition();
    return Math.hypot(p.x - root.position.x, p.z - root.position.z) < 18.0;
  }

  function updateClubFromController(dt){
    const inRoom = isInsidePrivateRange();
    if (!inRoom){
      club.visible = false;
      return { grip: false, active: false, trigger: 0, inRoom: false };
    }
    const right = hands?.getRightController?.() || hands?.getRight?.() || null;
    const controller = right?.userData?.controller || right;
    const active = !!right;
    if (!active){
      club.visible = true;
      club.position.copy(root.localToWorld(new THREE.Vector3(0.32, 1.10, 4.44)));
      club.rotation.set(-0.15, 0.18, 0.12);
      club.userData.glow.intensity = 0.25;
      return { grip: false, active: false, trigger: 0 };
    }
    if (controller?.updateWorldMatrix) controller.updateWorldMatrix(true, false);
    if (right.getWorldPosition) right.getWorldPosition(controllerPos);
    else controller?.getWorldPosition?.(controllerPos);
    if (right.getWorldQuaternion) right.getWorldQuaternion(controllerQuat);
    else controller?.getWorldQuaternion?.(controllerQuat);
    club.visible = true;
    club.position.copy(controllerPos);
    club.quaternion.copy(controllerQuat);
    const trigger = triggerValue(right);
    club.userData.glow.intensity = trigger > 0.18 ? 1.4 : 0.25;
    return { grip: trigger > 0.18, active: true, trigger };
  }

  function updatePhysics(dt){
    if (!flying && !rolling) return;
    const prev = ball.position.clone();
    if (flying){
      velocity.y -= 9.8 * dt;
      ball.position.addScaledVector(velocity, dt);
      const d = horizontal(ball.position.clone().sub(lastBallXZ)).length();
      carryDistance += d;
      totalDistance += d;
      lastBallXZ.set(ball.position.x, 0, ball.position.z);
      if (ball.position.y <= BALL_RADIUS){
        ball.position.y = BALL_RADIUS;
        velocity.y = Math.abs(velocity.y) * 0.22;
        velocity.x *= 0.72;
        velocity.z *= 0.72;
        flying = velocity.y > 0.42 && horizontal(velocity).length() > 1.0;
        rolling = !flying;
      }
    } else if (rolling){
      const move = horizontal(velocity).multiplyScalar(dt);
      ball.position.add(move);
      totalDistance += move.length();
      velocity.x *= Math.pow(0.25, dt);
      velocity.z *= Math.pow(0.25, dt);
      velocity.y = 0;
      if (horizontal(velocity).length() < 0.08) {
        rolling = false;
        updateBoard("settled");
      }
    }
    if (Math.abs(ball.position.x) > 4.4 || ball.position.z < -8.2 || ball.position.z > 5.4){
      velocity.multiplyScalar(0.2);
      ball.position.x = clamp(ball.position.x, -4.4, 4.4);
      ball.position.z = clamp(ball.position.z, -8.2, 5.4);
      rolling = true;
      flying = false;
    }
    ball.rotation.x += (ball.position.z - prev.z) * 8.0;
    ball.rotation.z -= (ball.position.x - prev.x) * 8.0;
    ballShadow.position.set(ball.position.x, 0.024, ball.position.z);
    ballShadow.scale.setScalar(clamp(1.5 - ball.position.y * 0.35, 0.45, 1.35));
    const now = performance.now();
    if (now - lastBoardAt > 250){
      updateBoard(flying ? "airborne" : rolling ? "rolling" : "ready");
      lastBoardAt = now;
    }
  }

  function update(dt = 0.016){
    const clubState = updateClubFromController(dt);
    lastClubHead.copy(clubHead);
    club.userData.head.getWorldPosition(clubHead);
    if (lastClubHead.lengthSq() > 0.0001) clubVelocity.copy(clubHead).sub(lastClubHead).multiplyScalar(1 / Math.max(dt, 0.001));
    else clubVelocity.set(0,0,0);
    ball.getWorldPosition(ballWorld);
    const nearBall = clubHead.distanceTo(ballWorld) < 0.30;
    const speed = clubVelocity.length();
    const canImpact = !flying && !rolling && clubState.grip && nearBall && speed > 1.15 && performance.now() - lastImpactAt.value > 650;
    if (canImpact){
      const dir = root.worldToLocal(clubHead.clone().add(clubVelocity.clone().normalize())).sub(root.worldToLocal(clubHead.clone()));
      if (dir.z > -0.12) dir.z = -1;
      launchFromClub(speed * 1.85, dir);
    }
    updatePhysics(dt);
  }

  root.userData.resetBall = resetBall;
  root.userData.demoShot = demoShot;
  scene.userData._pgaClub = { root, update, demoShot, resetBall };

  sceneTargets.pgaDrive = {
    pos: root.position.clone().add(new THREE.Vector3(0, 0, 6.0)),
    look: root.position.clone().add(new THREE.Vector3(0, 1.22, 0.35))
  };
  sceneTargets.pgaChipPutt = {
    pos: root.position.clone().add(new THREE.Vector3(3.6, 0, 3.2)),
    look: root.position.clone().add(new THREE.Vector3(0, 1.05, -3.5))
  };

  log?.("[pga_controller_club] Phase 31 private room range loaded");
  return { root, update, demoShot, resetBall, targets: { pgaDrive: sceneTargets.pgaDrive, pgaChipPutt: sceneTargets.pgaChipPutt } };
}
