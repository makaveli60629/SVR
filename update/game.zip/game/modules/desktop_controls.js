import * as THREE from "three";
import { CONFIG } from "./config.js";
import { sanitizeFloorTarget } from "./utils.js";

export function createDesktopControls({ camera, domElement }) {
  let roomClamp = CONFIG.ROOM_RADIUS - 2;
  const state = {
    yaw: CONFIG.SPAWN.yaw,
    pitch: 0,
    keys: new Set(),
    locked: false,
  };

  domElement.addEventListener("click", () => {
    if (!state.locked) domElement.requestPointerLock?.();
  });

  document.addEventListener("pointerlockchange", () => {
    state.locked = document.pointerLockElement === domElement;
  });

  document.addEventListener("mousemove", (e) => {
    if (!state.locked) return;
    state.yaw -= e.movementX * CONFIG.DESKTOP_SENSITIVITY;
    state.pitch -= e.movementY * CONFIG.DESKTOP_SENSITIVITY;
    state.pitch = Math.max(-1.2, Math.min(1.2, state.pitch));
  });

  document.addEventListener("keydown", (e) => {
    state.keys.add(e.code);
    if (e.code === "Escape") document.exitPointerLock?.();
  });
  document.addEventListener("keyup", (e) => state.keys.delete(e.code));

  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();
  const up = new THREE.Vector3(0, 1, 0);

  function applyRotation() {
    camera.rotation.order = "YXZ";
    camera.rotation.y = state.yaw;
    camera.rotation.x = state.pitch;
  }

  function update(dt) {
    applyRotation();

    forward.set(0, 0, -1).applyAxisAngle(up, state.yaw).normalize();
    right.copy(forward).cross(up).normalize();

    let moveF = 0;
    let moveR = 0;
    let moveY = 0;
    if (state.keys.has("KeyW")) moveF += 1;
    if (state.keys.has("KeyS")) moveF -= 1;
    if (state.keys.has("KeyD")) moveR += 1;
    if (state.keys.has("KeyA")) moveR -= 1;
    if (state.keys.has("ShiftLeft") || state.keys.has("ShiftRight")) moveY -= 1;
    if (state.keys.has("ControlLeft") || state.keys.has("ControlRight")) moveY += 1;

    camera.position.addScaledVector(forward, moveF * CONFIG.DESKTOP_SPEED * dt);
    camera.position.addScaledVector(right, moveR * CONFIG.DESKTOP_SPEED * dt);
    camera.position.y = Math.max(0.7, camera.position.y + moveY * CONFIG.DESKTOP_VERTICAL_SPEED * dt);
    const safe = sanitizeFloorTarget(camera.position, {
      roomRadius: roomClamp,
      tableCenter: new THREE.Vector3(CONFIG.TABLE_CENTER.x, 0, CONFIG.TABLE_CENTER.z),
      tableRadiusX: CONFIG.TABLE_RADIUS_X,
      tableRadiusZ: CONFIG.TABLE_RADIUS_Z,
      tableMargin: CONFIG.TABLE_SAFE_MARGIN,
    });
    camera.position.x = safe.x;
    camera.position.z = safe.z;
  }

  function setPose(position, yaw = state.yaw, pitch = state.pitch) {
    camera.position.copy(position);
    state.yaw = yaw;
    state.pitch = pitch;
    applyRotation();
  }

  function getYaw() {
    return state.yaw;
  }

  function addYaw(delta) {
    state.yaw += delta;
    applyRotation();
  }

  function setRoomClamp(next) {
    roomClamp = next;
  }

  return { update, setPose, getYaw, addYaw, setRoomClamp };
}
