import * as THREE from "three";
import { CONFIG } from "./config.js";

/**
 * Desktop controls:
 * - WASD move (works even without pointer lock)
 * - Mouse look only when pointer locked
 * - Space up / Shift down
 * - Ctrl boost
 */
export function createDesktopControls({ rig, domElement }) {
  const state = { yaw: 0, pitch: 0, keys: new Set(), locked: false };

  domElement.addEventListener("click", () => {
    // Click enables mouse-look (optional)
    domElement.requestPointerLock?.();
  });
  document.addEventListener("pointerlockchange", () => {
    state.locked = document.pointerLockElement === domElement;
  });

  document.addEventListener("mousemove", (e) => {
    if (!state.locked) return;
    const sens = 0.0023;
    state.yaw -= e.movementX * sens;
    state.pitch -= e.movementY * sens;
    state.pitch = Math.max(-1.25, Math.min(1.25, state.pitch));
  });

  document.addEventListener("keydown", (e) => {
    state.keys.add(e.code);
    if (e.code === "Escape") document.exitPointerLock?.();
  });
  document.addEventListener("keyup", (e) => state.keys.delete(e.code));

  const fwd = new THREE.Vector3(), right = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);

  function update(dt) {
    fwd.set(0, 0, -1).applyAxisAngle(up, state.yaw).normalize();
    right.copy(fwd).cross(up).normalize();

    let mf = 0, mr = 0;
    if (state.keys.has("KeyW")) mf += 1;
    if (state.keys.has("KeyS")) mf -= 1;
    if (state.keys.has("KeyD")) mr += 1;
    if (state.keys.has("KeyA")) mr -= 1;

    const spd = CONFIG.DESKTOP_SPEED * (state.keys.has("ControlLeft") ? CONFIG.DESKTOP_BOOST : 1);
    rig.player.position.addScaledVector(fwd, mf * spd * dt);
    rig.player.position.addScaledVector(right, mr * spd * dt);
    rig.player.position.y = 0;

    rig.applyCamera({ yaw: state.yaw, pitch: state.pitch });
  }

  function setYawPitch(yaw, pitch) {
    state.yaw = yaw;
    state.pitch = pitch;
  }

  return { update, setYawPitch, getState: () => ({ ...state }) };
}
