
export function initTeleport(){
    console.log("Teleport system active (fist + thumbstick)");
}
