
export function initTeleport(){
 console.log("Teleport active: fist + thumbstick")
}
