import * as THREE from "three";
import { CONFIG } from "./config.js";
import { sanitizeFloorTarget } from "./utils.js";
import { getHandAimPoint, isPinching } from "./gesture_utils.js";

export function createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp }) {
  let enabled = false;
  let target = null;
  let hoveredDistance = 0;
  let lastTeleport = 0;

  const pointer = new THREE.Mesh(
    new THREE.CircleGeometry(0.34, 48),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.72, side: THREE.DoubleSide })
  );
  pointer.rotation.x = -Math.PI / 2;
  pointer.position.y = 0.02;
  pointer.visible = false;
  scene.add(pointer);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.36, 0.54, 64),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, emissive: 0x4a126e, emissiveIntensity: 1.3, transparent: true, opacity: 0.66, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.021;
  ring.visible = false;
  scene.add(ring);

  let arcInner = null;
  let arcOuter = null;
  const arcInnerMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.88, blending: THREE.AdditiveBlending, depthWrite: false });
  const arcOuterMat = new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.28, blending: THREE.AdditiveBlending, depthWrite: false });

  const raycaster = new THREE.Raycaster();
  const dir = new THREE.Vector3();
  const origin = new THREE.Vector3();
  const head = new THREE.Vector3();
  const tableCenter = new THREE.Vector3(CONFIG.TABLE_CENTER.x, 0, CONFIG.TABLE_CENTER.z);

  function setControllerRayVisible(controller, visible) {
    const rayLine = controller?.getObjectByName("ray");
    if (rayLine) rayLine.visible = !!visible;
  }

  function setEnabled(next, controller = null) {
    enabled = !!next;
    if (!enabled) clearVisuals(controller);
  }

  function toggle(controller = null) {
    setEnabled(!enabled, controller);
    return enabled;
  }

  function isEnabled() {
    return enabled;
  }

  function clearVisuals(controller = null) {
    pointer.visible = false;
    ring.visible = false;
    if (arcInner) arcInner.visible = false;
    if (arcOuter) arcOuter.visible = false;
    target = null;
    hoveredDistance = 0;
    setControllerRayVisible(controller, false);
  }

  function showArc(from, to) {
    const distance = from.distanceTo(to);
    const mid = from.clone().lerp(to, 0.5);
    mid.y += 0.75 + distance * 0.06;
    const curve = new THREE.CatmullRomCurve3([from, mid, to.clone().setY(0.02)]);
    const innerGeo = new THREE.TubeGeometry(curve, 22, 0.019, 10, false);
    const outerGeo = new THREE.TubeGeometry(curve, 22, 0.042, 10, false);

    if (!arcInner) {
      arcOuter = new THREE.Mesh(outerGeo, arcOuterMat);
      arcInner = new THREE.Mesh(innerGeo, arcInnerMat);
      scene.add(arcOuter);
      scene.add(arcInner);
    } else {
      arcInner.geometry.dispose();
      arcOuter.geometry.dispose();
      arcInner.geometry = innerGeo;
      arcOuter.geometry = outerGeo;
    }
    arcInner.visible = true;
    arcOuter.visible = true;
  }

  function updateVisualTarget(point) {
    target = sanitizeFloorTarget(point, {
      roomRadius: roomClamp,
      tableCenter,
      tableRadiusX: CONFIG.TABLE_RADIUS_X,
      tableRadiusZ: CONFIG.TABLE_RADIUS_Z,
      tableMargin: CONFIG.TABLE_SAFE_MARGIN,
    });
    pointer.visible = true;
    ring.visible = true;
    pointer.position.set(target.x, 0.02, target.z);
    ring.position.set(target.x, 0.021, target.z);
    renderer.xr.getCamera(camera).getWorldPosition(head);
    hoveredDistance = Math.hypot(target.x - head.x, target.z - head.z);
  }

  function computeControllerTarget(controller) {
    controller.getWorldPosition(origin);
    dir.set(0, 0, -1).applyQuaternion(controller.getWorldQuaternion(new THREE.Quaternion())).normalize();
    raycaster.set(origin, dir);
    const denom = dir.y;
    if (Math.abs(denom) < 0.0001) return null;
    const t = -origin.y / denom;
    if (!isFinite(t) || t < 0.15 || t > CONFIG.TELEPORT_RANGE) return null;
    return origin.clone().addScaledVector(dir, t);
  }

  function computeHandTarget(hand) {
    return getHandAimPoint(hand, CONFIG.TELEPORT_RANGE);
  }

  function doTeleport(controller = null) {
    const now = performance.now();
    if (!target || now - lastTeleport < CONFIG.TELEPORT_COOLDOWN_MS) return false;
    playerRig.teleportTo(target);
    lastTeleport = now;
    setEnabled(false, controller);
    return true;
  }

  function update({ xrPresenting, rightController, rightHand, statusCb = () => {} }) {
    if (!enabled) {
      clearVisuals(rightController);
      statusCb(xrPresenting ? "Teleport OFF • arm from watch" : "Teleport OFF • press T or watch TP");
      return;
    }

    let point = null;
    let arcStart = null;
    if (xrPresenting && rightController) {
      point = computeControllerTarget(rightController);
      arcStart = rightController.getWorldPosition(new THREE.Vector3());
    }

    if (!point && xrPresenting && rightHand) {
      point = computeHandTarget(rightHand);
      const tip = rightHand.joints?.["index-finger-tip"];
      if (tip) arcStart = tip.getWorldPosition(new THREE.Vector3());
    }

    if (!xrPresenting && !point) {
      renderer.xr.getCamera(camera).getWorldPosition(head);
      point = new THREE.Vector3(head.x, 0, head.z - 2.2);
      arcStart = head.clone();
    }

    if (!point) {
      clearVisuals(rightController);
      statusCb("Teleport ON • aim toward floor");
      return;
    }

    updateVisualTarget(point);
    if (arcStart) showArc(arcStart, target);

    let released = false;
    if (xrPresenting && rightController) {
      const selecting = !!rightController.userData.selecting;
      if (rightController.userData.wasSelecting && !selecting) released = true;
      rightController.userData.wasSelecting = selecting;
    } else if (xrPresenting && rightHand) {
      const pinching = isPinching(rightHand);
      if (rightHand.userData.wasPinching && !pinching) released = true;
      rightHand.userData.wasPinching = pinching;
    }

    if (released) doTeleport(rightController);

    statusCb(`Teleport ON • ${hoveredDistance.toFixed(1)}m • release trigger/pinch`);
  }

  return { update, toggle, isEnabled, setEnabled, clearVisuals };
}
