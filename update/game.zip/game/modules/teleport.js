import * as THREE from "three";
import { CONFIG } from "./config.js";
import { sanitizeFloorTarget } from "./utils.js";
import { getHandAimPoint, isPinching } from "./gesture_utils.js";

export function createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp }) {
  let enabled = false;
  let target = null;
  let hoveredDistance = 0;
  let lastTeleport = 0;

  const pointer = new THREE.Mesh(
    new THREE.CircleGeometry(0.28, 48),
    new THREE.MeshBasicMaterial({ color: 0x73ffd0, transparent: true, opacity: 0.56, side: THREE.DoubleSide, depthWrite: false })
  );
  pointer.rotation.x = -Math.PI / 2;
  pointer.position.y = 0.02;
  pointer.visible = false;
  scene.add(pointer);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.32, 0.48, 64),
    new THREE.MeshStandardMaterial({ color: 0x73ffd0, emissive: 0x174637, emissiveIntensity: 0.8, transparent: true, opacity: 0.72, side: THREE.DoubleSide, depthWrite: false })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.021;
  ring.visible = false;
  scene.add(ring);

  let arcInner = null;
  let arcOuter = null;
  const arcInnerMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.92, blending: THREE.AdditiveBlending, depthWrite: false });
  const arcOuterMat = new THREE.MeshBasicMaterial({ color: 0x73ffd0, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false });

  const raycaster = new THREE.Raycaster();
  const dir = new THREE.Vector3();
  const origin = new THREE.Vector3();
  const head = new THREE.Vector3();
  const quat = new THREE.Quaternion();
  const tableCenter = new THREE.Vector3(CONFIG.TABLE_CENTER.x, 0, CONFIG.TABLE_CENTER.z);

  function setEnabled(next) {
    enabled = !!next;
    if (!enabled) clearVisuals();
  }

  function toggle() {
    setEnabled(!enabled);
    return enabled;
  }

  function isEnabled() {
    return enabled;
  }

  function clearVisuals() {
    pointer.visible = false;
    ring.visible = false;
    if (arcInner) arcInner.visible = false;
    if (arcOuter) arcOuter.visible = false;
    target = null;
    hoveredDistance = 0;
  }

  function showArc(from, to) {
    const distance = from.distanceTo(to);
    const mid = from.clone().lerp(to, 0.5);
    mid.y += 0.7 + distance * 0.05;
    const curve = new THREE.CatmullRomCurve3([from, mid, to.clone().setY(0.02)]);
    const innerGeo = new THREE.TubeGeometry(curve, 22, 0.015, 10, false);
    const outerGeo = new THREE.TubeGeometry(curve, 22, 0.035, 10, false);

    if (!arcInner) {
      arcOuter = new THREE.Mesh(outerGeo, arcOuterMat);
      arcInner = new THREE.Mesh(innerGeo, arcInnerMat);
      scene.add(arcOuter);
      scene.add(arcInner);
    } else {
      arcInner.geometry.dispose();
      arcOuter.geometry.dispose();
      arcInner.geometry = innerGeo;
      arcOuter.geometry = outerGeo;
    }
    arcInner.visible = true;
    arcOuter.visible = true;
  }

  function updateVisualTarget(point) {
    target = sanitizeFloorTarget(point, {
      roomRadius: roomClamp,
      tableCenter,
      tableRadiusX: CONFIG.TABLE_RADIUS_X,
      tableRadiusZ: CONFIG.TABLE_RADIUS_Z,
      tableMargin: CONFIG.TABLE_SAFE_MARGIN,
    });
    pointer.visible = true;
    ring.visible = true;
    pointer.position.set(target.x, 0.02, target.z);
    ring.position.set(target.x, 0.021, target.z);
    renderer.xr.getCamera(camera).getWorldPosition(head);
    hoveredDistance = Math.hypot(target.x - head.x, target.z - head.z);
  }

  function computeControllerTarget(controller) {
    controller.getWorldPosition(origin);
    controller.getWorldQuaternion(quat);
    dir.set(0, -0.22, -1).applyQuaternion(quat).normalize();
    raycaster.set(origin, dir);
    const denom = dir.y;
    if (Math.abs(denom) < 0.0001) return null;
    const t = -origin.y / denom;
    if (!isFinite(t) || t < 0.15 || t > CONFIG.TELEPORT_RANGE) return null;
    return origin.clone().addScaledVector(dir, t);
  }

  function computeHandTarget(hand) {
    return getHandAimPoint(hand, CONFIG.TELEPORT_RANGE);
  }

  function doTeleport() {
    const now = performance.now();
    if (!target || now - lastTeleport < CONFIG.TELEPORT_COOLDOWN_MS) return false;
    playerRig.teleportTo(target);
    lastTeleport = now;
    setEnabled(false);
    return true;
  }

  function update({ xrPresenting, rightController, rightHand, statusCb = () => {} }) {
    if (!enabled) {
      clearVisuals();
      statusCb(xrPresenting ? "Teleport OFF • arm from watch TP" : "Teleport OFF • press T or watch TP");
      return;
    }

    let point = null;
    let arcStart = null;

    if (xrPresenting && rightController) {
      point = computeControllerTarget(rightController);
      arcStart = rightController.getWorldPosition(new THREE.Vector3());
      const rayLine = rightController.getObjectByName("ray");
      if (rayLine) rayLine.visible = false;
    }

    if (!point && xrPresenting && rightHand) {
      point = computeHandTarget(rightHand);
      const tip = rightHand.joints?.["index-finger-tip"];
      if (tip) arcStart = tip.getWorldPosition(new THREE.Vector3());
    }

    if (!xrPresenting && !point) {
      renderer.xr.getCamera(camera).getWorldPosition(head);
      point = new THREE.Vector3(head.x, 0, head.z - 2.2);
      arcStart = head.clone();
    }

    if (!point) {
      clearVisuals();
      statusCb("Teleport ON • aim toward floor");
      return;
    }

    updateVisualTarget(point);
    if (arcStart) showArc(arcStart, target);

    let released = false;
    if (xrPresenting && rightController) {
      const selecting = !!rightController.userData.selecting;
      if (rightController.userData.wasSelecting && !selecting) released = true;
      rightController.userData.wasSelecting = selecting;
    } else if (xrPresenting && rightHand) {
      const pinching = isPinching(rightHand);
      if (rightHand.userData.wasPinching && !pinching) released = true;
      rightHand.userData.wasPinching = pinching;
    }

    if (released) doTeleport();

    statusCb(`Teleport ON • ${hoveredDistance.toFixed(1)}m • release trigger`);
  }

  return { update, toggle, isEnabled, setEnabled, clearVisuals };
}
