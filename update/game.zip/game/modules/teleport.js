import * as THREE from "three";
import { CONFIG } from "./config.js";
import { isPinching, isFist, aimPoint } from "./gestures.js";

/**
 * Teleport Rig (Face-Fist Toggle):
 * - Bring a CLOSED FIST close to your FACE (headset) to toggle teleport ON/OFF.
 * - When ON: pointer + arc are active and GLOW PURPLE.
 * - Pinch + release teleports to the pointer target.
 * - When OFF: no glow and no pointer.
 *
 * Why this is reliable on Quest:
 * - Uses wrist distance to headset camera (no palm normals, no metacarpal joints).
 */

export function createTeleportRig({ scene, renderer, camera, roomClamp, log=console.log }) {
  let baseRefSpace=null;
  let playerX=0, playerZ=CONFIG.SPAWN_Z;

  function setPlayerXZ(x,z){
    playerX=x; playerZ=z;
    if (!baseRefSpace) return;
    const xform=new XRRigidTransform({ x:-playerX, y:0, z:-playerZ });
    renderer.xr.setReferenceSpace(baseRefSpace.getOffsetReferenceSpace(xform));
  }

  // Pointer
  const pointer=new THREE.Mesh(
    new THREE.PlaneGeometry(CONFIG.POINTER_SIZE, CONFIG.POINTER_SIZE),
    new THREE.MeshBasicMaterial({
      transparent:true, alphaTest:0.45, depthWrite:false,
      polygonOffset:true, polygonOffsetFactor:-2, side:THREE.DoubleSide
    })
  );
  pointer.rotation.x=-Math.PI/2;
  pointer.position.y=0.013;
  pointer.visible=false;
  scene.add(pointer);

  // Ring (glow controlled)
  const ringMat = new THREE.MeshStandardMaterial({
    color:0xb48cff, roughness:0.3, metalness:0.2,
    emissive:0x2a0d3a, emissiveIntensity:0.0, // OFF by default
    side:THREE.DoubleSide
  });
  const ring=new THREE.Mesh(
    new THREE.RingGeometry(CONFIG.RING_INNER, CONFIG.RING_OUTER, 72),
    ringMat
  );
  ring.rotation.x=-Math.PI/2;
  ring.position.y=0.012;
  ring.visible=false;
  scene.add(ring);

  // Arc (tube glow)
  let arcInner=null, arcOuter=null;
  const arcInnerMat = new THREE.MeshBasicMaterial({
    color:0xb48cff, transparent:true, opacity:CONFIG.ARC_INNER_OPACITY,
    depthWrite:false, blending:THREE.AdditiveBlending
  });
  const arcOuterMat = new THREE.MeshBasicMaterial({
    color:0xb48cff, transparent:true, opacity:CONFIG.ARC_OUTER_OPACITY,
    depthWrite:false, blending:THREE.AdditiveBlending
  });

  function showArc(from,to,dist){
    const mid=from.clone().lerp(to,0.5);
    mid.y += CONFIG.ARC_HEIGHT_BASE + dist*CONFIG.ARC_HEIGHT_PER_M;
    const curve=new THREE.CatmullRomCurve3([from, mid, to.clone().setY(0.02)]);
    const gi=new THREE.TubeGeometry(curve, CONFIG.ARC_SEGMENTS, CONFIG.ARC_INNER_RADIUS, 10, false);
    const go=new THREE.TubeGeometry(curve, CONFIG.ARC_SEGMENTS, CONFIG.ARC_OUTER_RADIUS, 10, false);

    if (!arcInner){
      arcOuter=new THREE.Mesh(go, arcOuterMat);
      arcInner=new THREE.Mesh(gi, arcInnerMat);
      scene.add(arcOuter); scene.add(arcInner);
    } else {
      arcInner.geometry.dispose(); arcOuter.geometry.dispose();
      arcInner.geometry=gi; arcOuter.geometry=go;
    }
    arcInner.visible=true; arcOuter.visible=true;
  }
  function hideArc(){ if (arcInner) arcInner.visible=false; if (arcOuter) arcOuter.visible=false; }

  function setGlow(on){
    ringMat.emissiveIntensity = on ? 1.15 : 0.0;
    if (arcInnerMat) arcInnerMat.opacity = on ? CONFIG.ARC_INNER_OPACITY : 0.0;
    if (arcOuterMat) arcOuterMat.opacity = on ? CONFIG.ARC_OUTER_OPACITY : 0.0;
  }

  // State
  let mode=false;        // teleport enabled?
  let active=null;       // active hand object
  let cooldownUntil=0;
  let lastTP=0;

  // Face toggle detection
  const camPos=new THREE.Vector3();
  const wristPos=new THREE.Vector3();
  const FACE_DIST = 0.28; // meters (tune)
  const toCam=new THREE.Vector3();

  function fistNearFace(hand){
    const wrist=hand?.joints?.["wrist"];
    if (!wrist) return false;
    const xrCam=renderer.xr.getCamera(camera);
    xrCam.getWorldPosition(camPos);
    wrist.getWorldPosition(wristPos);
    const d = wristPos.distanceTo(camPos);
    return d < FACE_DIST;
  }

  function clamp(p){
    const r=roomClamp;
    return new THREE.Vector3(
      THREE.MathUtils.clamp(p.x, -r, r),
      0,
      THREE.MathUtils.clamp(p.z, -r, r)
    );
  }

  function teleportByDelta(target){
    const xrCam=renderer.xr.getCamera(camera);
    const head=new THREE.Vector3();
    xrCam.getWorldPosition(head);
    const dx=target.x - head.x;
    const dz=target.z - head.z;
    setPlayerXZ(playerX + dx, playerZ + dz);
  }

  async function onSessionStart(){
    baseRefSpace = await renderer.xr.getSession().requestReferenceSpace("local-floor");
    setPlayerXZ(CONFIG.SPAWN_X, CONFIG.SPAWN_Z);
    mode=false; active=null;
    pointer.visible=false; ring.visible=false; hideArc();
    setGlow(false);
  }

  function setLogoTexture(tex){
    pointer.material.map=tex;
    pointer.material.needsUpdate=true;
  }

  function update({ leftHand, rightHand, statusCb=()=>{}, modeCb=()=>{} }){
    if (!leftHand?.joints || !rightHand?.joints) return;
    const now=performance.now();

    const fistL = isFist(leftHand);
    const fistR = isFist(rightHand);

    const nearL = fistL && fistNearFace(leftHand);
    const nearR = fistR && fistNearFace(rightHand);

    // Edge detect "near face fist" to toggle
    if (leftHand.userData._wasNear === undefined) leftHand.userData._wasNear=false;
    if (rightHand.userData._wasNear === undefined) rightHand.userData._wasNear=false;

    const risingL = nearL && !leftHand.userData._wasNear;
    const risingR = nearR && !rightHand.userData._wasNear;

    if ((risingL || risingR) && now > cooldownUntil){
      const selected = risingR ? rightHand : leftHand; // prefer right if both
      if (!mode){
        mode=true;
        active=selected;
      } else {
        // If already on: toggle off (regardless of hand)
        mode=false;
        active=null;
      }
      cooldownUntil = now + (CONFIG.TOGGLE_COOLDOWN_MS || 450);
      log("Teleport mode:", mode, "active:", active===rightHand?"right":active===leftHand?"left":"none");
    }

    leftHand.userData._wasNear = nearL;
    rightHand.userData._wasNear = nearR;

    if (!mode || !active){
      pointer.visible=false; ring.visible=false; hideArc();
      setGlow(false);
      statusCb("TELEPORT OFF • Make a FIST near your face to turn ON");
      modeCb("Hands: TELEPORT OFF");
      return;
    }

    // ON state: glow purple, pointer active
    setGlow(true);

    const p = aimPoint(active);
    if (!p){
      pointer.visible=false; ring.visible=false; hideArc();
      statusCb("TELEPORT ON • Aim not found (point down slightly) • FIST near face to turn OFF");
      modeCb(`Hands: TELEPORT ON (${active===rightHand?"RIGHT":"LEFT"})`);
      return;
    }

    const target = clamp(p);
    pointer.visible=true; ring.visible=true;
    pointer.position.set(target.x,0.013,target.z);
    ring.position.set(target.x,0.012,target.z);

    const xrCam=renderer.xr.getCamera(camera);
    const head=new THREE.Vector3();
    xrCam.getWorldPosition(head);
    const dist=Math.hypot(target.x-head.x, target.z-head.z);

    const tip=active.joints?.["index-finger-tip"];
    if (tip){
      const start=new THREE.Vector3();
      tip.getWorldPosition(start);
      showArc(start, target, dist);
    } else hideArc();

    statusCb(`TELEPORT ON • Target ${dist.toFixed(1)}m • Pinch+release to jump • FIST near face to turn OFF`);
    modeCb(`Hands: TELEPORT ON (${active===rightHand?"RIGHT":"LEFT"})`);

    const pinch = isPinching(active);
    if (active.userData._wasPinching===undefined) active.userData._wasPinching=false;

    if (active.userData._wasPinching && !pinch){
      if (now-lastTP > (CONFIG.TELEPORT_COOLDOWN_MS||250)){
        teleportByDelta(target);
        lastTP=now;
      }
    }
    active.userData._wasPinching = pinch;
  }

  return { onSessionStart, setLogoTexture, update };
}
