import * as THREE from "three";
import { CONFIG } from "./config.js";
import { sanitizeFloorTarget } from "./utils.js";
import { getHandAimPoint, isPinching } from "./gesture_utils.js";

export function createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp }) {
  let enabled = false;
  let target = null;
  let hoveredDistance = 0;
  let lastTeleport = 0;

  const pointer = new THREE.Mesh(
    new THREE.CircleGeometry(0.34, 48),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.72, side: THREE.DoubleSide })
  );
  pointer.rotation.x = -Math.PI / 2;
  pointer.position.y = 0.02;
  pointer.visible = false;
  scene.add(pointer);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.36, 0.54, 64),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, emissive: 0x4a126e, emissiveIntensity: 1.6, transparent: true, opacity: 0.7, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.021;
  ring.visible = false;
  scene.add(ring);

  let arcInner = null;
  let arcOuter = null;
  const arcInnerMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
  const arcOuterMat = new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.42, blending: THREE.AdditiveBlending, depthWrite: false });

  const raycaster = new THREE.Raycaster();
  const dir = new THREE.Vector3();
  const origin = new THREE.Vector3();
  const head = new THREE.Vector3();
  const controllerWorldPos = new THREE.Vector3();

  function setEnabled(next) {
    enabled = !!next;
    if (!enabled) clearVisuals();
  }

  function toggle() {
    setEnabled(!enabled);
    return enabled;
  }

  function isEnabled() {
    return enabled;
  }

  function clearVisuals() {
    pointer.visible = false;
    ring.visible = false;
    if (arcInner) arcInner.visible = false;
    if (arcOuter) arcOuter.visible = false;
    target = null;
    hoveredDistance = 0;
  }

  function showArc(from, to) {
    const distance = from.distanceTo(to);
    const mid = from.clone().lerp(to, 0.5);
    mid.y += 0.8 + distance * 0.07;
    const curve = new THREE.CatmullRomCurve3([from, mid, to.clone().setY(0.02)]);
    const innerGeo = new THREE.TubeGeometry(curve, 28, 0.022, 10, false);
    const outerGeo = new THREE.TubeGeometry(curve, 28, 0.05, 10, false);

    if (!arcInner) {
      arcOuter = new THREE.Mesh(outerGeo, arcOuterMat);
      arcInner = new THREE.Mesh(innerGeo, arcInnerMat);
      scene.add(arcOuter);
      scene.add(arcInner);
    } else {
      arcInner.geometry.dispose();
      arcOuter.geometry.dispose();
      arcInner.geometry = innerGeo;
      arcOuter.geometry = outerGeo;
    }
    arcInner.visible = true;
    arcOuter.visible = true;
  }

  function updateVisualTarget(point) {
    target = sanitizeFloorTarget(point, {
      roomRadius: roomClamp,
      tableCenter: new THREE.Vector3(CONFIG.TABLE_CENTER.x, 0, CONFIG.TABLE_CENTER.z),
      tableRadiusX: CONFIG.TABLE_RADIUS_X,
      tableRadiusZ: CONFIG.TABLE_RADIUS_Z,
      tableMargin: CONFIG.TABLE_SAFE_MARGIN,
    });
    pointer.visible = true;
    ring.visible = true;
    pointer.position.set(target.x, 0.02, target.z);
    ring.position.set(target.x, 0.021, target.z);
    renderer.xr.getCamera(camera).getWorldPosition(head);
    hoveredDistance = Math.hypot(target.x - head.x, target.z - head.z);
  }

  function computeControllerTarget(controller) {
    controller.getWorldPosition(origin);
    dir.set(0, 0, -1).applyQuaternion(controller.getWorldQuaternion(new THREE.Quaternion())).normalize();
    raycaster.set(origin, dir);
    const denom = dir.y;
    if (Math.abs(denom) < 0.0001) return null;
    const t = -origin.y / denom;
    if (!isFinite(t) || t < 0.15 || t > CONFIG.TELEPORT_RANGE) return null;
    const hit = origin.clone().addScaledVector(dir, t);
    return hit;
  }

  function computeHandTarget(hand) {
    return getHandAimPoint(hand, CONFIG.TELEPORT_RANGE);
  }

  function doTeleport() {
    const now = performance.now();
    if (!target || now - lastTeleport < CONFIG.TELEPORT_COOLDOWN_MS) return false;
    playerRig.teleportTo(target);
    lastTeleport = now;
    return true;
  }

  function update({ xrPresenting, rightController, rightHand, statusCb=()=>{} }) {
    if (!enabled) {
      clearVisuals();
      statusCb(xrPresenting ? "Teleport OFF • use watch TP button" : "Teleport OFF • press T or watch TP");
      return;
    }

    let point = null;
    let arcStart = null;
    if (xrPresenting && rightController) {
      point = computeControllerTarget(rightController);
      const rayLine = rightController.getObjectByName("ray");
      if (rayLine) {
        rayLine.visible = true;
        rayLine.material.color.set(0x65ffe0);
        rayLine.scale.z = point ? Math.max(0.25, rightController.getWorldPosition(controllerWorldPos).distanceTo(point)) : 4;
      }
      arcStart = rightController.getWorldPosition(controllerWorldPos).clone();
    }
    if (!point && xrPresenting && rightHand) {
      point = computeHandTarget(rightHand);
      const tip = rightHand.joints?.["index-finger-tip"];
      if (tip) arcStart = tip.getWorldPosition(controllerWorldPos).clone();
    }

    if (!xrPresenting && !point) {
      renderer.xr.getCamera(camera).getWorldPosition(head);
      point = new THREE.Vector3(head.x, 0, head.z - 2.2);
      arcStart = head.clone();
    }

    if (!point) {
      clearVisuals();
      statusCb("Teleport ON • aim toward floor");
      return;
    }

    updateVisualTarget(point);
    if (arcStart) showArc(arcStart, target);

    let released = false;
    if (xrPresenting && rightController) {
      const selecting = !!rightController.userData.selecting;
      if (rightController.userData.wasSelecting && !selecting) released = true;
      rightController.userData.wasSelecting = selecting;
    } else if (xrPresenting && rightHand) {
      const pinching = isPinching(rightHand);
      if (rightHand.userData.wasPinching && !pinching) released = true;
      rightHand.userData.wasPinching = pinching;
    }

    if (released) {
      doTeleport();
    }

    statusCb(`Teleport ON • ${hoveredDistance.toFixed(1)}m • release trigger/pinch to jump`);
  }

  return { update, toggle, isEnabled, setEnabled, clearVisuals };
}
