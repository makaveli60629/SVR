import * as THREE from "three";
import { CONFIG } from "./config.js";
import { sanitizeFloorTarget } from "./utils.js";
import { getHandAimPoint, isPinching } from "./gesture_utils.js";

export function createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp }) {
  let enabled = false;
  let target = null;
  let hoveredDistance = 0;
  let lastTeleport = 0;

  const pointer = new THREE.Mesh(
    new THREE.CircleGeometry(0.34, 48),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.72, side: THREE.DoubleSide })
  );
  pointer.rotation.x = -Math.PI / 2;
  pointer.position.y = 0.02;
  pointer.visible = false;
  scene.add(pointer);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.36, 0.54, 64),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, emissive: 0x4a126e, emissiveIntensity: 1.4, transparent: true, opacity: 0.68, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.021;
  ring.visible = false;
  scene.add(ring);

  let arcInner = null;
  let arcOuter = null;
  const arcInnerMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.88, blending: THREE.AdditiveBlending, depthWrite: false });
  const arcOuterMat = new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.38, blending: THREE.AdditiveBlending, depthWrite: false });

  const raycaster = new THREE.Raycaster();
  const dir = new THREE.Vector3();
  const origin = new THREE.Vector3();
  const head = new THREE.Vector3();
  const controllerWorldPos = new THREE.Vector3();
  const controllerQuat = new THREE.Quaternion();

  function setEnabled(next) {
    enabled = !!next;
    if (!enabled) clearVisuals();
  }

  function toggle() {
    setEnabled(!enabled);
    return enabled;
  }

  function isEnabled() {
    return enabled;
  }

  function clearVisuals() {
    pointer.visible = false;
    ring.visible = false;
    if (arcInner) arcInner.visible = false;
    if (arcOuter) arcOuter.visible = false;
    target = null;
    hoveredDistance = 0;
  }

  function showArc(from, to) {
    const distance = from.distanceTo(to);
    const mid = from.clone().lerp(to, 0.5);
    mid.y += 0.78 + distance * 0.07;
    const curve = new THREE.CatmullRomCurve3([from, mid, to.clone().setY(0.02)]);
    const innerGeo = new THREE.TubeGeometry(curve, 28, 0.022, 10, false);
    const outerGeo = new THREE.TubeGeometry(curve, 28, 0.05, 10, false);

    if (!arcInner) {
      arcOuter = new THREE.Mesh(outerGeo, arcOuterMat);
      arcInner = new THREE.Mesh(innerGeo, arcInnerMat);
      scene.add(arcOuter);
      scene.add(arcInner);
    } else {
      arcInner.geometry.dispose();
      arcOuter.geometry.dispose();
      arcInner.geometry = innerGeo;
      arcOuter.geometry = outerGeo;
    }
    arcInner.visible = true;
    arcOuter.visible = true;
  }

  function updateVisualTarget(point) {
    target = sanitizeFloorTarget(point, {
      roomRadius: roomClamp,
      tableCenter: new THREE.Vector3(CONFIG.TABLE_CENTER.x, 0, CONFIG.TABLE_CENTER.z),
      tableRadiusX: CONFIG.TABLE_RADIUS_X,
      tableRadiusZ: CONFIG.TABLE_RADIUS_Z,
      tableMargin: CONFIG.TABLE_SAFE_MARGIN,
    });
    pointer.visible = true;
    ring.visible = true;
    pointer.position.set(target.x, 0.02, target.z);
    ring.position.set(target.x, 0.021, target.z);
    renderer.xr.getCamera(camera).getWorldPosition(head);
    hoveredDistance = Math.hypot(target.x - head.x, target.z - head.z);
  }

  function computeControllerTarget(controller) {
    controller.getWorldPosition(origin);
    controller.getWorldQuaternion(controllerQuat);
    dir.set(0, 0, -1).applyQuaternion(controllerQuat).normalize();
    raycaster.set(origin, dir);
    const denom = dir.y;
    if (Math.abs(denom) < 0.0001) return null;
    const t = -origin.y / denom;
    if (!isFinite(t) || t < 0.15 || t > CONFIG.TELEPORT_RANGE) return null;
    return origin.clone().addScaledVector(dir, t);
  }

  function computeHandTarget(hand) {
    return getHandAimPoint(hand, CONFIG.TELEPORT_RANGE);
  }

  function doTeleport() {
    const now = performance.now();
    if (!target || now - lastTeleport < CONFIG.TELEPORT_COOLDOWN_MS) return false;
    playerRig.teleportTo(target);
    lastTeleport = now;
    setEnabled(false);
    clearVisuals();
    return true;
  }

  function update({ xrPresenting, rightController, rightHand, statusCb = () => {} }) {
    const rayLine = rightController?.getObjectByName?.("ray");
    if (rayLine) rayLine.visible = false;

    if (!enabled) {
      clearVisuals();
      statusCb(xrPresenting ? "Teleport OFF • press watch TP, then hold/release trigger" : "Teleport OFF • press T or watch TP");
      return;
    }

    if (!xrPresenting) {
      renderer.xr.getCamera(camera).getWorldPosition(head);
      const point = new THREE.Vector3(head.x, 0, head.z - 2.2);
      updateVisualTarget(point);
      showArc(head.clone(), target);
      statusCb(`Teleport ARMED • ${hoveredDistance.toFixed(1)}m`);
      return;
    }

    const controllerAiming = !!rightController?.userData?.selecting;
    const handAiming = !rightController && !!rightHand && isPinching(rightHand);
    const aiming = controllerAiming || handAiming;

    let point = null;
    let arcStart = null;
    if (controllerAiming && rightController) {
      point = computeControllerTarget(rightController);
      arcStart = rightController.getWorldPosition(controllerWorldPos).clone();
    } else if (handAiming && rightHand) {
      point = computeHandTarget(rightHand);
      const tip = rightHand.joints?.["index-finger-tip"];
      if (tip) arcStart = tip.getWorldPosition(controllerWorldPos).clone();
    }

    if (aiming && point) {
      updateVisualTarget(point);
      if (arcStart) showArc(arcStart, target);
    } else {
      clearVisuals();
    }

    const justReleasedController = rightController?.userData?.teleportWasAiming && !controllerAiming;
    const justReleasedHand = rightHand?.userData?.teleportWasAiming && !handAiming;
    if (justReleasedController || justReleasedHand) {
      doTeleport();
    }

    if (rightController) rightController.userData.teleportWasAiming = controllerAiming;
    if (rightHand) rightHand.userData.teleportWasAiming = handAiming;

    if (aiming && target) {
      statusCb(`Teleport ARMED • ${hoveredDistance.toFixed(1)}m • release trigger to jump`);
    } else {
      statusCb("Teleport ARMED • hold trigger to aim, release to jump");
    }
  }

  return { update, toggle, isEnabled, setEnabled, clearVisuals };
}
