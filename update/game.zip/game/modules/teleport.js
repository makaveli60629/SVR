import * as THREE from "three";
import { CONFIG } from "./config.js";
import { isPinching, isFist, aimPoint } from "./gestures.js";

export function createTeleportRig({ scene, renderer, camera, roomClamp, log=console.log }) {
  let baseRefSpace=null;
  let playerX=0, playerZ=CONFIG.SPAWN_Z;

  function setPlayerXZ(x,z){
    playerX=x; playerZ=z;
    if (!baseRefSpace) return;
    const xform=new XRRigidTransform({ x:-playerX, y:0, z:-playerZ });
    renderer.xr.setReferenceSpace(baseRefSpace.getOffsetReferenceSpace(xform));
  }

  const pointer=new THREE.Mesh(
    new THREE.PlaneGeometry(CONFIG.POINTER_SIZE, CONFIG.POINTER_SIZE),
    new THREE.MeshBasicMaterial({
      transparent:true, alphaTest:0.2, depthWrite:false,
      polygonOffset:true, polygonOffsetFactor:-2, side:THREE.DoubleSide,
      color:0xffffff
    })
  );
  pointer.rotation.x=-Math.PI/2;
  pointer.position.y=0.013;
  pointer.visible=false;
  scene.add(pointer);

  const ringMat = new THREE.MeshStandardMaterial({
    color:0xc89cff, roughness:0.25, metalness:0.18,
    emissive:0x3b0f55, emissiveIntensity:0.0,
    side:THREE.DoubleSide, transparent:true, opacity:0.98
  });
  const ring=new THREE.Mesh(
    new THREE.RingGeometry(CONFIG.RING_INNER, CONFIG.RING_OUTER, 96),
    ringMat
  );
  ring.rotation.x=-Math.PI/2;
  ring.position.y=0.012;
  ring.visible=false;
  scene.add(ring);

  const pulse = new THREE.Mesh(
    new THREE.RingGeometry(CONFIG.RING_OUTER * 0.94, CONFIG.RING_OUTER * 1.12, 96),
    new THREE.MeshBasicMaterial({
      color:0xb48cff,
      transparent:true,
      opacity:0.0,
      side:THREE.DoubleSide,
      blending:THREE.AdditiveBlending,
      depthWrite:false,
    })
  );
  pulse.rotation.x = -Math.PI/2;
  pulse.position.y = 0.014;
  pulse.visible = false;
  scene.add(pulse);

  let arcInner=null, arcOuter=null;
  const arcInnerMat = new THREE.MeshBasicMaterial({
    color:0xd3adff, transparent:true, opacity:CONFIG.ARC_INNER_OPACITY,
    depthWrite:false, blending:THREE.AdditiveBlending
  });
  const arcOuterMat = new THREE.MeshBasicMaterial({
    color:0x8b48ff, transparent:true, opacity:CONFIG.ARC_OUTER_OPACITY,
    depthWrite:false, blending:THREE.AdditiveBlending
  });

  function showArc(from,to,dist){
    const mid=from.clone().lerp(to,0.5);
    mid.y += CONFIG.ARC_HEIGHT_BASE + dist*CONFIG.ARC_HEIGHT_PER_M;
    const curve=new THREE.CatmullRomCurve3([from, mid, to.clone().setY(0.02)]);
    const gi=new THREE.TubeGeometry(curve, CONFIG.ARC_SEGMENTS, CONFIG.ARC_INNER_RADIUS, 12, false);
    const go=new THREE.TubeGeometry(curve, CONFIG.ARC_SEGMENTS, CONFIG.ARC_OUTER_RADIUS, 12, false);

    if (!arcInner){
      arcOuter=new THREE.Mesh(go, arcOuterMat);
      arcInner=new THREE.Mesh(gi, arcInnerMat);
      scene.add(arcOuter); scene.add(arcInner);
    } else {
      arcInner.geometry.dispose(); arcOuter.geometry.dispose();
      arcInner.geometry=gi; arcOuter.geometry=go;
    }
    arcInner.visible=true; arcOuter.visible=true;
  }
  function hideArc(){ if (arcInner) arcInner.visible=false; if (arcOuter) arcOuter.visible=false; }

  function setGlow(on){
    ringMat.emissiveIntensity = on ? 1.7 : 0.0;
    pulse.material.opacity = on ? 0.42 : 0.0;
    if (arcInnerMat) arcInnerMat.opacity = on ? CONFIG.ARC_INNER_OPACITY : 0.0;
    if (arcOuterMat) arcOuterMat.opacity = on ? CONFIG.ARC_OUTER_OPACITY : 0.0;
  }

  let mode=false;
  let active=null;
  let cooldownUntil=0;
  let lastTP=0;
  const camPos=new THREE.Vector3();
  const wristPos=new THREE.Vector3();
  const FACE_DIST = 0.30;
  const head=new THREE.Vector3();

  function fistNearFace(hand){
    const wrist=hand?.joints?.["wrist"];
    if (!wrist) return false;
    const xrCam=renderer.xr.getCamera(camera);
    xrCam.getWorldPosition(camPos);
    wrist.getWorldPosition(wristPos);
    return wristPos.distanceTo(camPos) < FACE_DIST;
  }

  function clamp(p){
    const r=roomClamp;
    return new THREE.Vector3(
      THREE.MathUtils.clamp(p.x, -r, r),
      0,
      THREE.MathUtils.clamp(p.z, -r, r)
    );
  }

  function teleportByDelta(target){
    const xrCam=renderer.xr.getCamera(camera);
    xrCam.getWorldPosition(head);
    const dx=target.x - head.x;
    const dz=target.z - head.z;
    setPlayerXZ(playerX + dx, playerZ + dz);
  }

  async function onSessionStart(){
    const session = renderer.xr.getSession();
    baseRefSpace = await session.requestReferenceSpace("local-floor");
    setPlayerXZ(CONFIG.SPAWN_X, CONFIG.SPAWN_Z);
    mode=false; active=null;
    pointer.visible=false; ring.visible=false; pulse.visible=false; hideArc();
    setGlow(false);
  }

  function setLogoTexture(tex){
    pointer.material.map=tex;
    pointer.material.needsUpdate=true;
  }

  function updateHandEdgeState(hand){
    if (!hand) return { rising:false, near:false, fist:false };
    if (hand.userData._wasNear === undefined) hand.userData._wasNear=false;
    const fist = !!hand?.joints && isFist(hand);
    const near = fist && fistNearFace(hand);
    const rising = near && !hand.userData._wasNear;
    hand.userData._wasNear = near;
    return { rising, near, fist };
  }

  function update({ leftHand, rightHand, statusCb=()=>{}, modeCb=()=>{} }){
    const anyHands = !!leftHand?.joints || !!rightHand?.joints;
    if (!renderer.xr.isPresenting){
      pointer.visible=false; ring.visible=false; pulse.visible=false; hideArc();
      setGlow(false);
      statusCb("Desktop preview ready • Click to look • WASD move • Enter VR for teleport");
      modeCb("Hands: DESKTOP");
      return;
    }
    if (!anyHands){
      pointer.visible=false; ring.visible=false; pulse.visible=false; hideArc();
      setGlow(false);
      statusCb("Waiting for hands/controllers…");
      modeCb("Hands: waiting…");
      return;
    }

    const now=performance.now();
    const leftState = updateHandEdgeState(leftHand);
    const rightState = updateHandEdgeState(rightHand);

    if ((leftState.rising || rightState.rising) && now > cooldownUntil){
      const selected = rightState.rising ? rightHand : leftHand;
      mode = !mode;
      active = mode ? selected : null;
      cooldownUntil = now + (CONFIG.TOGGLE_COOLDOWN_MS || 500);
      if (active?.userData) active.userData._wasPinching = false;
      log("Teleport mode:", mode, "active:", active===rightHand?"right":active===leftHand?"left":"none");
    }

    if (active && !active?.joints) active = null;
    if (!mode || !active){
      pointer.visible=false; ring.visible=false; pulse.visible=false; hideArc();
      setGlow(false);
      statusCb("TELEPORT OFF • Make a fist near your face to turn ON");
      modeCb("Hands: TELEPORT OFF");
      return;
    }

    const p = aimPoint(active);
    if (!p){
      pointer.visible=false; ring.visible=false; pulse.visible=false; hideArc();
      setGlow(true);
      statusCb("TELEPORT ON • Point down slightly • Fist near face to turn OFF");
      modeCb(`Hands: TELEPORT ON (${active===rightHand?"RIGHT":"LEFT"})`);
      return;
    }

    const target = clamp(p);
    pointer.visible=true; ring.visible=true; pulse.visible=true;
    pointer.position.set(target.x,0.013,target.z);
    ring.position.set(target.x,0.012,target.z);
    pulse.position.set(target.x,0.014,target.z);

    const xrCam=renderer.xr.getCamera(camera);
    xrCam.getWorldPosition(head);
    const dist=Math.hypot(target.x-head.x, target.z-head.z);
    const pulseScale = 1 + 0.06 * Math.sin(now * 0.012);
    pulse.scale.setScalar(pulseScale);
    setGlow(true);

    const tip=active.joints?.["index-finger-tip"];
    if (tip){
      const start=new THREE.Vector3();
      tip.getWorldPosition(start);
      showArc(start, target, dist);
    } else hideArc();

    statusCb(`TELEPORT ON • ${dist.toFixed(1)}m • Pinch + release to jump`);
    modeCb(`Hands: TELEPORT ON (${active===rightHand?"RIGHT":"LEFT"})`);

    const pinch = isPinching(active);
    if (active.userData._wasPinching===undefined) active.userData._wasPinching=false;
    if (active.userData._wasPinching && !pinch){
      if (now-lastTP > (CONFIG.TELEPORT_COOLDOWN_MS||280)){
        teleportByDelta(target);
        lastTP=now;
      }
    }
    active.userData._wasPinching = pinch;
  }

  return { onSessionStart, setLogoTexture, update };
}
