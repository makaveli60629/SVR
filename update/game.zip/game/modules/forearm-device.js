(function () {
  const THREE = AFRAME.THREE;
  const V0 = new THREE.Vector3();
  const V1 = new THREE.Vector3();
  const V2 = new THREE.Vector3();
  const V3 = new THREE.Vector3();
  const Q0 = new THREE.Quaternion();
  const Q1 = new THREE.Quaternion();
  const M0 = new THREE.Matrix4();

  const DEVICE_LAYOUT = {
    left: {
      forearmOffset: 0.086,
      liftOffset: 0.022,
      lateralOffset: -0.004,
      length: 0.156,
      width: 0.056,
      depth: 0.010,
      clampDepth: 0.014,
      screenInset: 0.0016
    }
  };

  window.SVRForearmDeviceLayout = DEVICE_LAYOUT;

  function isQuestBrowser() {
    return /OculusBrowser|Quest/i.test(navigator.userAgent || '');
  }

  function sceneInVR(scene) {
    return !!scene && scene.is && scene.is('vr-mode');
  }

  function getXRFrame(scene) {
    return (scene && scene.frame) || (scene && scene.renderer && scene.renderer.xr && scene.renderer.xr.getFrame && scene.renderer.xr.getFrame()) || null;
  }

  function getReferenceSpace(scene, handComp, trackedWebXR) {
    return (handComp && handComp.referenceSpace) ||
      (trackedWebXR && trackedWebXR.system && trackedWebXR.system.referenceSpace) ||
      (scene && scene.renderer && scene.renderer.xr && scene.renderer.xr.getReferenceSpace && scene.renderer.xr.getReferenceSpace()) ||
      null;
  }

  function getController(el) {
    const tracked = el.components['tracked-controls'];
    const trackedWebXR = el.components['tracked-controls-webxr'];
    return (tracked && tracked.controller) || (trackedWebXR && trackedWebXR.controller) || null;
  }

  function getJointPose(el, jointName) {
    const scene = el.sceneEl;
    const handComp = el.components['hand-tracking-controls'];
    const trackedWebXR = el.components['tracked-controls-webxr'];
    const controller = getController(el);
    const hand = controller && controller.hand;
    const frame = getXRFrame(scene);
    const referenceSpace = getReferenceSpace(scene, handComp, trackedWebXR);
    if (!frame || !hand || !hand.get || !referenceSpace) return null;
    const joint = hand.get(jointName);
    if (!joint) return null;
    const pose = frame.getJointPose(joint, referenceSpace);
    return pose && pose.transform ? pose : null;
  }

  function findNamedBone(root, patterns) {
    let found = null;
    if (!root) return null;
    root.traverse(function (obj) {
      if (found) return;
      const name = String(obj.name || '').toLowerCase();
      for (let i = 0; i < patterns.length; i++) {
        if (patterns[i].test(name)) {
          found = obj;
          break;
        }
      }
    });
    return found;
  }

  function getBasisPose(wrist, index, pinky, cameraObj, side) {
    const midpoint = V3.copy(index).add(pinky).multiplyScalar(0.5);
    const forearmDir = wrist.clone().sub(midpoint).normalize();
    let acrossPalm = index.clone().sub(pinky).normalize();
    let faceNormal = new THREE.Vector3().crossVectors(acrossPalm, forearmDir).normalize();

    if (cameraObj) {
      cameraObj.getWorldPosition(V0);
      if (faceNormal.dot(V0.sub(wrist)) < 0) faceNormal.multiplyScalar(-1);
    }

    acrossPalm = new THREE.Vector3().crossVectors(faceNormal, forearmDir).normalize();
    if (side === 'right') acrossPalm.multiplyScalar(-1);

    M0.makeBasis(forearmDir, acrossPalm, faceNormal);
    const worldQ = new THREE.Quaternion().setFromRotationMatrix(M0);
    return {
      position: wrist,
      quaternion: worldQ,
      forearmDir: forearmDir,
      acrossPalm: acrossPalm,
      faceNormal: faceNormal
    };
  }

  function computeWorldPose(el, cache, side) {
    const cameraObj = el.sceneEl && el.sceneEl.camera && el.sceneEl.camera.el && el.sceneEl.camera.el.object3D;
    const layout = DEVICE_LAYOUT[side] || DEVICE_LAYOUT.left;

    if (cache.wristObj && cache.indexObj && cache.pinkyObj) {
      cache.wristObj.getWorldPosition(V0);
      cache.indexObj.getWorldPosition(V1);
      cache.pinkyObj.getWorldPosition(V2);
      const pose = getBasisPose(V0.clone(), V1.clone(), V2.clone(), cameraObj, side);
      pose.position = pose.position
        .clone()
        .add(pose.forearmDir.clone().multiplyScalar(layout.forearmOffset))
        .add(pose.faceNormal.clone().multiplyScalar(layout.liftOffset))
        .add(pose.acrossPalm.clone().multiplyScalar(layout.lateralOffset));
      return pose;
    }

    const wristPose = getJointPose(el, 'wrist');
    const indexPose = getJointPose(el, 'index-finger-metacarpal');
    const pinkyPose = getJointPose(el, 'pinky-finger-metacarpal');
    if (wristPose && indexPose && pinkyPose) {
      const wt = wristPose.transform;
      const it = indexPose.transform;
      const pt = pinkyPose.transform;
      const wrist = new THREE.Vector3(wt.position.x, wt.position.y, wt.position.z);
      const index = new THREE.Vector3(it.position.x, it.position.y, it.position.z);
      const pinky = new THREE.Vector3(pt.position.x, pt.position.y, pt.position.z);
      const pose = getBasisPose(wrist, index, pinky, cameraObj, side);
      pose.position = pose.position
        .clone()
        .add(pose.forearmDir.clone().multiplyScalar(layout.forearmOffset))
        .add(pose.faceNormal.clone().multiplyScalar(layout.liftOffset))
        .add(pose.acrossPalm.clone().multiplyScalar(layout.lateralOffset));
      return pose;
    }

    return null;
  }

  function makeDeviceEntity(layout) {
    const root = document.createElement('a-entity');
    root.setAttribute('class', 'svr-forearm-device');
    root.setAttribute('visible', 'false');

    const body = document.createElement('a-box');
    body.setAttribute('width', String(layout.length));
    body.setAttribute('height', String(layout.width));
    body.setAttribute('depth', String(layout.depth));
    body.setAttribute('radius', '0.009');
    body.setAttribute('color', '#090909');
    body.setAttribute('material', 'metalness:0.92; roughness:0.28');
    root.appendChild(body);

    const bezel = document.createElement('a-box');
    bezel.setAttribute('width', String(layout.length - 0.008));
    bezel.setAttribute('height', String(layout.width - 0.008));
    bezel.setAttribute('depth', String(layout.depth + 0.001));
    bezel.setAttribute('position', '0 0 0.0005');
    bezel.setAttribute('color', '#151515');
    bezel.setAttribute('material', 'metalness:0.85; roughness:0.4');
    root.appendChild(bezel);

    const screen = document.createElement('a-plane');
    screen.setAttribute('width', String(layout.length - 0.016));
    screen.setAttribute('height', String(layout.width - 0.016));
    screen.setAttribute('position', `0 0 ${layout.depth / 2 + layout.screenInset}`);
    screen.setAttribute('material', 'src:#watchCanvas; shader:flat; side:double; transparent:false');
    root.appendChild(screen);

    const glow = document.createElement('a-plane');
    glow.setAttribute('width', String(layout.length - 0.012));
    glow.setAttribute('height', String(layout.width - 0.012));
    glow.setAttribute('position', `0 0 ${layout.depth / 2}`);
    glow.setAttribute('material', 'color:#7f37ff; shader:flat; opacity:0.10; transparent:true; side:double');
    root.appendChild(glow);

    const clampA = document.createElement('a-box');
    clampA.setAttribute('width', '0.016');
    clampA.setAttribute('height', String(layout.width + 0.016));
    clampA.setAttribute('depth', String(layout.clampDepth));
    clampA.setAttribute('position', `${-(layout.length / 2) + 0.010} 0 0`);
    clampA.setAttribute('color', '#101010');
    root.appendChild(clampA);

    const clampB = document.createElement('a-box');
    clampB.setAttribute('width', '0.016');
    clampB.setAttribute('height', String(layout.width + 0.016));
    clampB.setAttribute('depth', String(layout.clampDepth));
    clampB.setAttribute('position', `${(layout.length / 2) - 0.010} 0 0`);
    clampB.setAttribute('color', '#101010');
    root.appendChild(clampB);

    const sideButtonA = document.createElement('a-box');
    sideButtonA.setAttribute('width', '0.008');
    sideButtonA.setAttribute('height', '0.012');
    sideButtonA.setAttribute('depth', '0.003');
    sideButtonA.setAttribute('position', `${layout.length / 2 - 0.012} ${layout.width / 2 + 0.005} 0.001`);
    sideButtonA.setAttribute('color', '#37c8ff');
    sideButtonA.setAttribute('material', 'emissive:#37c8ff; emissiveIntensity:0.55');
    root.appendChild(sideButtonA);

    const sideButtonB = document.createElement('a-box');
    sideButtonB.setAttribute('width', '0.008');
    sideButtonB.setAttribute('height', '0.012');
    sideButtonB.setAttribute('depth', '0.003');
    sideButtonB.setAttribute('position', `${layout.length / 2 - 0.024} ${layout.width / 2 + 0.005} 0.001`);
    sideButtonB.setAttribute('color', '#9d57ff');
    sideButtonB.setAttribute('material', 'emissive:#9d57ff; emissiveIntensity:0.55');
    root.appendChild(sideButtonB);

    root.object3D.userData.svrSkipHandMaterial = true;
    root.object3D.traverse(function (obj) {
      obj.userData.svrSkipHandMaterial = true;
    });

    return root;
  }

  AFRAME.registerComponent('quest-hand-gate', {
    init: function () {
      const el = this.el;
      const scene = el.sceneEl;
      const sync = function () {
        el.object3D.visible = isQuestBrowser() && sceneInVR(scene);
      };
      scene.addEventListener('enter-vr', sync);
      scene.addEventListener('exit-vr', sync);
      setTimeout(sync, 0);
    }
  });

  AFRAME.registerComponent('forearm-device', {
    schema: { side: { default: 'left' } },

    init: function () {
      if (this.data.side !== 'left') return;
      if (window.SVRWatchUI && window.SVRWatchUI.draw) window.SVRWatchUI.draw();

      const layout = DEVICE_LAYOUT[this.data.side] || DEVICE_LAYOUT.left;
      this.root = makeDeviceEntity(layout);
      this.el.appendChild(this.root);
      this.rootObj = this.root.object3D;
      this.cache = { wristObj: null, indexObj: null, pinkyObj: null };
      this.frames = 0;
    },

    tick: function () {
      if (!this.rootObj) return;
      const active = isQuestBrowser() && sceneInVR(this.el.sceneEl);
      this.rootObj.visible = active;
      if (!active) return;

      if ((!this.cache.wristObj || !this.cache.indexObj || !this.cache.pinkyObj) && this.frames % 20 === 0) {
        const rootObj = this.el.object3D;
        this.cache.wristObj = findNamedBone(rootObj, [/^wrist$/, /wrist/, /hand_wrist/, /b_l_wrist/, /leftwrist/]);
        this.cache.indexObj = findNamedBone(rootObj, [/index.*metacarpal/, /index.*proximal/, /index.*knuckle/, /b_l_index1/]);
        this.cache.pinkyObj = findNamedBone(rootObj, [/pinky.*metacarpal/, /little.*metacarpal/, /pinky.*proximal/, /b_l_pinky1/]);
      }
      this.frames += 1;

      const pose = computeWorldPose(this.el, this.cache, this.data.side);
      if (!pose) {
        this.rootObj.visible = false;
        return;
      }

      const parentObj = this.el.object3D;
      const localPos = parentObj.worldToLocal(pose.position.clone());
      parentObj.getWorldQuaternion(Q0);
      Q1.copy(Q0).invert().multiply(pose.quaternion);

      this.rootObj.visible = true;
      this.rootObj.position.copy(localPos);
      this.rootObj.quaternion.copy(Q1);
    }
  });
})();
