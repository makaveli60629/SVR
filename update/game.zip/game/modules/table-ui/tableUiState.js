export function formatEngineResult(demo){
  const names = demo.showdown.winners.map(w=>w.name).join(", ");
  const hand = demo.showdown.winners[0]?.result?.name || "Unknown";
  const sidePots = demo.sidePots?.length ?? 0;
  return `Poker Engine Test: winner=${names} | hand=${hand} | sidePots=${sidePots} | release UI locked`;
}
