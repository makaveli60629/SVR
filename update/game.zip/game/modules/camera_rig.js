import * as THREE from "three";
import { CONFIG } from "./config.js";

// Player rig supports first-person + third-person (desktop) so you can see your avatar.
export function createPlayerRig({ camera }) {
  const player = new THREE.Group();
  player.position.set(CONFIG.SPAWN_X, 0, CONFIG.SPAWN_Z);

  // Simple avatar body (only visible in 3rd-person)
  const body = new THREE.Mesh(
    new THREE.CylinderGeometry(0.22, 0.26, 1.25, 18),
    new THREE.MeshStandardMaterial({
      color: 0x6b2cff,
      roughness: 0.65,
      metalness: 0.1,
      emissive: 0x1a0a2a,
      emissiveIntensity: 0.35,
    })
  );
  body.position.set(0, 0.95, 0);
  body.visible = false;
  player.add(body);

  let thirdPerson = false;

  function setThirdPerson(on) {
    thirdPerson = !!on;
    body.visible = thirdPerson;
  }

  function toggleThirdPerson() {
    setThirdPerson(!thirdPerson);
    return thirdPerson;
  }

  function applyCamera({ yaw, pitch }) {
    player.rotation.y = yaw;

    if (!thirdPerson) {
      camera.position.copy(player.position).add(new THREE.Vector3(0, CONFIG.SPAWN_Y, 0));
      camera.rotation.order = "YXZ";
      camera.rotation.y = yaw;
      camera.rotation.x = pitch;
    } else {
      const back = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
      const camPos = player.position
        .clone()
        .add(new THREE.Vector3(0, 1.9, 0))
        .addScaledVector(back, 4.4);
      camera.position.copy(camPos);
      const target = player.position.clone().add(new THREE.Vector3(0, 1.55, 0));
      camera.lookAt(target);
    }
  }

  function recenter() {
    player.position.set(CONFIG.SPAWN_X, 0, CONFIG.SPAWN_Z);
  }

  return { player, setThirdPerson, toggleThirdPerson, applyCamera, recenter };
}
