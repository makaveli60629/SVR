
import { urlsFor } from "./asset_base.js";

const out = document.getElementById("out");
const btn = document.getElementById("run");

const list = [
  "table/table.fbx",
  "npc/eric/eric.fbx",
  "storefronts/store.fbx",
  "other/willis.fbx",
  "other/handcocktower.fbx",
  "other/trump.fbx",
  "other/trumptowers.fbx",
];

async function head(url){
  try{
    const r = await fetch(url, { method:"HEAD", cache:"no-store" });
    return r.status;
  }catch(e){
    return "ERR";
  }
}

btn?.addEventListener("click", async ()=>{
  out.textContent = "Running...\n";
  for (const rel of list){
    out.textContent += "\n" + rel + "\n";
    const candidates = urlsFor(rel);
    let ok=false;
    for (const u of candidates){
      const st = await head(u);
      out.textContent += `  ${st}  ${u}\n`;
      if (st === 200) { ok=true; break; }
    }
    if (!ok) out.textContent += "  => NOT FOUND\n";
  }
});
