import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { CONFIG } from "./config.js";
import { urlsFor } from "./asset_base.js";

const CANDIDATES = {
  TABLE: [ ...urlsFor("table/table.fbx") ],
  ERIC:  [ ...urlsFor("npc/eric/eric.fbx") ],
};

function delay(ms){ return new Promise(r => setTimeout(r, ms)); }

async function loadFBXWithTimeout(loader, url, ms){
  return await Promise.race([
    loader.loadAsync(url),
    (async()=>{ await delay(ms); throw new Error("timeout"); })(),
  ]);
}

async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const obj = await loadFBXWithTimeout(loader, url, timeoutMs);
      log("Loaded FBX:", url);
      return obj;
    }catch(err){
      log("FBX missing/timeout:", url);
    }
  }
  return null;
}

function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const ctr = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(ctr);
  return { size, ctr };
}

function dropToGround(obj){
  const { size, ctr } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - ctr.y;
}

function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}

function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia = Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

function buildOuterCity(scene, radius){
  const towerMat = new THREE.MeshStandardMaterial({
    color: 0x0c0c18,
    roughness: 0.78,
    metalness: 0.12,
    emissive: 0x140a22,
    emissiveIntensity: 0.65,
  });
  const windowMat = new THREE.MeshStandardMaterial({
    color: 0xb48cff,
    roughness: 0.25,
    metalness: 0.22,
    emissive: 0x2a0d3a,
    emissiveIntensity: 1.2,
  });

  const group = new THREE.Group();
  const count = 160;
  for (let i = 0; i < count; i++){
    const angle = (i / count) * Math.PI * 2;
    const ring = radius + 12 + Math.random() * 12;
    const h = 10 + Math.random() * 40;
    const w = 1.6 + Math.random() * 4.1;
    const d = 1.6 + Math.random() * 4.1;
    const x = Math.cos(angle) * ring;
    const z = Math.sin(angle) * ring;

    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), towerMat);
    body.position.set(x, h / 2, z);
    body.rotation.y = -angle + Math.PI / 2;
    group.add(body);

    if (Math.random() < 0.72){
      const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.22, d * 1.04), windowMat);
      strip.position.set(x, 2 + Math.random() * Math.max(2, h - 5), z);
      strip.rotation.y = body.rotation.y;
      group.add(strip);
    }
  }

  // Landmark silhouettes.
  const willis = new THREE.Mesh(
    new THREE.BoxGeometry(4.8, 44, 4.8),
    new THREE.MeshStandardMaterial({ color: 0x151526, roughness: 0.7, metalness: 0.12, emissive: 0x1b1033, emissiveIntensity: 0.55 })
  );
  willis.position.set(-14, 22, -(radius + 18));
  group.add(willis);
  for (const dx of [-0.6, 0.6]){
    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.2, 8), new THREE.MeshBasicMaterial({ color: 0xff4a4a }));
    antenna.position.set(willis.position.x + dx, 45.5, willis.position.z);
    group.add(antenna);
  }

  const hancock = new THREE.Mesh(
    new THREE.CylinderGeometry(2.6, 4.4, 39, 10),
    new THREE.MeshStandardMaterial({ color: 0x141722, roughness: 0.62, metalness: 0.2, emissive: 0x121a2f, emissiveIntensity: 0.5 })
  );
  hancock.position.set(14, 19.5, -(radius + 18));
  group.add(hancock);
  for (let y = 8; y < 34; y += 6){
    const brace = new THREE.Mesh(new THREE.BoxGeometry(0.2, 6.0, 0.2), new THREE.MeshBasicMaterial({ color: 0xb7d7ff }));
    brace.position.set(hancock.position.x, y, hancock.position.z + 1.8);
    brace.rotation.z = Math.PI / 4;
    group.add(brace.clone());
    brace.rotation.z = -Math.PI / 4;
    group.add(brace.clone());
  }

  const trump = new THREE.Mesh(
    new THREE.CylinderGeometry(3.1, 4.4, 47, 14),
    new THREE.MeshPhysicalMaterial({ color: 0xd8e4ff, roughness: 0.18, metalness: 0.15, transmission: 0.25, transparent: true, opacity: 0.9 })
  );
  trump.position.set(0, 23.5, -(radius + 23));
  group.add(trump);

  scene.add(group);
}

function addMoon(scene, radius){
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(7.5, 32, 32),
    new THREE.MeshStandardMaterial({ color: 0xe8e8ff, roughness: 1.0, metalness: 0.0, emissive: 0x20243d, emissiveIntensity: 0.38 })
  );
  moon.position.set(-55, 55, -(radius + 72));
  scene.add(moon);
}

function addStarfield(scene, radius){
  const positions = [];
  for (let i = 0; i < 700; i++){
    const angle = Math.random() * Math.PI * 2;
    const dist = radius + 40 + Math.random() * 120;
    const y = 18 + Math.random() * 70;
    positions.push(Math.cos(angle) * dist, y, Math.sin(angle) * dist - 40);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  const pts = new THREE.Points(
    geo,
    new THREE.PointsMaterial({ color: 0xf7f2ff, size: 0.33, transparent: true, opacity: 0.85 })
  );
  scene.add(pts);
}

function buildProceduralTable(scene){
  const root = new THREE.Group();

  const rail = new THREE.Mesh(
    new THREE.CylinderGeometry(1.55, 1.7, 0.18, 48),
    new THREE.MeshStandardMaterial({ color: 0x251321, roughness: 0.85, metalness: 0.08, emissive: 0x1c0818, emissiveIntensity: 0.28 })
  );
  rail.position.y = 0.78;
  root.add(rail);

  const felt = new THREE.Mesh(
    new THREE.CylinderGeometry(1.26, 1.35, 0.08, 48),
    new THREE.MeshStandardMaterial({ color: 0x144b34, roughness: 0.92, metalness: 0.02, emissive: 0x07180f, emissiveIntensity: 0.16 })
  );
  felt.position.y = 0.81;
  root.add(felt);

  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.52, 0.78, 18),
    new THREE.MeshStandardMaterial({ color: 0x1b1b22, roughness: 0.74, metalness: 0.24 })
  );
  base.position.y = 0.39;
  root.add(base);

  for (let i = 0; i < 6; i++){
    const angle = (i / 6) * Math.PI * 2;
    const seat = new THREE.Mesh(
      new THREE.RingGeometry(0.22, 0.32, 36),
      new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.3, metalness: 0.15, emissive: 0x2a0d3a, emissiveIntensity: 0.9, side: THREE.DoubleSide })
    );
    seat.rotation.x = -Math.PI / 2;
    seat.position.set(Math.cos(angle) * 2.35, 0.015, Math.sin(angle) * 2.35);
    root.add(seat);
  }

  scene.add(root);
  return root;
}

function buildDealerStandIn(scene){
  const group = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.24, 1.0, 8, 16),
    new THREE.MeshStandardMaterial({ color: 0x22242c, roughness: 0.6, metalness: 0.1, emissive: 0x170d22, emissiveIntensity: 0.25 })
  );
  body.position.y = 1.0;
  group.add(body);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.18, 18, 18),
    new THREE.MeshStandardMaterial({ color: 0xcda78e, roughness: 0.95, metalness: 0.0 })
  );
  head.position.y = 1.78;
  group.add(head);

  group.position.set(0, 0, -2.2);
  group.rotation.y = Math.PI;
  scene.add(group);
  return group;
}

export async function buildSkylineRoom(scene, { log = console.log } = {}) {
  const radius = CONFIG.ROOM_RADIUS ?? 32;
  const wallH = CONFIG.WALL_HEIGHT ?? 22;

  scene.add(new THREE.HemisphereLight(0xffffff, 0x0a0a18, 1.55));
  const key = new THREE.PointLight(0xffffff, 75, 250, 2.0);
  key.position.set(0, 12, 0);
  scene.add(key);
  const violetFill = new THREE.PointLight(0xb48cff, 26, 80, 2.2);
  violetFill.position.set(0, 5, -4);
  scene.add(violetFill);

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(radius + 30, 180),
    new THREE.MeshStandardMaterial({ color: 0x050508, roughness: 0.96, metalness: 0.02 })
  );
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, wallH, 180, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x070712, roughness: 0.85, metalness: 0.06, emissive: 0x2a0d3a, emissiveIntensity: 0.42, side: THREE.BackSide })
  );
  wall.position.y = wallH / 2;
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(radius - 0.8, 0.24, 16, 200),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.24, metalness: 0.34, emissive: 0x2a0d3a, emissiveIntensity: 1.55 })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.y = wallH - 0.35;
  scene.add(rim);

  buildOuterCity(scene, radius);
  addMoon(scene, radius);
  addStarfield(scene, radius);
  buildProceduralTable(scene);
  buildDealerStandIn(scene);

  scene.userData._tickWorld = (dt)=>{
    scene.userData._t = (scene.userData._t || 0) + dt;
    rim.material.emissiveIntensity = 1.3 + Math.sin(scene.userData._t * 0.8) * 0.25;
  };

  (async()=>{
    const table = await tryLoadFBX(CANDIDATES.TABLE, log, 10000);
    if (table){
      table.traverse((child)=>{
        if (child.isMesh){
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });
      scaleToHeight(table, 0.95);
      dropToGround(table);
      fitDiameter(table, 2.75);
      dropToGround(table);
      table.position.set(0, 0, 0);
      scene.add(table);
    }

    const eric = await tryLoadFBX(CANDIDATES.ERIC, log, 10000);
    if (eric){
      scaleToHeight(eric, 1.78);
      dropToGround(eric);
      eric.position.set(0, 0, -2.2);
      eric.rotation.y = Math.PI;
      scene.add(eric);
    }
  })().catch((err)=> log("Asset stream error:", String(err)));

  return { roomClamp: radius - 2.0 };
}
