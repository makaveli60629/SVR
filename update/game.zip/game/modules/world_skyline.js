import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { CONFIG } from "./config.js";
import { assetUrls, loadFirstTexture } from "./asset_base.js";

function delay(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }
async function withTimeout(promise, ms){
  return await Promise.race([
    promise,
    (async()=>{ await delay(ms); throw new Error("timeout"); })()
  ]);
}

function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  return { size, center };
}
function dropToGround(obj){
  const { size, center } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - center.y;
}
function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}
function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia = Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

async function tryLoadGLTF(urls, log, timeoutMs = 12000){
  const loader = new GLTFLoader();
  for (const url of urls){
    try{
      const gltf = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded GLTF:", url);
      return gltf.scene;
    }catch(_err){ log("GLTF miss:", url); }
  }
  return null;
}
async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const fbx = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded FBX:", url);
      return fbx;
    }catch(_err){ log("FBX miss:", url); }
  }
  return null;
}

function canvasTexture(width, height, painter){
  const c = document.createElement("canvas");
  c.width = width; c.height = height;
  const x = c.getContext("2d");
  painter(x, width, height);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  return tex;
}

function makeSpriteTexture(){
  return canvasTexture(128, 128, (x,w,h)=>{
    const g = x.createRadialGradient(w/2,h/2,3,w/2,h/2,58);
    g.addColorStop(0,"rgba(255,255,255,1)");
    g.addColorStop(0.18,"rgba(220,230,255,0.95)");
    g.addColorStop(0.42,"rgba(180,140,255,0.26)");
    g.addColorStop(1,"rgba(180,140,255,0)");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
  });
}

function makeEarthTexture(){
  return canvasTexture(1024, 512, (x,w,h)=>{
    x.fillStyle = "#0a2c60";
    x.fillRect(0,0,w,h);
    for (let i = 0; i < 65; i++){
      x.fillStyle = `rgba(${20 + Math.random()*40|0}, ${90 + Math.random()*90|0}, ${60 + Math.random()*60|0}, ${0.55 + Math.random()*0.25})`;
      x.beginPath();
      x.ellipse(Math.random()*w, Math.random()*h, 40+Math.random()*130, 18+Math.random()*75, Math.random()*Math.PI, 0, Math.PI*2);
      x.fill();
    }
    x.fillStyle = "rgba(255,255,255,0.18)";
    for (let i = 0; i < 22; i++){
      x.beginPath();
      x.ellipse(Math.random()*w, Math.random()*h, 60+Math.random()*180, 15+Math.random()*40, Math.random()*Math.PI, 0, Math.PI*2);
      x.fill();
    }
  });
}

function makeFloorTexture(){
  return canvasTexture(1024, 1024, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0,"#17141c");
    g.addColorStop(1,"#09090e");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(210,210,255,0.08)";
    x.lineWidth = 4;
    for (let i=0;i<24;i++){
      const yy = (i/24)*h;
      x.beginPath(); x.moveTo(0,yy); x.lineTo(w,yy); x.stroke();
      x.beginPath(); x.moveTo(yy,0); x.lineTo(yy,h); x.stroke();
    }
    x.fillStyle = "rgba(255,255,255,0.05)";
    for (let i=0;i<2000;i++) x.fillRect(Math.random()*w, Math.random()*h, 1, 1);
  });
}

function makeWallTexture(){
  return canvasTexture(1024, 512, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,0,h);
    g.addColorStop(0,"#221523");
    g.addColorStop(1,"#0b0d16");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    for (let row = 0; row < 8; row++){
      for (let col = 0; col < 12; col++){
        x.strokeStyle = "rgba(255,255,255,0.05)";
        x.strokeRect(col*(w/12), row*(h/8), w/12, h/8);
      }
    }
    x.strokeStyle = "rgba(180,140,255,0.12)";
    x.lineWidth = 3;
    for (let i=0;i<10;i++){
      const yy = 26 + i * 48;
      x.beginPath(); x.moveTo(0,yy); x.lineTo(w,yy); x.stroke();
    }
  });
}

function makeChairTexture(){
  return canvasTexture(512, 512, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0,"#2c1a34");
    g.addColorStop(1,"#17111f");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(255,255,255,0.08)";
    x.lineWidth = 2;
    for (let i=0;i<24;i++){
      x.beginPath();
      x.moveTo(0, i*(h/24));
      x.lineTo(w, i*(h/24));
      x.stroke();
    }
  });
}

function makeWoodTexture(){
  return canvasTexture(1024, 256, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,0,h);
    g.addColorStop(0,"#5f381c");
    g.addColorStop(1,"#2a160d");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    for (let i=0;i<180;i++){
      x.strokeStyle = `rgba(${120+Math.random()*80|0},${70+Math.random()*35|0},${35+Math.random()*20|0},0.22)`;
      x.beginPath();
      const yy = Math.random()*h;
      x.moveTo(0,yy);
      x.bezierCurveTo(w*0.25, yy+Math.random()*18-9, w*0.75, yy+Math.random()*18-9, w, yy+Math.random()*12-6);
      x.stroke();
    }
  });
}

function buildStars(scene, R){
  const count = 5200;
  const pos = new Float32Array(count * 3);
  const col = new Float32Array(count * 3);
  for (let i = 0; i < count; i++){
    const rr = R + 70 + Math.random() * 150;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.48 + 0.02;
    pos[i*3+0] = Math.cos(theta) * Math.sin(phi) * rr;
    pos[i*3+1] = Math.cos(phi) * rr * 0.95 + 24;
    pos[i*3+2] = Math.sin(theta) * Math.sin(phi) * rr;
    const tint = 0.84 + Math.random() * 0.16;
    col[i*3+0] = tint;
    col[i*3+1] = 0.88 + Math.random() * 0.12;
    col[i*3+2] = 0.96 + Math.random() * 0.04;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({
    size: 0.16,
    sizeAttenuation: true,
    transparent: true,
    opacity: 0.95,
    map: makeSpriteTexture(),
    vertexColors: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  }));
  scene.add(pts);

  const spriteGroup = new THREE.Group();
  for (let i = 0; i < 320; i++){
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: makeSpriteTexture(),
      color: new THREE.Color(i % 7 === 0 ? 0xb48cff : 0xffffff),
      transparent: true,
      opacity: 0.28 + Math.random() * 0.18,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    }));
    spr.scale.setScalar(0.12 + Math.random() * 0.32);
    const rr = R + 60 + Math.random() * 110;
    const theta = Math.random() * Math.PI * 2;
    const y = 32 + Math.random() * 90;
    spr.position.set(Math.cos(theta) * rr, y, Math.sin(theta) * rr);
    spriteGroup.add(spr);
  }
  scene.add(spriteGroup);
  return { pts, spriteGroup };
}

function buildOuterCity(scene, R){
  const group = new THREE.Group();
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x080a14,
    roughness: 0.76,
    metalness: 0.1,
    emissive: 0x180b22,
    emissiveIntensity: 0.4
  });
  const glowMat = new THREE.MeshStandardMaterial({
    color: 0xb48cff,
    roughness: 0.18,
    metalness: 0.25,
    emissive: 0x36124d,
    emissiveIntensity: 1.5
  });

  const count = 220;
  for (let i = 0; i < count; i++){
    const a = (i / count) * Math.PI * 2;
    const rr = (R + 8) + Math.random() * 22;
    const h = 12 + Math.random() * 46;
    const w = 2.0 + Math.random() * 4.2;
    const d = 2.0 + Math.random() * 4.2;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;

    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), baseMat);
    body.position.set(x, h / 2, z);
    body.rotation.y = -a + Math.PI / 2;
    group.add(body);

    const stripCount = 2 + (Math.random() * 4 | 0);
    for (let s = 0; s < stripCount; s++){
      const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.95, 0.16, d * 1.03), glowMat);
      strip.position.set(x, 2 + ((s + 1) / (stripCount + 1)) * (h - 3), z);
      strip.rotation.y = body.rotation.y;
      group.add(strip);
    }
  }
  scene.add(group);
  return group;
}

function makeSeat(scene, x, z, angle, label, chairMat, metalMat){
  const group = new THREE.Group();
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.36, 0.54, 48),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.72, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.014;
  group.add(ring);

  const seatBase = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.11, 0.72, 18), metalMat);
  seatBase.position.y = 0.36;
  group.add(seatBase);

  const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 0.06, 28), metalMat);
  foot.position.y = 0.03;
  group.add(foot);

  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.12, 0.68), chairMat);
  seat.position.y = 0.72;
  seat.castShadow = true;
  seat.receiveShadow = true;
  group.add(seat);

  const back = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.72, 0.12), chairMat);
  back.position.set(0, 1.08, -0.28);
  back.rotation.x = -0.12;
  back.castShadow = true;
  back.receiveShadow = true;
  group.add(back);

  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 0.56), chairMat);
  armL.position.set(-0.34, 0.88, 0.02);
  group.add(armL);
  const armR = armL.clone();
  armR.position.x = 0.34;
  group.add(armR);

  const legs = [
    [-0.24,0.34,-0.24],[0.24,0.34,-0.24],[-0.24,0.34,0.24],[0.24,0.34,0.24]
  ];
  for (const [lx,ly,lz] of legs){
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.035, 0.72, 12), metalMat);
    leg.position.set(lx, ly, lz);
    group.add(leg);
  }

  group.position.set(x, 0, z);
  group.rotation.y = angle;
  scene.add(group);
  return { group, ring, x, z, angle, label };
}

function addChipsAndCards(scene){
  const group = new THREE.Group();
  const chipMatA = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.35, metalness: 0.25, emissive: 0x230d30, emissiveIntensity: 0.35 });
  const chipMatB = new THREE.MeshStandardMaterial({ color: 0x00e2c7, roughness: 0.35, metalness: 0.25, emissive: 0x06261f, emissiveIntensity: 0.28 });
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf2f2ff, roughness: 0.85, metalness: 0.03 });
  const stacks = [[-0.92, 1.08, chipMatA],[-0.38, 1.18, chipMatB],[0.42, 1.14, chipMatA],[0.95, 1.0, chipMatB]];
  for (const [x, z, mat] of stacks){
    for (let i = 0; i < 6; i++){
      const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.018, 24), mat);
      chip.position.set(x, 0.845 + i * 0.02, z - 0.19);
      chip.rotation.x = Math.PI / 2;
      group.add(chip);
    }
  }
  for (let i = 0; i < 5; i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.003, 0.18), cardMat);
    card.position.set(-0.3 + i * 0.15, 0.842, -0.03 + (i % 2) * 0.01);
    card.rotation.y = -0.18 + i * 0.09;
    group.add(card);
  }
  scene.add(group);
}

function applyEricMaterial(obj, texture, normalTex){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    child.material = new THREE.MeshStandardMaterial({
      map: texture || null,
      normalMap: normalTex || null,
      color: texture ? 0xffffff : 0xd6d4e8,
      roughness: 0.68,
      metalness: 0.02,
      emissive: 0x0d0914,
      emissiveIntensity: 0.06,
      skinning: !!child.isSkinnedMesh
    });
  });
}

function touchModelShadows(obj){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    if (!Array.isArray(child.material) && child.material){
      child.material.side = THREE.DoubleSide;
    }
  });
}

export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const R = CONFIG.ROOM_RADIUS;
  const H = CONFIG.WALL_HEIGHT;

  scene.fog = new THREE.FogExp2(0x04050a, 0.0068);

  const hemi = new THREE.HemisphereLight(0xffffff, 0x070913, 1.35);
  scene.add(hemi);

  const key = new THREE.DirectionalLight(0xffffff, 1.7);
  key.position.set(16, 26, 12);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.left = -20;
  key.shadow.camera.right = 20;
  key.shadow.camera.top = 20;
  key.shadow.camera.bottom = -20;
  scene.add(key);

  const tableSpot = new THREE.SpotLight(0xf9f0ff, 6.2, 70, Math.PI * 0.22, 0.35, 1.35);
  tableSpot.position.set(0, 14, 4);
  tableSpot.target.position.set(0, 0.8, 0);
  tableSpot.castShadow = true;
  scene.add(tableSpot);
  scene.add(tableSpot.target);

  const fill = new THREE.PointLight(0xb48cff, 4.8, 120, 2.0);
  fill.position.set(0, 9.5, 0);
  scene.add(fill);

  const rimLight = new THREE.PointLight(0x61a9ff, 2.8, 160, 2.0);
  rimLight.position.set(20, 18, -34);
  scene.add(rimLight);

  const floorTexLoaded = await loadFirstTexture(assetUrls("texture/cloth_diffuse.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const floorBump = await loadFirstTexture(assetUrls("texture/cloth_bump.jpg"));
  const floorTex = floorTexLoaded || makeFloorTexture();
  floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
  floorTex.repeat.set(18, 18);
  if (floorBump){ floorBump.wrapS = floorBump.wrapT = THREE.RepeatWrapping; floorBump.repeat.set(18, 18); }

  const wallTexLoaded = await loadFirstTexture(assetUrls("texture/leather_dark.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const wallBump = await loadFirstTexture(assetUrls("texture/leather_dark_bump.jpg"));
  const wallTex = wallTexLoaded || makeWallTexture();
  wallTex.wrapS = wallTex.wrapT = THREE.RepeatWrapping;
  wallTex.repeat.set(10, 3);
  if (wallBump){ wallBump.wrapS = wallBump.wrapT = THREE.RepeatWrapping; wallBump.repeat.set(10, 3); }

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(R + 34, 220),
    new THREE.MeshStandardMaterial({
      color: 0x0a0a10,
      roughness: 0.98,
      metalness: 0.02,
      map: floorTex,
      bumpMap: floorBump || null,
      bumpScale: floorBump ? 0.22 : 0.08
    })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, H, 220, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0x0b0c16,
      roughness: 0.82,
      metalness: 0.06,
      emissive: 0x180b25,
      emissiveIntensity: 0.18,
      side: THREE.BackSide,
      map: wallTex,
      bumpMap: wallBump || null,
      bumpScale: wallBump ? 0.08 : 0.05
    })
  );
  wall.position.set(0, H / 2, 0);
  scene.add(wall);

  const ceiling = new THREE.Mesh(
    new THREE.CircleGeometry(R, 180),
    new THREE.MeshStandardMaterial({ color: 0x070811, roughness: 0.96, metalness: 0.02, side: THREE.BackSide })
  );
  ceiling.rotation.x = Math.PI / 2;
  ceiling.position.y = H;
  scene.add(ceiling);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(R - 1.2, 0.18, 16, 220),
    new THREE.MeshStandardMaterial({
      color: 0xb48cff,
      roughness: 0.2,
      metalness: 0.35,
      emissive: 0x2a0d3a,
      emissiveIntensity: 1.45
    })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.set(0, H - 0.55, 0);
  scene.add(rim);

  const innerPlatform = new THREE.Mesh(
    new THREE.CylinderGeometry(8.8, 9.2, 0.3, 96),
    new THREE.MeshStandardMaterial({
      color: 0x14121b,
      roughness: 0.78,
      metalness: 0.12,
      emissive: 0x12061c,
      emissiveIntensity: 0.12
    })
  );
  innerPlatform.position.y = 0.15;
  innerPlatform.receiveShadow = true;
  scene.add(innerPlatform);

  const city = buildOuterCity(scene, R);
  const stars = buildStars(scene, R);

  const moonTex = await loadFirstTexture(assetUrls("texture/moon_diffuse.png"), { colorSpace: THREE.SRGBColorSpace });
  const moonBump = await loadFirstTexture(assetUrls("texture/moon_bump.png"));
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(5.6, 40, 40),
    new THREE.MeshStandardMaterial({
      color: 0xe9e9ff,
      roughness: 1.0,
      metalness: 0.0,
      map: moonTex || null,
      bumpMap: moonBump || null,
      bumpScale: moonBump ? 0.18 : 0,
      emissive: 0x0f1020,
      emissiveIntensity: 0.16
    })
  );
  moon.position.set(-28, 46, -(R + 48));
  scene.add(moon);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(8.2, 48, 48),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.95,
      metalness: 0.0,
      map: makeEarthTexture(),
      emissive: 0x061227,
      emissiveIntensity: 0.24
    })
  );
  earth.position.set(38, 38, -(R + 60));
  earth.rotation.z = 0.35;
  scene.add(earth);

  const earthGlow = new THREE.PointLight(0x4fa6ff, 3.4, 120, 2.0);
  earthGlow.position.copy(earth.position).add(new THREE.Vector3(0,0,14));
  scene.add(earthGlow);

  const atmosphereGlow = new THREE.Mesh(
    new THREE.SphereGeometry(R + 12, 42, 42),
    new THREE.MeshBasicMaterial({ color: 0x140820, transparent: true, opacity: 0.08, side: THREE.BackSide })
  );
  scene.add(atmosphereGlow);

  const haze = new THREE.Mesh(
    new THREE.CylinderGeometry(14, 22, 6, 64, 1, true),
    new THREE.MeshBasicMaterial({ color: 0x251138, transparent: true, opacity: 0.08, side: THREE.DoubleSide })
  );
  haze.position.y = 3.5;
  scene.add(haze);

  const chairTex = makeChairTexture();
  chairTex.repeat.set(2,2);
  const chairMat = new THREE.MeshStandardMaterial({ map: chairTex, color: 0xffffff, roughness: 0.62, metalness: 0.12, emissive: 0x12081a, emissiveIntensity: 0.10 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x272a31, roughness: 0.35, metalness: 0.55, emissive: 0x0e1016, emissiveIntensity: 0.08 });

  const seatRadius = 3.35;
  const seats = [
    makeSeat(scene, 0,  seatRadius, Math.PI, "Front Center", chairMat, metalMat),
    makeSeat(scene, -2.75, 1.78, Math.PI * 0.72, "Front Left", chairMat, metalMat),
    makeSeat(scene,  2.75, 1.78, -Math.PI * 0.72, "Front Right", chairMat, metalMat),
    makeSeat(scene, -2.75, -1.78, Math.PI * 0.28, "Back Left", chairMat, metalMat),
    makeSeat(scene,  2.75, -1.78, -Math.PI * 0.28, "Back Right", chairMat, metalMat),
    makeSeat(scene, 0, -seatRadius, 0, "Dealer Side", chairMat, metalMat)
  ];

  const table = await tryLoadGLTF(assetUrls("models/table.glb"), log, 10000) || await tryLoadFBX(assetUrls("models/table.fbx"), log, 10000);
  if (table){
    touchModelShadows(table);
    scaleToHeight(table, 0.96);
    dropToGround(table);
    fitDiameter(table, 3.25);
    dropToGround(table);
    table.position.set(0, 0, 0);
    scene.add(table);
  }

  const feltMap = await loadFirstTexture(assetUrls("texture/tablefelt.png"), { colorSpace: THREE.SRGBColorSpace }) || makeFloorTexture();
  feltMap.wrapS = feltMap.wrapT = THREE.RepeatWrapping;
  feltMap.repeat.set(1,1);
  const feltTop = new THREE.Mesh(
    new THREE.CylinderGeometry(1.32, 1.38, 0.05, 64),
    new THREE.MeshStandardMaterial({ color: 0xffffff, map: feltMap, roughness: 0.82, metalness: 0.02 })
  );
  feltTop.position.y = 0.84;
  feltTop.receiveShadow = true;
  feltTop.castShadow = true;
  scene.add(feltTop);

  const railMap = makeWoodTexture();
  railMap.repeat.set(2,1);
  const rail = new THREE.Mesh(
    new THREE.TorusGeometry(1.52, 0.15, 18, 64),
    new THREE.MeshStandardMaterial({ map: railMap, color: 0xffffff, roughness: 0.58, metalness: 0.14, emissive: 0x140b06, emissiveIntensity: 0.06 })
  );
  rail.rotation.x = Math.PI / 2;
  rail.position.y = 0.95;
  rail.castShadow = true;
  rail.receiveShadow = true;
  scene.add(rail);

  addChipsAndCards(scene);

  const ericTex = await loadFirstTexture(assetUrls("models/eric/rp_eric_rigged_001_dif.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const ericNorm = await loadFirstTexture(assetUrls("models/eric/rp_eric_rigged_001_norm.jpg"));
  const eric = await tryLoadFBX(assetUrls("models/eric/eric.fbx"), log, 12000);
  if (eric){
    applyEricMaterial(eric, ericTex, ericNorm);
    scaleToHeight(eric, 1.78);
    dropToGround(eric);
    eric.position.set(0, 0, -2.3);
    eric.rotation.y = Math.PI;
    scene.add(eric);
  }

  scene.userData._tickWorld = (dt)=>{
    scene.userData._time = (scene.userData._time || 0) + dt;
    const t = scene.userData._time;
    moon.rotation.y += dt * 0.022;
    earth.rotation.y += dt * 0.04;
    earth.rotation.z = 0.32 + Math.sin(t * 0.08) * 0.04;
    earth.position.x = 38 + Math.cos(t * 0.05) * 1.8;
    moon.position.y = 46 + Math.sin(t * 0.06) * 1.6;
    rim.material.emissiveIntensity = 1.25 + Math.sin(t * 1.2) * 0.22;
    stars.spriteGroup.rotation.y += dt * 0.0022;
    city.rotation.y += dt * 0.0025;
    haze.material.opacity = 0.06 + Math.sin(t * 0.3) * 0.015;
  };

  return {
    roomClamp: R - 2.5,
    tableCenter: new THREE.Vector3(0, 0, 0),
    seats,
    joinRadius: 6.4,
    previewOrbitRadius: 10.5
  };
}
