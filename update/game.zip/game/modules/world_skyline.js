import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";
import { FBXLoader } from "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/loaders/FBXLoader.js";
import { GLTFLoader } from "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/loaders/GLTFLoader.js";
import { CONFIG } from "./config.js";
import { urlsFor } from "./asset_base.js";

const CANDIDATES = {
  TABLE: [
    ...urlsFor("models/table.glb"),
    ...urlsFor("models/table.fbx"),
    ...urlsFor("table/table.fbx")
  ],
  ERIC: [
    ...urlsFor("models/eric/eric.fbx"),
    ...urlsFor("locomotion/eric.fbx"),
    ...urlsFor("npc/eric/eric.fbx")
  ],
  MOON_TEX: [
    ...urlsFor("texture/moon_diffuse.png")
  ],
  TABLE_LOGO: [
    ...urlsFor("ui/logo_table.png")
  ]
};

function delay(ms){ return new Promise(r=>setTimeout(r, ms)); }

async function loadTextureWithFallback(urls){
  const loader = new THREE.TextureLoader();
  for (const u of urls){
    try{
      const tex = await loader.loadAsync(u);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      return tex;
    }catch{}
  }
  return null;
}

async function loadAssetWithTimeout(promise, ms){
  return await Promise.race([
    promise,
    (async()=>{ await delay(ms); throw new Error("timeout"); })()
  ]);
}

async function tryLoadObject(urls, log, timeoutMs=12000){
  const fbxLoader = new FBXLoader();
  const gltfLoader = new GLTFLoader();
  for (const u of urls){
    try{
      let obj;
      if (/\.glb($|\?)/i.test(u) || /\.gltf($|\?)/i.test(u)){
        const gltf = await loadAssetWithTimeout(gltfLoader.loadAsync(u), timeoutMs);
        obj = gltf.scene;
      } else {
        obj = await loadAssetWithTimeout(fbxLoader.loadAsync(u), timeoutMs);
      }
      log("Loaded asset:", u);
      return obj;
    }catch(e){
      log("Asset missing/timeout:", u);
    }
  }
  return null;
}

function boxMetrics(obj){
  const box=new THREE.Box3().setFromObject(obj);
  const size=new THREE.Vector3();
  const center=new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  return { box, size, center, minY:box.min.y, maxY:box.max.y };
}

function dropToGround(obj){
  const { minY } = boxMetrics(obj);
  obj.position.y -= minY;
}

function scaleToHeight(obj, targetH){
  const { size } = boxMetrics(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}

function fitDiameter(obj, targetDia){
  const { size } = boxMetrics(obj);
  const dia=Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

function createFallbackTable(){
  const g = new THREE.Group();
  const railMat = new THREE.MeshStandardMaterial({ color:0x1b0d1c, roughness:0.7, metalness:0.18, emissive:0x220b22, emissiveIntensity:0.35 });
  const feltMat = new THREE.MeshStandardMaterial({ color:0x4d0f58, roughness:0.95, metalness:0.02, emissive:0x2c0730, emissiveIntensity:0.2 });
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(1.55,1.55,0.16,48), railMat);
  rim.position.y = 0.92;
  g.add(rim);
  const felt = new THREE.Mesh(new THREE.CylinderGeometry(1.28,1.28,0.05,48), feltMat);
  felt.position.y = 0.95;
  g.add(felt);
  for (const x of [-1.0, -0.35, 0.35, 1.0]){
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.09,0.88,18), railMat);
    leg.position.set(x,0.44,0);
    g.add(leg);
  }
  return g;
}

function addStars(scene, count=400){
  const pos = new Float32Array(count * 3);
  for (let i=0;i<count;i++){
    const r = 120 + Math.random()*180;
    const a = Math.random() * Math.PI * 2;
    const y = 18 + Math.random() * 90;
    pos[i*3+0] = Math.cos(a) * r;
    pos[i*3+1] = y;
    pos[i*3+2] = Math.sin(a) * r;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ color:0xd8ccff, size:0.55, sizeAttenuation:true, transparent:true, opacity:0.95 }));
  scene.add(pts);
}

function buildOuterCity(scene, R){
  const bodyMat=new THREE.MeshStandardMaterial({
    color:0x0b0b16, roughness:0.8, metalness:0.08,
    emissive:0x180920, emissiveIntensity:0.55
  });
  const glowMat=new THREE.MeshStandardMaterial({
    color:0xc89cff, roughness:0.22, metalness:0.18,
    emissive:0x4b1a69, emissiveIntensity:1.35
  });
  const grp=new THREE.Group();
  const count=150;
  for(let i=0;i<count;i++){
    const a=(i/count)*Math.PI*2;
    const rr=(R+9)+(Math.random()*11);
    const h=8+Math.random()*28;
    const w=1.4+Math.random()*3.6;
    const d=1.4+Math.random()*3.6;
    const x=Math.cos(a)*rr, z=Math.sin(a)*rr;
    const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d), bodyMat);
    b.position.set(x,h/2,z);
    b.rotation.y=-a+Math.PI/2;
    grp.add(b);
    if(Math.random()<0.72){
      const strip=new THREE.Mesh(new THREE.BoxGeometry(w*0.92,0.22,d*1.04), glowMat);
      strip.position.set(x, 1.7+Math.random()*(h-3.2), z);
      strip.rotation.y=b.rotation.y;
      grp.add(strip);
    }
  }
  scene.add(grp);
}

function makeEarthTexture(){
  const c=document.createElement("canvas");
  c.width=1024; c.height=512;
  const ctx=c.getContext("2d");
  const grd=ctx.createLinearGradient(0,0,0,c.height);
  grd.addColorStop(0,"#11377a");
  grd.addColorStop(0.5,"#1778bb");
  grd.addColorStop(1,"#0a2859");
  ctx.fillStyle=grd;
  ctx.fillRect(0,0,c.width,c.height);
  ctx.fillStyle="rgba(38,173,88,0.95)";
  const blobs = [
    [120,120,130,80],[250,250,180,90],[420,150,210,110],[560,280,170,90],[760,130,230,120],[860,300,150,80]
  ];
  for (const [x,y,w,h] of blobs){
    ctx.beginPath();
    ctx.ellipse(x,y,w,h,Math.random()*0.7,0,Math.PI*2); ctx.fill();
    ctx.beginPath();
    ctx.ellipse(x+w*0.2,y+h*0.2,w*0.5,h*0.45,Math.random()*0.5,0,Math.PI*2); ctx.fill();
  }
  ctx.fillStyle="rgba(255,255,255,0.18)";
  for(let i=0;i<18;i++){
    ctx.beginPath();
    ctx.ellipse(Math.random()*c.width, Math.random()*c.height, 90+Math.random()*110, 18+Math.random()*24, Math.random()*Math.PI, 0, Math.PI*2);
    ctx.fill();
  }
  const tex=new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function addPlanetBackdrop(scene, moonTex){
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(6.5, 32, 32),
    new THREE.MeshStandardMaterial({ map:moonTex || null, color:moonTex ? 0xffffff : 0xe7e7ff, roughness:1.0, metalness:0.0, emissive:0x1b1630, emissiveIntensity:0.28 })
  );
  moon.position.set(-42, 30, -82);
  scene.add(moon);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(4.8, 32, 32),
    new THREE.MeshStandardMaterial({ map:makeEarthTexture(), roughness:0.95, metalness:0.0, emissive:0x071024, emissiveIntensity:0.2 })
  );
  earth.position.set(28, 20, -72);
  scene.add(earth);

  const glow = new THREE.Mesh(
    new THREE.SphereGeometry(7.2, 24, 24),
    new THREE.MeshBasicMaterial({ color:0xc08cff, transparent:true, opacity:0.09, depthWrite:false })
  );
  glow.position.copy(earth.position);
  scene.add(glow);

  scene.userData._planets = { moon, earth, glow };
}

function createSeatAndTableDecor(scene, tableTopY, logoTex){
  const chairMat = new THREE.MeshStandardMaterial({ color:0x16121d, roughness:0.8, metalness:0.12, emissive:0x25103a, emissiveIntensity:0.35 });
  const metalMat = new THREE.MeshStandardMaterial({ color:0x9b86b8, roughness:0.28, metalness:0.45, emissive:0x2a1436, emissiveIntensity:0.2 });
  const chairRadius = 2.16;
  const angles = [Math.PI, Math.PI*0.66, Math.PI*0.34, 0, -Math.PI*0.34, -Math.PI*0.66];
  for (const a of angles){
    const x = Math.sin(a) * chairRadius;
    const z = Math.cos(a) * chairRadius;
    const stool = new THREE.Group();
    const seat = new THREE.Mesh(new THREE.CylinderGeometry(0.32,0.34,0.1,24), chairMat);
    seat.position.y = 0.52;
    stool.add(seat);
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.07,0.48,18), metalMat);
    post.position.y = 0.24;
    stool.add(post);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.24,0.04,18), metalMat);
    base.position.y = 0.02;
    stool.add(base);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.42,0.28,0.06), chairMat);
    back.position.set(0,0.78,-0.22);
    stool.add(back);
    stool.position.set(x,0,z);
    stool.lookAt(0,0.5,0);
    stool.rotateY(Math.PI);
    scene.add(stool);

    const seatRing = new THREE.Mesh(
      new THREE.RingGeometry(0.26,0.37,36),
      new THREE.MeshBasicMaterial({ color:0xb48cff, transparent:true, opacity:0.35, side:THREE.DoubleSide })
    );
    seatRing.rotation.x = -Math.PI/2;
    seatRing.position.set(x,0.015,z);
    scene.add(seatRing);
  }

  if (logoTex){
    const feltLogo = new THREE.Mesh(
      new THREE.PlaneGeometry(1.55, 1.55),
      new THREE.MeshBasicMaterial({ map:logoTex, transparent:true, opacity:0.82, depthWrite:false })
    );
    feltLogo.rotation.x = -Math.PI/2;
    feltLogo.position.set(0, tableTopY + 0.012, 0.05);
    scene.add(feltLogo);
  }

  const chipColors = [0xd55262, 0x171717, 0xece8f7, 0x2f73d9];
  const chipMat = chipColors.map((c)=> new THREE.MeshStandardMaterial({ color:c, roughness:0.5, metalness:0.08, emissive:c, emissiveIntensity:0.08 }));
  const chipGeo = new THREE.CylinderGeometry(0.085,0.085,0.022,24);
  const chipStacks = [
    [-0.58, -0.06, 5, 0],
    [-0.34, 0.18, 4, 1],
    [0.38, -0.08, 6, 2],
    [0.6, 0.2, 4, 3]
  ];
  for (const [x,z,count,matIx] of chipStacks){
    for (let i=0;i<count;i++){
      const chip = new THREE.Mesh(chipGeo, chipMat[matIx]);
      chip.position.set(x, tableTopY + 0.015 + i*0.018, z);
      chip.rotation.x = Math.PI/2;
      scene.add(chip);
    }
  }

  const cardGeo = new THREE.PlaneGeometry(0.18, 0.26);
  const cardBack = new THREE.MeshStandardMaterial({ color:0xf2f2f8, roughness:0.95, metalness:0.0, emissive:0x241538, emissiveIntensity:0.06 });
  const cards = [
    [-0.12, 0.46, -0.14],
    [0.12, 0.52, 0.15],
    [0, -0.42, -0.04]
  ];
  for (const [x,z,r] of cards){
    const card = new THREE.Mesh(cardGeo, cardBack);
    card.rotation.x = -Math.PI/2;
    card.rotation.z = r;
    card.position.set(x, tableTopY + 0.014, z);
    scene.add(card);
  }
}

export async function buildSkylineRoom(scene, { log=console.log } = {}){
  const R = CONFIG.ROOM_RADIUS ?? 28;
  const H = CONFIG.WALL_HEIGHT ?? 10.5;

  scene.fog = new THREE.FogExp2(0x06040a, 0.0085);
  scene.add(new THREE.HemisphereLight(0xf4efff, 0x09080d, 1.45));
  const key=new THREE.DirectionalLight(0xfaf5ff, 2.4);
  key.position.set(6,12,7);
  scene.add(key);
  const fill=new THREE.PointLight(0xb48cff, 3.8, 80, 2.0);
  fill.position.set(0,6.2,0.8);
  scene.add(fill);

  const floorMesh=new THREE.Mesh(
    new THREE.CircleGeometry(R+28, 160),
    new THREE.MeshStandardMaterial({ color:0x050508, roughness:0.97, metalness:0.02 })
  );
  floorMesh.rotation.x = -Math.PI/2;
  scene.add(floorMesh);

  const wallMesh=new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, H, 160, 1, true),
    new THREE.MeshStandardMaterial({ color:0x080710, roughness:0.86, metalness:0.05, emissive:0x1e0a28, emissiveIntensity:0.34, side:THREE.BackSide, transparent:true, opacity:0.86 })
  );
  wallMesh.position.set(0, H/2, 0);
  scene.add(wallMesh);

  const rimMesh=new THREE.Mesh(
    new THREE.TorusGeometry(R-0.55, 0.2, 12, 180),
    new THREE.MeshStandardMaterial({ color:0xc89cff, roughness:0.25, metalness:0.35, emissive:0x401060, emissiveIntensity:1.3 })
  );
  rimMesh.rotation.x = Math.PI/2;
  rimMesh.position.set(0, H-0.12, 0);
  scene.add(rimMesh);

  addStars(scene, 480);
  buildOuterCity(scene, R);
  const moonTex = await loadTextureWithFallback(CANDIDATES.MOON_TEX);
  addPlanetBackdrop(scene, moonTex);
  const tableLogoTex = await loadTextureWithFallback(CANDIDATES.TABLE_LOGO);

  scene.userData._tickWorld = (dt)=>{
    scene.userData._t=(scene.userData._t||0)+dt;
    const t = scene.userData._t;
    rimMesh.material.emissiveIntensity = 1.15 + Math.sin(t*0.8) * 0.15;
    if (scene.userData._planets){
      scene.userData._planets.moon.rotation.y += dt * 0.03;
      scene.userData._planets.earth.rotation.y += dt * 0.08;
      scene.userData._planets.glow.material.opacity = 0.07 + 0.03*Math.sin(t*1.1);
    }
  };

  const table = await tryLoadObject(CANDIDATES.TABLE, log, 12000) || createFallbackTable();
  table.traverse?.((c)=>{ if(c.isMesh){ c.castShadow=true; c.receiveShadow=true; } });
  scaleToHeight(table, 0.98);
  fitDiameter(table, 3.05);
  dropToGround(table);
  table.position.set(0,0,0);
  scene.add(table);
  const tableMetrics = boxMetrics(table);
  const tableTopY = tableMetrics.maxY;
  createSeatAndTableDecor(scene, tableTopY, tableLogoTex);

  const dealerRing = new THREE.Mesh(
    new THREE.RingGeometry(0.28,0.42,36),
    new THREE.MeshBasicMaterial({ color:0xd2a0ff, transparent:true, opacity:0.35, side:THREE.DoubleSide })
  );
  dealerRing.rotation.x = -Math.PI/2;
  dealerRing.position.set(0,0.014,-2.02);
  scene.add(dealerRing);

  const eric = await tryLoadObject(CANDIDATES.ERIC, log, 12000);
  if(eric){
    eric.traverse?.((c)=>{ if(c.isMesh){ c.castShadow=true; c.receiveShadow=true; } });
    scaleToHeight(eric, 1.8);
    dropToGround(eric);
    eric.position.set(0,0,-1.95);
    eric.rotation.y = Math.PI;
    scene.add(eric);
  }

  return { roomClamp: R-2.4 };
}
