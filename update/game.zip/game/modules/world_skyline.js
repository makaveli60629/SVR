import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { CONFIG } from "./config.js";
import { assetUrls, loadFirstTexture } from "./asset_base.js";

function delay(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }

async function withTimeout(promise, ms){
  return await Promise.race([
    promise,
    (async()=>{ await delay(ms); throw new Error("timeout"); })()
  ]);
}

function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  return { size, center };
}

function dropToGround(obj){
  const { size, center } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - center.y;
}

function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}

function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia = Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

async function tryLoadGLTF(urls, log, timeoutMs = 12000){
  const loader = new GLTFLoader();
  for (const url of urls){
    try{
      const gltf = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded GLTF:", url);
      return gltf.scene;
    }catch(err){
      log("GLTF miss:", url);
    }
  }
  return null;
}

async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const fbx = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded FBX:", url);
      return fbx;
    }catch(err){
      log("FBX miss:", url);
    }
  }
  return null;
}

function applyFallbackCharacterMaterial(obj){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    child.material = new THREE.MeshStandardMaterial({
      color: 0xd6d4e8,
      roughness: 0.62,
      metalness: 0.08,
      emissive: 0x120f20,
      emissiveIntensity: 0.18
    });
  });
}

function applyTableMaterial(obj){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    const old = child.material;
    if (Array.isArray(old)) return;
    if (!old || !old.map){
      child.material = new THREE.MeshStandardMaterial({
        color: 0x2b2333,
        roughness: 0.72,
        metalness: 0.18,
        emissive: 0x12081a,
        emissiveIntensity: 0.08
      });
    }
  });
}

function addSeat(scene, x, z, color = 0x7b42d9){
  const group = new THREE.Group();

  const stool = new THREE.Mesh(
    new THREE.CylinderGeometry(0.24, 0.27, 0.52, 24),
    new THREE.MeshStandardMaterial({
      color: 0x2b2333,
      roughness: 0.6,
      metalness: 0.18,
      emissive: 0x11071a,
      emissiveIntensity: 0.1
    })
  );
  stool.position.set(0, 0.26, 0);
  group.add(stool);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.32, 0.44, 40),
    new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: 0.7,
      side: THREE.DoubleSide
    })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.014;
  group.add(ring);

  group.position.set(x, 0, z);
  scene.add(group);
  return group;
}

function addChipsAndCards(scene){
  const group = new THREE.Group();
  const chipMatA = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.35, metalness: 0.25, emissive: 0x230d30, emissiveIntensity: 0.35 });
  const chipMatB = new THREE.MeshStandardMaterial({ color: 0x00e2c7, roughness: 0.35, metalness: 0.25, emissive: 0x06261f, emissiveIntensity: 0.28 });
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf2f2ff, roughness: 0.85, metalness: 0.03 });

  const stacks = [
    [-0.72, 0.92, chipMatA],
    [-0.30, 1.02, chipMatB],
    [0.32, 0.97, chipMatA],
    [0.72, 0.86, chipMatB]
  ];

  for (const [x, z, mat] of stacks){
    for (let i = 0; i < 5; i++){
      const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.018, 24), mat);
      chip.position.set(x, 0.84 + i * 0.02, z - 0.15);
      chip.rotation.x = Math.PI / 2;
      group.add(chip);
    }
  }

  for (let i = 0; i < 5; i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.003, 0.18), cardMat);
    card.position.set(-0.28 + i * 0.14, 0.84, -0.02 + (i % 2) * 0.01);
    card.rotation.y = -0.15 + i * 0.08;
    group.add(card);
  }

  scene.add(group);
  return group;
}

function buildOuterCity(scene, R){
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x0c0c18,
    roughness: 0.78,
    metalness: 0.12,
    emissive: 0x140a22,
    emissiveIntensity: 0.65
  });
  const glowMat = new THREE.MeshStandardMaterial({
    color: 0xb48cff,
    roughness: 0.22,
    metalness: 0.22,
    emissive: 0x2a0d3a,
    emissiveIntensity: 1.3
  });

  const group = new THREE.Group();
  const count = 120;

  for (let i = 0; i < count; i++){
    const a = (i / count) * Math.PI * 2;
    const rr = (R + 7) + Math.random() * 9;
    const h = 6 + Math.random() * 22;
    const w = 1.4 + Math.random() * 3.2;
    const d = 1.4 + Math.random() * 3.2;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;

    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), baseMat);
    body.position.set(x, h / 2, z);
    body.rotation.y = -a + Math.PI / 2;
    group.add(body);

    if (Math.random() < 0.72){
      const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.94, 0.18, d * 1.05), glowMat);
      strip.position.set(x, 1.8 + Math.random() * (h - 3.0), z);
      strip.rotation.y = body.rotation.y;
      group.add(strip);
    }
  }

  const landmarks = [
    { x: -9.5, z: -(R + 9), h: 26, w: 1.5, d: 1.5 },
    { x: 0, z: -(R + 10), h: 28, w: 2.1, d: 2.1 },
    { x: 9.3, z: -(R + 9), h: 24, w: 1.9, d: 1.9 }
  ];

  for (const lm of landmarks){
    const tower = new THREE.Mesh(new THREE.BoxGeometry(lm.w, lm.h, lm.d), baseMat);
    tower.position.set(lm.x, lm.h / 2, lm.z);
    group.add(tower);

    const crown = new THREE.Mesh(new THREE.BoxGeometry(lm.w * 1.05, 0.22, lm.d * 1.08), glowMat);
    crown.position.set(lm.x, lm.h - 0.6, lm.z);
    group.add(crown);
  }

  scene.add(group);
}

export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const R = CONFIG.ROOM_RADIUS;
  const H = CONFIG.WALL_HEIGHT;

  scene.add(new THREE.HemisphereLight(0xffffff, 0x0a0a18, 1.45));

  const key = new THREE.DirectionalLight(0xffffff, 1.3);
  key.position.set(5, 12, 7);
  scene.add(key);

  const centerLight = new THREE.PointLight(0xb48cff, 2.8, 90, 2.0);
  centerLight.position.set(0, 5.8, 0);
  scene.add(centerLight);

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(R + 20, 160),
    new THREE.MeshStandardMaterial({ color: 0x050508, roughness: 0.95, metalness: 0.02 })
  );
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  const platform = new THREE.Mesh(
    new THREE.CylinderGeometry(7.2, 7.5, 0.28, 80),
    new THREE.MeshStandardMaterial({
      color: 0x18131e,
      roughness: 0.8,
      metalness: 0.16,
      emissive: 0x12071a,
      emissiveIntensity: 0.18
    })
  );
  platform.position.y = 0.14;
  scene.add(platform);

  const feltTex = await loadFirstTexture(assetUrls("texture/tablefelt.png"), { colorSpace: THREE.SRGBColorSpace });
  const felt = new THREE.Mesh(
    new THREE.CylinderGeometry(2.1, 2.1, 0.06, 80),
    new THREE.MeshStandardMaterial({
      color: 0x17322c,
      roughness: 0.92,
      metalness: 0.03,
      map: feltTex || null
    })
  );
  felt.position.y = 0.81;
  scene.add(felt);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, H, 160, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0x070712,
      roughness: 0.85,
      metalness: 0.06,
      emissive: 0x2a0d3a,
      emissiveIntensity: 0.45,
      side: THREE.BackSide
    })
  );
  wall.position.set(0, H / 2, 0);
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(R - 0.8, 0.18, 14, 180),
    new THREE.MeshStandardMaterial({
      color: 0xb48cff,
      roughness: 0.25,
      metalness: 0.35,
      emissive: 0x2a0d3a,
      emissiveIntensity: 1.5
    })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.set(0, H - 0.4, 0);
  scene.add(rim);

  buildOuterCity(scene, R);

  const moonTex = await loadFirstTexture(assetUrls("texture/moon_diffuse.png"), { colorSpace: THREE.SRGBColorSpace });
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(5.8, 32, 32),
    new THREE.MeshStandardMaterial({
      color: 0xe9e9ff,
      roughness: 1.0,
      metalness: 0.0,
      map: moonTex || null,
      emissive: 0x161621,
      emissiveIntensity: 0.2
    })
  );
  moon.position.set(-26, 21, -(R + 20));
  scene.add(moon);

  addSeat(scene, 0, 3.05);
  addSeat(scene, -2.45, 0.5);
  addSeat(scene, 2.45, 0.5);
  addSeat(scene, 0, -3.25, 0x9333ea);
  addChipsAndCards(scene);

  const table = await tryLoadGLTF(assetUrls("models/table.glb"), log, 10000) || await tryLoadFBX(assetUrls("models/table.fbx"), log, 10000);
  if (table){
    applyTableMaterial(table);
    scaleToHeight(table, 0.94);
    dropToGround(table);
    fitDiameter(table, 3.05);
    dropToGround(table);
    table.position.set(0, 0, 0);
    scene.add(table);
  } else {
    const fallbackTable = new THREE.Mesh(
      new THREE.CylinderGeometry(1.62, 1.74, 0.18, 64),
      new THREE.MeshStandardMaterial({
        color: 0x2b2333,
        roughness: 0.78,
        metalness: 0.12,
        emissive: 0x15091e,
        emissiveIntensity: 0.18
      })
    );
    fallbackTable.position.y = 0.86;
    scene.add(fallbackTable);
  }

  const eric = await tryLoadFBX(assetUrls("models/eric/eric.fbx"), log, 12000);
  if (eric){
    applyFallbackCharacterMaterial(eric);
    scaleToHeight(eric, 1.78);
    dropToGround(eric);
    eric.position.set(0, 0, -2.15);
    eric.rotation.y = Math.PI;
    scene.add(eric);
  } else {
    const dealer = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.8, 8, 16), new THREE.MeshStandardMaterial({ color: 0xbfc3d9, roughness: 0.55 }));
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 18, 18), new THREE.MeshStandardMaterial({ color: 0xded8cf, roughness: 0.75 }));
    body.position.y = 1.0;
    head.position.y = 1.7;
    dealer.add(body, head);
    dealer.position.set(0, 0, -2.15);
    dealer.rotation.y = Math.PI;
    scene.add(dealer);
  }

  scene.userData._tickWorld = (dt)=>{
    scene.userData._time = (scene.userData._time || 0) + dt;
    moon.rotation.y += dt * 0.04;
    rim.material.emissiveIntensity = 1.25 + Math.sin(scene.userData._time * 1.2) * 0.18;
  };

  return { roomClamp: R - 1.8 };
}
