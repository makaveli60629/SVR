import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { CONFIG } from "./config.js";
import { assetUrls, loadFirstTexture } from "./asset_base.js";

function delay(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }
async function withTimeout(promise, ms){
  return await Promise.race([
    promise,
    (async()=>{ await delay(ms); throw new Error("timeout"); })()
  ]);
}

function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  return { size, center };
}
function dropToGround(obj){
  const { size, center } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - center.y;
}
function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}
function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia = Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

async function tryLoadGLTF(urls, log, timeoutMs = 12000){
  const loader = new GLTFLoader();
  for (const url of urls){
    try{
      const gltf = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded GLTF:", url);
      return gltf.scene;
    }catch(err){ log("GLTF miss:", url); }
  }
  return null;
}
async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const fbx = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded FBX:", url);
      return fbx;
    }catch(err){ log("FBX miss:", url); }
  }
  return null;
}

function makeSpriteTexture(){
  const c = document.createElement("canvas");
  c.width = 128; c.height = 128;
  const x = c.getContext("2d");
  const g = x.createRadialGradient(64,64,4,64,64,60);
  g.addColorStop(0,"rgba(255,255,255,1)");
  g.addColorStop(0.18,"rgba(200,220,255,0.95)");
  g.addColorStop(0.45,"rgba(180,140,255,0.3)");
  g.addColorStop(1,"rgba(180,140,255,0)");
  x.fillStyle = g;
  x.fillRect(0,0,128,128);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeEarthTexture(){
  const c = document.createElement("canvas");
  c.width = 1024; c.height = 512;
  const x = c.getContext("2d");
  x.fillStyle = "#0a2c60";
  x.fillRect(0,0,c.width,c.height);
  for (let i = 0; i < 60; i++){
    x.fillStyle = `rgba(${20 + Math.random()*40|0}, ${90 + Math.random()*80|0}, ${60 + Math.random()*60|0}, ${0.55 + Math.random()*0.25})`;
    x.beginPath();
    const px = Math.random() * c.width;
    const py = Math.random() * c.height;
    const rx = 40 + Math.random() * 130;
    const ry = 18 + Math.random() * 75;
    x.ellipse(px, py, rx, ry, Math.random()*Math.PI, 0, Math.PI*2);
    x.fill();
  }
  x.fillStyle = "rgba(255,255,255,0.18)";
  for (let i = 0; i < 18; i++){
    x.beginPath();
    const px = Math.random() * c.width;
    const py = Math.random() * c.height;
    const rx = 60 + Math.random() * 180;
    const ry = 15 + Math.random() * 40;
    x.ellipse(px, py, rx, ry, Math.random()*Math.PI, 0, Math.PI*2);
    x.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildStars(scene, R){
  const count = 2400;
  const pos = new Float32Array(count * 3);
  const col = new Float32Array(count * 3);
  for (let i = 0; i < count; i++){
    const rr = R + 45 + Math.random() * 90;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.46 + 0.06;
    pos[i*3+0] = Math.cos(theta) * Math.sin(phi) * rr;
    pos[i*3+1] = Math.cos(phi) * rr * 0.9 + 30;
    pos[i*3+2] = Math.sin(theta) * Math.sin(phi) * rr;

    const tint = 0.8 + Math.random() * 0.2;
    col[i*3+0] = tint;
    col[i*3+1] = 0.88 + Math.random() * 0.12;
    col[i*3+2] = 0.95 + Math.random() * 0.05;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({
    size: 0.42,
    sizeAttenuation: true,
    transparent: true,
    opacity: 0.95,
    map: makeSpriteTexture(),
    vertexColors: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  }));
  scene.add(pts);

  const spriteGroup = new THREE.Group();
  for (let i = 0; i < 140; i++){
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: makeSpriteTexture(),
      color: new THREE.Color(i % 5 === 0 ? 0xb48cff : 0xffffff),
      transparent: true,
      opacity: 0.5 + Math.random() * 0.25,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    }));
    spr.scale.setScalar(0.55 + Math.random() * 0.85);
    const rr = R + 38 + Math.random() * 70;
    const theta = Math.random() * Math.PI * 2;
    const y = 16 + Math.random() * 55;
    spr.position.set(Math.cos(theta) * rr, y, Math.sin(theta) * rr);
    spriteGroup.add(spr);
  }
  scene.add(spriteGroup);
  return { pts, spriteGroup };
}

function buildOuterCity(scene, R){
  const group = new THREE.Group();
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x080a14,
    roughness: 0.76,
    metalness: 0.1,
    emissive: 0x180b22,
    emissiveIntensity: 0.4
  });
  const glowMat = new THREE.MeshStandardMaterial({
    color: 0xb48cff,
    roughness: 0.18,
    metalness: 0.25,
    emissive: 0x36124d,
    emissiveIntensity: 1.5
  });

  const count = 220;
  for (let i = 0; i < count; i++){
    const a = (i / count) * Math.PI * 2;
    const rr = (R + 6) + Math.random() * 18;
    const h = 8 + Math.random() * 38;
    const w = 1.8 + Math.random() * 4.0;
    const d = 1.8 + Math.random() * 4.0;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;

    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), baseMat);
    body.position.set(x, h / 2, z);
    body.rotation.y = -a + Math.PI / 2;
    group.add(body);

    const stripCount = 2 + (Math.random() * 4 | 0);
    for (let s = 0; s < stripCount; s++){
      const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.95, 0.16, d * 1.03), glowMat);
      strip.position.set(x, 2 + ((s + 1) / (stripCount + 1)) * (h - 3), z);
      strip.rotation.y = body.rotation.y;
      group.add(strip);
    }
  }
  scene.add(group);
  return group;
}

function makeSeat(scene, x, z, angle, label){
  const group = new THREE.Group();
  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(0.34, 0.38, 0.1, 32),
    new THREE.MeshStandardMaterial({ color: 0x14131c, roughness: 0.74, metalness: 0.12, emissive: 0x0d0715, emissiveIntensity: 0.12 })
  );
  base.position.y = 0.05;
  group.add(base);

  const seat = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.31, 0.14, 32),
    new THREE.MeshStandardMaterial({ color: 0x24182f, roughness: 0.58, metalness: 0.16, emissive: 0x160a20, emissiveIntensity: 0.15 })
  );
  seat.position.y = 0.38;
  group.add(seat);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.36, 0.53, 48),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.72, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.014;
  group.add(ring);

  group.position.set(x, 0, z);
  group.rotation.y = angle;
  scene.add(group);
  return { group, ring, x, z, angle, label };
}

function addChipsAndCards(scene){
  const group = new THREE.Group();
  const chipMatA = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.35, metalness: 0.25, emissive: 0x230d30, emissiveIntensity: 0.35 });
  const chipMatB = new THREE.MeshStandardMaterial({ color: 0x00e2c7, roughness: 0.35, metalness: 0.25, emissive: 0x06261f, emissiveIntensity: 0.28 });
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf2f2ff, roughness: 0.85, metalness: 0.03 });
  const stacks = [[-0.92, 1.08, chipMatA],[-0.38, 1.18, chipMatB],[0.42, 1.14, chipMatA],[0.95, 1.0, chipMatB]];
  for (const [x, z, mat] of stacks){
    for (let i = 0; i < 6; i++){
      const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.018, 24), mat);
      chip.position.set(x, 0.845 + i * 0.02, z - 0.19);
      chip.rotation.x = Math.PI / 2;
      group.add(chip);
    }
  }
  for (let i = 0; i < 5; i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.003, 0.18), cardMat);
    card.position.set(-0.3 + i * 0.15, 0.842, -0.03 + (i % 2) * 0.01);
    card.rotation.y = -0.18 + i * 0.09;
    group.add(card);
  }
  scene.add(group);
}

function applyEricMaterial(obj, texture, normalTex){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    child.material = new THREE.MeshStandardMaterial({
      map: texture || null,
      normalMap: normalTex || null,
      color: texture ? 0xffffff : 0xd6d4e8,
      roughness: 0.7,
      metalness: 0.02,
      emissive: 0x0d0914,
      emissiveIntensity: 0.06,
      skinning: !!child.isSkinnedMesh
    });
  });
}

function touchModelShadows(obj){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    if (!Array.isArray(child.material) && child.material){
      child.material.side = THREE.DoubleSide;
    }
  });
}

export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const R = CONFIG.ROOM_RADIUS;
  const H = CONFIG.WALL_HEIGHT;

  scene.fog = new THREE.FogExp2(0x04050a, 0.0085);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x070913, 1.18));

  const key = new THREE.DirectionalLight(0xffffff, 1.35);
  key.position.set(12, 24, 10);
  scene.add(key);

  const rimLight = new THREE.PointLight(0xb48cff, 4.2, 140, 2.0);
  rimLight.position.set(0, 8.6, 0);
  scene.add(rimLight);

  const floorTex = await loadFirstTexture(assetUrls("texture/cloth_diffuse.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const floorBump = await loadFirstTexture(assetUrls("texture/cloth_bump.jpg"));
  if (floorTex){
    floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
    floorTex.repeat.set(16, 16);
  }
  if (floorBump){
    floorBump.wrapS = floorBump.wrapT = THREE.RepeatWrapping;
    floorBump.repeat.set(16, 16);
  }

  const wallTex = await loadFirstTexture(assetUrls("texture/leather_dark.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const wallBump = await loadFirstTexture(assetUrls("texture/leather_dark_bump.jpg"));
  if (wallTex){
    wallTex.wrapS = wallTex.wrapT = THREE.RepeatWrapping;
    wallTex.repeat.set(9, 2.8);
  }
  if (wallBump){
    wallBump.wrapS = wallBump.wrapT = THREE.RepeatWrapping;
    wallBump.repeat.set(9, 2.8);
  }

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(R + 30, 180),
    new THREE.MeshStandardMaterial({
      color: 0x0a0a10,
      roughness: 0.98,
      metalness: 0.02,
      map: floorTex || null,
      bumpMap: floorBump || null,
      bumpScale: floorBump ? 0.22 : 0
    })
  );
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, H, 180, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0x0b0c16,
      roughness: 0.84,
      metalness: 0.05,
      emissive: 0x180b25,
      emissiveIntensity: 0.16,
      side: THREE.BackSide,
      map: wallTex || null,
      bumpMap: wallBump || null,
      bumpScale: wallBump ? 0.08 : 0
    })
  );
  wall.position.set(0, H / 2, 0);
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(R - 1.2, 0.18, 16, 220),
    new THREE.MeshStandardMaterial({
      color: 0xb48cff,
      roughness: 0.2,
      metalness: 0.35,
      emissive: 0x2a0d3a,
      emissiveIntensity: 1.4
    })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.set(0, H - 0.55, 0);
  scene.add(rim);

  const innerPlatform = new THREE.Mesh(
    new THREE.CylinderGeometry(8.4, 8.8, 0.28, 96),
    new THREE.MeshStandardMaterial({
      color: 0x14121b,
      roughness: 0.78,
      metalness: 0.12,
      emissive: 0x12061c,
      emissiveIntensity: 0.12
    })
  );
  innerPlatform.position.y = 0.14;
  scene.add(innerPlatform);

  const city = buildOuterCity(scene, R);
  const stars = buildStars(scene, R);

  const moonTex = await loadFirstTexture(assetUrls("texture/moon_diffuse.png"), { colorSpace: THREE.SRGBColorSpace });
  const moonBump = await loadFirstTexture(assetUrls("texture/moon_bump.png"));
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(5.6, 40, 40),
    new THREE.MeshStandardMaterial({
      color: 0xe9e9ff,
      roughness: 1.0,
      metalness: 0.0,
      map: moonTex || null,
      bumpMap: moonBump || null,
      bumpScale: moonBump ? 0.18 : 0,
      emissive: 0x0f1020,
      emissiveIntensity: 0.16
    })
  );
  moon.position.set(-26, 28, -(R + 32));
  scene.add(moon);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(7.8, 48, 48),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.95,
      metalness: 0.0,
      map: makeEarthTexture(),
      emissive: 0x061227,
      emissiveIntensity: 0.22
    })
  );
  earth.position.set(34, 24, -(R + 46));
  scene.add(earth);

  const earthGlow = new THREE.PointLight(0x4fa6ff, 2.6, 80, 2.0);
  earthGlow.position.copy(earth.position).add(new THREE.Vector3(0,0,10));
  scene.add(earthGlow);

  addChipsAndCards(scene);

  const seatRadius = 3.35;
  const seats = [
    makeSeat(scene, 0,  seatRadius, Math.PI, "Front Center"),
    makeSeat(scene, -2.75, 1.78, Math.PI * 0.72, "Front Left"),
    makeSeat(scene,  2.75, 1.78, -Math.PI * 0.72, "Front Right"),
    makeSeat(scene, -2.75, -1.78, Math.PI * 0.28, "Back Left"),
    makeSeat(scene,  2.75, -1.78, -Math.PI * 0.28, "Back Right"),
    makeSeat(scene, 0, -seatRadius, 0, "Dealer Side")
  ];

  const table = await tryLoadGLTF(assetUrls("models/table.glb"), log, 10000) || await tryLoadFBX(assetUrls("models/table.fbx"), log, 10000);
  if (table){
    touchModelShadows(table);
    scaleToHeight(table, 0.96);
    dropToGround(table);
    fitDiameter(table, 3.25);
    dropToGround(table);
    table.position.set(0, 0, 0);
    scene.add(table);
  }

  const ericTex = await loadFirstTexture(assetUrls("models/eric/rp_eric_rigged_001_dif.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const ericNorm = await loadFirstTexture(assetUrls("models/eric/rp_eric_rigged_001_norm.jpg"));
  const eric = await tryLoadFBX(assetUrls("models/eric/eric.fbx"), log, 12000);
  if (eric){
    applyEricMaterial(eric, ericTex, ericNorm);
    scaleToHeight(eric, 1.78);
    dropToGround(eric);
    eric.position.set(0, 0, -2.25);
    eric.rotation.y = 0;
    scene.add(eric);
  }

  const atmosphereGlow = new THREE.Mesh(
    new THREE.SphereGeometry(R + 8, 42, 42),
    new THREE.MeshBasicMaterial({ color: 0x140820, transparent: true, opacity: 0.06, side: THREE.BackSide })
  );
  scene.add(atmosphereGlow);

  scene.userData._tickWorld = (dt)=>{
    scene.userData._time = (scene.userData._time || 0) + dt;
    const t = scene.userData._time;
    moon.rotation.y += dt * 0.03;
    earth.rotation.y += dt * 0.05;
    earth.rotation.z = Math.sin(t * 0.08) * 0.08;
    rim.material.emissiveIntensity = 1.25 + Math.sin(t * 1.2) * 0.22;
    stars.spriteGroup.rotation.y += dt * 0.0035;
    city.rotation.y += dt * 0.0025;
  };

  return {
    roomClamp: R - 2.5,
    tableCenter: new THREE.Vector3(0, 0, 0),
    seats,
    joinRadius: 6.2,
    previewOrbitRadius: 10.5
  };
}
