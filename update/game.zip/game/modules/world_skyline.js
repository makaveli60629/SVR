import * as THREE from 'three';
import { CONFIG } from './config.js';

function loadTexture(url){
  const loader = new THREE.TextureLoader();
  return new Promise((resolve)=>{
    loader.load(url, (t)=>{ t.colorSpace = THREE.SRGBColorSpace; resolve(t); }, undefined, ()=>resolve(null));
  });
}

function makeMaterial(color, emissive=0x000000, emissiveIntensity=0){
  return new THREE.MeshStandardMaterial({
    color,
    roughness: 0.6,
    metalness: 0.12,
    emissive,
    emissiveIntensity,
  });
}

function addStars(scene, flareTex, R){
  const grp = new THREE.Group();
  const count = 180;
  for (let i=0;i<count;i++){
    const s = new THREE.Sprite(new THREE.SpriteMaterial({
      map: flareTex || null,
      color: 0xf4f2ff,
      transparent: true,
      opacity: 0.85,
      depthWrite: false,
    }));
    const ang = Math.random() * Math.PI * 2;
    const rr = R + 30 + Math.random() * 36;
    const h = 22 + Math.random() * 32;
    s.position.set(Math.cos(ang) * rr, h, Math.sin(ang) * rr);
    const scale = 0.18 + Math.random() * 0.22;
    s.scale.setScalar(scale);
    grp.add(s);
  }
  scene.add(grp);
}

function addOuterCity(scene, R){
  const grp = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({
    color: 0x0c1018,
    roughness: 0.72,
    metalness: 0.22,
    emissive: 0x0a1020,
    emissiveIntensity: 0.35,
  });
  const winMat = new THREE.MeshStandardMaterial({
    color: 0xcfd6ff,
    roughness: 0.18,
    metalness: 0.08,
    emissive: 0x6fa0ff,
    emissiveIntensity: 0.55,
  });

  const count = 64;
  for (let i=0;i<count;i++){
    const ang = (i / count) * Math.PI * 2;
    const rr = R + 9 + Math.random() * 10;
    const w = 2 + Math.random() * 3.8;
    const d = 2 + Math.random() * 3.8;
    const h = 8 + Math.random() * 24;
    const x = Math.cos(ang) * rr;
    const z = Math.sin(ang) * rr;
    const tower = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), bodyMat);
    tower.position.set(x, h / 2, z);
    tower.rotation.y = -ang + Math.PI / 2;
    tower.castShadow = true;
    tower.receiveShadow = true;
    grp.add(tower);

    if (Math.random() < 0.9){
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.18, d * 1.02), winMat);
      stripe.position.set(x, 2 + Math.random() * Math.max(2, h - 4), z);
      stripe.rotation.y = tower.rotation.y;
      grp.add(stripe);
    }
  }
  scene.add(grp);
}

function buildChair(){
  const grp = new THREE.Group();
  const seatMat = new THREE.MeshStandardMaterial({
    color: 0x1b1523,
    roughness: 0.58,
    metalness: 0.18,
    emissive: 0x170d20,
    emissiveIntensity: 0.25,
  });
  const legMat = new THREE.MeshStandardMaterial({
    color: 0x2d2340,
    roughness: 0.35,
    metalness: 0.4,
  });
  const seat = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.52, 0.12, 28), seatMat);
  seat.position.y = 0.56;
  seat.castShadow = true;
  seat.receiveShadow = true;
  grp.add(seat);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.75, 0.12), seatMat);
  back.position.set(0, 0.95, -0.34);
  back.castShadow = true;
  grp.add(back);
  for (const dx of [-0.22, 0.22]){
    for (const dz of [-0.18, 0.18]){
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.58, 10), legMat);
      leg.position.set(dx, 0.28, dz);
      leg.castShadow = true;
      grp.add(leg);
    }
  }
  return grp;
}

function buildDealer(scene){
  const grp = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x22222e, roughness: 0.72, metalness: 0.06 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xb68b72, roughness: 0.85, metalness: 0.0 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.72, 4, 8), bodyMat);
  torso.position.y = 1.05;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 20, 20), skinMat);
  head.position.y = 1.65;
  grp.add(torso, head);
  grp.position.set(0, 0, -3.05);
  grp.rotation.y = Math.PI;
  scene.add(grp);
}

function addTable(scene){
  const grp = new THREE.Group();
  const railMat = new THREE.MeshStandardMaterial({
    color: 0x241a2b,
    roughness: 0.58,
    metalness: 0.14,
    emissive: 0x100914,
    emissiveIntensity: 0.15,
  });
  const feltMat = new THREE.MeshStandardMaterial({
    color: 0x145e2a,
    roughness: 0.92,
    metalness: 0.0,
    emissive: 0x04200c,
    emissiveIntensity: 0.18,
  });
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x17111f, roughness: 0.65, metalness: 0.18 });

  const top = new THREE.Mesh(new THREE.CylinderGeometry(2.7, 2.95, 0.18, 48), railMat);
  top.position.y = 0.93;
  top.castShadow = true;
  top.receiveShadow = true;
  grp.add(top);

  const felt = new THREE.Mesh(new THREE.CylinderGeometry(2.05, 2.12, 0.03, 48), feltMat);
  felt.position.y = 0.985;
  felt.castShadow = true;
  felt.receiveShadow = true;
  grp.add(felt);

  const rim = new THREE.Mesh(new THREE.TorusGeometry(2.24, 0.1, 12, 64), railMat);
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 1.02;
  grp.add(rim);

  const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.42, 0.92, 24), baseMat);
  pedestal.position.y = 0.46;
  pedestal.castShadow = true;
  grp.add(pedestal);

  const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.1, 0.1, 32), baseMat);
  foot.position.y = 0.05;
  foot.receiveShadow = true;
  grp.add(foot);

  // cards and chips for visual feedback
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf7f7fb, roughness: 0.6, metalness: 0.0 });
  const chipMat = new THREE.MeshStandardMaterial({ color: 0xd44545, roughness: 0.35, metalness: 0.08, emissive: 0x2a0808, emissiveIntensity: 0.2 });
  for (let i=0;i<2;i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.01, 0.56), cardMat);
    card.position.set(-0.18 + i * 0.42, 1.005, 1.2);
    card.rotation.y = 0.12 * (i ? -1 : 1);
    grp.add(card);
  }
  for (let i=0;i<6;i++){
    const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.08, 20), chipMat);
    chip.position.set(0.9 + (i % 3) * 0.12, 1.03 + Math.floor(i / 3) * 0.05, 1.1);
    grp.add(chip);
  }

  scene.add(grp);
  return grp;
}

async function addMoonAndEarth(scene, R){
  const moonUrl = new URL('../assets/textures/moon_recovery_diffuse.png', import.meta.url).toString();
  const earthUrl = new URL('../assets/textures/earth_recovery_diffuse.png', import.meta.url).toString();
  const flareUrl = new URL('../flare.png', import.meta.url).toString();
  const [moonTex, earthTex, flareTex] = await Promise.all([
    loadTexture(moonUrl),
    loadTexture(earthUrl),
    loadTexture(flareUrl),
  ]);

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(7.8, 40, 40),
    new THREE.MeshStandardMaterial({
      map: moonTex,
      color: 0xffffff,
      roughness: 1.0,
      metalness: 0.0,
      emissive: new THREE.Color(0xb7c7ff),
      emissiveIntensity: 0.6,
    })
  );
  moon.position.set(-18, 56, -(R + 48));
  scene.add(moon);

  const moonHalo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: flareTex,
    color: 0xdfe8ff,
    transparent: true,
    opacity: 0.55,
    depthWrite: false,
  }));
  moonHalo.scale.set(24, 24, 1);
  moonHalo.position.copy(moon.position);
  scene.add(moonHalo);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(4.6, 32, 32),
    new THREE.MeshStandardMaterial({
      map: earthTex,
      color: 0xffffff,
      roughness: 0.95,
      metalness: 0.0,
      emissive: new THREE.Color(0x4fa4ff),
      emissiveIntensity: 0.55,
    })
  );
  earth.position.set(16, 46, -(R + 60));
  scene.add(earth);

  const earthHalo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: flareTex,
    color: 0x8bc7ff,
    transparent: true,
    opacity: 0.34,
    depthWrite: false,
  }));
  earthHalo.scale.set(14, 14, 1);
  earthHalo.position.copy(earth.position);
  scene.add(earthHalo);

  scene.userData._tickWorld = (dt)=>{
    moon.rotation.y += dt * 0.03;
    earth.rotation.y += dt * 0.06;
    earth.position.x = 16 + Math.sin(performance.now() * 0.00007) * 2.4;
    earth.position.y = 46 + Math.cos(performance.now() * 0.00005) * 1.2;
    earthHalo.position.copy(earth.position);
  };

  return flareTex;
}

export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const R = CONFIG.ROOM_RADIUS ?? 32;
  const H = CONFIG.WALL_HEIGHT ?? 22;

  scene.fog = new THREE.FogExp2(0x050608, 0.012);

  const hemi = new THREE.HemisphereLight(0xeef3ff, 0x06080f, 2.3);
  scene.add(hemi);

  const key = new THREE.DirectionalLight(0xc7d6ff, 2.3);
  key.position.set(-22, 34, -28);
  key.castShadow = false;
  scene.add(key);

  const accent = new THREE.PointLight(0xb48cff, 18, 45, 2.0);
  accent.position.set(0, 6, 0);
  scene.add(accent);

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(R + 22, 120),
    new THREE.MeshStandardMaterial({ color: 0x050508, roughness: 0.96, metalness: 0.02 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, H, 120, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0x0a0b12,
      roughness: 0.86,
      metalness: 0.06,
      emissive: 0x190926,
      emissiveIntensity: 0.22,
      side: THREE.BackSide,
    })
  );
  wall.position.set(0, H / 2, 0);
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(R - 0.45, 0.14, 12, 96),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, emissive: 0x4b1b73, emissiveIntensity: 1.2, roughness: 0.25, metalness: 0.35 })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.y = H - 0.35;
  scene.add(rim);

  const flareTex = await addMoonAndEarth(scene, R);
  addStars(scene, flareTex, R);
  addOuterCity(scene, R);
  addTable(scene);

  for (let i = 0; i < 6; i++){
    const chair = buildChair();
    const ang = (i / 6) * Math.PI * 2 + Math.PI / 6;
    const rr = 3.75;
    chair.position.set(Math.cos(ang) * rr, 0, Math.sin(ang) * rr);
    chair.rotation.y = -ang + Math.PI;
    scene.add(chair);
  }

  buildDealer(scene);
  log('Quest-safe geometry recovery scene built');
  return { roomClamp: R - 2 };
}
