import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { CONFIG } from "./config.js";
import { urlsFor } from "./asset_base.js";

const CANDIDATES = {
  TABLE: [ ...urlsFor("table/table.fbx") ],
  ERIC:  [ ...urlsFor("npc/eric/eric.fbx") ],
};

function delay(ms){ return new Promise(r => setTimeout(r, ms)); }

async function loadFBXWithTimeout(loader, url, ms){
  return await Promise.race([
    loader.loadAsync(url),
    (async()=>{ await delay(ms); throw new Error("timeout"); })(),
  ]);
}

async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const obj = await loadFBXWithTimeout(loader, url, timeoutMs);
      log("Loaded FBX:", url);
      return obj;
    }catch(err){
      log("FBX missing/timeout:", url);
    }
  }
  return null;
}

function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const ctr = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(ctr);
  return { size, ctr };
}

function dropToGround(obj){
  const { size, ctr } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - ctr.y;
}

function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}

function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia = Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

function buildOuterCity(scene, radius){
  const towerMat = new THREE.MeshStandardMaterial({
    color: 0x0c0c18,
    roughness: 0.78,
    metalness: 0.12,
    emissive: 0x140a22,
    emissiveIntensity: 0.65,
  });
  const windowMat = new THREE.MeshStandardMaterial({
    color: 0xb48cff,
    roughness: 0.25,
    metalness: 0.22,
    emissive: 0x2a0d3a,
    emissiveIntensity: 1.2,
  });

  const group = new THREE.Group();
  const count = 160;
  for (let i = 0; i < count; i++){
    const angle = (i / count) * Math.PI * 2;
    const ring = radius + 12 + Math.random() * 12;
    const h = 10 + Math.random() * 40;
    const w = 1.6 + Math.random() * 4.1;
    const d = 1.6 + Math.random() * 4.1;
    const x = Math.cos(angle) * ring;
    const z = Math.sin(angle) * ring;

    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), towerMat);
    body.position.set(x, h / 2, z);
    body.rotation.y = -angle + Math.PI / 2;
    group.add(body);

    if (Math.random() < 0.72){
      const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.22, d * 1.04), windowMat);
      strip.position.set(x, 2 + Math.random() * Math.max(2, h - 5), z);
      strip.rotation.y = body.rotation.y;
      group.add(strip);
    }
  }

  // Landmark silhouettes.
  const willis = new THREE.Mesh(
    new THREE.BoxGeometry(4.8, 44, 4.8),
    new THREE.MeshStandardMaterial({ color: 0x151526, roughness: 0.7, metalness: 0.12, emissive: 0x1b1033, emissiveIntensity: 0.55 })
  );
  willis.position.set(-14, 22, -(radius + 18));
  group.add(willis);
  for (const dx of [-0.6, 0.6]){
    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.2, 8), new THREE.MeshBasicMaterial({ color: 0xff4a4a }));
    antenna.position.set(willis.position.x + dx, 45.5, willis.position.z);
    group.add(antenna);
  }

  const hancock = new THREE.Mesh(
    new THREE.CylinderGeometry(2.6, 4.4, 39, 10),
    new THREE.MeshStandardMaterial({ color: 0x141722, roughness: 0.62, metalness: 0.2, emissive: 0x121a2f, emissiveIntensity: 0.5 })
  );
  hancock.position.set(14, 19.5, -(radius + 18));
  group.add(hancock);
  for (let y = 8; y < 34; y += 6){
    const brace = new THREE.Mesh(new THREE.BoxGeometry(0.2, 6.0, 0.2), new THREE.MeshBasicMaterial({ color: 0xb7d7ff }));
    brace.position.set(hancock.position.x, y, hancock.position.z + 1.8);
    brace.rotation.z = Math.PI / 4;
    group.add(brace.clone());
    brace.rotation.z = -Math.PI / 4;
    group.add(brace.clone());
  }

  const trump = new THREE.Mesh(
    new THREE.CylinderGeometry(3.1, 4.4, 47, 14),
    new THREE.MeshPhysicalMaterial({ color: 0xd8e4ff, roughness: 0.18, metalness: 0.15, transmission: 0.25, transparent: true, opacity: 0.9 })
  );
  trump.position.set(0, 23.5, -(radius + 23));
  group.add(trump);

  scene.add(group);
}

function addMoon(scene, radius){
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(7.5, 32, 32),
    new THREE.MeshStandardMaterial({ color: 0xe8e8ff, roughness: 1.0, metalness: 0.0, emissive: 0x20243d, emissiveIntensity: 0.38 })
  );
  moon.position.set(-55, 55, -(radius + 72));
  scene.add(moon);
}

function addStarfield(scene, radius){
  const positions = [];
  for (let i = 0; i < 700; i++){
    const angle = Math.random() * Math.PI * 2;
    const dist = radius + 40 + Math.random() * 120;
    const y = 18 + Math.random() * 70;
    positions.push(Math.cos(angle) * dist, y, Math.sin(angle) * dist - 40);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  const pts = new THREE.Points(
    geo,
    new THREE.PointsMaterial({ color: 0xf7f2ff, size: 0.33, transparent: true, opacity: 0.85 })
  );
  scene.add(pts);
}



function makeCanvasTexture(draw, width = 1024, height = 1024){
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  draw(ctx, width, height);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

function roundRect(ctx, x, y, w, h, r){
  const rr = Math.min(r, w * 0.5, h * 0.5);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function drawWrappedText(ctx, text, x, y, maxWidth, lineHeight){
  const words = text.split(/\s+/);
  let line = "";
  let yy = y;
  for (const word of words){
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line){
      ctx.fillText(line, x, yy);
      line = word;
      yy += lineHeight;
    }else{
      line = test;
    }
  }
  if (line) ctx.fillText(line, x, yy);
  return yy;
}


function buildInstructorPanelTexture(){
  return makeCanvasTexture((ctx, w, h)=>{
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, "#06110b");
    grad.addColorStop(0.48, "#10281a");
    grad.addColorStop(1, "#060709");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = "#ff2a3d";
    ctx.lineWidth = 18;
    roundRect(ctx, 28, 28, w - 56, h - 56, 44);
    ctx.stroke();

    ctx.fillStyle = "rgba(255,255,255,0.06)";
    roundRect(ctx, 54, 54, w - 108, 136, 28);
    ctx.fill();

    ctx.fillStyle = "#ff6a75";
    ctx.font = "700 38px Arial";
    ctx.fillText("VR GOLF • PGA HUB • SOUTH LOBBY", 86, 128);

    ctx.fillStyle = "#ffffff";
    ctx.font = "700 72px Arial";
    ctx.fillText("JUAN ESPEJO", 86, 245);

    ctx.fillStyle = "#ffe6e9";
    ctx.font = "600 34px Arial";
    ctx.fillText("In honor of a Des Plaines golf instructor at Maryville Academy", 86, 305);

    ctx.fillStyle = "#8df0b7";
    ctx.font = "700 38px Arial";
    ctx.fillText("ABOUT", 86, 400);

    ctx.fillStyle = "#f3fff8";
    ctx.font = "400 31px Arial";
    const about = "Juan E. Espejo is listed as a golf instructor at Maryville Academy in Des Plaines, Illinois. The profile describes private and group lessons for golfers of all skill levels, from beginners learning fundamentals to experienced players working to lower scores.";
    let y = drawWrappedText(ctx, about, 86, 462, w - 172, 44);

    y += 78;
    ctx.fillStyle = "#ff8590";
    ctx.font = "700 34px Arial";
    ctx.fillText("FEATURES", 86, y);
    y += 52;

    ctx.fillStyle = "#f3fff8";
    ctx.font = "500 29px Arial";
    for (const line of [
      "• Private lessons",
      "• Group coaching",
      "• Beginner fundamentals",
      "• Score-lowering refinement",
      "• VR golf academy showcase",
    ]){
      ctx.fillText(line, 96, y);
      y += 46;
    }

    y += 24;
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    roundRect(ctx, 72, h - 250, w - 144, 158, 24);
    ctx.fill();
    ctx.strokeStyle = "rgba(255, 106, 117, 0.72)";
    ctx.lineWidth = 4;
    roundRect(ctx, 72, h - 250, w - 144, 158, 24);
    ctx.stroke();

    ctx.fillStyle = "#ff6a75";
    ctx.font = "700 32px Arial";
    ctx.fillText("RESERVED FRONTAGE", 104, h - 182);
    ctx.fillStyle = "#ffffff";
    ctx.font = "700 40px Arial";
    ctx.fillText("JUAN ESPEJO VR GOLF ACADEMY HUB", 104, h - 128);
    ctx.fillStyle = "#baf9d0";
    ctx.font = "600 28px Arial";
    ctx.fillText("Official PGA logo slot held for client artwork", 104, h - 84);
  }, 1100, 1500);
}

function buildGolfMarqueeTexture(){
  return makeCanvasTexture((ctx, w, h)=>{
    const grad = ctx.createLinearGradient(0, 0, w, 0);
    grad.addColorStop(0, "#2a0308");
    grad.addColorStop(0.5, "#72111d");
    grad.addColorStop(1, "#2a0308");
    ctx.fillStyle = grad;
    roundRect(ctx, 0, 0, w, h, 44);
    ctx.fill();

    ctx.strokeStyle = "#ff4958";
    ctx.lineWidth = 18;
    roundRect(ctx, 14, 14, w - 28, h - 28, 38);
    ctx.stroke();

    ctx.textAlign = "center";
    ctx.fillStyle = "#ffffff";
    ctx.font = "700 86px Arial";
    ctx.fillText("VR GOLF PGA HUB", w / 2, 148);
    ctx.fillStyle = "#ffcad0";
    ctx.font = "700 48px Arial";
    ctx.fillText("IN HONOR OF JUAN ESPEJO", w / 2, 224);
  }, 1600, 300);
}

function buildReservePlaqueTexture(){
  return makeCanvasTexture((ctx, w, h)=>{
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, "#220206");
    grad.addColorStop(1, "#4f0912");
    ctx.fillStyle = grad;
    roundRect(ctx, 0, 0, w, h, 24);
    ctx.fill();
    ctx.strokeStyle = "#ff5968";
    ctx.lineWidth = 10;
    roundRect(ctx, 10, 10, w - 20, h - 20, 22);
    ctx.stroke();
    ctx.textAlign = "center";
    ctx.fillStyle = "#ff8690";
    ctx.font = "700 56px Arial";
    ctx.fillText("RESERVED FOR", w / 2, 90);
    ctx.fillStyle = "#ffffff";
    ctx.font = "700 68px Arial";
    ctx.fillText("JUAN ESPEJO", w / 2, 172);
  }, 900, 230);
}

function buildPGABadgeTexture(){
  return makeCanvasTexture((ctx, w, h)=>{
    const cx = w / 2;
    const cy = h / 2;
    const outer = Math.min(w, h) * 0.46;

    ctx.clearRect(0, 0, w, h);
    const glow = ctx.createRadialGradient(cx, cy, outer * 0.15, cx, cy, outer * 1.05);
    glow.addColorStop(0, "rgba(255, 73, 88, 0.42)");
    glow.addColorStop(1, "rgba(255, 73, 88, 0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, w, h);

    ctx.beginPath();
    ctx.arc(cx, cy, outer, 0, Math.PI * 2);
    ctx.fillStyle = "#7f0c16";
    ctx.fill();
    ctx.lineWidth = 34;
    ctx.strokeStyle = "#ff4958";
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, cy, outer * 0.78, 0, Math.PI * 2);
    ctx.fillStyle = "#250306";
    ctx.fill();
    ctx.lineWidth = 10;
    ctx.strokeStyle = "rgba(255, 212, 216, 0.92)";
    ctx.stroke();

    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.font = "700 182px Arial";
    ctx.fillText("PGA", cx, cy + 42);
    ctx.font = "700 52px Arial";
    ctx.fillStyle = "#ffd2d7";
    ctx.fillText("LOGO SLOT", cx, cy - 136);
    ctx.font = "700 44px Arial";
    ctx.fillText("CLIENT ART HERE", cx, cy + 142);
    ctx.font = "500 28px Arial";
    ctx.fillStyle = "rgba(255,255,255,0.82)";
    ctx.fillText("red placeholder until official logo arrives", cx, cy + 206);
  }, 900, 900);
}

function addJuanEspejoFeature(scene, radius){
  const anchorAngle = Math.PI * 0.25;
  const group = new THREE.Group();
  const innerRadius = radius - 6.2;
  group.position.set(Math.cos(anchorAngle) * innerRadius, 0, Math.sin(anchorAngle) * innerRadius);
  group.rotation.y = anchorAngle + Math.PI;

  const boothFloor = new THREE.Mesh(
    new THREE.BoxGeometry(11.6, 0.12, 6.6),
    new THREE.MeshStandardMaterial({ color: 0x112418, roughness: 0.94, metalness: 0.03, emissive: 0x0d1c13, emissiveIntensity: 0.22 })
  );
  boothFloor.position.set(0, 0.06, 0);
  group.add(boothFloor);

  const turf = new THREE.Mesh(
    new THREE.BoxGeometry(10.7, 0.04, 5.7),
    new THREE.MeshStandardMaterial({ color: 0x1d6a39, roughness: 1.0, metalness: 0.0, emissive: 0x0d2315, emissiveIntensity: 0.18 })
  );
  turf.position.set(0, 0.15, 0.05);
  group.add(turf);

  const puttingLane = new THREE.Mesh(
    new THREE.BoxGeometry(6.3, 0.02, 1.15),
    new THREE.MeshStandardMaterial({ color: 0x2f9d52, roughness: 0.98, metalness: 0.0 })
  );
  puttingLane.position.set(0.4, 0.18, 1.55);
  group.add(puttingLane);

  const laneLine = new THREE.Mesh(
    new THREE.BoxGeometry(5.8, 0.021, 0.06),
    new THREE.MeshBasicMaterial({ color: 0xf3fff8 })
  );
  laneLine.position.set(0.4, 0.191, 1.55);
  group.add(laneLine);

  const curbMat = new THREE.MeshStandardMaterial({ color: 0xff4958, roughness: 0.22, metalness: 0.4, emissive: 0x7a0e18, emissiveIntensity: 0.88 });
  const frontRail = new THREE.Mesh(new THREE.BoxGeometry(11.8, 0.14, 0.14), curbMat);
  frontRail.position.set(0, 0.2, 3.25);
  group.add(frontRail);
  const backRail = frontRail.clone();
  backRail.position.z = -3.25;
  group.add(backRail);
  const leftRail = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 6.36), curbMat);
  leftRail.position.set(-5.82, 0.2, 0);
  group.add(leftRail);
  const rightRail = leftRail.clone();
  rightRail.position.x = 5.82;
  group.add(rightRail);

  const backWall = new THREE.Mesh(
    new THREE.BoxGeometry(10.9, 5.8, 0.24),
    new THREE.MeshStandardMaterial({ color: 0x0e1016, roughness: 0.64, metalness: 0.15, emissive: 0x1a0710, emissiveIntensity: 0.32 })
  );
  backWall.position.set(0, 3.0, -2.74);
  group.add(backWall);

  const backGlow = new THREE.Mesh(
    new THREE.PlaneGeometry(10.35, 5.25),
    new THREE.MeshBasicMaterial({ color: 0x120b12 })
  );
  backGlow.position.set(0, 3.0, -2.61);
  group.add(backGlow);

  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xdfeeff, roughness: 0.08, metalness: 0.0, transmission: 0.78, transparent: true, opacity: 0.34 });
  const leftGlass = new THREE.Mesh(new THREE.BoxGeometry(0.08, 4.3, 3.2), glassMat);
  leftGlass.position.set(-5.05, 2.3, -0.95);
  group.add(leftGlass);
  const rightGlass = leftGlass.clone();
  rightGlass.position.x = 5.05;
  group.add(rightGlass);

  const infoPanel = new THREE.Mesh(
    new THREE.PlaneGeometry(3.55, 4.85),
    new THREE.MeshBasicMaterial({ map: buildInstructorPanelTexture() })
  );
  infoPanel.position.set(-2.8, 3.08, -2.6);
  group.add(infoPanel);

  const marquee = new THREE.Mesh(
    new THREE.PlaneGeometry(6.5, 1.22),
    new THREE.MeshBasicMaterial({ map: buildGolfMarqueeTexture() })
  );
  marquee.position.set(0.3, 6.18, -2.52);
  group.add(marquee);

  const badge = new THREE.Mesh(
    new THREE.CircleGeometry(1.5, 64),
    new THREE.MeshBasicMaterial({ map: buildPGABadgeTexture(), transparent: true })
  );
  badge.position.set(4.1, 6.3, -2.5);
  group.add(badge);

  const badgeFrame = new THREE.Mesh(
    new THREE.RingGeometry(1.53, 1.72, 64),
    new THREE.MeshStandardMaterial({ color: 0xff4958, roughness: 0.2, metalness: 0.48, emissive: 0x7a0e18, emissiveIntensity: 1.0, side: THREE.DoubleSide })
  );
  badgeFrame.position.copy(badge.position);
  group.add(badgeFrame);

  const reservePlaque = new THREE.Mesh(
    new THREE.PlaneGeometry(3.95, 1.02),
    new THREE.MeshBasicMaterial({ map: buildReservePlaqueTexture() })
  );
  reservePlaque.position.set(3.38, 1.18, -2.57);
  group.add(reservePlaque);

  const portraitUrl = new URL("../assets/ui/juan-espejo.jpg", import.meta.url).toString();
  const portraitTex = new THREE.TextureLoader().load(portraitUrl);
  portraitTex.colorSpace = THREE.SRGBColorSpace;
  const portraitFrame = new THREE.Mesh(
    new THREE.BoxGeometry(2.18, 2.8, 0.08),
    new THREE.MeshStandardMaterial({ color: 0x301216, roughness: 0.32, metalness: 0.32, emissive: 0x3a0f16, emissiveIntensity: 0.5 })
  );
  portraitFrame.position.set(3.45, 3.72, -2.74);
  group.add(portraitFrame);
  const portrait = new THREE.Mesh(
    new THREE.PlaneGeometry(1.92, 2.54),
    new THREE.MeshBasicMaterial({ map: portraitTex })
  );
  portrait.position.set(3.45, 3.72, -2.68);
  group.add(portrait);

  const pedestalMat = new THREE.MeshStandardMaterial({ color: 0x14181e, roughness: 0.55, metalness: 0.28, emissive: 0x0d1116, emissiveIntensity: 0.2 });
  const teePedestal = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.42, 0.9, 22), pedestalMat);
  teePedestal.position.set(-0.9, 0.5, 0.2);
  group.add(teePedestal);
  const teeStem = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 0.18, 16), new THREE.MeshStandardMaterial({ color: 0xc32636, roughness: 0.5, metalness: 0.2 }));
  teeStem.position.set(-0.9, 1.02, 0.2);
  group.add(teeStem);
  const golfBall = new THREE.Mesh(
    new THREE.SphereGeometry(0.12, 24, 24),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.92, metalness: 0.0, emissive: 0x383838, emissiveIntensity: 0.08 })
  );
  golfBall.position.set(-0.9, 1.14, 0.2);
  group.add(golfBall);

  const targetRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.36, 0.045, 16, 48),
    new THREE.MeshStandardMaterial({ color: 0x89f3b1, roughness: 0.18, metalness: 0.1, emissive: 0x2c8f56, emissiveIntensity: 0.82 })
  );
  targetRing.rotation.x = Math.PI / 2;
  targetRing.position.set(2.75, 0.23, 1.55);
  group.add(targetRing);

  const cup = new THREE.Mesh(
    new THREE.CylinderGeometry(0.09, 0.11, 0.08, 18),
    new THREE.MeshStandardMaterial({ color: 0xf1f5f7, roughness: 0.7, metalness: 0.03 })
  );
  cup.position.set(2.75, 0.18, 1.55);
  group.add(cup);
  const flagPole = new THREE.Mesh(
    new THREE.CylinderGeometry(0.02, 0.02, 0.72, 10),
    new THREE.MeshStandardMaterial({ color: 0xf1f5f7, roughness: 0.25, metalness: 0.18 })
  );
  flagPole.position.set(2.75, 0.58, 1.55);
  group.add(flagPole);
  const flag = new THREE.Mesh(
    new THREE.PlaneGeometry(0.34, 0.22),
    new THREE.MeshBasicMaterial({ color: 0xff5d6c, side: THREE.DoubleSide })
  );
  flag.position.set(2.93, 0.76, 1.55);
  group.add(flag);

  const clubMat = new THREE.MeshStandardMaterial({ color: 0xd9dfe3, roughness: 0.28, metalness: 0.72 });
  const gripMat = new THREE.MeshStandardMaterial({ color: 0x171717, roughness: 0.82, metalness: 0.08 });
  for (const [x, z, tilt] of [[-4.3, 1.85, -0.24], [-3.95, 2.0, -0.17]]){
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 1.54, 10), clubMat);
    shaft.position.set(x, 0.9, z);
    shaft.rotation.z = tilt;
    group.add(shaft);
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.26, 10), gripMat);
    grip.position.set(x + Math.sin(-tilt) * 0.7, 1.56, z);
    grip.rotation.z = tilt;
    group.add(grip);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.08, 0.12), new THREE.MeshStandardMaterial({ color: 0x1b1e24, roughness: 0.5, metalness: 0.48 }));
    head.position.set(x - Math.sin(-tilt) * 0.66, 0.18, z);
    head.rotation.z = tilt;
    group.add(head);
  }

  const accentStrips = [];
  for (const x of [-5.18, -1.05, 1.3, 5.18]){
    const strip = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 5.7, 0.12),
      new THREE.MeshStandardMaterial({ color: 0xff4958, roughness: 0.24, metalness: 0.36, emissive: 0x7a0e18, emissiveIntensity: 0.9 })
    );
    strip.position.set(x, 3.0, -2.48);
    group.add(strip);
    accentStrips.push(strip);
  }

  const honorTextTex = makeCanvasTexture((ctx, w, h)=>{
    ctx.fillStyle = "rgba(8,8,10,0.88)";
    roundRect(ctx, 0, 0, w, h, 24);
    ctx.fill();
    ctx.strokeStyle = "#8df0b7";
    ctx.lineWidth = 8;
    roundRect(ctx, 8, 8, w - 16, h - 16, 20);
    ctx.stroke();
    ctx.textAlign = "center";
    ctx.fillStyle = "#ffffff";
    ctx.font = "700 52px Arial";
    ctx.fillText("MARYVILLE ACADEMY • DES PLAINES, IL", w / 2, 82);
    ctx.fillStyle = "#b7ffd1";
    ctx.font = "600 34px Arial";
    ctx.fillText("Private lessons • Group lessons • VR golf showcase", w / 2, 136);
  }, 1200, 180);
  const honorText = new THREE.Mesh(
    new THREE.PlaneGeometry(4.8, 0.72),
    new THREE.MeshBasicMaterial({ map: honorTextTex, transparent: true })
  );
  honorText.position.set(0.55, 4.84, -2.55);
  group.add(honorText);

  scene.add(group);
  scene.userData._juanFeature = { group, badgeFrame, accentStrips, golfBall, targetRing, flag };
}

function buildProceduralTable(scene){
  const root = new THREE.Group();

  const rail = new THREE.Mesh(
    new THREE.CylinderGeometry(1.55, 1.7, 0.18, 48),
    new THREE.MeshStandardMaterial({ color: 0x251321, roughness: 0.85, metalness: 0.08, emissive: 0x1c0818, emissiveIntensity: 0.28 })
  );
  rail.position.y = 0.78;
  root.add(rail);

  const felt = new THREE.Mesh(
    new THREE.CylinderGeometry(1.26, 1.35, 0.08, 48),
    new THREE.MeshStandardMaterial({ color: 0x144b34, roughness: 0.92, metalness: 0.02, emissive: 0x07180f, emissiveIntensity: 0.16 })
  );
  felt.position.y = 0.81;
  root.add(felt);

  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.52, 0.78, 18),
    new THREE.MeshStandardMaterial({ color: 0x1b1b22, roughness: 0.74, metalness: 0.24 })
  );
  base.position.y = 0.39;
  root.add(base);

  for (let i = 0; i < 6; i++){
    const angle = (i / 6) * Math.PI * 2;
    const seat = new THREE.Mesh(
      new THREE.RingGeometry(0.22, 0.32, 36),
      new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.3, metalness: 0.15, emissive: 0x2a0d3a, emissiveIntensity: 0.9, side: THREE.DoubleSide })
    );
    seat.rotation.x = -Math.PI / 2;
    seat.position.set(Math.cos(angle) * 2.35, 0.015, Math.sin(angle) * 2.35);
    root.add(seat);
  }

  scene.add(root);
  return root;
}

function buildDealerStandIn(scene){
  const group = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.24, 1.0, 8, 16),
    new THREE.MeshStandardMaterial({ color: 0x22242c, roughness: 0.6, metalness: 0.1, emissive: 0x170d22, emissiveIntensity: 0.25 })
  );
  body.position.y = 1.0;
  group.add(body);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.18, 18, 18),
    new THREE.MeshStandardMaterial({ color: 0xcda78e, roughness: 0.95, metalness: 0.0 })
  );
  head.position.y = 1.78;
  group.add(head);

  group.position.set(0, 0, -2.2);
  group.rotation.y = Math.PI;
  scene.add(group);
  return group;
}

export async function buildSkylineRoom(scene, { log = console.log } = {}) {
  const radius = CONFIG.ROOM_RADIUS ?? 32;
  const wallH = CONFIG.WALL_HEIGHT ?? 22;

  scene.add(new THREE.HemisphereLight(0xffffff, 0x0a0a18, 1.55));
  const key = new THREE.PointLight(0xffffff, 75, 250, 2.0);
  key.position.set(0, 12, 0);
  scene.add(key);
  const violetFill = new THREE.PointLight(0xb48cff, 26, 80, 2.2);
  violetFill.position.set(0, 5, -4);
  scene.add(violetFill);

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(radius + 30, 180),
    new THREE.MeshStandardMaterial({ color: 0x050508, roughness: 0.96, metalness: 0.02 })
  );
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, wallH, 180, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x070712, roughness: 0.85, metalness: 0.06, emissive: 0x2a0d3a, emissiveIntensity: 0.42, side: THREE.BackSide })
  );
  wall.position.y = wallH / 2;
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(radius - 0.8, 0.24, 16, 200),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.24, metalness: 0.34, emissive: 0x2a0d3a, emissiveIntensity: 1.55 })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.y = wallH - 0.35;
  scene.add(rim);

  buildOuterCity(scene, radius);
  addMoon(scene, radius);
  addStarfield(scene, radius);
  addJuanEspejoFeature(scene, radius);
  buildProceduralTable(scene);
  buildDealerStandIn(scene);

  scene.userData._tickWorld = (dt)=>{
    scene.userData._t = (scene.userData._t || 0) + dt;
    rim.material.emissiveIntensity = 1.3 + Math.sin(scene.userData._t * 0.8) * 0.25;
    if (scene.userData._juanFeature){
      const t = scene.userData._t;
      const feature = scene.userData._juanFeature;
      feature.badgeFrame.material.emissiveIntensity = 0.88 + Math.sin(t * 1.6) * 0.2;
      for (let i = 0; i < feature.accentStrips.length; i++){
        feature.accentStrips[i].material.emissiveIntensity = 0.82 + Math.sin(t * 1.25 + i * 0.35) * 0.16;
      }
      feature.targetRing.material.emissiveIntensity = 0.72 + Math.sin(t * 1.9) * 0.18;
      feature.golfBall.position.y = 1.14 + Math.sin(t * 2.1) * 0.015;
      feature.flag.rotation.y = Math.sin(t * 1.4) * 0.22;
    }
  };

  (async()=>{
    const table = await tryLoadFBX(CANDIDATES.TABLE, log, 10000);
    if (table){
      table.traverse((child)=>{
        if (child.isMesh){
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });
      scaleToHeight(table, 0.95);
      dropToGround(table);
      fitDiameter(table, 2.75);
      dropToGround(table);
      table.position.set(0, 0, 0);
      scene.add(table);
    }

    const eric = await tryLoadFBX(CANDIDATES.ERIC, log, 10000);
    if (eric){
      scaleToHeight(eric, 1.78);
      dropToGround(eric);
      eric.position.set(0, 0, -2.2);
      eric.rotation.y = Math.PI;
      scene.add(eric);
    }
  })().catch((err)=> log("Asset stream error:", String(err)));

  return { roomClamp: radius - 2.0 };
}
