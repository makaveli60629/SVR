import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { CONFIG } from "./config.js";
import { urlsFor } from "./asset_base.js";

/**
 * CLEAN SKYLINE WORLD
 * - No duplicate const declarations
 * - Renders immediately (floor/wall/city/moon)
 * - Streams FBX assets after render (table, NPCs, store, landmarks)
 */



function fixMaterials(obj){
  obj.traverse((n)=>{
    if (!n.isMesh) return;
    n.castShadow = false;
    n.receiveShadow = true;
    const m = n.material;
    if (Array.isArray(m)){
      m.forEach(mm=>{ if (mm) { mm.needsUpdate = true; mm.transparent = mm.transparent || false; } });
    } else if (m){
      m.needsUpdate = true;
      m.transparent = m.transparent || false;
    }
  });
}


function addStars(scene){
  const geo = new THREE.BufferGeometry();
  const N = 1400;
  const pos = new Float32Array(N*3);
  for(let i=0;i<N;i++){
    const r = 120 + Math.random()*220;
    const a = Math.random()*Math.PI*2;
    const y = 30 + Math.random()*120;
    pos[i*3+0] = Math.cos(a)*r;
    pos[i*3+1] = y;
    pos[i*3+2] = Math.sin(a)*r;
  }
  geo.setAttribute("position", new THREE.BufferAttribute(pos,3));
  const mat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.55, sizeAttenuation: true, transparent:true, opacity:0.75 });
  const pts = new THREE.Points(geo, mat);
  pts.renderOrder = -10;
  scene.add(pts);
}

function addPurpleSprites(scene){
  // Uses flare.png (already in /game/)
  const tex = new THREE.TextureLoader().load("./flare.png");
  const N=70;
  const sprites=[];
  for(let i=0;i<N;i++){
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, color: 0xffffff, transparent:true, opacity: 0.22, depthWrite:false }));
    const x = (Math.random()*2-1)*35;
    const z = (Math.random()*2-1)*35;
    const y = Math.random()*10;
    s.position.set(x,y,z);
    const sc = 0.12 + Math.random()*0.22;
    s.scale.set(sc, sc, 1);
    s.userData.v = 0.6 + Math.random()*1.3;
    sprites.push(s);
    scene.add(s);
  }
  scene.userData._sprites = sprites;
}

function addSeatStools(scene, tablePos=new THREE.Vector3(0,0,0)){
  const seats=[];
  const stoolMat = new THREE.MeshStandardMaterial({ color: 0x2b0a3a, roughness:0.65, metalness:0.2, emissive:0x140522, emissiveIntensity:0.4 });
  for(let i=0;i<6;i++){
    const ang = i*(Math.PI*2/6);
    const x = tablePos.x + Math.cos(ang)*2.25;
    const z = tablePos.z + Math.sin(ang)*2.25;
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.25,0.28,0.45,18), stoolMat);
    base.position.set(x,0.225,z);
    base.userData.seat = true;
    base.userData.seatIndex = i;
    seats.push(base);
    scene.add(base);
  }
  scene.userData.seats = seats;
}

function addLighting(scene){
  // Brighter, cleaner lighting for loaded FBXs
  const amb = new THREE.AmbientLight(0xffffff, 0.85);
  scene.add(amb);

  const key = new THREE.DirectionalLight(0xffffff, 1.55);
  key.position.set(8, 14, 6);
  scene.add(key);

  const fill = new THREE.DirectionalLight(0xbba0ff, 0.85);
  fill.position.set(-10, 8, -6);
  scene.add(fill);

  const rim = new THREE.PointLight(0x66ddff, 0.85, 65);
  rim.position.set(0, 10, -18);
  scene.add(rim);
}

const CANDIDATES = {
  TABLE:       [ ...urlsFor("table/table.fbx") ],
  ERIC:        [ ...urlsFor("npc/eric/eric.fbx") ],
  CARLA:       [ ...urlsFor("npc/carla/carla.fbx") ],
  CLAUDIA:     [ ...urlsFor("npc/claudia/claudia.fbx") ],
  STORE:       [ ...urlsFor("storefronts/store.fbx") ],
  WILLIS:      [ ...urlsFor("other/willis.fbx") ],
  HANCOCK:     [ ...urlsFor("other/handcocktower.fbx") ],
  TRUMP:       [ ...urlsFor("other/trump.fbx") ],
  TRUMPTOWERS: [ ...urlsFor("other/trumptowers.fbx") ],
};

function delay(ms){ return new Promise(r=>setTimeout(r, ms)); }

async function loadFBXWithTimeout(loader, url, ms){
  return await Promise.race([
    loader.loadAsync(url),
    (async()=>{ await delay(ms); throw new Error("timeout"); })()
  ]);
}

async function tryLoadFBX(urls, log, timeoutMs=12000){
  const loader = new FBXLoader();
  for (const u of urls){
    try{
      const obj = await loadFBXWithTimeout(loader, u, timeoutMs);
      log("Loaded FBX:", u);
      return obj;
    }catch(e){
      log("FBX missing/timeout:", u);
    }
  }
  return null;
}

function boxSize(obj){
  const box=new THREE.Box3().setFromObject(obj);
  const size=new THREE.Vector3(); box.getSize(size);
  const ctr=new THREE.Vector3(); box.getCenter(ctr);
  return { size, ctr };
}

function dropToGround(obj){
  const { size, ctr } = boxSize(obj);
  obj.position.y += (size.y*0.5) - ctr.y;
}

function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y>0.0001) obj.scale.multiplyScalar(targetH/size.y);
}

function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia=Math.max(size.x, size.z);
  if (dia>0.0001) obj.scale.multiplyScalar(targetDia/dia);
}

function applyGlassy(obj){
  const glass = new THREE.MeshPhysicalMaterial({
    color: 0xbfd0ff, roughness: 0.08, metalness: 0.15,
    transmission: 0.65, transparent:true, opacity:0.95, thickness:0.35,
    envMapIntensity: 1.0, clearcoat: 1.0, clearcoatRoughness: 0.05,
    emissive: new THREE.Color(0x070713), emissiveIntensity: 0.35
  });
  obj.traverse((c)=>{ if (c.isMesh){ c.castShadow=true; c.receiveShadow=true; c.material=glass; }});
}

function applyWindowGlow(obj){
  const mat = new THREE.MeshStandardMaterial({
    color: 0x0a0a14, roughness: 0.75, metalness: 0.15,
    emissive: 0xb48cff, emissiveIntensity: 0.25
  });
  obj.traverse((c)=>{ if (c.isMesh){ c.castShadow=true; c.receiveShadow=true; c.material=mat; }});
}

function addBeacon(scene, pos){
  const light=new THREE.PointLight(0xff2a2a, 0.15, 55, 2.0);
  light.position.copy(pos);
  scene.add(light);
  const bulb=new THREE.Mesh(new THREE.SphereGeometry(0.32,16,16), new THREE.MeshBasicMaterial({color:0xff2a2a}));
  bulb.position.copy(pos);
  bulb.visible=false;
  scene.add(bulb);
  if(!scene.userData._beacons) scene.userData._beacons=[];
  scene.userData._beacons.push({light, bulb, phase: Math.random()*Math.PI*2});
}

function buildOuterCity(scene, R){
  const bMat=new THREE.MeshStandardMaterial({
    color:0x0c0c18, roughness:0.78, metalness:0.12,
    emissive:0x140a22, emissiveIntensity:0.65
  });
  const wMat=new THREE.MeshStandardMaterial({
    color:0xb48cff, roughness:0.22, metalness:0.22,
    emissive:0x2a0d3a, emissiveIntensity:1.2
  });
  const grp=new THREE.Group();
  const count=180;
  for(let i=0;i<count;i++){
    const a=(i/count)*Math.PI*2;
    const rr=(R+10)+(Math.random()*12);
    const h=10+Math.random()*42;
    const w=1.6+Math.random()*4.2;
    const d=1.6+Math.random()*4.2;
    const x=Math.cos(a)*rr, z=Math.sin(a)*rr;
    const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d), bMat);
    b.position.set(x,h/2,z);
    b.rotation.y=-a+Math.PI/2;
    grp.add(b);
    if(Math.random()<0.70){
      const strip=new THREE.Mesh(new THREE.BoxGeometry(w*0.92,0.24,d*1.06), wMat);
      strip.position.set(x, 2.0+Math.random()*(h-4.0), z);
      strip.rotation.y=b.rotation.y;
      grp.add(strip);
    }
  }
  scene.add(grp);
}

function addMoon(scene, R){
  const moon=new THREE.Mesh(
    new THREE.SphereGeometry(7.5,32,32),
    new THREE.MeshStandardMaterial({ color:0xe9e9ff, roughness:1.0, metalness:0.0, emissive:0x1a1a2a, emissiveIntensity:0.35 })
  );
  moon.position.set(-55,55, -(R+70));
  scene.add(moon);
}

export async function buildSkylineRoom(scene, { log=console.log } = {}){
  const R = CONFIG.ROOM_RADIUS ?? 28;
  const H = (CONFIG.WALL_HEIGHT ?? 14) * 0.5;

  scene.add(new THREE.HemisphereLight(0xffffff, 0x0a0a18, 1.6));
  const ceiling=new THREE.PointLight(0xffffff, 3.2, 320);
  ceiling.position.set(0, H+6, 0);
  scene.add(ceiling);

  const floorMesh=new THREE.Mesh(
    new THREE.CircleGeometry(R+30, 160),
    new THREE.MeshStandardMaterial({ color:0x050508, roughness:0.95, metalness:0.02 })
  );
  floorMesh.rotation.x = -Math.PI/2;
  scene.add(floorMesh);

  const wallMesh=new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, H, 160, 1, true),
    new THREE.MeshStandardMaterial({ color:0x070712, roughness:0.85, metalness:0.06, emissive:0x2a0d3a, emissiveIntensity:0.45, side:THREE.BackSide })
  );
  wallMesh.position.set(0, H/2, 0);
  scene.add(wallMesh);

  const rimMesh=new THREE.Mesh(
    new THREE.TorusGeometry(R-0.8, 0.25, 14, 180),
    new THREE.MeshStandardMaterial({ color:0xb48cff, roughness:0.25, metalness:0.35, emissive:0x2a0d3a, emissiveIntensity:1.6 })
  );
  rimMesh.rotation.x = Math.PI/2;
  rimMesh.position.set(0, H-0.35, 0);
  scene.add(rimMesh);

  buildOuterCity(scene, R);
  addMoon(scene, R);

  scene.userData._tickWorld = (dt)=>{
    scene.userData._t=(scene.userData._t||0)+dt;
    if(scene.userData._beacons){
      for(const b of scene.userData._beacons){
        const s=Math.sin(scene.userData._t*4.2 + b.phase);
        const on=s>0.7;
        b.light.intensity = on ? 3.2 : 0.15;
        b.bulb.visible = on;
      }
    }
  };

  (async()=>{
    const table = await tryLoadFBX(CANDIDATES.TABLE, log, 12000);
    if(table){
      table.traverse((c)=>{ if(c.isMesh){ c.castShadow=true; c.receiveShadow=true; }});
      scaleToHeight(table, 0.95);
      dropToGround(table);
      fitDiameter(table, 2.75);
      dropToGround(table);
      table.position.set(0,0,0);
      scene.add(table);
    }

    const eric = await tryLoadFBX(CANDIDATES.ERIC, log, 12000);
    if(eric){
      scaleToHeight(eric, 1.78);
      dropToGround(eric);
      eric.position.set(0,0,-2.2);
      eric.rotation.y = Math.PI;
      scene.add(eric);
    }

    const store = await tryLoadFBX(CANDIDATES.STORE, log, 12000);
    if(store){
      scaleToHeight(store, 2.4);
      dropToGround(store);
      store.position.set(8.0,0,8.5);
      store.rotation.set(-Math.PI/2, Math.PI, 0);
      store.scale.multiplyScalar(0.35);
      scene.add(store);
    }

    const willis = await tryLoadFBX(CANDIDATES.WILLIS, log, 14000);
    if(willis){
      scaleToHeight(willis, 52);
      dropToGround(willis);
      willis.position.set(-12,0, -(R+20));
      willis.rotation.y = 0.18;
      applyWindowGlow(willis);
      scene.add(willis);
      const topY = boxSize(willis).size.y;
      addBeacon(scene, new THREE.Vector3(-12-0.6, topY+2.0, -(R+20)));
      addBeacon(scene, new THREE.Vector3(-12+0.6, topY+2.3, -(R+20)));
    }

    const hancock = await tryLoadFBX(CANDIDATES.HANCOCK, log, 14000);
    if(hancock){
      scaleToHeight(hancock, 48);
      dropToGround(hancock);
      hancock.position.set(12,0, -(R+20));
      hancock.rotation.y = -0.18;
      applyGlassy(hancock);
      scene.add(hancock);
      const topY = boxSize(hancock).size.y;
      addBeacon(scene, new THREE.Vector3(12, topY+2.2, -(R+20)));
    }

    const trump = await tryLoadFBX(CANDIDATES.TRUMP, log, 14000);
    if(trump){
      scaleToHeight(trump, 56);
      dropToGround(trump);
      trump.position.set(0,0, -(R+24));
      applyGlassy(trump);
      scene.add(trump);
      const topY = boxSize(trump).size.y;
      addBeacon(scene, new THREE.Vector3(0, topY+2.4, -(R+24)));
    }

    const trumptowers = await tryLoadFBX(CANDIDATES.TRUMPTOWERS, log, 60000);
    // FALLBACK_TRUMPTOWERS: if this large FBX times out, we still keep Trump (already loaded) as tallest landmark
    if(trumptowers){
      scaleToHeight(trumptowers, 60);
      dropToGround(trumptowers);
      trumptowers.position.set(0,0, -(R+28));
      applyGlassy(trumptowers);
      scene.add(trumptowers);
      const topY = boxSize(trumptowers).size.y;
      addBeacon(scene, new THREE.Vector3(0, topY+2.4, -(R+28)));
    }
  })().catch((e)=>log("Asset stream error:", String(e)));

  return { roomClamp: R-2.0 };
}
