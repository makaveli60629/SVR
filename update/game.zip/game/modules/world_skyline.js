import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { CONFIG } from './config.js';

function loadTexture(url, repeat=null){
  const loader = new THREE.TextureLoader();
  return new Promise((resolve)=>{
    loader.load(url, (t)=>{
      t.colorSpace = THREE.SRGBColorSpace;
      if (repeat){
        t.wrapS = t.wrapT = THREE.RepeatWrapping;
        t.repeat.set(repeat[0], repeat[1]);
      }
      resolve(t);
    }, undefined, ()=>resolve(null));
  });
}

function loadGLB(url){
  const loader = new GLTFLoader();
  return new Promise((resolve)=>{
    loader.load(url, (gltf)=>resolve(gltf.scene || null), undefined, ()=>resolve(null));
  });
}

function addStars(scene, flareTex, R){
  const grp = new THREE.Group();
  const count = 260;
  for (let i=0;i<count;i++){
    const s = new THREE.Sprite(new THREE.SpriteMaterial({
      map: flareTex || null,
      color: 0xf4f2ff,
      transparent: true,
      opacity: 0.82,
      depthWrite: false,
    }));
    const ang = Math.random() * Math.PI * 2;
    const rr = R + 28 + Math.random() * 42;
    const h = 24 + Math.random() * 34;
    s.position.set(Math.cos(ang) * rr, h, Math.sin(ang) * rr);
    const scale = 0.08 + Math.random() * 0.12;
    s.scale.setScalar(scale);
    grp.add(s);
  }
  scene.add(grp);
}

function addOuterCity(scene, R){
  const grp = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({
    color: 0x0c1018,
    roughness: 0.72,
    metalness: 0.22,
    emissive: 0x0a1020,
    emissiveIntensity: 0.35,
  });
  const winMat = new THREE.MeshStandardMaterial({
    color: 0xcfd6ff,
    roughness: 0.18,
    metalness: 0.08,
    emissive: 0x6fa0ff,
    emissiveIntensity: 0.85,
  });

  const count = 64;
  for (let i=0;i<count;i++){
    const ang = (i / count) * Math.PI * 2;
    const rr = R + 9 + Math.random() * 10;
    const w = 2 + Math.random() * 3.8;
    const d = 2 + Math.random() * 3.8;
    const h = 8 + Math.random() * 24;
    const x = Math.cos(ang) * rr;
    const z = Math.sin(ang) * rr;
    const tower = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), bodyMat);
    tower.position.set(x, h / 2, z);
    tower.rotation.y = -ang + Math.PI / 2;
    tower.castShadow = true;
    tower.receiveShadow = true;
    grp.add(tower);

    if (Math.random() < 0.9){
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.18, d * 1.02), winMat);
      stripe.position.set(x, 2 + Math.random() * Math.max(2, h - 4), z);
      stripe.rotation.y = tower.rotation.y;
      grp.add(stripe);
    }
  }
  scene.add(grp);
}

function buildChair(){
  const grp = new THREE.Group();
  const seatMat = new THREE.MeshStandardMaterial({
    color: 0x1b1523,
    roughness: 0.58,
    metalness: 0.18,
    emissive: 0x170d20,
    emissiveIntensity: 0.25,
  });
  const legMat = new THREE.MeshStandardMaterial({
    color: 0x2d2340,
    roughness: 0.35,
    metalness: 0.4,
  });
  const seat = new THREE.Mesh(new THREE.CylinderGeometry(0.44, 0.48, 0.12, 28), seatMat);
  seat.position.y = 0.56;
  seat.castShadow = true;
  seat.receiveShadow = true;
  grp.add(seat);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.72, 0.12), seatMat);
  back.position.set(0, 0.94, -0.34);
  back.castShadow = true;
  grp.add(back);
  for (const dx of [-0.2, 0.2]){
    for (const dz of [-0.18, 0.18]){
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.58, 10), legMat);
      leg.position.set(dx, 0.28, dz);
      leg.castShadow = true;
      grp.add(leg);
    }
  }
  return grp;
}

function buildDealer(scene){
  const grp = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x22222e, roughness: 0.72, metalness: 0.06 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xb68b72, roughness: 0.85, metalness: 0.0 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.72, 4, 8), bodyMat);
  torso.position.y = 1.05;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 20, 20), skinMat);
  head.position.y = 1.65;
  grp.add(torso, head);
  grp.position.set(0, 0, -2.1);
  grp.rotation.y = Math.PI;
  scene.add(grp);
}

function makeFeltTexture(logoImage){
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#070707';
  ctx.fillRect(0,0,canvas.width,canvas.height);

  // subtle cloth texture tint bands
  const grad = ctx.createLinearGradient(0,0,canvas.width,canvas.height);
  grad.addColorStop(0,'rgba(255,255,255,0.02)');
  grad.addColorStop(1,'rgba(255,255,255,0)');
  ctx.fillStyle = grad; ctx.fillRect(0,0,canvas.width,canvas.height);

  // outer trim ellipse
  ctx.strokeStyle = 'rgba(255,255,255,0.85)';
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.ellipse(canvas.width/2, canvas.height/2, 860, 360, 0, 0, Math.PI*2);
  ctx.stroke();

  // pass line curve on dealer side
  ctx.strokeStyle = 'rgba(255,255,255,0.95)';
  ctx.lineWidth = 10;
  ctx.beginPath();
  ctx.ellipse(canvas.width/2, canvas.height*0.74, 620, 180, 0, Math.PI*1.05, Math.PI*1.95);
  ctx.stroke();

  // small player guide dashes
  ctx.lineWidth = 6;
  ctx.setLineDash([24,18]);
  ctx.beginPath();
  ctx.ellipse(canvas.width/2, canvas.height/2, 690, 270, 0, 0.1, Math.PI-0.1);
  ctx.stroke();
  ctx.setLineDash([]);

  if (logoImage){
    const ratio = logoImage.width / logoImage.height;
    const h = 240;
    const w = h * ratio;
    ctx.globalAlpha = 0.95;
    ctx.drawImage(logoImage, canvas.width/2 - w/2, canvas.height/2 - h/2, w, h);
    ctx.globalAlpha = 1;
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

async function addRealTable(scene){
  const tableUrl = new URL('../assets/models/table.glb', import.meta.url).toString();
  const logoUrl = new URL('../assets/logo.png', import.meta.url).toString();
  const linenUrl = new URL('../assets/textures/linen.jpg', import.meta.url).toString();
  const linenBumpUrl = new URL('../assets/textures/linen_bump.jpg', import.meta.url).toString();
  const leatherUrl = new URL('../assets/textures/leather_dark.jpg', import.meta.url).toString();
  const leatherBumpUrl = new URL('../assets/textures/leather_dark_bump.jpg', import.meta.url).toString();

  const [tableScene, logoTex, linenTex, linenBump, leatherTex, leatherBump] = await Promise.all([
    loadGLB(tableUrl),
    loadTexture(logoUrl),
    loadTexture(linenUrl, [4,4]),
    loadTexture(linenBumpUrl, [4,4]),
    loadTexture(leatherUrl, [3,3]),
    loadTexture(leatherBumpUrl, [3,3]),
  ]);

  const grp = new THREE.Group();
  const railMat = new THREE.MeshStandardMaterial({
    map: leatherTex, bumpMap: leatherBump, bumpScale: 0.08,
    color: 0xffffff, roughness: 0.92, metalness: 0.02,
    emissive: 0x050505, emissiveIntensity: 0.08
  });

  let bbox = null;
  if (tableScene){
    tableScene.traverse((obj)=>{
      if (obj.isMesh){
        obj.castShadow = true;
        obj.receiveShadow = true;
        obj.material = railMat;
      }
    });
    tableScene.scale.setScalar(0.00125);
    const box = new THREE.Box3().setFromObject(tableScene);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    tableScene.position.x -= center.x;
    tableScene.position.z -= center.z;
    tableScene.position.y -= box.min.y;
    bbox = new THREE.Box3().setFromObject(tableScene);
    grp.add(tableScene);
  } else {
    const fallback = new THREE.Mesh(new THREE.CylinderGeometry(2.85, 3.1, 0.18, 56), railMat);
    fallback.position.y = 0.93;
    fallback.castShadow = true;
    fallback.receiveShadow = true;
    grp.add(fallback);
    bbox = new THREE.Box3(new THREE.Vector3(-3.1,0,-1.6), new THREE.Vector3(3.1,1.0,1.6));
  }

  // custom black felt with pass line and logo
  const logoImg = logoTex?.image || null;
  const feltCanvasTex = makeFeltTexture(logoImg);
  const feltMat = new THREE.MeshStandardMaterial({
    map: feltCanvasTex,
    bumpMap: linenBump || null,
    bumpScale: 0.03,
    roughnessMap: linenTex || null,
    color: 0xffffff, roughness: 0.96, metalness: 0.0,
    emissive: 0x020202, emissiveIntensity: 0.05
  });
  const felt = new THREE.Mesh(new THREE.CylinderGeometry(1,1,0.03,72), feltMat);
  felt.scale.set(1.42,1,0.74);
  felt.position.y = 0.84;
  felt.castShadow = true; felt.receiveShadow = true;
  grp.add(felt);

  // chips and cards aligned to felt
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf7f7fb, roughness: 0.6, metalness: 0.0 });
  const chipMat = new THREE.MeshStandardMaterial({ color: 0xd44545, roughness: 0.35, metalness: 0.08, emissive: 0x2a0808, emissiveIntensity: 0.2 });
  for (let i=0;i<2;i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.01, 0.56), cardMat);
    card.position.set(-0.18 + i * 0.42, 0.865, 0.72);
    card.rotation.y = 0.12 * (i ? -1 : 1);
    grp.add(card);
  }
  for (let i=0;i<6;i++){
    const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.08, 20), chipMat);
    chip.position.set(0.98 + (i % 3) * 0.12, 0.89 + Math.floor(i / 3) * 0.05, 0.72);
    grp.add(chip);
  }

  scene.add(grp);
  return grp;
}

async function addMoonAndEarth(scene, R){
  const moonUrl = new URL('../assets/textures/moon_recovery_diffuse.png', import.meta.url).toString();
  const earthUrl = new URL('../assets/textures/earth/earth albedo.jpg', import.meta.url).toString();
  const earthFallbackUrl = new URL('../assets/textures/earth_recovery_diffuse.png', import.meta.url).toString();
  const flareUrl = new URL('../flare.png', import.meta.url).toString();
  const [moonTex, earthTexPrimary, earthTexFallback, flareTex] = await Promise.all([
    loadTexture(moonUrl),
    loadTexture(earthUrl),
    loadTexture(earthFallbackUrl),
    loadTexture(flareUrl),
  ]);
  const earthTex = earthTexPrimary || earthTexFallback;

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(9.5, 40, 40),
    new THREE.MeshStandardMaterial({
      map: moonTex,
      color: 0xffffff,
      roughness: 1.0,
      metalness: 0.0,
      emissive: new THREE.Color(0x6e7c98),
      emissiveIntensity: 0.35,
    })
  );
  moon.position.set(-20, 50, -(R + 40));
  scene.add(moon);

  const moonHalo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: flareTex, color: 0xdfe8ff, transparent: true, opacity: 0.35, depthWrite: false,
  }));
  moonHalo.scale.set(28, 28, 1);
  moonHalo.position.copy(moon.position);
  scene.add(moonHalo);

  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(4.5, 32, 32),
    new THREE.MeshStandardMaterial({
      map: earthTex, color: 0xffffff, roughness: 0.95, metalness: 0.0,
      emissive: new THREE.Color(0x2f7bd0), emissiveIntensity: 0.25,
    })
  );
  earth.position.set(17, 44, -(R + 62));
  scene.add(earth);

  const earthHalo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: flareTex, color: 0x8bc7ff, transparent: true, opacity: 0.20, depthWrite: false,
  }));
  earthHalo.scale.set(12, 12, 1);
  earthHalo.position.copy(earth.position);
  scene.add(earthHalo);

  scene.userData._tickWorld = (dt)=>{
    moon.rotation.y += dt * 0.02;
    earth.rotation.y += dt * 0.05;
    earth.position.x = 17 + Math.sin(performance.now() * 0.00005) * 1.8;
    earth.position.y = 44 + Math.cos(performance.now() * 0.00004) * 1.0;
    earthHalo.position.copy(earth.position);
  };

  return flareTex;
}

export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const R = CONFIG.ROOM_RADIUS ?? 32;
  const H = CONFIG.WALL_HEIGHT ?? 22;

  scene.fog = new THREE.FogExp2(0x050608, 0.010);

  const hemi = new THREE.HemisphereLight(0xf4f6ff, 0x070810, 2.7);
  scene.add(hemi);

  const key = new THREE.DirectionalLight(0xd7e4ff, 2.8);
  key.position.set(-22, 34, -28);
  key.castShadow = false;
  scene.add(key);

  const accent = new THREE.PointLight(0xb48cff, 24, 52, 2.0);
  accent.position.set(0, 6, 0);
  scene.add(accent);

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(R + 22, 120),
    new THREE.MeshStandardMaterial({ color: 0x050508, roughness: 0.96, metalness: 0.02 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, H, 120, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0x0a0b12,
      roughness: 0.86,
      metalness: 0.06,
      emissive: 0x190926,
      emissiveIntensity: 0.22,
      side: THREE.BackSide,
    })
  );
  wall.position.set(0, H / 2, 0);
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(R - 0.45, 0.14, 12, 96),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, emissive: 0x4b1b73, emissiveIntensity: 1.2, roughness: 0.25, metalness: 0.35 })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.y = H - 0.35;
  scene.add(rim);

  const flareTex = await addMoonAndEarth(scene, R);
  addStars(scene, flareTex, R);
  addOuterCity(scene, R);
  await addRealTable(scene);

  const chairPos = [
    [0, 2.05, Math.PI],
    [-1.9, 1.15, 2.58],
    [1.9, 1.15, -2.58],
    [1.9, -1.15, -0.56],
    [-1.9, -1.15, 0.56],
    [0, -2.05, 0],
  ];
  for (const [x, z, ry] of chairPos){
    const chair = buildChair();
    chair.position.set(x, 0, z);
    chair.rotation.y = ry;
    scene.add(chair);
  }

  buildDealer(scene);
  log('Quest-safe real table + custom black felt + passline + center logo • phase 59');
  return { roomClamp: R - 2 };
}
