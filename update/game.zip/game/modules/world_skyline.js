import * as THREE from 'three';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { CONFIG } from './config.js';
import { urlsFor } from './asset_base.js';
import { addReikiHub } from './hubs/reiki_hub.js';
import { addPgaHub } from './hubs/pga_hub.js';

const CANDIDATES = {
  TABLE: [ ...urlsFor('table/table.fbx') ],
  ERIC: [ ...urlsFor('npc/eric/eric.fbx') ],
};

function delay(ms){ return new Promise(r=>setTimeout(r, ms)); }
async function loadFBXWithTimeout(loader, url, ms){
  return await Promise.race([loader.loadAsync(url), (async()=>{ await delay(ms); throw new Error('timeout'); })()]);
}
async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try { const obj = await loadFBXWithTimeout(loader, url, timeoutMs); log('Loaded FBX:', url); return obj; }
    catch (err){ log('FBX missing/timeout:', url); }
  }
  return null;
}
function boxSize(obj){ const box=new THREE.Box3().setFromObject(obj); const size=new THREE.Vector3(); const ctr=new THREE.Vector3(); box.getSize(size); box.getCenter(ctr); return { size, ctr }; }
function dropToGround(obj){ const { size, ctr } = boxSize(obj); obj.position.y += (size.y * 0.5) - ctr.y; }
function scaleToHeight(obj, targetH){ const { size } = boxSize(obj); if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y); }
function fitDiameter(obj, targetDia){ const { size } = boxSize(obj); const dia = Math.max(size.x, size.z); if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia); }
function roundRect(ctx,x,y,w,h,r){ const rr=Math.min(r,w*0.5,h*0.5); ctx.beginPath(); ctx.moveTo(x+rr,y); ctx.arcTo(x+w,y,x+w,y+h,rr); ctx.arcTo(x+w,y+h,x,y+h,rr); ctx.arcTo(x,y+h,x,y,rr); ctx.arcTo(x,y,x+w,y,rr); ctx.closePath(); }
function makeCanvasTexture(draw, width=1024, height=1024){ const canvas=document.createElement('canvas'); canvas.width=width; canvas.height=height; const ctx=canvas.getContext('2d'); draw(ctx,width,height); const tex=new THREE.CanvasTexture(canvas); tex.colorSpace=THREE.SRGBColorSpace; tex.anisotropy=8; return tex; }
function drawWrappedText(ctx, text, x, y, maxWidth, lineHeight){ const words=text.split(/\s+/); let line=''; let yy=y; for (const word of words){ const test = line ? `${line} ${word}` : word; if (ctx.measureText(test).width > maxWidth && line){ ctx.fillText(line,x,yy); line=word; yy += lineHeight; } else line=test; } if (line) ctx.fillText(line,x,yy); return yy; }

function loadTexture(rel){
  return new Promise((resolve)=>{
    const loader = new THREE.TextureLoader();
    loader.load(new URL(`../assets/${rel}`, import.meta.url).toString(), (tex)=>{
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.ClampToEdgeWrapping;
      resolve(tex);
    }, undefined, ()=>resolve(null));
  });
}

function buildOuterCity(scene, radius){
  const towerMat = new THREE.MeshStandardMaterial({ color:0x0d1119, roughness:0.82, metalness:0.08, emissive:0x14203b, emissiveIntensity:0.36 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color:0x8ebcff, roughness:0.16, metalness:0.12, transmission:0.12, transparent:true, opacity:0.9 });
  const windowMat = new THREE.MeshBasicMaterial({ color:0x7bc8ff, transparent:true, opacity:0.82 });
  const group = new THREE.Group();
  const rings = [radius+12, radius+18, radius+24];
  const counts = [28, 36, 42];
  for (let r=0;r<rings.length;r++){
    for (let i=0;i<counts[r];i++){
      const angle = (i / counts[r]) * Math.PI * 2;
      const x = Math.cos(angle) * rings[r];
      const z = Math.sin(angle) * rings[r];
      const h = 13 + r*4 + (Math.sin(i*1.37)*0.5 + 0.5)*24;
      const w = 2.2 + (i%3)*0.8 + r*0.2;
      const d = 2.0 + ((i+1)%4)*0.6;
      const useCylinder = ((i+r)%5===0);
      const geo = useCylinder ? new THREE.CylinderGeometry(w*0.44, w*0.58, h, 10) : new THREE.BoxGeometry(w,h,d);
      const mesh = new THREE.Mesh(geo, useCylinder ? glassMat : towerMat);
      mesh.position.set(x, h*0.5, z);
      mesh.rotation.y = -angle + Math.PI*0.5;
      group.add(mesh);
      const bands = 2 + (i % 3);
      for (let b=0;b<bands;b++){
        const strip = new THREE.Mesh(new THREE.BoxGeometry(useCylinder ? w*0.9 : w*0.88, 0.16, useCylinder ? w*0.9 : d*1.03), windowMat);
        strip.position.set(x, h*(0.24 + 0.17*b), z);
        strip.rotation.y = mesh.rotation.y;
        group.add(strip);
      }
    }
  }
  const willis = new THREE.Mesh(new THREE.BoxGeometry(5.4, 46, 5.2), new THREE.MeshStandardMaterial({ color:0x101526, roughness:0.72, metalness:0.12, emissive:0x161d37, emissiveIntensity:0.42 }));
  willis.position.set(-18,23,-(radius+18)); group.add(willis);
  for (const dx of [-0.7,0.7]){ const a = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,3.3,8), new THREE.MeshBasicMaterial({ color:0xff6a75 })); a.position.set(willis.position.x+dx,47.6,willis.position.z); group.add(a); }
  const hancock = new THREE.Mesh(new THREE.CylinderGeometry(2.9,4.6,40,12), new THREE.MeshStandardMaterial({ color:0x111825, roughness:0.6, metalness:0.18, emissive:0x13203c, emissiveIntensity:0.36 }));
  hancock.position.set(16,20,-(radius+18)); group.add(hancock);
  scene.add(group);
  scene.userData._outerCity = group;
  return group;
}

function addBuildingBillboard(scene, { position, accent='#42d392', title='', subtitle='', detail='', icon='✦' }){
  const group = new THREE.Group();
  const frame = new THREE.Mesh(new THREE.BoxGeometry(7.8, 3.9, 0.18), new THREE.MeshStandardMaterial({ color:0x11161f, roughness:0.32, metalness:0.32, emissive:new THREE.Color(accent).multiplyScalar(0.15), emissiveIntensity:0.95 }));
  group.add(frame);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(7.45, 3.55), new THREE.MeshBasicMaterial({ map: makeCanvasTexture((ctx,w,h)=>{
    const grad = ctx.createLinearGradient(0,0,w,h); grad.addColorStop(0,'#071018'); grad.addColorStop(1,'#0e1118'); ctx.fillStyle=grad; roundRect(ctx,0,0,w,h,28); ctx.fill();
    ctx.strokeStyle=accent; ctx.lineWidth=12; roundRect(ctx,12,12,w-24,h-24,24); ctx.stroke(); ctx.textAlign='center'; ctx.fillStyle=accent; ctx.font='700 108px Arial'; ctx.fillText(icon,w/2,126); ctx.fillStyle='#ffffff'; ctx.font='700 72px Arial'; ctx.fillText(title,w/2,220); ctx.fillStyle='rgba(255,255,255,0.94)'; ctx.font='600 40px Arial'; ctx.fillText(subtitle,w/2,300); ctx.fillStyle=accent; ctx.font='600 34px Arial'; ctx.fillText(detail,w/2,364);
  }, 1400, 740) }));
  face.position.z = 0.095; group.add(face); group.position.copy(position); group.lookAt(0, position.y, 0); scene.add(group); return group;
}

function addCelestialBodies(scene, radius){
  const moon = new THREE.Mesh(new THREE.SphereGeometry(4.8, 64, 64), new THREE.MeshStandardMaterial({ color:0xf5f6ff, roughness:0.98, emissive:0x24334a, emissiveIntensity:0.28 }));
  const mars = new THREE.Mesh(new THREE.SphereGeometry(2.8, 48, 48), new THREE.MeshStandardMaterial({ color:0xffddcf, roughness:0.96, emissive:0x2c1610, emissiveIntensity:0.15 }));
  scene.add(moon,mars);
  scene.userData._celestial = { moon, mars, radius, baseY: CONFIG.WALL_HEIGHT + 26, baseZ: -(radius + 86), orbit: 28 };
  return scene.userData._celestial;
}

async function applyCelestialTextures(scene){
  const celestial = scene.userData._celestial; if (!celestial) return;
  const moonTex = await loadTexture('texture/moon_diffuse.png');
  const moonBump = await loadTexture('texture/moon_bump.png');
  const marsTex = await loadTexture('texture/mars/diffuse_1k.jpg');
  const marsBump = await loadTexture('texture/mars/bump_1k.jpg');
  if (moonTex){ celestial.moon.material.map = moonTex; celestial.moon.material.bumpMap = moonBump || null; celestial.moon.material.bumpScale = 0.16; celestial.moon.material.needsUpdate = true; }
  if (marsTex){ celestial.mars.material.map = marsTex; celestial.mars.material.bumpMap = marsBump || null; celestial.mars.material.bumpScale = 0.08; celestial.mars.material.needsUpdate = true; }
}

function addStarfield(scene, radius){
  const positions = [], colors = [];
  const palette = [new THREE.Color(0xf8f5ff), new THREE.Color(0xa8c8ff), new THREE.Color(0xffb7f1), new THREE.Color(0xb0ffd9)];
  for (let i=0;i<520;i++){
    const angle = Math.random()*Math.PI*2;
    const dist = radius + 42 + Math.random()*110;
    const y = 24 + Math.random()*62;
    positions.push(Math.cos(angle)*dist, y, Math.sin(angle)*dist - 48);
    const c = palette[i % palette.length]; colors.push(c.r,c.g,c.b);
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(positions,3)); geo.setAttribute('color', new THREE.Float32BufferAttribute(colors,3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ size:0.24, transparent:true, opacity:0.88, vertexColors:true })); scene.add(pts); return pts;
}

function addLobbySprites(scene, radius){
  const textures = ['rgba(110,255,198,0.95)','rgba(255,124,227,0.92)','rgba(180,132,255,0.92)'].map(c=>makeCanvasTexture((ctx,w,h)=>{
    const grad=ctx.createRadialGradient(w/2,h/2,8,w/2,h/2,w*0.4); grad.addColorStop(0,'rgba(255,255,255,1)'); grad.addColorStop(0.28,c); grad.addColorStop(1,'rgba(255,255,255,0)'); ctx.fillStyle=grad; ctx.fillRect(0,0,w,h);
  }, 256, 256));
  const particles=[];
  for (let i=0;i<180;i++){
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map:textures[i%textures.length], transparent:true, opacity:0.42 + Math.random()*0.22, depthWrite:false }));
    const angle = Math.random()*Math.PI*2; const dist = 4 + Math.random()*(radius-8); sprite.position.set(Math.cos(angle)*dist, 0.18 + Math.random()*4.4, Math.sin(angle)*dist); const s = 0.08 + Math.random()*0.08; sprite.scale.setScalar(s); scene.add(sprite); particles.push({ sprite, speed:0.10 + Math.random()*0.12, drift:(Math.random()-0.5)*0.08 });
  }
  return particles;
}

function addPortalPad(scene, { position, label, accent=0x7dffb2, url }){
  const group = new THREE.Group();
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.55, 0.84, 56), new THREE.MeshStandardMaterial({ color: accent, roughness:0.24, metalness:0.16, emissive: accent, emissiveIntensity: 0.72, side:THREE.DoubleSide }));
  ring.rotation.x = -Math.PI/2; ring.position.y = 0.03; group.add(ring);
  const disc = new THREE.Mesh(new THREE.CircleGeometry(0.52, 48), new THREE.MeshBasicMaterial({ map: makeCanvasTexture((ctx,w,h)=>{
    const grad=ctx.createRadialGradient(w/2,h/2,8,w/2,h/2,w*0.45); grad.addColorStop(0,'rgba(255,255,255,0.95)'); grad.addColorStop(0.28,new THREE.Color(accent).getStyle()); grad.addColorStop(1,'rgba(0,0,0,0)'); ctx.fillStyle=grad; ctx.fillRect(0,0,w,h); ctx.textAlign='center'; ctx.fillStyle='rgba(255,255,255,0.96)'; ctx.font='700 86px Arial'; ctx.fillText(label.toUpperCase(), w/2, h/2+24);
  }, 1024, 1024), transparent:true, opacity:0.92, side:THREE.DoubleSide }));
  disc.rotation.x=-Math.PI/2; disc.position.y=0.031; group.add(disc);
  const plaque = new THREE.Mesh(new THREE.PlaneGeometry(1.8,0.36), new THREE.MeshBasicMaterial({ map: makeCanvasTexture((ctx,w,h)=>{ ctx.fillStyle='rgba(4,8,12,0.92)'; roundRect(ctx,0,0,w,h,20); ctx.fill(); ctx.strokeStyle=new THREE.Color(accent).getStyle(); ctx.lineWidth=8; roundRect(ctx,8,8,w-16,h-16,16); ctx.stroke(); ctx.textAlign='center'; ctx.fillStyle='#fff'; ctx.font='700 74px Arial'; ctx.fillText(label.toUpperCase(), w/2, 98); }, 1000, 180), transparent:true }));
  plaque.position.set(0,1.25,-0.1); group.add(plaque);
  group.position.copy(position); scene.add(group);
  return { group, center: position.clone(), radius: 0.95, url };
}

function buildProceduralTable(scene){
  const root = new THREE.Group();
  const rail = new THREE.Mesh(new THREE.CylinderGeometry(1.55,1.7,0.18,48), new THREE.MeshStandardMaterial({ color:0x251321, roughness:0.85, metalness:0.08, emissive:0x1c0818, emissiveIntensity:0.28 })); rail.position.y = 0.78; root.add(rail);
  const felt = new THREE.Mesh(new THREE.CylinderGeometry(1.26,1.35,0.08,48), new THREE.MeshStandardMaterial({ color:0x144b34, roughness:0.92, metalness:0.02, emissive:0x07180f, emissiveIntensity:0.16 })); felt.position.y = 0.81; root.add(felt);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.28,0.52,0.78,18), new THREE.MeshStandardMaterial({ color:0x1b1b22, roughness:0.74, metalness:0.24 })); base.position.y = 0.39; root.add(base);
  scene.add(root); return root;
}
function buildDealerStandIn(scene){
  const group = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.24,1.0,8,16), new THREE.MeshStandardMaterial({ color:0x22242c, roughness:0.6, metalness:0.1, emissive:0x170d22, emissiveIntensity:0.25 })); body.position.y = 1.0; group.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18,18,18), new THREE.MeshStandardMaterial({ color:0xcda78e, roughness:0.95 })); head.position.y = 1.78; group.add(head);
  group.position.set(0,0,-2.2); group.rotation.y = Math.PI; scene.add(group); return group;
}

export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const radius = CONFIG.ROOM_RADIUS ?? 32;
  const wallH = CONFIG.WALL_HEIGHT ?? 22;
  scene.add(new THREE.HemisphereLight(0xffffff, 0x081018, 1.45));
  const key = new THREE.PointLight(0xffffff, 62, 260, 2.0); key.position.set(0, 12, 2); scene.add(key);
  const violetFill = new THREE.PointLight(0xb48cff, 22, 90, 2.1); violetFill.position.set(0, 5, -6); scene.add(violetFill);
  const mintFill = new THREE.PointLight(0x78ffd2, 14, 70, 2.0); mintFill.position.set(-5, 4, 8); scene.add(mintFill);

  const floor = new THREE.Mesh(new THREE.CircleGeometry(radius + 30, 180), new THREE.MeshStandardMaterial({ color:0x050508, roughness:0.97, metalness:0.02 })); floor.rotation.x=-Math.PI/2; scene.add(floor);
  const wall = new THREE.Mesh(new THREE.CylinderGeometry(radius,radius,wallH,200,1,true), new THREE.MeshStandardMaterial({ color:0x070712, roughness:0.85, metalness:0.06, emissive:0x18263c, emissiveIntensity:0.26, side:THREE.BackSide })); wall.position.y = wallH/2; scene.add(wall);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(radius-0.8,0.22,16,220), new THREE.MeshStandardMaterial({ color:0xb48cff, roughness:0.22, metalness:0.34, emissive:0x2a0d3a, emissiveIntensity:1.2 })); rim.rotation.x = Math.PI/2; rim.position.y = wallH-0.28; scene.add(rim);

  buildOuterCity(scene, radius);
  addBuildingBillboard(scene, { position:new THREE.Vector3(-26, 16, -(radius + 14.8)), accent:'#ff9a56', title:'ESPRESSO WITH CREAM', subtitle:'Smooth roast • warm glow', detail:'Lobby-facing sponsor feature', icon:'☕' });
  addBuildingBillboard(scene, { position:new THREE.Vector3(26, 15.8, -(radius + 14.6)), accent:'#55ffd2', title:'TRUEITIVE.COM', subtitle:'Holistic Healing & Wellness', detail:'Founder-led Reiki network', icon:'✦' });
  addCelestialBodies(scene, radius);
  applyCelestialTextures(scene).catch(()=>{});
  addStarfield(scene, radius);
  const lobbySprites = addLobbySprites(scene, radius);

  const mainPanel = new THREE.Mesh(new THREE.PlaneGeometry(9.2, wallH-0.4), new THREE.MeshBasicMaterial({ map: makeCanvasTexture((ctx,w,h)=>{
    const grad = ctx.createLinearGradient(0,0,w,h); grad.addColorStop(0,'#0a1020'); grad.addColorStop(1,'#040507'); ctx.fillStyle=grad; roundRect(ctx,0,0,w,h,42); ctx.fill(); ctx.strokeStyle='#a88cff'; ctx.lineWidth=16; roundRect(ctx,16,16,w-32,h-32,34); ctx.stroke(); ctx.textAlign='center'; ctx.fillStyle='#ffffff'; ctx.font='700 130px Arial'; ctx.fillText('SCARLETT VR POKER', w/2, 180); ctx.fillStyle='#d7c9ff'; ctx.font='700 74px Arial'; ctx.fillText('MAIN LOBBY', w/2, 280); ctx.fillStyle='#8ef7c8'; ctx.font='600 46px Arial'; ctx.fillText('Jumbotron • Reiki Room • Scorpion Room', w/2, 360); ctx.fillStyle='rgba(255,255,255,0.85)'; ctx.font='600 38px Arial'; ctx.fillText('Real lobby restored • hubs aligned • room portals active', w/2, 430); }, 1800, 1600), transparent:true }));
  mainPanel.position.set(0, wallH*0.5, -radius + 0.36); mainPanel.rotation.y = 0; scene.add(mainPanel);

  const pga = await addPgaHub(scene, { radius, wallHeight: wallH, log });
  const reiki = await addReikiHub(scene, { radius, wallHeight: wallH, log });

  const padReiki = addPortalPad(scene, { position:new THREE.Vector3(-5.0, 0, 7.0), label:'Reiki', accent:0x78ffd2, url:'./reiki/' });
  const padScorpion = addPortalPad(scene, { position:new THREE.Vector3(5.0, 0, 7.0), label:'Scorpion', accent:0xb48cff, url:'./sandbox/' });
  scene.userData._roomPortals = [padReiki, padScorpion, pga.portal, reiki.portal].filter(Boolean);

  const tablePlaceholder = buildProceduralTable(scene);
  const dealerPlaceholder = buildDealerStandIn(scene);

  scene.userData._tickWorld = (dt)=>{
    const t = scene.userData._elapsed = (scene.userData._elapsed || 0) + dt;
    rim.material.emissiveIntensity = 1.0 + Math.sin(t*0.4)*0.12;
    for (let i=0;i<lobbySprites.length;i++){
      const s = lobbySprites[i];
      s.sprite.position.y += s.speed * dt;
      s.sprite.position.x += Math.sin(t*0.6 + i)*s.drift*dt;
      if (s.sprite.position.y > 5.2){ s.sprite.position.y = 0.16; }
    }
    const c = scene.userData._celestial;
    if (c){
      const phase = t * 0.018;
      c.moon.position.set(Math.cos(phase) * 18, c.baseY + Math.sin(phase*0.4) * 2.2, c.baseZ + Math.sin(phase) * 11);
      c.mars.position.set(Math.cos(phase + 0.65) * 12, c.baseY + 6 + Math.sin(phase + 0.65) * 1.5, c.baseZ + 10 + Math.sin(phase + 0.65) * 7);
      c.moon.rotation.y += dt * 0.03;
      c.mars.rotation.y += dt * 0.018;
    }
  };

  (async()=>{
    const table = await tryLoadFBX(CANDIDATES.TABLE, log, 10000);
    if (table){
      table.traverse((child)=>{ if (child.isMesh){ child.castShadow = true; child.receiveShadow = true; } });
      scaleToHeight(table, 0.95); dropToGround(table); fitDiameter(table, 2.75); dropToGround(table); table.position.set(0,0,0);
      if (tablePlaceholder?.parent) tablePlaceholder.parent.remove(tablePlaceholder); scene.add(table);
    }
    const eric = await tryLoadFBX(CANDIDATES.ERIC, log, 10000);
    if (eric){ scaleToHeight(eric, 1.78); dropToGround(eric); eric.position.set(0,0,-2.2); eric.rotation.y = Math.PI; if (dealerPlaceholder?.parent) dealerPlaceholder.parent.remove(dealerPlaceholder); scene.add(eric); }
  })().catch((err)=> log('Asset stream error:', String(err)));

  return { roomClamp: radius - 2.0 };
}
