import * as THREE from "three";
import { CONFIG } from "./config.js";
import { makeCanvasLabel, roundRect } from "./utils.js";

const SUITS = ["S", "H", "D", "C"];
const SUIT_SYMBOL = { S: "♠", H: "♥", D: "♦", C: "♣" };
const SUIT_COLOR = { S: "#101218", C: "#101218", H: "#c71f44", D: "#c71f44" };
const RANK_LABEL = { 14: "A", 13: "K", 12: "Q", 11: "J", 10: "10", 9: "9", 8: "8", 7: "7", 6: "6", 5: "5", 4: "4", 3: "3", 2: "2" };

export function createPokerDemo({ scene, chairRings = [], statusCb = () => {}, log = console.log }) {
  const group = new THREE.Group();
  scene.add(group);

  const uiRoot = new THREE.Group();
  uiRoot.position.set(0, CONFIG.TABLE_TOP_Y + 0.34, -0.04);
  group.add(uiRoot);

  const dealerOrigin = new THREE.Vector3(0, CONFIG.TABLE_TOP_Y + 0.045, -0.66);
  const boardAnchors = [-0.44, -0.22, 0, 0.22, 0.44].map((x) => ({
    position: new THREE.Vector3(x, CONFIG.TABLE_TOP_Y + 0.024, -0.02),
    rotationY: 0,
  }));
  const burnAnchors = [-0.34, -0.24, -0.14].map((x) => ({
    position: new THREE.Vector3(x, CONFIG.TABLE_TOP_Y + 0.022, -0.34),
    rotationY: 0,
  }));
  const playerAnchors = makePlayerAnchors();

  const cardObjects = [];
  const animations = [];
  const textureCache = new Map();
  const ringBase = chairRings.map((ring) => ({
    color: ring.material.color.clone(),
    emissive: ring.material.emissive.clone(),
    emissiveIntensity: ring.material.emissiveIntensity ?? 1,
  }));

  const info = makeDynamicPanel(1024, 180, 2.55, 0.42);
  info.mesh.position.set(0, 0, 0.08);
  uiRoot.add(info.mesh);

  const showdown = makeDynamicPanel(1024, 180, 2.85, 0.44);
  showdown.mesh.position.set(0, 0.42, -0.18);
  uiRoot.add(showdown.mesh);

  const roleMarkers = {
    dealer: createSeatMarker("D", 0xf3f4fb, 0x6a6595, "#20232c"),
    sb: createSeatMarker("SB", 0x8ce5ff, 0x22596d, "#0f2331", 0.11),
    bb: createSeatMarker("BB", 0xffd977, 0x664e17, "#261d06", 0.11),
  };
  group.add(roleMarkers.dealer);
  group.add(roleMarkers.sb);
  group.add(roleMarkers.bb);

  const potStack = new THREE.Group();
  group.add(potStack);

  let handNumber = 0;
  let nowS = 0;
  let queued = [];
  let stepIndex = 0;
  let current = null;

  function makePlayerAnchors() {
    const anchors = [];
    for (let i = 0; i < CONFIG.CHAIR_COUNT; i += 1) {
      const a = (i / CONFIG.CHAIR_COUNT) * Math.PI * 2 + Math.PI;
      const radial = new THREE.Vector3(Math.cos(a), 0, Math.sin(a));
      const tangent = new THREE.Vector3(-Math.sin(a), 0, Math.cos(a));
      const base = new THREE.Vector3(radial.x * 1.13, CONFIG.TABLE_TOP_Y + 0.024, radial.z * 0.78).addScaledVector(radial, -0.04);
      const yaw = Math.atan2(-base.x, -base.z);
      anchors.push({
        index: i,
        name: `P${i + 1}`,
        radial,
        cards: [
          { position: base.clone().addScaledVector(tangent, -0.11), rotationY: yaw },
          { position: base.clone().addScaledVector(tangent, 0.11), rotationY: yaw },
        ],
      });
    }
    return anchors;
  }

  function createSeatMarker(text, color, emissive, textColor = "#111111", scale = 0.125) {
    const wrap = new THREE.Group();
    const disc = new THREE.Mesh(
      new THREE.CylinderGeometry(scale, scale, 0.024, 28),
      new THREE.MeshStandardMaterial({ color, emissive, emissiveIntensity: 0.9, roughness: 0.34, metalness: 0.18 })
    );
    disc.rotation.x = Math.PI / 2;
    wrap.add(disc);

    const { texture } = makeCanvasLabel({
      width: 256,
      height: 256,
      draw(ctx, w, h) {
        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = textColor;
        ctx.font = text.length > 1 ? "bold 100px system-ui" : "bold 128px system-ui";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(text, w / 2, h / 2 + 8);
      },
    });
    const label = new THREE.Mesh(
      new THREE.PlaneGeometry(scale * 1.55, scale * 1.55),
      new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, side: THREE.DoubleSide })
    );
    label.rotation.x = -Math.PI / 2;
    label.position.y = 0.017;
    wrap.add(label);
    wrap.visible = false;
    return wrap;
  }

  function makeDynamicPanel(width, height, worldW, worldH) {
    const { canvas, ctx, texture } = makeCanvasLabel({
      width,
      height,
      draw(drawCtx, w, h) {
        drawCtx.clearRect(0, 0, w, h);
      },
    });
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(worldW, worldH),
      new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, side: THREE.DoubleSide })
    );
    return { mesh, canvas, ctx, texture };
  }

  function paintPanel(panel, title, subtitle, accent = "rgba(180,140,255,0.92)") {
    const { ctx, canvas, texture } = panel;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(0,0,0,0.58)";
    roundRect(ctx, 12, 12, canvas.width - 24, canvas.height - 24, 36);
    ctx.fill();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 8;
    roundRect(ctx, 12, 12, canvas.width - 24, canvas.height - 24, 36);
    ctx.stroke();
    ctx.fillStyle = "#f5f0ff";
    ctx.font = "bold 78px system-ui";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(title, canvas.width / 2, 68);
    ctx.fillStyle = "rgba(236,232,255,0.92)";
    ctx.font = "40px system-ui";
    ctx.fillText(subtitle, canvas.width / 2, 126);
    texture.needsUpdate = true;
  }

  function paintInfo(title, subtitle) {
    paintPanel(info, title, subtitle, "rgba(126,240,208,0.92)");
  }

  function getCardTexture(card) {
    const key = card ? `${card.rank}${card.suit}` : "back";
    if (textureCache.has(key)) return textureCache.get(key);
    const { texture } = makeCanvasLabel({
      width: 512,
      height: 768,
      draw(ctx, w, h) {
        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = "#ffffff";
        roundRect(ctx, 12, 12, w - 24, h - 24, 38);
        ctx.fill();
        ctx.strokeStyle = "#d6d9e7";
        ctx.lineWidth = 8;
        roundRect(ctx, 12, 12, w - 24, h - 24, 38);
        ctx.stroke();
        if (!card) {
          ctx.fillStyle = "#160d28";
          roundRect(ctx, 38, 38, w - 76, h - 76, 30);
          ctx.fill();
          ctx.strokeStyle = "rgba(180,140,255,0.85)";
          ctx.lineWidth = 10;
          roundRect(ctx, 54, 54, w - 108, h - 108, 22);
          ctx.stroke();
          ctx.fillStyle = "rgba(239,233,255,0.95)";
          ctx.font = "bold 86px system-ui";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText("SVR", w / 2, h / 2 - 30);
          ctx.font = "bold 44px system-ui";
          ctx.fillText("ALL IN", w / 2, h / 2 + 44);
          return;
        }
        const color = SUIT_COLOR[card.suit];
        const rank = RANK_LABEL[card.rank];
        const suit = SUIT_SYMBOL[card.suit];
        ctx.fillStyle = color;
        ctx.font = "bold 108px Georgia, serif";
        ctx.textAlign = "left";
        ctx.textBaseline = "top";
        ctx.fillText(rank, 44, 28);
        ctx.font = "bold 86px Georgia, serif";
        ctx.fillText(suit, 48, 138);
        ctx.textAlign = "right";
        ctx.textBaseline = "bottom";
        ctx.fillText(rank, w - 44, h - 136);
        ctx.font = "bold 86px Georgia, serif";
        ctx.fillText(suit, w - 48, h - 28);
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.font = "bold 220px Georgia, serif";
        ctx.globalAlpha = 0.92;
        ctx.fillText(suit, w / 2, h / 2 + 18);
        ctx.globalAlpha = 1;
      },
    });
    texture.colorSpace = THREE.SRGBColorSpace;
    textureCache.set(key, texture);
    return texture;
  }

  function createCardMesh(card) {
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(0.18, 0.26),
      new THREE.MeshStandardMaterial({ map: getCardTexture(card), transparent: false, roughness: 0.82, metalness: 0.02, emissive: 0x120810, emissiveIntensity: 0.05, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 })
    );
    mesh.userData.card = card;
    mesh.position.copy(dealerOrigin);
    mesh.rotation.x = -Math.PI / 2;
    return mesh;
  }

  function addCard(card, target, delay = 0.42) {
    const mesh = createCardMesh(card);
    mesh.position.copy(dealerOrigin);
    mesh.rotation.set(-Math.PI / 2, 0, 0);
    group.add(mesh);
    cardObjects.push(mesh);
    animations.push({
      mesh,
      fromPos: dealerOrigin.clone(),
      toPos: target.position.clone(),
      fromRotX: -Math.PI / 2,
      toRotX: -Math.PI / 2,
      fromRotY: 0,
      toRotY: target.rotationY,
      start: nowS,
      end: nowS + delay,
    });
    return mesh;
  }

  function addBurnCard(index, delay = 0.38) {
    return addCard(null, burnAnchors[index], delay);
  }

  function clearCards() {
    while (cardObjects.length) {
      const mesh = cardObjects.pop();
      mesh.parent?.remove(mesh);
    }
    animations.length = 0;
  }

  function updateMarkerPosition(marker, seatIndex, radius = 0.36, height = 0.052, lateral = 0) {
    const anchor = playerAnchors[seatIndex];
    const radial = anchor.radial.clone().multiplyScalar(radius);
    const tangent = new THREE.Vector3(-anchor.radial.z, 0, anchor.radial.x).multiplyScalar(lateral);
    marker.position.copy(new THREE.Vector3(radial.x, CONFIG.TABLE_TOP_Y + height, radial.z).add(tangent));
    marker.visible = true;
  }

  function setRoleMarkers(dealerIndex, sbIndex, bbIndex) {
    updateMarkerPosition(roleMarkers.dealer, dealerIndex, 0.38, 0.05, 0);
    updateMarkerPosition(roleMarkers.sb, sbIndex, 0.34, 0.045, -0.06);
    updateMarkerPosition(roleMarkers.bb, bbIndex, 0.34, 0.045, 0.06);
  }

  function clearPotStack() {
    while (potStack.children.length) potStack.remove(potStack.children[0]);
  }

  function refreshPotStack() {
    clearPotStack();
    if (!current) return;
    const chipCount = Math.max(1, Math.min(26, Math.round(current.pot / 20)));
    const palette = [0x7d4dff, 0x2bd4ff, 0xf2d269, 0xff6fb1];
    for (let i = 0; i < chipCount; i += 1) {
      const chip = new THREE.Mesh(
        new THREE.CylinderGeometry(0.066, 0.066, 0.016, 24),
        new THREE.MeshStandardMaterial({ color: palette[i % palette.length], roughness: 0.34, metalness: 0.14, emissive: palette[i % palette.length], emissiveIntensity: 0.32 })
      );
      const layer = Math.floor(i / 7);
      const offset = i % 7;
      chip.rotation.x = Math.PI / 2;
      chip.position.set((offset - 3) * 0.028, CONFIG.TABLE_TOP_Y + 0.026 + layer * 0.018, 0.18 + Math.sin(i * 1.7) * 0.012);
      chip.userData.baseY = chip.position.y;
      potStack.add(chip);
    }
  }

  function resetRingHighlights() {
    chairRings.forEach((ring, i) => {
      if (!ringBase[i]) return;
      ring.material.color.copy(ringBase[i].color);
      ring.material.emissive.copy(ringBase[i].emissive);
      ring.material.emissiveIntensity = ringBase[i].emissiveIntensity;
      ring.material.opacity = 0.58;
      ring.scale.setScalar(1);
    });
  }

  function applyWinnerHighlight(index) {
    chairRings.forEach((ring, i) => {
      if (i === index) {
        ring.material.color.set(0xf2d269);
        ring.material.emissive.set(0x6c5320);
        ring.material.emissiveIntensity = 2.8;
        ring.material.opacity = 0.95;
        ring.scale.setScalar(1.03);
      }
    });
  }

  function applyActionHighlight(index) {
    chairRings.forEach((ring, i) => {
      if (!ringBase[i]) return;
      if (i === index) {
        ring.material.color.set(0x8ce5ff);
        ring.material.emissive.set(0x16485e);
        ring.material.emissiveIntensity = 2.1;
        ring.material.opacity = 0.92;
        ring.scale.setScalar(1.018);
      } else if (current?.stage !== "showdown") {
        ring.material.color.copy(ringBase[i].color);
        ring.material.emissive.copy(ringBase[i].emissive);
        ring.material.emissiveIntensity = ringBase[i].emissiveIntensity;
        ring.material.opacity = 0.56;
        ring.scale.setScalar(1);
      }
    });
  }

  function createDeck() {
    const deck = [];
    for (const suit of SUITS) {
      for (let rank = 2; rank <= 14; rank += 1) deck.push({ rank, suit, code: `${RANK_LABEL[rank]}${suit}` });
    }
    return deck;
  }

  function shuffle(deck) {
    for (let i = deck.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
  }

  function compareArrays(a, b) {
    const len = Math.max(a.length, b.length);
    for (let i = 0; i < len; i += 1) {
      const av = a[i] ?? -1;
      const bv = b[i] ?? -1;
      if (av !== bv) return av - bv;
    }
    return 0;
  }

  function evaluate5(cards) {
    const ranks = cards.map((c) => c.rank).sort((a, b) => b - a);
    const counts = new Map();
    ranks.forEach((r) => counts.set(r, (counts.get(r) || 0) + 1));
    const byCount = [...counts.entries()].sort((a, b) => b[1] - a[1] || b[0] - a[0]);
    const flush = cards.every((c) => c.suit === cards[0].suit);
    const uniqueRanks = [...new Set(ranks)].sort((a, b) => b - a);
    let straightHigh = 0;
    if (uniqueRanks.length >= 5) {
      for (let i = 0; i <= uniqueRanks.length - 5; i += 1) {
        const slice = uniqueRanks.slice(i, i + 5);
        if (slice[0] - slice[4] === 4) {
          straightHigh = slice[0];
          break;
        }
      }
      if (!straightHigh && uniqueRanks.includes(14) && uniqueRanks.includes(5) && uniqueRanks.includes(4) && uniqueRanks.includes(3) && uniqueRanks.includes(2)) straightHigh = 5;
    }
    if (straightHigh && flush) return { score: [8, straightHigh], name: straightHigh === 14 ? "Royal Flush" : "Straight Flush" };
    if (byCount[0][1] === 4) {
      const kicker = byCount.find((e) => e[1] === 1)[0];
      return { score: [7, byCount[0][0], kicker], name: "Four of a Kind" };
    }
    if (byCount[0][1] === 3 && byCount[1]?.[1] === 2) return { score: [6, byCount[0][0], byCount[1][0]], name: "Full House" };
    if (flush) return { score: [5, ...ranks], name: "Flush" };
    if (straightHigh) return { score: [4, straightHigh], name: "Straight" };
    if (byCount[0][1] === 3) {
      const kickers = byCount.filter((e) => e[1] === 1).map((e) => e[0]).sort((a, b) => b - a);
      return { score: [3, byCount[0][0], ...kickers], name: "Three of a Kind" };
    }
    if (byCount[0][1] === 2 && byCount[1]?.[1] === 2) {
      const pairRanks = byCount.filter((e) => e[1] === 2).map((e) => e[0]).sort((a, b) => b - a);
      const kicker = byCount.find((e) => e[1] === 1)[0];
      return { score: [2, pairRanks[0], pairRanks[1], kicker], name: "Two Pair" };
    }
    if (byCount[0][1] === 2) {
      const kickers = byCount.filter((e) => e[1] === 1).map((e) => e[0]).sort((a, b) => b - a);
      return { score: [1, byCount[0][0], ...kickers], name: "Pair" };
    }
    return { score: [0, ...ranks], name: "High Card" };
  }

  function evaluate7(cards) {
    let best = null;
    for (let a = 0; a < cards.length - 4; a += 1) {
      for (let b = a + 1; b < cards.length - 3; b += 1) {
        for (let c = b + 1; c < cards.length - 2; c += 1) {
          for (let d = c + 1; d < cards.length - 1; d += 1) {
            for (let e = d + 1; e < cards.length; e += 1) {
              const result = evaluate5([cards[a], cards[b], cards[c], cards[d], cards[e]]);
              if (!best || compareArrays(result.score, best.score) > 0) best = result;
            }
          }
        }
      }
    }
    return best;
  }

  function formatCards(cards) {
    return cards.map((card) => `${RANK_LABEL[card.rank]}${SUIT_SYMBOL[card.suit]}`).join(" ");
  }

  function seatName(index) {
    return playerAnchors[index]?.name || `P${index + 1}`;
  }

  function handStrengthToBet(result, street = "preflop") {
    const level = result.score[0];
    if (street === "preflop") return level >= 2 ? 80 : level >= 1 ? 50 : 35;
    if (street === "flop") return level >= 3 ? 120 : level >= 1 ? 60 : 40;
    if (street === "turn") return level >= 4 ? 160 : level >= 2 ? 80 : 45;
    return level >= 5 ? 220 : level >= 2 ? 90 : 55;
  }

  function actionText(playerName, street, verb, amount) {
    return `${playerName} ${verb} • ${street} • +$${amount}`;
  }

  function setAction(playerIndex, street, verb, amount, subtitle) {
    current.actorIndex = playerIndex;
    current.stage = street.toLowerCase();
    current.pot += amount;
    applyActionHighlight(playerIndex);
    refreshPotStack();
    paintInfo(actionText(seatName(playerIndex), street, verb, amount), subtitle || `pot $${current.pot}`);
    statusCb(`HAND ${handNumber} • ${seatName(playerIndex)} ${verb.toLowerCase()} • pot $${current.pot}`);
  }

  function schedule(at, fn) {
    queued.push({ at, fn });
  }

  function planHand() {
    handNumber += 1;
    clearCards();
    clearPotStack();
    resetRingHighlights();

    const dealerIndex = (handNumber - 1) % CONFIG.CHAIR_COUNT;
    const sbIndex = (dealerIndex + 1) % CONFIG.CHAIR_COUNT;
    const bbIndex = (dealerIndex + 2) % CONFIG.CHAIR_COUNT;

    const deck = shuffle(createDeck());
    const players = playerAnchors.map((anchor) => ({ anchor, cards: [deck.shift(), deck.shift()] }));
    const board = [deck.shift(), deck.shift(), deck.shift(), deck.shift(), deck.shift()];
    const results = players.map((player) => ({ player, result: evaluate7([...player.cards, ...board]) }));
    results.sort((a, b) => compareArrays(b.result.score, a.result.score));
    const winner = results[0];
    const runnerUp = results[1];
    const preflopAggressor = winner.player.anchor.index;
    const flopAggressor = runnerUp.player.anchor.index;
    const turnAggressor = winner.player.anchor.index;
    const riverAggressor = winner.player.anchor.index;

    current = { players, board, winner, results, handNumber, dealerIndex, sbIndex, bbIndex, actorIndex: null, pot: 0, stage: "shuffle" };

    setRoleMarkers(dealerIndex, sbIndex, bbIndex);
    refreshPotStack();

    queued = [];
    let t = nowS + 0.75;

    schedule(t, () => {
      current.stage = "blinds";
      current.pot = 30;
      refreshPotStack();
      applyActionHighlight(bbIndex);
      paintInfo(`Dealer ${seatName(dealerIndex)} • SB ${seatName(sbIndex)} • BB ${seatName(bbIndex)}`, `Hand ${handNumber} • pot $${current.pot}`);
      paintPanel(showdown, "Texas Hold’em extended demo", `Hand ${handNumber} • dealer button + blinds + burn cards live`, "rgba(126,240,208,0.92)");
      statusCb(`HAND ${handNumber} • blinds live • pot $${current.pot}`);
    });

    for (let round = 0; round < 2; round += 1) {
      for (let i = 0; i < players.length; i += 1) {
        t += 0.42;
        schedule(t, () => {
          const player = players[i];
          const card = player.cards[round];
          addCard(card, player.anchor.cards[round], 0.46);
          current.stage = "deal";
          current.actorIndex = player.anchor.index;
          applyActionHighlight(player.anchor.index);
          paintInfo(`Dealing ${player.anchor.name}`, `${formatCards(player.cards.slice(0, round + 1))} • pot $${current.pot}`);
          statusCb(`HAND ${handNumber} • dealing ${player.anchor.name}`);
        });
      }
    }

    t += 0.95;
    schedule(t, () => {
      const actor = preflopAggressor;
      const result = current.results.find((r) => r.player.anchor.index === actor)?.result || winner.result;
      const amount = handStrengthToBet(result, "preflop");
      setAction(actor, "Preflop", result.score[0] >= 2 ? "raises" : "calls", amount, `${formatCards(players[actor].cards)} • pot $${current.pot + amount}`);
    });

    t += 0.52;
    schedule(t, () => {
      addBurnCard(0, 0.34);
      paintInfo("Burn", `Dealer burns before the flop • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • burn before flop`);
    });

    t += 0.53;
    schedule(t, () => {
      current.stage = "flop";
      for (let i = 0; i < 3; i += 1) addCard(board[i], boardAnchors[i], 0.52);
      current.pot += 90;
      refreshPotStack();
      applyActionHighlight(flopAggressor);
      paintInfo("Flop", `${formatCards(board.slice(0, 3))} • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • flop ${formatCards(board.slice(0, 3))}`);
    });

    t += 1.2;
    schedule(t, () => {
      const actor = flopAggressor;
      const result = current.results.find((r) => r.player.anchor.index === actor)?.result || runnerUp.result;
      const amount = handStrengthToBet(result, "flop");
      const isBet = result.score[0] >= 1;
      setAction(actor, "Flop", isBet ? "bets" : "checks", isBet ? amount : 0, `${seatName(actor)} live on the flop • pot $${current.pot}`);
    });

    t += 0.58;
    schedule(t, () => {
      addBurnCard(1, 0.34);
      paintInfo("Burn", `Dealer burns before the turn • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • burn before turn`);
    });

    t += 0.67;
    schedule(t, () => {
      current.stage = "turn";
      addCard(board[3], boardAnchors[3], 0.52);
      current.pot += 60;
      refreshPotStack();
      applyActionHighlight(turnAggressor);
      paintInfo("Turn", `${formatCards(board.slice(0, 4))} • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • turn ${formatCards(board.slice(0, 4))}`);
    });

    t += 1.2;
    schedule(t, () => {
      const actor = turnAggressor;
      const result = current.results.find((r) => r.player.anchor.index === actor)?.result || winner.result;
      const amount = handStrengthToBet(result, "turn");
      const isBet = result.score[0] >= 2;
      setAction(actor, "Turn", isBet ? "bets" : "checks", isBet ? amount : 0, `${winner.result.name} pressure building • pot $${current.pot}`);
    });

    t += 0.58;
    schedule(t, () => {
      addBurnCard(2, 0.34);
      paintInfo("Burn", `Dealer burns before the river • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • burn before river`);
    });

    t += 0.67;
    schedule(t, () => {
      current.stage = "river";
      addCard(board[4], boardAnchors[4], 0.52);
      current.pot += 60;
      refreshPotStack();
      applyActionHighlight(riverAggressor);
      paintInfo("River", `${formatCards(board)} • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • river ${formatCards(board)}`);
    });

    t += 1.2;
    schedule(t, () => {
      const actor = riverAggressor;
      const result = current.results.find((r) => r.player.anchor.index === actor)?.result || winner.result;
      const amount = handStrengthToBet(result, "river");
      const isShove = result.score[0] >= 2;
      setAction(actor, "River", isShove ? "shoves" : "checks", isShove ? amount : 0, `${winner.result.name} showdown line • pot $${current.pot}`);
    });

    t += 1.55;
    schedule(t, () => {
      current.stage = "showdown";
      current.actorIndex = winner.player.anchor.index;
      applyWinnerHighlight(winner.player.anchor.index);
      refreshPotStack();
      const winnerCards = formatCards(winner.player.cards);
      const boardText = formatCards(board);
      paintInfo(`Showdown • ${winner.player.anchor.name} wins`, `${winner.result.name} • pot $${current.pot}`);
      paintPanel(showdown, `${winner.player.anchor.name} • ${winner.result.name}`, `Hole ${winnerCards} • Board ${boardText}`, "rgba(244,210,105,0.98)");
      statusCb(`HAND ${handNumber} • ${winner.player.anchor.name} wins • ${winner.result.name}`);
      log("Poker showdown", { hand: handNumber, dealer: seatName(dealerIndex), sb: seatName(sbIndex), bb: seatName(bbIndex), winner: winner.player.anchor.name, handName: winner.result.name, board: boardText });
    });

    t += 4.6;
    schedule(t, () => {
      paintPanel(showdown, "Next hand loading", `Auto-dealing hand ${handNumber + 1}`, "rgba(126,240,208,0.92)");
      planHand();
    });

    stepIndex = 0;
    paintPanel(showdown, "Texas Hold’em extended demo", `Hand ${handNumber} • real 52-card deck + burn cards`, "rgba(126,240,208,0.92)");
    paintInfo("Shuffling live deck", `Hand ${handNumber} • button moving to ${seatName(dealerIndex)}`);
    statusCb(`HAND ${handNumber} • shuffling real deck`);
  }

  function updateAnimations() {
    for (let i = animations.length - 1; i >= 0; i -= 1) {
      const anim = animations[i];
      const span = Math.max(0.0001, anim.end - anim.start);
      const t = THREE.MathUtils.clamp((nowS - anim.start) / span, 0, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      anim.mesh.position.lerpVectors(anim.fromPos, anim.toPos, eased);
      anim.mesh.position.y += Math.sin(eased * Math.PI) * 0.14;
      anim.mesh.rotation.x = THREE.MathUtils.lerp(anim.fromRotX, anim.toRotX, eased);
      anim.mesh.rotation.y = THREE.MathUtils.lerp(anim.fromRotY, anim.toRotY, eased);
      if (t >= 1) animations.splice(i, 1);
    }
  }

  function updateRings() {
    if (!current) return;
    if (current.stage === "showdown") {
      chairRings.forEach((ring, i) => {
        if (i === current.winner.player.anchor.index) {
          ring.material.opacity = 0.88 + Math.sin(nowS * 5.2) * 0.08;
          ring.material.emissiveIntensity = 2.2 + Math.sin(nowS * 6.0) * 0.45;
        }
      });
      return;
    }
    if (current.actorIndex !== null && current.actorIndex !== undefined) {
      const ring = chairRings[current.actorIndex];
      if (ring) {
        ring.material.opacity = 0.84 + Math.sin(nowS * 5.5) * 0.08;
        ring.material.emissiveIntensity = 1.8 + Math.sin(nowS * 6.2) * 0.35;
      }
    }
  }

  function updatePotStack() {
    potStack.children.forEach((chip, i) => {
      chip.position.y = chip.userData.baseY + Math.sin(nowS * 2.8 + i * 0.4) * 0.002;
      chip.rotation.z = Math.sin(nowS * 1.1 + i * 0.18) * 0.04;
    });
  }

  function updateRoleMarkers() {
    const bob = Math.sin(nowS * 2.1) * 0.003;
    [roleMarkers.dealer, roleMarkers.sb, roleMarkers.bb].forEach((marker, i) => {
      if (!marker.visible) return;
      marker.position.y = CONFIG.TABLE_TOP_Y + (i === 0 ? 0.05 : 0.045) + bob + i * 0.001;
      marker.rotation.y += 0.002 + i * 0.0004;
    });
  }

  function update(now, dt) {
    nowS = now;
    if (!current) planHand();
    while (queued[stepIndex] && nowS >= queued[stepIndex].at) {
      const queueRef = queued;
      queued[stepIndex].fn();
      if (queued !== queueRef) break;
      stepIndex += 1;
    }
    updateAnimations();
    updateRings();
    updatePotStack();
    updateRoleMarkers();
    cardObjects.forEach((mesh, i) => {
      if (animations.find((anim) => anim.mesh === mesh)) return;
      mesh.position.y = mesh.userData.baseY ?? mesh.position.y;
      if (mesh.userData.baseY === undefined) mesh.userData.baseY = mesh.position.y;
      mesh.position.y = mesh.userData.baseY + Math.sin(nowS * 1.8 + i * 0.3) * 0.0015;
    });
  }

  return {
    update,
    forceNextHand() {
      planHand();
    },
  };
}
