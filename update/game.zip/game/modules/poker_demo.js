import * as THREE from "three";
import { CONFIG } from "./config.js";
import { makeCanvasLabel, roundRect } from "./utils.js";

const SUITS = ["S", "H", "D", "C"];
const SUIT_SYMBOL = { S: "♠", H: "♥", D: "♦", C: "♣" };
const SUIT_COLOR = { S: "#101218", C: "#101218", H: "#c71f44", D: "#c71f44" };
const RANK_LABEL = { 14: "A", 13: "K", 12: "Q", 11: "J", 10: "10", 9: "9", 8: "8", 7: "7", 6: "6", 5: "5", 4: "4", 3: "3", 2: "2" };

export function createPokerDemo({ scene, chairRings = [], statusCb = () => {}, log = console.log }) {
  const group = new THREE.Group();
  scene.add(group);

  const uiRoot = new THREE.Group();
  uiRoot.position.set(0, CONFIG.TABLE_TOP_Y + 0.34, -0.04);
  group.add(uiRoot);

  const dealerOrigin = new THREE.Vector3(0, CONFIG.TABLE_TOP_Y + 0.03, -0.66);
  const boardAnchors = [-0.44, -0.22, 0, 0.22, 0.44].map((x) => ({
    position: new THREE.Vector3(x, CONFIG.TABLE_TOP_Y + 0.013, -0.02),
    rotationY: 0,
  }));
  const playerAnchors = makePlayerAnchors();

  const cardObjects = [];
  const animations = [];
  const textureCache = new Map();
  const ringBase = chairRings.map((ring) => ({ color: ring.material.color.clone(), emissive: ring.material.emissive.clone() }));

  const info = makeDynamicPanel(1024, 180, 2.5, 0.42);
  info.mesh.position.set(0, 0, 0.08);
  uiRoot.add(info.mesh);
  const showdown = makeDynamicPanel(1024, 180, 2.8, 0.44);
  showdown.mesh.position.set(0, 0.42, -0.18);
  uiRoot.add(showdown.mesh);

  let handNumber = 0;
  let nowS = 0;
  let queued = [];
  let stepIndex = 0;
  let stepAt = 0;
  let current = null;

  function makePlayerAnchors() {
    const anchors = [];
    for (let i = 0; i < CONFIG.CHAIR_COUNT; i += 1) {
      const a = (i / CONFIG.CHAIR_COUNT) * Math.PI * 2 + Math.PI;
      const radial = new THREE.Vector3(Math.cos(a), 0, Math.sin(a));
      const tangent = new THREE.Vector3(-Math.sin(a), 0, Math.cos(a));
      const base = new THREE.Vector3(radial.x * 1.13, CONFIG.TABLE_TOP_Y + 0.013, radial.z * 0.78).addScaledVector(radial, -0.04);
      const yaw = Math.atan2(-base.x, -base.z);
      anchors.push({
        index: i,
        name: `P${i + 1}`,
        cards: [
          { position: base.clone().addScaledVector(tangent, -0.11), rotationY: yaw },
          { position: base.clone().addScaledVector(tangent, 0.11), rotationY: yaw },
        ],
        labelPos: base.clone().add(new THREE.Vector3(0, 0.13, 0)),
      });
    }
    return anchors;
  }

  function makeDynamicPanel(width, height, worldW, worldH) {
    const { canvas, ctx, texture } = makeCanvasLabel({
      width,
      height,
      draw(drawCtx, w, h) {
        drawCtx.clearRect(0, 0, w, h);
      },
    });
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(worldW, worldH),
      new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, side: THREE.DoubleSide })
    );
    return { mesh, canvas, ctx, texture };
  }

  function paintPanel(panel, title, subtitle, accent = "rgba(180,140,255,0.92)") {
    const { ctx, canvas, texture } = panel;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(0,0,0,0.58)";
    roundRect(ctx, 12, 12, canvas.width - 24, canvas.height - 24, 36);
    ctx.fill();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 8;
    roundRect(ctx, 12, 12, canvas.width - 24, canvas.height - 24, 36);
    ctx.stroke();
    ctx.fillStyle = "#f5f0ff";
    ctx.font = "bold 78px system-ui";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(title, canvas.width / 2, 68);
    ctx.fillStyle = "rgba(236,232,255,0.92)";
    ctx.font = "40px system-ui";
    ctx.fillText(subtitle, canvas.width / 2, 126);
    texture.needsUpdate = true;
  }

  function getCardTexture(card) {
    const key = card ? `${card.rank}${card.suit}` : "back";
    if (textureCache.has(key)) return textureCache.get(key);
    const { texture } = makeCanvasLabel({
      width: 512,
      height: 768,
      draw(ctx, w, h) {
        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = "#ffffff";
        roundRect(ctx, 12, 12, w - 24, h - 24, 38);
        ctx.fill();
        ctx.strokeStyle = "#d6d9e7";
        ctx.lineWidth = 8;
        roundRect(ctx, 12, 12, w - 24, h - 24, 38);
        ctx.stroke();
        if (!card) {
          ctx.fillStyle = "#160d28";
          roundRect(ctx, 38, 38, w - 76, h - 76, 30);
          ctx.fill();
          ctx.strokeStyle = "rgba(180,140,255,0.85)";
          ctx.lineWidth = 10;
          roundRect(ctx, 54, 54, w - 108, h - 108, 22);
          ctx.stroke();
          ctx.fillStyle = "rgba(239,233,255,0.95)";
          ctx.font = "bold 86px system-ui";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText("SVR", w / 2, h / 2 - 30);
          ctx.font = "bold 44px system-ui";
          ctx.fillText("ALL IN", w / 2, h / 2 + 44);
          return;
        }
        const color = SUIT_COLOR[card.suit];
        const rank = RANK_LABEL[card.rank];
        const suit = SUIT_SYMBOL[card.suit];
        ctx.fillStyle = color;
        ctx.font = "bold 108px Georgia, serif";
        ctx.textAlign = "left";
        ctx.textBaseline = "top";
        ctx.fillText(rank, 44, 28);
        ctx.font = "bold 86px Georgia, serif";
        ctx.fillText(suit, 48, 138);
        ctx.textAlign = "right";
        ctx.textBaseline = "bottom";
        ctx.fillText(rank, w - 44, h - 136);
        ctx.font = "bold 86px Georgia, serif";
        ctx.fillText(suit, w - 48, h - 28);
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.font = "bold 220px Georgia, serif";
        ctx.globalAlpha = 0.92;
        ctx.fillText(suit, w / 2, h / 2 + 18);
        ctx.globalAlpha = 1;
      },
    });
    texture.colorSpace = THREE.SRGBColorSpace;
    textureCache.set(key, texture);
    return texture;
  }

  function createCardMesh(card) {
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(0.18, 0.26),
      new THREE.MeshStandardMaterial({
        map: getCardTexture(card),
        transparent: false,
        roughness: 0.82,
        metalness: 0.02,
        emissive: 0x120810,
        emissiveIntensity: 0.06,
        side: THREE.DoubleSide,
      })
    );
    mesh.userData.card = card;
    mesh.position.copy(dealerOrigin);
    mesh.rotation.x = -Math.PI / 2;
    return mesh;
  }

  function addCard(card, target, delay = 0.42) {
    const mesh = createCardMesh(card);
    mesh.position.copy(dealerOrigin);
    mesh.rotation.set(-Math.PI / 2, 0, 0);
    group.add(mesh);
    cardObjects.push(mesh);
    animations.push({
      mesh,
      fromPos: dealerOrigin.clone(),
      toPos: target.position.clone(),
      fromRotX: -Math.PI / 2,
      toRotX: -Math.PI / 2,
      fromRotY: 0,
      toRotY: target.rotationY,
      start: nowS,
      end: nowS + delay,
    });
    return mesh;
  }

  function clearCards() {
    while (cardObjects.length) {
      const mesh = cardObjects.pop();
      mesh.parent?.remove(mesh);
    }
    animations.length = 0;
  }

  function resetRingHighlights() {
    chairRings.forEach((ring, i) => {
      if (!ringBase[i]) return;
      ring.material.color.copy(ringBase[i].color);
      ring.material.emissive.copy(ringBase[i].emissive);
      ring.material.opacity = 0.58;
      ring.scale.setScalar(1);
    });
  }

  function applyWinnerHighlight(index) {
    chairRings.forEach((ring, i) => {
      if (i === index) {
        ring.material.color.set(0xf2d269);
        ring.material.emissive.set(0x6c5320);
        ring.material.emissiveIntensity = 2.8;
        ring.material.opacity = 0.95;
        ring.scale.setScalar(1.03);
      }
    });
  }

  function createDeck() {
    const deck = [];
    for (const suit of SUITS) {
      for (let rank = 2; rank <= 14; rank += 1) deck.push({ rank, suit, code: `${RANK_LABEL[rank]}${suit}` });
    }
    return deck;
  }

  function shuffle(deck) {
    for (let i = deck.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
  }

  function compareArrays(a, b) {
    const len = Math.max(a.length, b.length);
    for (let i = 0; i < len; i += 1) {
      const av = a[i] ?? -1;
      const bv = b[i] ?? -1;
      if (av !== bv) return av - bv;
    }
    return 0;
  }

  function evaluate5(cards) {
    const ranks = cards.map((c) => c.rank).sort((a, b) => b - a);
    const counts = new Map();
    ranks.forEach((r) => counts.set(r, (counts.get(r) || 0) + 1));
    const byCount = [...counts.entries()].sort((a, b) => b[1] - a[1] || b[0] - a[0]);
    const flush = cards.every((c) => c.suit === cards[0].suit);
    const uniqueRanks = [...new Set(ranks)].sort((a, b) => b - a);
    let straightHigh = 0;
    if (uniqueRanks.length >= 5) {
      for (let i = 0; i <= uniqueRanks.length - 5; i += 1) {
        const slice = uniqueRanks.slice(i, i + 5);
        if (slice[0] - slice[4] === 4) {
          straightHigh = slice[0];
          break;
        }
      }
      if (!straightHigh && uniqueRanks.includes(14) && uniqueRanks.includes(5) && uniqueRanks.includes(4) && uniqueRanks.includes(3) && uniqueRanks.includes(2)) {
        straightHigh = 5;
      }
    }
    if (straightHigh && flush) return { score: [8, straightHigh], name: straightHigh === 14 ? 'Royal Flush' : 'Straight Flush' };
    if (byCount[0][1] === 4) {
      const kicker = byCount.find((e) => e[1] === 1)[0];
      return { score: [7, byCount[0][0], kicker], name: 'Four of a Kind' };
    }
    if (byCount[0][1] === 3 && byCount[1]?.[1] === 2) return { score: [6, byCount[0][0], byCount[1][0]], name: 'Full House' };
    if (flush) return { score: [5, ...ranks], name: 'Flush' };
    if (straightHigh) return { score: [4, straightHigh], name: 'Straight' };
    if (byCount[0][1] === 3) {
      const kickers = byCount.filter((e) => e[1] === 1).map((e) => e[0]).sort((a, b) => b - a);
      return { score: [3, byCount[0][0], ...kickers], name: 'Three of a Kind' };
    }
    if (byCount[0][1] === 2 && byCount[1]?.[1] === 2) {
      const pairRanks = byCount.filter((e) => e[1] === 2).map((e) => e[0]).sort((a, b) => b - a);
      const kicker = byCount.find((e) => e[1] === 1)[0];
      return { score: [2, pairRanks[0], pairRanks[1], kicker], name: 'Two Pair' };
    }
    if (byCount[0][1] === 2) {
      const kickers = byCount.filter((e) => e[1] === 1).map((e) => e[0]).sort((a, b) => b - a);
      return { score: [1, byCount[0][0], ...kickers], name: 'Pair' };
    }
    return { score: [0, ...ranks], name: 'High Card' };
  }

  function evaluate7(cards) {
    let best = null;
    for (let a = 0; a < cards.length - 4; a += 1) {
      for (let b = a + 1; b < cards.length - 3; b += 1) {
        for (let c = b + 1; c < cards.length - 2; c += 1) {
          for (let d = c + 1; d < cards.length - 1; d += 1) {
            for (let e = d + 1; e < cards.length; e += 1) {
              const result = evaluate5([cards[a], cards[b], cards[c], cards[d], cards[e]]);
              if (!best || compareArrays(result.score, best.score) > 0) best = result;
            }
          }
        }
      }
    }
    return best;
  }

  function formatCards(cards) {
    return cards.map((card) => `${RANK_LABEL[card.rank]}${SUIT_SYMBOL[card.suit]}`).join(' ');
  }

  function planHand() {
    handNumber += 1;
    clearCards();
    resetRingHighlights();
    const deck = shuffle(createDeck());
    const players = playerAnchors.map((anchor) => ({ anchor, cards: [deck.shift(), deck.shift()] }));
    const board = [deck.shift(), deck.shift(), deck.shift(), deck.shift(), deck.shift()];
    const results = players.map((player) => ({
      player,
      result: evaluate7([...player.cards, ...board]),
    }));
    results.sort((a, b) => compareArrays(b.result.score, a.result.score));
    const winner = results[0];
    current = { players, board, winner, results, pot: 0, handNumber, stepLabel: 'Shuffling', stage: 'shuffle' };

    queued = [];
    let t = nowS + 0.9;
    queued.push({ at: t, fn: () => {
      current.stage = 'blinds';
      current.pot = 30;
      refreshLabels('Blinds posted', `Hand ${handNumber} • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • blinds live • pot $${current.pot}`);
    }});
    for (let round = 0; round < 2; round += 1) {
      for (let i = 0; i < players.length; i += 1) {
        t += 0.46;
        queued.push({ at: t, fn: () => {
          current.stage = 'deal';
          const card = players[i].cards[round];
          addCard(card, players[i].anchor.cards[round]);
          current.pot += 20;
          refreshLabels(`Dealing hole cards`, `${players[i].anchor.name} • ${formatCards(players[i].cards.slice(0, round + 1))} • pot $${current.pot}`);
          statusCb(`HAND ${handNumber} • dealing ${players[i].anchor.name} • pot $${current.pot}`);
        }});
      }
    }
    t += 1.0;
    queued.push({ at: t, fn: () => {
      current.stage = 'flop';
      for (let i = 0; i < 3; i += 1) addCard(board[i], boardAnchors[i], 0.5);
      current.pot += 120;
      refreshLabels('Flop', `${formatCards(board.slice(0, 3))} • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • flop ${formatCards(board.slice(0, 3))}`);
    }});
    t += 1.35;
    queued.push({ at: t, fn: () => {
      current.stage = 'turn';
      addCard(board[3], boardAnchors[3], 0.5);
      current.pot += 80;
      refreshLabels('Turn', `${formatCards(board.slice(0, 4))} • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • turn ${formatCards(board.slice(0, 4))}`);
    }});
    t += 1.3;
    queued.push({ at: t, fn: () => {
      current.stage = 'river';
      addCard(board[4], boardAnchors[4], 0.5);
      current.pot += 80;
      refreshLabels('River', `${formatCards(board)} • pot $${current.pot}`);
      statusCb(`HAND ${handNumber} • river ${formatCards(board)}`);
    }});
    t += 1.6;
    queued.push({ at: t, fn: () => {
      current.stage = 'showdown';
      applyWinnerHighlight(winner.player.anchor.index);
      const winnerCards = formatCards(winner.player.cards);
      refreshLabels(`Showdown • ${winner.player.anchor.name} wins`, `${winner.result.name} • hole ${winnerCards} • board ${formatCards(board)} • pot $${current.pot}`);
      paintPanel(showdown, `${winner.player.anchor.name} • ${winner.result.name}`, `Wins hand ${handNumber} with ${winnerCards}`, 'rgba(244,210,105,0.98)');
      statusCb(`HAND ${handNumber} • ${winner.player.anchor.name} wins • ${winner.result.name}`);
      log('Poker showdown', { hand: handNumber, winner: winner.player.anchor.name, handName: winner.result.name, board: formatCards(board) });
    }});
    t += 4.8;
    queued.push({ at: t, fn: () => {
      paintPanel(showdown, 'Next hand loading', `Auto-dealing hand ${handNumber + 1}`, 'rgba(126,240,208,0.92)');
      planHand();
    }});

    stepIndex = 0;
    stepAt = queued[0]?.at ?? (nowS + 3);
    paintPanel(showdown, 'Texas Hold’em demo', `Hand ${handNumber} • real 52-card deck`, 'rgba(126,240,208,0.92)');
    refreshLabels('Shuffling live deck', `Hand ${handNumber} • auto demo starting`);
    statusCb(`HAND ${handNumber} • shuffling real deck`);
  }

  function refreshLabels(title, subtitle) {
    paintPanel(info, title, subtitle);
  }

  function updateAnimations() {
    for (let i = animations.length - 1; i >= 0; i -= 1) {
      const anim = animations[i];
      const span = Math.max(0.0001, anim.end - anim.start);
      const t = THREE.MathUtils.clamp((nowS - anim.start) / span, 0, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      anim.mesh.position.lerpVectors(anim.fromPos, anim.toPos, eased);
      anim.mesh.position.y += Math.sin(eased * Math.PI) * 0.14;
      anim.mesh.rotation.x = THREE.MathUtils.lerp(anim.fromRotX, anim.toRotX, eased);
      anim.mesh.rotation.y = THREE.MathUtils.lerp(anim.fromRotY, anim.toRotY, eased);
      if (t >= 1) animations.splice(i, 1);
    }
  }

  function updateRings() {
    if (!current || current.stage !== 'showdown') return;
    chairRings.forEach((ring, i) => {
      if (i === current.winner.player.anchor.index) {
        ring.material.opacity = 0.88 + Math.sin(nowS * 5.2) * 0.08;
        ring.material.emissiveIntensity = 2.2 + Math.sin(nowS * 6.0) * 0.45;
      }
    });
  }

  function update(now, dt) {
    nowS = now;
    if (!current) planHand();
    while (queued[stepIndex] && nowS >= queued[stepIndex].at) {
      const queueRef = queued;
      queued[stepIndex].fn();
      if (queued !== queueRef) break;
      stepIndex += 1;
      stepAt = queued[stepIndex]?.at ?? (nowS + 999);
    }
    updateAnimations();
    updateRings();
    cardObjects.forEach((mesh, i) => {
      if (animations.find((anim) => anim.mesh === mesh)) return;
      mesh.position.y = (mesh.userData.baseY ?? mesh.position.y);
      if (mesh.userData.baseY === undefined) mesh.userData.baseY = mesh.position.y;
      mesh.position.y = mesh.userData.baseY + Math.sin(nowS * 1.8 + i * 0.3) * 0.0015;
    });
  }

  return {
    update,
    forceNextHand() {
      planHand();
    },
  };
}
