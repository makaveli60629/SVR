export function createXRInput({ scene, renderer, log = console.log }) {
  const hands = { left: null, right: null, raw: [] };
  const controllers = { left: null, right: null, raw: [] };
  const controllerGrips = [];

  for (let i = 0; i < 2; i += 1) {
    const hand = renderer.xr.getHand(i);
    hand.userData.handIndex = i;
    hand.addEventListener("connected", (ev) => {
      const handedness = ev?.data?.handedness || (i === 0 ? "left" : "right");
      hands[handedness] = hand;
      log("Hand connected", handedness);
    });
    hand.addEventListener("disconnected", () => {
      if (hands.left === hand) hands.left = null;
      if (hands.right === hand) hands.right = null;
      log("Hand disconnected", i);
    });
    scene.add(hand);
    hands.raw.push(hand);

    const controller = renderer.xr.getController(i);
    controller.userData.controllerIndex = i;
    controller.userData.selecting = false;
    controller.userData.squeeze = false;
    controller.userData.axisLatch = 0;
    controller.userData.gamepad = null;
    controller.addEventListener("connected", (ev) => {
      const handedness = ev?.data?.handedness || (i === 0 ? "left" : "right");
      controller.userData.handedness = handedness;
      controller.userData.gamepad = ev?.data?.gamepad || null;
      controllers[handedness] = controller;
      log("Controller connected", handedness);
    });
    controller.addEventListener("disconnected", () => {
      if (controllers.left === controller) controllers.left = null;
      if (controllers.right === controller) controllers.right = null;
      controller.userData.gamepad = null;
      log("Controller disconnected", i);
    });
    controller.addEventListener("selectstart", () => { controller.userData.selecting = true; });
    controller.addEventListener("selectend", () => { controller.userData.selecting = false; });
    controller.addEventListener("squeezestart", () => { controller.userData.squeeze = true; });
    controller.addEventListener("squeezeend", () => { controller.userData.squeeze = false; });

    scene.add(controller);
    controllers.raw.push(controller);

    const grip = renderer.xr.getControllerGrip(i);
    controllerGrips.push(grip);
    scene.add(grip);
  }

  function getState() {
    return {
      leftHand: hands.left || hands.raw[0] || null,
      rightHand: hands.right || hands.raw[1] || hands.raw[0] || null,
      leftController: controllers.left || controllers.raw[0] || null,
      rightController: controllers.right || controllers.raw[1] || controllers.raw[0] || null,
    };
  }

  return { getState, hands, controllers, controllerGrips };
}
