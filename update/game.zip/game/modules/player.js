
export function initPlayer(){
    console.log("Player system ready (hands + spawn)");
}
