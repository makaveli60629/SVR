
export function initPlayer(){
 console.log("Player spawn at casino entrance")
}
