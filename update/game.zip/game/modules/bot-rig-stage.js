(function () {
  function setText(el, value, color, width) {
    el.setAttribute('text', `value: ${value}; align: center; color: ${color}; width: ${width}; wrapCount: 28`);
  }

  AFRAME.registerComponent('snap-turn-right-stick', {
    schema: { angle: { default: 45 }, threshold: { default: 0.75 } },
    init: function () { this.latched = false; },
    tick: function () {
      const pads = navigator.getGamepads ? navigator.getGamepads() : [];
      let axis = 0;
      for (let i = 0; i < pads.length; i++) {
        const p = pads[i];
        if (!p || !p.connected || !p.axes || p.axes.length < 3) continue;
        const hand = p.hand || '';
        if (hand === 'right' || !axis) axis = p.axes[2] || p.axes[0] || 0;
        if (hand === 'right' && axis) break;
      }
      if (!this.latched && axis > this.data.threshold) {
        this.el.object3D.rotation.y -= THREE.MathUtils.degToRad(this.data.angle);
        this.latched = true;
      } else if (!this.latched && axis < -this.data.threshold) {
        this.el.object3D.rotation.y += THREE.MathUtils.degToRad(this.data.angle);
        this.latched = true;
      } else if (Math.abs(axis) < 0.25) {
        this.latched = false;
      }
    }
  });

  AFRAME.registerComponent('load-fbx-fit', {
    schema: {
      src: {type: 'string'},
      height: {type: 'number', default: 1.75},
      floor: {type: 'number', default: 0},
      color: {type: 'string', default: ''}
    },
    init: function () {
      const data = this.data;
      if (!window.THREE || !THREE.FBXLoader) return;
      const loader = new THREE.FBXLoader();
      loader.load(
        data.src,
        (obj) => {
          try {
            const mesh = obj;
            mesh.scale.set(1, 1, 1);
            const box = new THREE.Box3().setFromObject(mesh);
            const size = new THREE.Vector3();
            const center = new THREE.Vector3();
            box.getSize(size);
            if (!size.y || !isFinite(size.y)) return;
            const s = data.height / size.y;
            mesh.scale.setScalar(s);
            const box2 = new THREE.Box3().setFromObject(mesh);
            box2.getCenter(center);
            mesh.position.x -= center.x;
            mesh.position.z -= center.z;
            const box3 = new THREE.Box3().setFromObject(mesh);
            mesh.position.y += data.floor - box3.min.y;
            mesh.traverse((node) => {
              if (!node.isMesh) return;
              node.castShadow = true;
              node.receiveShadow = true;
              if (data.color && node.material) {
                if (Array.isArray(node.material)) {
                  node.material = node.material.map((m) => {
                    const clone = m.clone ? m.clone() : m;
                    if (clone.color) clone.color = new THREE.Color(data.color);
                    return clone;
                  });
                } else if (node.material.clone) {
                  node.material = node.material.clone();
                  if (node.material.color) node.material.color = new THREE.Color(data.color);
                }
              }
            });
            this.el.setObject3D('mesh', mesh);
          } catch (err) {
            console.error(err);
          }
        },
        undefined,
        (err) => console.error('FBX load error', data.src, err)
      );
    }
  });

  AFRAME.registerComponent('bot-rig-stage', {
    init: function () {
      const root = this.el;

      const dealer = document.createElement('a-entity');
      dealer.setAttribute('position', '0 0 -2.75');
      dealer.setAttribute('rotation', '0 180 0');
      dealer.setAttribute('load-fbx-fit', 'src: assets/models/eric/eric.fbx; height: 1.78; floor: 0');
      root.appendChild(dealer);

      const stoolDefs = [
        { id: 'left', x: -3.0, z: 0.35, ry: 90, open: false },
        { id: 'right', x: 3.0, z: 0.35, ry: -90, open: false },
        { id: 'northLeft', x: -1.92, z: -2.10, ry: 30, open: false },
        { id: 'northRight', x: 1.92, z: -2.10, ry: -30, open: false },
        { id: 'southOpen', x: 0, z: 2.95, ry: 180, open: true }
      ];

      stoolDefs.forEach((s) => {
        const stool = document.createElement('a-cylinder');
        stool.setAttribute('position', `${s.x} 0.39 ${s.z}`);
        stool.setAttribute('radius', '0.24');
        stool.setAttribute('height', '0.78');
        stool.setAttribute('color', s.open ? '#31593a' : '#2f3340');
        stool.setAttribute('material', s.open ? 'emissive: #31593a; emissiveIntensity: 0.24; roughness: 0.88' : 'roughness: 0.92');
        root.appendChild(stool);

        const seatGlow = document.createElement('a-ring');
        seatGlow.setAttribute('position', `${s.x} 0.80 ${s.z}`);
        seatGlow.setAttribute('rotation', '-90 0 0');
        seatGlow.setAttribute('radius-inner', '0.18');
        seatGlow.setAttribute('radius-outer', '0.30');
        seatGlow.setAttribute('color', s.open ? '#88ffad' : '#6f61ff');
        seatGlow.setAttribute('material', `opacity: ${s.open ? 0.65 : 0.22}; transparent: true; side: double`);
        root.appendChild(seatGlow);

        if (s.open) {
          const txt = document.createElement('a-entity');
          txt.setAttribute('position', `${s.x} 1.16 ${s.z + 0.12}`);
          txt.setAttribute('rotation', '0 180 0');
          setText(txt, 'OPEN PLAYER SEAT', '#9effb9', 5.6);
          root.appendChild(txt);
        } else {
          const bot = document.createElement('a-entity');
          bot.setAttribute('position', `${s.x} 0 ${s.z}`);
          bot.setAttribute('rotation', `0 ${s.ry} 0`);
          bot.setAttribute('load-fbx-fit', 'src: assets/models/poses/male_sitting_pose.fbx; height: 1.20; floor: 0.28');
          root.appendChild(bot);
        }
      });

      const reikiWall = document.createElement('a-entity');
      reikiWall.setAttribute('position', '-10.8 2.65 -9.1');
      reikiWall.setAttribute('rotation', '0 34 0');
      const reikiPlane = document.createElement('a-plane');
      reikiPlane.setAttribute('width', '3.8');
      reikiPlane.setAttribute('height', '2.8');
      reikiPlane.setAttribute('color', '#143328');
      reikiPlane.setAttribute('material', 'emissive: #143328; emissiveIntensity: 0.22');
      reikiWall.appendChild(reikiPlane);
      const reikiText1 = document.createElement('a-entity');
      reikiText1.setAttribute('position', '0 0.42 0.02');
      setText(reikiText1, 'REIKI HUB', '#a9ffd4', 5.8);
      reikiWall.appendChild(reikiText1);
      const reikiText2 = document.createElement('a-entity');
      reikiText2.setAttribute('position', '0 -0.18 0.02');
      setText(reikiText2, 'TRUEITIVE', '#f5fff8', 5.2);
      reikiWall.appendChild(reikiText2);
      root.appendChild(reikiWall);

      const pgaWall = document.createElement('a-entity');
      pgaWall.setAttribute('position', '10.8 2.65 -9.1');
      pgaWall.setAttribute('rotation', '0 -34 0');
      const pgaPlane = document.createElement('a-plane');
      pgaPlane.setAttribute('width', '3.8');
      pgaPlane.setAttribute('height', '2.8');
      pgaPlane.setAttribute('color', '#1c3046');
      pgaPlane.setAttribute('material', 'emissive: #1c3046; emissiveIntensity: 0.22');
      pgaWall.appendChild(pgaPlane);
      const pgaText1 = document.createElement('a-entity');
      pgaText1.setAttribute('position', '0 0.42 0.02');
      setText(pgaText1, 'PGA HUB', '#a6dcff', 5.8);
      pgaWall.appendChild(pgaText1);
      const pgaText2 = document.createElement('a-entity');
      pgaText2.setAttribute('position', '0 -0.18 0.02');
      setText(pgaText2, 'JUAN ESPEJO', '#f3fbff', 5.2);
      pgaWall.appendChild(pgaText2);
      root.appendChild(pgaWall);
    }
  });
})();