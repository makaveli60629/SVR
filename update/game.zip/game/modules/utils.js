import * as THREE from "three";

export function makeCanvasLabel({ width=512, height=256, draw }) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  draw(ctx, width, height);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return { canvas, ctx, texture };
}

export function makeTextPlane(text, { width=256, height=128, fg="#f2ecff", bg="rgba(0,0,0,0.55)", border="rgba(180,140,255,0.6)", font="bold 56px system-ui" }={}) {
  const { texture } = makeCanvasLabel({ width, height, draw(ctx, w, h) {
    ctx.clearRect(0,0,w,h);
    ctx.fillStyle = bg;
    roundRect(ctx, 8, 8, w - 16, h - 16, 22);
    ctx.fill();
    ctx.strokeStyle = border;
    ctx.lineWidth = 6;
    roundRect(ctx, 8, 8, w - 16, h - 16, 22);
    ctx.stroke();
    ctx.fillStyle = fg;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = font;
    ctx.fillText(text, w / 2, h / 2 + 4);
  }});
  return texture;
}

export function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export function clampXZ(v, radius) {
  const p = v.clone();
  p.x = THREE.MathUtils.clamp(p.x, -radius, radius);
  p.z = THREE.MathUtils.clamp(p.z, -radius, radius);
  return p;
}

export function yawToQuaternion(yaw) {
  const q = new THREE.Quaternion();
  q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
  return q;
}

export function faceYaw(from, to) {
  return Math.atan2(to.x - from.x, to.z - from.z);
}

export function pulse(value, speed, min=0, max=1) {
  const t = (Math.sin(value * speed) + 1) * 0.5;
  return THREE.MathUtils.lerp(min, max, t);
}


export function clampInsideRoomDisk(v, radius) {
  const p = v.clone();
  const len = Math.hypot(p.x, p.z);
  if (len > radius && len > 0.00001) {
    const s = radius / len;
    p.x *= s;
    p.z *= s;
  }
  return p;
}

export function pushOutsideEllipse(v, center, radiusX, radiusZ, margin = 0) {
  const p = v.clone();
  const rx = radiusX + margin;
  const rz = radiusZ + margin;
  let dx = p.x - center.x;
  let dz = p.z - center.z;
  let norm = (dx * dx) / (rx * rx) + (dz * dz) / (rz * rz);
  if (norm < 1) {
    if (Math.abs(dx) < 0.0001 && Math.abs(dz) < 0.0001) {
      dz = rz;
      norm = 1;
    }
    const scale = 1 / Math.sqrt(Math.max(norm, 0.000001));
    p.x = center.x + dx * scale;
    p.z = center.z + dz * scale;
  }
  return p;
}

export function sanitizeFloorTarget(v, { roomRadius, tableCenter, tableRadiusX, tableRadiusZ, tableMargin = 0 }) {
  let p = clampInsideRoomDisk(v, roomRadius);
  p = pushOutsideEllipse(p, tableCenter, tableRadiusX, tableRadiusZ, tableMargin);
  p.y = v.y;
  return p;
}
