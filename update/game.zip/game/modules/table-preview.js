(function () {
  function make(el, tag, attrs) {
    const node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      node.setAttribute(key, attrs[key]);
    });
    el.appendChild(node);
    return node;
  }

  function makeCard(parent, opts) {
    const card = make(parent, 'a-entity', {
      position: opts.position,
      rotation: opts.rotation || '-90 0 0'
    });

    make(card, 'a-plane', {
      width: opts.width || '0.34',
      height: opts.height || '0.48',
      color: '#fbfdff',
      material: 'roughness:0.96; metalness:0.0; shader:standard',
      shadow: 'cast:false; receive:true'
    });

    make(card, 'a-plane', {
      width: (parseFloat(opts.width || '0.34') - 0.02).toString(),
      height: (parseFloat(opts.height || '0.48') - 0.02).toString(),
      position: '0 0 0.0008',
      color: '#ffffff',
      material: 'roughness:1.0; metalness:0.0; shader:flat'
    });

    make(card, 'a-entity', {
      text: 'value:' + opts.rank + '; align:center; anchor:center; width:2.2; color:' + opts.color,
      position: '0 0.09 0.0018'
    });

    make(card, 'a-entity', {
      text: 'value:' + opts.suit + '; align:center; anchor:center; width:2.4; color:' + opts.color,
      position: '0 -0.06 0.0018'
    });

    make(card, 'a-ring', {
      'radius-inner': '0.148',
      'radius-outer': '0.155',
      position: '0 0 0.0012',
      color: '#d8dee8',
      material: 'shader:flat; opacity:0.55; transparent:true'
    });

    return card;
  }

  AFRAME.registerComponent('svr-table-preview', {
    init: function () {
      const root = this.el;
      root.innerHTML = '';

      make(root, 'a-cylinder', {
        radius: '2.65',
        height: '0.19',
        scale: '1.40 1 1.08',
        position: '0 0.79 0',
        color: '#1a120d',
        material: 'roughness:0.68; metalness:0.16; shader:standard'
      });

      make(root, 'a-cylinder', {
        radius: '2.34',
        height: '0.11',
        scale: '1.34 1 1.02',
        position: '0 0.86 0',
        color: '#7b5225',
        material: 'roughness:0.34; metalness:0.42; emissive:#3a2108; emissiveIntensity:0.10; shader:standard'
      });

      make(root, 'a-circle', {
        radius: '2.00',
        rotation: '-90 0 0',
        scale: '1.30 1 0.98',
        position: '0 0.922 0',
        color: '#0f6b3c',
        material: 'roughness:0.95; metalness:0.02; shader:standard'
      });

      make(root, 'a-ring', {
        'radius-inner': '1.92',
        'radius-outer': '2.00',
        rotation: '-90 0 0',
        scale: '1.30 1 0.98',
        position: '0 0.924 0',
        color: '#d2aa58',
        material: 'roughness:0.42; metalness:0.28; shader:standard'
      });

      make(root, 'a-circle', {
        radius: '1.66',
        rotation: '-90 0 0',
        scale: '1.18 1 0.80',
        position: '0 0.926 0.02',
        color: '#08351e',
        material: 'roughness:0.99; metalness:0.01; opacity:0.88; transparent:true; shader:standard'
      });

      make(root, 'a-plane', {
        width: '2.24',
        height: '0.52',
        rotation: '-90 0 0',
        position: '0 0.928 -0.04',
        color: '#0b1720',
        material: 'roughness:0.92; metalness:0.03; opacity:0.92; transparent:true; shader:standard'
      });

      make(root, 'a-plane', {
        width: '1.46',
        height: '0.06',
        rotation: '-90 0 0',
        position: '0 0.929 0.26',
        color: '#ddc37c',
        material: 'roughness:0.78; metalness:0.08; shader:standard'
      });

      make(root, 'a-circle', {
        radius: '0.40',
        rotation: '-90 0 0',
        scale: '1.84 1 0.98',
        position: '0 0.927 0.56',
        material: 'src:assets/logo.png; transparent:true; shader:flat; side:double; opacity:0.98'
      });

      const board = [
        {x: -0.88, rank: 'A', suit: '♠', color: '#111111'},
        {x: -0.44, rank: 'K', suit: '♥', color: '#cc1d1d'},
        {x: 0.00, rank: '10', suit: '♦', color: '#cc1d1d'},
        {x: 0.44, rank: '8', suit: '♣', color: '#111111'},
        {x: 0.88, rank: '2', suit: '♠', color: '#111111'}
      ];

      board.forEach(function (card) {
        makeCard(root, {
          position: card.x + ' 0.932 -0.04',
          rank: card.rank,
          suit: card.suit,
          color: card.color
        });
      });

      makeCard(root, {
        position: '-0.20 0.933 1.30',
        rank: 'Q',
        suit: '♠',
        color: '#111111'
      });

      makeCard(root, {
        position: '0.20 0.933 1.30',
        rank: 'Q',
        suit: '♥',
        color: '#cc1d1d'
      });

      const spots = [
        {x: 0, z: 1.16, sx: 1.42, sz: 0.96},
        {x: -1.52, z: 0.48, sx: 1.14, sz: 0.88},
        {x: 1.52, z: 0.48, sx: 1.14, sz: 0.88},
        {x: -1.64, z: -0.70, sx: 1.02, sz: 0.80},
        {x: 1.64, z: -0.70, sx: 1.02, sz: 0.80},
        {x: 0, z: -1.20, sx: 1.32, sz: 0.78}
      ];

      spots.forEach(function (spot) {
        make(root, 'a-ring', {
          'radius-inner': '0.18',
          'radius-outer': '0.22',
          rotation: '-90 0 0',
          position: spot.x + ' 0.932 ' + spot.z,
          scale: spot.sx + ' 1 ' + spot.sz,
          color: '#e7cb7f',
          material: 'roughness:0.50; metalness:0.24; opacity:0.98; transparent:true; shader:standard'
        });
        make(root, 'a-circle', {
          radius: '0.172',
          rotation: '-90 0 0',
          position: spot.x + ' 0.9315 ' + spot.z,
          scale: spot.sx + ' 1 ' + spot.sz,
          color: '#123b27',
          material: 'roughness:1; metalness:0; opacity:0.54; transparent:true; shader:standard'
        });
      });

      make(root, 'a-cylinder', {
        radius: '0.44',
        height: '0.78',
        position: '0 0.40 0',
        color: '#201510',
        material: 'roughness:0.74; metalness:0.14; shader:standard'
      });

      make(root, 'a-cylinder', {
        radius: '0.96',
        height: '0.10',
        scale: '1.24 1 0.86',
        position: '0 0.05 0',
        color: '#1b1411',
        material: 'roughness:0.78; metalness:0.12; shader:standard'
      });

      [-1.16, 1.16].forEach(function (x) {
        make(root, 'a-box', {
          width: '0.46',
          height: '0.04',
          depth: '0.22',
          position: x + ' 0.96 1.14',
          color: '#0d1015',
          material: 'roughness:0.78; metalness:0.08; shader:standard'
        });
      });
    }
  });
})();
