(function () {
  function make(el, tag, attrs) {
    const node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      node.setAttribute(key, attrs[key]);
    });
    el.appendChild(node);
    return node;
  }

  AFRAME.registerComponent('svr-table-preview', {
    init: function () {
      const root = this.el;

      // Main felt
      make(root, 'a-circle', {
        radius: '1.12',
        rotation: '-90 0 0',
        scale: '1.56 1 1',
        position: '0 0.79 0',
        color: '#0f5d35',
        material: 'roughness:0.94; metalness:0.02; shader:standard'
      });

      // Inner contrast felt
      make(root, 'a-circle', {
        radius: '0.98',
        rotation: '-90 0 0',
        scale: '1.46 1 1',
        position: '0 0.792 0',
        color: '#0b3a22',
        material: 'roughness:0.98; metalness:0.01; opacity:0.86; transparent:true; shader:standard'
      });

      // Rail ring
      make(root, 'a-ring', {
        radius-inner: '1.10',
        radius-outer: '1.30',
        rotation: '-90 0 0',
        scale: '1.58 1 1',
        position: '0 0.801 0',
        color: '#16110e',
        material: 'roughness:0.78; metalness:0.16; shader:standard'
      });

      // Brass accent ring
      make(root, 'a-ring', {
        radius-inner: '1.05',
        radius-outer: '1.08',
        rotation: '-90 0 0',
        scale: '1.55 1 1',
        position: '0 0.803 0',
        color: '#73582a',
        material: 'roughness:0.48; metalness:0.38; shader:standard'
      });

      // Community card strip
      make(root, 'a-plane', {
        width: '1.42',
        height: '0.32',
        rotation: '-90 0 0',
        position: '0 0.806 -0.02',
        color: '#0b1720',
        material: 'roughness:0.90; metalness:0.04; opacity:0.78; transparent:true; shader:standard'
      });

      const cardXs = [-0.56, -0.28, 0, 0.28, 0.56];
      cardXs.forEach(function (x) {
        make(root, 'a-plane', {
          width: '0.21',
          height: '0.28',
          rotation: '-90 0 0',
          position: x + ' 0.807 -0.02',
          color: '#f5f8ff',
          material: 'roughness:0.98; metalness:0.00; opacity:0.26; transparent:true; shader:standard'
        });
      });

      // Player betting spots
      const spots = [
        {x: 0, z: 0.64, sx: 1.22, sz: 0.82},
        {x: -1.06, z: 0.28, sx: 1.05, sz: 0.82},
        {x: 1.06, z: 0.28, sx: 1.05, sz: 0.82},
        {x: -1.18, z: -0.46, sx: 0.94, sz: 0.76},
        {x: 1.18, z: -0.46, sx: 0.94, sz: 0.76},
        {x: 0, z: -0.82, sx: 1.18, sz: 0.72}
      ];

      spots.forEach(function (spot) {
        make(root, 'a-ring', {
          radius-inner: '0.13',
          radius-outer: '0.155',
          rotation: '-90 0 0',
          position: spot.x + ' 0.808 ' + spot.z,
          scale: spot.sx + ' 1 ' + spot.sz,
          color: '#d7b66c',
          material: 'roughness:0.54; metalness:0.22; opacity:0.9; transparent:true; shader:standard'
        });
        make(root, 'a-circle', {
          radius: '0.125',
          rotation: '-90 0 0',
          position: spot.x + ' 0.8075 ' + spot.z,
          scale: spot.sx + ' 1 ' + spot.sz,
          color: '#113524',
          material: 'roughness:1; metalness:0; opacity:0.45; transparent:true; shader:standard'
        });
      });

      // Center logo plate
      make(root, 'a-circle', {
        radius: '0.24',
        rotation: '-90 0 0',
        scale: '1.55 1 0.9',
        position: '0 0.805 0.34',
        material: 'src:assets/logo.png; transparent:true; shader:flat; side:double; opacity:0.94'
      });

      // Dealer line
      make(root, 'a-plane', {
        width: '1.00',
        height: '0.03',
        rotation: '-90 0 0',
        position: '0 0.806 0.18',
        color: '#d6c38f',
        material: 'roughness:0.8; metalness:0.08; opacity:0.8; transparent:true; shader:standard'
      });

      // Simple chip tray bars for visual read
      [-0.88, 0.88].forEach(function (x) {
        make(root, 'a-box', {
          width: '0.32',
          height: '0.025',
          depth: '0.15',
          position: x + ' 0.83 0.72',
          color: '#12151c',
          material: 'roughness:0.78; metalness:0.08; shader:standard'
        });
      });
    }
  });
})();
