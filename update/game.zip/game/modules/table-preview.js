(function () {
  function make(el, tag, attrs) {
    const node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      node.setAttribute(key, attrs[key]);
    });
    el.appendChild(node);
    return node;
  }

  AFRAME.registerComponent('svr-table-preview', {
    init: function () {
      const root = this.el;

      make(root, 'a-cylinder', {
        radius: '2.35',
        height: '0.16',
        scale: '1.36 1 1.02',
        position: '0 0.74 0',
        color: '#120d0b',
        material: 'roughness:0.72; metalness:0.14; shader:standard'
      });

      make(root, 'a-cylinder', {
        radius: '2.08',
        height: '0.08',
        scale: '1.28 1 0.96',
        position: '0 0.80 0',
        color: '#8c6731',
        material: 'roughness:0.34; metalness:0.45; emissive:#3a2508; emissiveIntensity:0.15; shader:standard'
      });

      make(root, 'a-circle', {
        radius: '1.90',
        rotation: '-90 0 0',
        scale: '1.30 1 0.96',
        position: '0 0.845 0',
        color: '#0d6a3e',
        material: 'roughness:0.94; metalness:0.02; shader:standard'
      });

      make(root, 'a-circle', {
        radius: '1.62',
        rotation: '-90 0 0',
        scale: '1.18 1 0.84',
        position: '0 0.847 0.02',
        color: '#07361f',
        material: 'roughness:0.98; metalness:0.01; opacity:0.88; transparent:true; shader:standard'
      });

      make(root, 'a-ring', {
        radius-inner: '1.56',
        radius-outer: '1.62',
        rotation: '-90 0 0',
        scale: '1.16 1 0.84',
        position: '0 0.848 0',
        color: '#d8b46c',
        material: 'roughness:0.38; metalness:0.42; emissive:#5b430f; emissiveIntensity:0.12; shader:standard'
      });

      make(root, 'a-plane', {
        width: '2.00',
        height: '0.42',
        rotation: '-90 0 0',
        position: '0 0.849 -0.02',
        color: '#0b1720',
        material: 'roughness:0.90; metalness:0.04; opacity:0.80; transparent:true; shader:standard'
      });

      const cardXs = [-0.76, -0.38, 0, 0.38, 0.76];
      cardXs.forEach(function (x) {
        make(root, 'a-plane', {
          width: '0.28',
          height: '0.38',
          rotation: '-90 0 0',
          position: x + ' 0.851 -0.02',
          color: '#f8fbff',
          material: 'roughness:0.98; metalness:0.00; opacity:0.38; transparent:true; shader:standard'
        });
      });

      const spots = [
        {x: 0, z: 1.02, sx: 1.36, sz: 0.92},
        {x: -1.44, z: 0.42, sx: 1.12, sz: 0.86},
        {x: 1.44, z: 0.42, sx: 1.12, sz: 0.86},
        {x: -1.54, z: -0.62, sx: 1.02, sz: 0.80},
        {x: 1.54, z: -0.62, sx: 1.02, sz: 0.80},
        {x: 0, z: -1.10, sx: 1.30, sz: 0.78}
      ];

      spots.forEach(function (spot) {
        make(root, 'a-ring', {
          radius-inner: '0.16',
          radius-outer: '0.19',
          rotation: '-90 0 0',
          position: spot.x + ' 0.852 ' + spot.z,
          scale: spot.sx + ' 1 ' + spot.sz,
          color: '#e2c67f',
          material: 'roughness:0.52; metalness:0.26; opacity:0.96; transparent:true; shader:standard'
        });
        make(root, 'a-circle', {
          radius: '0.154',
          rotation: '-90 0 0',
          position: spot.x + ' 0.8515 ' + spot.z,
          scale: spot.sx + ' 1 ' + spot.sz,
          color: '#113524',
          material: 'roughness:1; metalness:0; opacity:0.44; transparent:true; shader:standard'
        });
      });

      make(root, 'a-circle', {
        radius: '0.34',
        rotation: '-90 0 0',
        scale: '1.68 1 0.96',
        position: '0 0.851 0.48',
        material: 'src:assets/logo.png; transparent:true; shader:flat; side:double; opacity:0.98'
      });

      make(root, 'a-plane', {
        width: '1.34',
        height: '0.038',
        rotation: '-90 0 0',
        position: '0 0.852 0.24',
        color: '#d6c38f',
        material: 'roughness:0.8; metalness:0.08; opacity:0.88; transparent:true; shader:standard'
      });

      [-1.10, 1.10].forEach(function (x) {
        make(root, 'a-box', {
          width: '0.44',
          height: '0.034',
          depth: '0.20',
          position: x + ' 0.88 1.04',
          color: '#10141a',
          material: 'roughness:0.78; metalness:0.08; shader:standard'
        });
      });
    }
  });
})();
