Phase K preserves real module slots for Trueitive Reiki and Juan Espejo PGA.
