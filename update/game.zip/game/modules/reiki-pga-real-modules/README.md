Phase L preserves real module slots for Trueitive Reiki and Juan Espejo PGA.
