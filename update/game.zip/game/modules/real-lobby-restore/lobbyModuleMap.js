export const LOBBY_MODULES=[
{ id:"true-lobby-shell", status:"boot-safe visible", note:"larger lobby shell restored as lightweight scaffold" },
{ id:"spawn-orientation", status:"locked", note:"standing spawn, facing table, north behind dealer/Claudia side" },
{ id:"table-chair-ring", status:"visible scaffold", note:"front/south seat preserved open" },
{ id:"reiki-module-slot", status:"placed", note:"wide Trueitive Reiki slot ready for real assets" },
{ id:"pga-module-slot", status:"placed", note:"Juan Espejo PGA slot ready for real assets" },
{ id:"camera3-live-view", status:"locked", note:"always-on top-right view" },
{ id:"webxr-enter-vr", status:"locked", note:"VRButton added and renderer.xr enabled" }
];
export function summarizeLobbyModules(modules=LOBBY_MODULES){return `Lobby Module Check: ${modules.length} modules mapped — ${modules.map(m=>m.id+":"+m.status).join(" | ")}`;}
