import * as THREE from "three";
import { CONFIG } from "./config.js";
import { sanitizeFloorTarget } from "./utils.js";

export function createPlayerRig({ renderer, camera, desktopControls, roomClamp = CONFIG.ROOM_RADIUS - 2, log=console.log }) {
  let baseRefSpace = null;
  let offsetX = 0;
  let offsetZ = 0;
  let yaw = 0;
  let seated = false;
  let seatedSeat = null;

  function applyRefSpace() {
    if (!baseRefSpace || !renderer.xr.isPresenting) return;
    const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), -yaw);
    const t = new XRRigidTransform(
      { x: -offsetX, y: 0, z: -offsetZ },
      { x: q.x, y: q.y, z: q.z, w: q.w }
    );
    renderer.xr.setReferenceSpace(baseRefSpace.getOffsetReferenceSpace(t));
  }

  async function onSessionStart() {
    baseRefSpace = await renderer.xr.getSession().requestReferenceSpace("local-floor");
    offsetX = 0;
    offsetZ = 0;
    yaw = 0;
    seated = false;
    seatedSeat = null;
    applyRefSpace();
  }



  function sanitizeWorldTarget(target) {
    const p = sanitizeFloorTarget(new THREE.Vector3(target.x, target.y ?? CONFIG.PLAYER_HEIGHT, target.z), {
      roomRadius: roomClamp,
      tableCenter: new THREE.Vector3(CONFIG.TABLE_CENTER.x, 0, CONFIG.TABLE_CENTER.z),
      tableRadiusX: CONFIG.TABLE_RADIUS_X,
      tableRadiusZ: CONFIG.TABLE_RADIUS_Z,
      tableMargin: CONFIG.TABLE_SAFE_MARGIN,
    });
    p.y = target.y ?? CONFIG.PLAYER_HEIGHT;
    return p;
  }

  function getHeadWorld() {
    const head = new THREE.Vector3();
    if (renderer.xr.isPresenting) {
      renderer.xr.getCamera(camera).getWorldPosition(head);
    } else {
      head.copy(camera.position);
    }
    return head;
  }

  function moveHeadTo(target, desiredYaw = null) {
    if (renderer.xr.isPresenting) {
      const head = getHeadWorld();
      offsetX += target.x - head.x;
      offsetZ += target.z - head.z;
      if (desiredYaw !== null) yaw = desiredYaw;
      applyRefSpace();
    } else {
      const pos = sanitizeWorldTarget(new THREE.Vector3(target.x, target.y ?? CONFIG.PLAYER_HEIGHT, target.z));
      desktopControls.setPose(pos, desiredYaw ?? desktopControls.getYaw(), 0);
    }
  }

  function setYaw(nextYaw) {
    yaw = nextYaw;
    if (renderer.xr.isPresenting) {
      applyRefSpace();
    } else {
      desktopControls.setPose(camera.position.clone(), nextYaw, camera.rotation.x);
    }
  }

  function snapTurn(deltaYaw) {
    if (renderer.xr.isPresenting) {
      yaw += deltaYaw;
      applyRefSpace();
    } else {
      desktopControls.addYaw(deltaYaw);
    }
  }

  function resetToSpawn() {
    seated = false;
    seatedSeat = null;
    moveHeadTo(sanitizeWorldTarget(new THREE.Vector3(CONFIG.SPAWN.x, CONFIG.SPAWN.y, CONFIG.SPAWN.z)), CONFIG.SPAWN.yaw);
    log("Reset to spawn");
  }

  function enterSeat(seat) {
    seated = true;
    seatedSeat = seat;
    const target = new THREE.Vector3(seat.anchor.x, seat.anchor.y, seat.anchor.z);
    moveHeadTo(target, seat.yaw);
    log("Entered seat", seat.index);
  }

  function standUp() {
    const lastSeat = seatedSeat;
    seated = false;
    seatedSeat = null;
    const head = getHeadWorld();
    const away = lastSeat
      ? new THREE.Vector3(head.x - CONFIG.TABLE_CENTER.x, 0, head.z - CONFIG.TABLE_CENTER.z).normalize()
      : new THREE.Vector3(0, 0, 1);
    if (!isFinite(away.x) || away.lengthSq() < 0.0001) away.set(0, 0, 1);
    const target = new THREE.Vector3(head.x, CONFIG.PLAYER_HEIGHT, head.z).addScaledVector(away, CONFIG.STANDUP_PUSHBACK);
    moveHeadTo(sanitizeWorldTarget(target), yaw);
    log("Stood up");
  }

  function isSeated() {
    return seated;
  }

  function getSeat() {
    return seatedSeat;
  }

  function getYaw() {
    return renderer.xr.isPresenting ? yaw : desktopControls.getYaw();
  }

  function teleportTo(target) {
    moveHeadTo(sanitizeWorldTarget(new THREE.Vector3(target.x, CONFIG.PLAYER_HEIGHT, target.z)), getYaw());
  }

  function ensureSafePosition() {
    const head = getHeadWorld();
    const safe = sanitizeWorldTarget(new THREE.Vector3(head.x, CONFIG.PLAYER_HEIGHT, head.z));
    const dx = safe.x - head.x;
    const dz = safe.z - head.z;
    if ((dx * dx + dz * dz) > 0.0004) {
      moveHeadTo(safe, null);
      return true;
    }
    return false;
  }

  return {
    onSessionStart,
    resetToSpawn,
    enterSeat,
    standUp,
    isSeated,
    getSeat,
    getYaw,
    snapTurn,
    teleportTo,
    ensureSafePosition,
    getHeadWorld,
  };
}
