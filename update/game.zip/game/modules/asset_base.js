// Asset base resolver.
// Prefer local packaged assets first so the deployed build stays self-contained.
export const ASSET_BASES = [
  new URL("../assets/", import.meta.url).toString(),
  new URL("../../assets/", import.meta.url).toString(),
  "https://cdn.jsdelivr.net/gh/makaveli60629/SVR@main/game/assets/",
  "https://cdn.jsdelivr.net/gh/makaveli60629/SVR@main/assets/"
];

export function urlsFor(pathRelativeToAssets){
  return ASSET_BASES.map(base => base + pathRelativeToAssets);
}
