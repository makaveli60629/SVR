// Asset base resolver (CLEAN PATHS)
// Order: CDN first (works even if host doesn't expose /assets), then /game/assets, then /assets.
export const ASSET_BASES = [
  "https://cdn.jsdelivr.net/gh/makaveli60629/SVR@main/assets/",
  new URL("../assets/", import.meta.url).toString(),    // /game/assets/
  new URL("../../assets/", import.meta.url).toString()  // /assets/
];

export function urlsFor(pathRelativeToAssets){
  return ASSET_BASES.map(b => b + pathRelativeToAssets);
}
