// Asset base resolver (CDN default).
// Your assets live in: makaveli60629/test@main/assets/*
// Default base uses jsDelivr GitHub CDN for fast, reliable loading.
//
// Override at runtime (optional):
//   window.SVR_ASSET_BASE = "https://cdn.jsdelivr.net/gh/<user>/<repo>@<branch>/assets/";
//
// Fallbacks (in case you later copy assets into the deployed site):
//   /assets/ , /game/assets/

const DEFAULT_CDN = "https://cdn.jsdelivr.net/gh/makaveli60629/test@main/assets/";

export const ASSET_BASES = [
  (typeof window !== "undefined" && window.SVR_ASSET_BASE) ? window.SVR_ASSET_BASE : null,
  DEFAULT_CDN,
  "/assets/",
  "/game/assets/",
  new URL("../../assets/", import.meta.url).toString(),
  new URL("../assets/", import.meta.url).toString(),
];

export function urlsFor(pathRelativeToAssets){
  return ASSET_BASES.filter(Boolean).map(b => (b.endsWith("/") ? b : (b + "/")) + pathRelativeToAssets);
}
