const rawBases = [
  new URL("../assets/", import.meta.url).toString(),
  new URL("../../assets/", import.meta.url).toString(),
  "https://cdn.jsdelivr.net/gh/makaveli60629/SVR@main/game/assets/",
  "https://cdn.jsdelivr.net/gh/makaveli60629/SVR@main/assets/"
];

export const ASSET_BASES = [...new Set(rawBases)];

export function urlsFor(pathRelativeToAssets){
  const clean = String(pathRelativeToAssets || "").replace(/^\/+/, "");
  return ASSET_BASES.map((b)=> new URL(clean, b).toString());
}
