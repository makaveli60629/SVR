(function () {
  const WATCH_LAYOUT = {
    title: 'SVR POKER',
    subtitle: 'QUEST FOREARM UI',
    pot: '15,200',
    stack: '68,500',
    cards: ['A♠', 'K♠'],
    board: ['9♥', '7♠', '10♦', '6♣'],
    buttons: ['FOLD', 'CALL', 'RAISE', 'ALL IN']
  };

  const THREE = AFRAME.THREE;
  const TMP_POS = new THREE.Vector3();
  const TMP_WORLD_QUAT = new THREE.Quaternion();
  const TMP_PARENT_QUAT = new THREE.Quaternion();
  const TMP_SCALE = new THREE.Vector3();
  const TMP_INV_PARENT = new THREE.Matrix4();
  const ROOT_SCALE = new THREE.Vector3(1, 1, 1);
  const DEFAULT_LOCAL_POS = new THREE.Vector3(0.055, -0.028, -0.088);
  const DEFAULT_LOCAL_QUAT = new THREE.Quaternion().setFromEuler(new THREE.Euler(-1.68, 0.03, 1.56, 'YXZ'));

  function isQuestBrowser() {
    return /OculusBrowser|Quest/i.test(navigator.userAgent || '');
  }

  function sceneInVR(scene) {
    return !!scene && scene.is && scene.is('vr-mode');
  }

  function getCanvas() {
    return document.getElementById('watchCanvas');
  }

  function getDiag() {
    return document.getElementById('diag');
  }

  function setDiag(text) {
    const el = getDiag();
    if (el) el.textContent = text;
  }

  function drawWatchUI(state) {
    const canvas = getCanvas();
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    const bg = ctx.createLinearGradient(0, 0, w, h);
    bg.addColorStop(0, '#050507');
    bg.addColorStop(1, '#10161f');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = '#8b42ff';
    ctx.lineWidth = 12;
    ctx.strokeRect(10, 10, w - 20, h - 20);

    ctx.fillStyle = '#d2a8ff';
    ctx.font = 'bold 48px Arial';
    ctx.fillText(state.title, 34, 60);

    ctx.fillStyle = '#8aa6c8';
    ctx.font = '24px Arial';
    ctx.fillText(state.subtitle, 36, 94);

    ctx.fillStyle = '#00ffa2';
    ctx.font = 'bold 60px Arial';
    ctx.fillText(state.stack, 360, 110);

    ctx.fillStyle = '#ffd84e';
    ctx.font = 'bold 28px Arial';
    ctx.fillText('POT ' + state.pot, 36, 144);

    ctx.fillStyle = '#1a7a3a';
    ctx.fillRect(24, 162, w - 48, 90);
    ctx.strokeStyle = '#7be2a0';
    ctx.lineWidth = 4;
    ctx.strokeRect(24, 162, w - 48, 90);

    const cardW = 92;
    const cardH = 126;
    const cardY = 138;
    const startX = 88;
    state.board.forEach(function (card, i) {
      const x = startX + i * 118;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, cardY, cardW, cardH);
      ctx.strokeStyle = '#202020';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, cardY, cardW, cardH);
      ctx.fillStyle = /♥|♦/.test(card) ? '#d92d2d' : '#101010';
      ctx.font = 'bold 44px Arial';
      ctx.fillText(card, x + 14, cardY + 74);
    });

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('HAND', 36, 322);

    state.cards.forEach(function (card, i) {
      const x = 120 + i * 112;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, 270, 92, 96);
      ctx.strokeStyle = '#202020';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, 270, 92, 96);
      ctx.fillStyle = /♥|♦/.test(card) ? '#d92d2d' : '#101010';
      ctx.font = 'bold 42px Arial';
      ctx.fillText(card, x + 16, 330);
    });

    const buttonColors = ['#3751ff', '#14b36b', '#f2a300', '#d92d2d'];
    state.buttons.forEach(function (label, i) {
      const x = 390 + i * 150;
      const y = 282;
      const width = i === 3 ? 152 : 132;
      ctx.fillStyle = buttonColors[i];
      ctx.fillRect(x, y, width, 62);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, 62);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px Arial';
      ctx.fillText(label, x + 18, y + 39);
    });
  }

  function getHandTrackingState(el) {
    const handComp = el.components['hand-tracking-controls'];
    const tracked = el.components['tracked-controls'];
    const trackedWebXR = el.components['tracked-controls-webxr'];
    const scene = el.sceneEl;
    const frame = scene && scene.frame;
    const controller = tracked && tracked.controller;
    const hand = controller && controller.hand;
    const referenceSpace = (handComp && handComp.referenceSpace) || (trackedWebXR && trackedWebXR.system && trackedWebXR.system.referenceSpace);
    return { frame, controller, hand, referenceSpace };
  }

  function getJointPose(el, jointName) {
    const state = getHandTrackingState(el);
    if (!state.frame || !state.hand || !state.referenceSpace || !state.hand.get) return null;
    const joint = state.hand.get(jointName);
    if (!joint) return null;
    const pose = state.frame.getJointPose(joint, state.referenceSpace);
    if (!pose || !pose.transform) return null;
    return pose;
  }

  function getEntityWorldData(el) {
    if (!el.object3D) return null;
    el.object3D.updateMatrixWorld(true);
    if (!el.object3D.parent) return null;
    el.object3D.matrixWorld.decompose(TMP_POS, TMP_PARENT_QUAT, TMP_SCALE);
    if (TMP_POS.length() < 0.0001) return null;
    return { position: TMP_POS.clone(), quaternion: TMP_PARENT_QUAT.clone() };
  }

  function getWristLocalPose(el) {
    const wristPose = getJointPose(el, 'wrist');
    if (!wristPose || !el.object3D || !el.object3D.parent) return null;

    const t = wristPose.transform;
    const worldPos = new THREE.Vector3(t.position.x, t.position.y, t.position.z);
    const worldQuat = new THREE.Quaternion(t.orientation.x, t.orientation.y, t.orientation.z, t.orientation.w);
    const sideSign = 1;
    const adjust = new THREE.Quaternion().setFromEuler(new THREE.Euler(-1.72, 0.16 * sideSign, 1.58 * sideSign, 'YXZ'));
    worldQuat.multiply(adjust);
    worldPos.add(new THREE.Vector3(0.034 * sideSign, -0.012, -0.09).applyQuaternion(worldQuat));

    el.object3D.parent.updateMatrixWorld(true);
    TMP_INV_PARENT.copy(el.object3D.matrixWorld).invert();
    const localPos = worldPos.clone().applyMatrix4(TMP_INV_PARENT);

    el.object3D.getWorldQuaternion(TMP_PARENT_QUAT);
    const localQuat = TMP_PARENT_QUAT.clone().invert().multiply(worldQuat);

    return { position: localPos, quaternion: localQuat };
  }

  function hasStableEntity(el) {
    const data = getEntityWorldData(el);
    return !!data;
  }

  AFRAME.registerComponent('quest-hand-gate', {
    init: function () {
      const el = this.el;
      const scene = el.sceneEl;
      const sync = function () {
        const on = isQuestBrowser() && sceneInVR(scene);
        el.object3D.visible = on;
      };
      scene.addEventListener('enter-vr', sync);
      scene.addEventListener('exit-vr', sync);
      setTimeout(sync, 0);
    }
  });

  AFRAME.registerComponent('forearm-watch', {
    schema: {
      side: { default: 'left' }
    },

    init: function () {
      if (this.data.side !== 'left') return;

      drawWatchUI(WATCH_LAYOUT);

      const root = document.createElement('a-entity');
      root.setAttribute('class', 'forearm-watch-root');
      root.setAttribute('visible', 'false');
      root.object3D.position.copy(DEFAULT_LOCAL_POS);
      root.object3D.quaternion.copy(DEFAULT_LOCAL_QUAT);

      const shell = document.createElement('a-box');
      shell.setAttribute('width', '0.205');
      shell.setAttribute('height', '0.074');
      shell.setAttribute('depth', '0.014');
      shell.setAttribute('color', '#080808');
      shell.setAttribute('material', 'metalness:0.9; roughness:0.28');
      root.appendChild(shell);

      const glass = document.createElement('a-plane');
      glass.setAttribute('width', '0.186');
      glass.setAttribute('height', '0.060');
      glass.setAttribute('position', '0 0 0.0082');
      glass.setAttribute('material', 'src:#watchCanvas; shader:flat; transparent:false; side:double');
      root.appendChild(glass);

      const leftClamp = document.createElement('a-box');
      leftClamp.setAttribute('width', '0.026');
      leftClamp.setAttribute('height', '0.098');
      leftClamp.setAttribute('depth', '0.022');
      leftClamp.setAttribute('position', '-0.116 0 0');
      leftClamp.setAttribute('color', '#101010');
      root.appendChild(leftClamp);

      const rightClamp = document.createElement('a-box');
      rightClamp.setAttribute('width', '0.026');
      rightClamp.setAttribute('height', '0.098');
      rightClamp.setAttribute('depth', '0.022');
      rightClamp.setAttribute('position', '0.116 0 0');
      rightClamp.setAttribute('color', '#101010');
      root.appendChild(rightClamp);

      const glow = document.createElement('a-plane');
      glow.setAttribute('width', '0.194');
      glow.setAttribute('height', '0.067');
      glow.setAttribute('position', '0 0 0.005');
      glow.setAttribute('material', 'color:#7a33ff; shader:flat; opacity:0.12; transparent:true; side:double');
      root.appendChild(glow);

      this.el.appendChild(root);
      this.root = root;
      this.rootObj = root.object3D;
      this.lastAnchorMode = '';

      const scene = this.el.sceneEl;
      const sync = () => {
        const on = isQuestBrowser() && sceneInVR(scene);
        this.rootObj.visible = on;
        setDiag(on ? 'SVR WATCH: QUEST ACTIVE' : 'SVR WATCH: VR OFF');
      };

      scene.addEventListener('enter-vr', sync);
      scene.addEventListener('exit-vr', sync);
      setTimeout(sync, 0);
    },

    tick: function () {
      if (!this.rootObj) return;
      const scene = this.el.sceneEl;
      const on = isQuestBrowser() && sceneInVR(scene);
      this.rootObj.visible = on;
      if (!on) return;

      let localPose = getWristLocalPose(this.el);
      let mode = 'wrist-local';

      if (!localPose && hasStableEntity(this.el)) {
        localPose = { position: DEFAULT_LOCAL_POS, quaternion: DEFAULT_LOCAL_QUAT };
        mode = 'hand-root-local';
      }

      if (!localPose) {
        this.rootObj.visible = false;
        if (this.lastAnchorMode !== 'waiting') {
          setDiag('SVR WATCH: WAITING FOR LEFT META HAND');
          this.lastAnchorMode = 'waiting';
        }
        return;
      }

      this.rootObj.visible = true;
      this.rootObj.position.copy(localPose.position);
      this.rootObj.quaternion.copy(localPose.quaternion);
      this.rootObj.scale.copy(ROOT_SCALE);

      if (mode !== this.lastAnchorMode) {
        setDiag(mode === 'wrist-local' ? 'SVR WATCH: WRIST LOCKED TO META HAND' : 'SVR WATCH: HAND ROOT SAFE LOCK');
        this.lastAnchorMode = mode;
      }
    }
  });

  window.SVRWatchUI = {
    setState: function (nextState) {
      Object.assign(WATCH_LAYOUT, nextState || {});
      drawWatchUI(WATCH_LAYOUT);
    }
  };
})();
