(function () {
  const THREE = AFRAME.THREE;
  const UI_STATE = {
    title: 'SVR POKER',
    subtitle: 'FOREARM HUD',
    pot: '15,200',
    stack: '68,500',
    cards: ['A♠', 'K♠'],
    board: ['9♥', '7♠', '10♦', '6♣'],
    buttons: ['FOLD', 'CALL', 'RAISE', 'ALL IN']
  };

  function drawWatchUI(state) {
    const canvas = document.getElementById('watchCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);
    const bg = ctx.createLinearGradient(0, 0, w, h);
    bg.addColorStop(0, '#06070a');
    bg.addColorStop(1, '#121926');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = '#924cff';
    ctx.lineWidth = 12;
    ctx.strokeRect(10, 10, w - 20, h - 20);

    ctx.fillStyle = '#d8b8ff';
    ctx.font = 'bold 48px Arial';
    ctx.fillText(state.title, 36, 60);

    ctx.fillStyle = '#90a6c5';
    ctx.font = '24px Arial';
    ctx.fillText(state.subtitle, 38, 94);

    ctx.fillStyle = '#19f2a2';
    ctx.font = 'bold 58px Arial';
    ctx.fillText(state.stack, 355, 110);

    ctx.fillStyle = '#ffd55a';
    ctx.font = 'bold 28px Arial';
    ctx.fillText('POT ' + state.pot, 36, 144);

    ctx.fillStyle = '#175630';
    ctx.fillRect(24, 162, w - 48, 90);
    ctx.strokeStyle = '#73e69f';
    ctx.lineWidth = 4;
    ctx.strokeRect(24, 162, w - 48, 90);

    const cardW = 92;
    const cardH = 126;
    const cardY = 138;
    const startX = 88;
    state.board.forEach(function (card, i) {
      const x = startX + i * 118;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, cardY, cardW, cardH);
      ctx.strokeStyle = '#202020';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, cardY, cardW, cardH);
      ctx.fillStyle = /♥|♦/.test(card) ? '#d92d2d' : '#101010';
      ctx.font = 'bold 44px Arial';
      ctx.fillText(card, x + 14, cardY + 74);
    });

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('HAND', 36, 322);

    state.cards.forEach(function (card, i) {
      const x = 120 + i * 112;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, 270, 92, 96);
      ctx.strokeStyle = '#202020';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, 270, 92, 96);
      ctx.fillStyle = /♥|♦/.test(card) ? '#d92d2d' : '#101010';
      ctx.font = 'bold 42px Arial';
      ctx.fillText(card, x + 16, 330);
    });

    const buttonColors = ['#3751ff', '#14b36b', '#f2a300', '#d92d2d'];
    state.buttons.forEach(function (label, i) {
      const x = 390 + i * 150;
      const y = 282;
      const width = i === 3 ? 152 : 132;
      ctx.fillStyle = buttonColors[i];
      ctx.fillRect(x, y, width, 62);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, 62);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px Arial';
      ctx.fillText(label, x + 18, y + 39);
    });
  }

  function getXRFrame(scene) {
    return scene && scene.renderer && scene.renderer.xr && scene.renderer.xr.getFrame ? scene.renderer.xr.getFrame() : null;
  }

  function getReferenceSpace(scene, el) {
    const xr = scene && scene.renderer && scene.renderer.xr;
    if (xr && xr.getReferenceSpace) return xr.getReferenceSpace();
    const handComp = el.components['hand-tracking-controls'];
    const trackedWebXR = el.components['tracked-controls-webxr'];
    return (handComp && handComp.referenceSpace) || (trackedWebXR && trackedWebXR.system && trackedWebXR.system.referenceSpace) || null;
  }

  function getController(el) {
    const tracked = el.components['tracked-controls'];
    const trackedWebXR = el.components['tracked-controls-webxr'];
    const handComp = el.components['hand-tracking-controls'];
    return (tracked && tracked.controller) || (trackedWebXR && trackedWebXR.controller) || (handComp && handComp.controller) || null;
  }

  function getJointWorldPose(el, jointName) {
    const scene = el.sceneEl;
    const frame = getXRFrame(scene);
    const referenceSpace = getReferenceSpace(scene, el);
    const controller = getController(el);
    const hand = controller && controller.hand;
    if (!frame || !referenceSpace || !hand || !hand.get) return null;
    const joint = hand.get(jointName);
    if (!joint) return null;
    const pose = frame.getJointPose(joint, referenceSpace);
    if (!pose || !pose.transform) return null;
    const t = pose.transform;
    return {
      position: new THREE.Vector3(t.position.x, t.position.y, t.position.z),
      quaternion: new THREE.Quaternion(t.orientation.x, t.orientation.y, t.orientation.z, t.orientation.w)
    };
  }

  function getEntityWorldPose(el) {
    if (!el || !el.object3D) return null;
    const pos = new THREE.Vector3();
    const quat = new THREE.Quaternion();
    el.object3D.getWorldPosition(pos);
    el.object3D.getWorldQuaternion(quat);
    if (!isFinite(pos.x) || !isFinite(pos.y) || !isFinite(pos.z)) return null;
    if (pos.length() < 0.0001) return null;
    return { position: pos, quaternion: quat };
  }

  AFRAME.registerComponent('forearm-watch', {
    schema: {
      side: { default: 'left' }
    },

    init: function () {
      drawWatchUI(UI_STATE);
      const scene = this.el.sceneEl;
      this.sideSign = this.data.side === 'left' ? -1 : 1;

      const root = document.createElement('a-entity');
      root.setAttribute('visible', 'false');

      const body = document.createElement('a-box');
      body.setAttribute('width', '0.258');
      body.setAttribute('height', '0.102');
      body.setAttribute('depth', '0.020');
      body.setAttribute('color', '#0f1116');
      body.setAttribute('material', 'metalness:0.2; roughness:0.85');
      root.appendChild(body);

      const glass = document.createElement('a-plane');
      glass.setAttribute('width', '0.228');
      glass.setAttribute('height', '0.076');
      glass.setAttribute('position', '0 0 0.0112');
      glass.setAttribute('material', 'src:#watchCanvas; shader:flat; transparent:false; side:double');
      root.appendChild(glass);

      const frameTop = document.createElement('a-box');
      frameTop.setAttribute('width', '0.258');
      frameTop.setAttribute('height', '0.010');
      frameTop.setAttribute('depth', '0.021');
      frameTop.setAttribute('position', '0 0.056 0');
      frameTop.setAttribute('color', '#07080b');
      root.appendChild(frameTop);

      const frameBottom = document.createElement('a-box');
      frameBottom.setAttribute('width', '0.258');
      frameBottom.setAttribute('height', '0.010');
      frameBottom.setAttribute('depth', '0.021');
      frameBottom.setAttribute('position', '0 -0.056 0');
      frameBottom.setAttribute('color', '#07080b');
      root.appendChild(frameBottom);

      const clampA = document.createElement('a-box');
      clampA.setAttribute('width', '0.024');
      clampA.setAttribute('height', '0.096');
      clampA.setAttribute('depth', '0.022');
      clampA.setAttribute('position', '-0.117 0 0');
      clampA.setAttribute('color', '#101216');
      root.appendChild(clampA);

      const clampB = document.createElement('a-box');
      clampB.setAttribute('width', '0.024');
      clampB.setAttribute('height', '0.096');
      clampB.setAttribute('depth', '0.022');
      clampB.setAttribute('position', '0.117 0 0');
      clampB.setAttribute('color', '#101216');
      root.appendChild(clampB);

      const glow = document.createElement('a-plane');
      glow.setAttribute('width', '0.238');
      glow.setAttribute('height', '0.083');
      glow.setAttribute('position', '0 0 0.006');
      glow.setAttribute('material', 'color:#7a33ff; shader:flat; opacity:0.10; transparent:true; side:double');
      root.appendChild(glow);

      scene.appendChild(root);
      this.root = root;
      this.rootObj = root.object3D;
      this.tmpOffset = new THREE.Vector3();
      this.adjust = new THREE.Quaternion();
      this.finalQuat = new THREE.Quaternion();
      this.hiddenFrames = 0;
    },

    tick: function () {
      if (!this.rootObj) return;
      const scene = this.el.sceneEl;
      const inVR = scene && scene.is && scene.is('vr-mode');
      if (!inVR) {
        this.rootObj.visible = false;
        return;
      }

      let pose = getJointWorldPose(this.el, 'wrist');
      let anchorQuat;
      let anchorPos;

      if (pose) {
        anchorPos = pose.position;
        anchorQuat = pose.quaternion;
      } else {
        pose = getEntityWorldPose(this.el);
        if (!pose) {
          this.hiddenFrames += 1;
          if (this.hiddenFrames > 2) this.rootObj.visible = false;
          return;
        }
        anchorPos = pose.position;
        anchorQuat = pose.quaternion;
      }

      this.hiddenFrames = 0;
      const side = this.sideSign;
      this.adjust.setFromEuler(new THREE.Euler(-1.64, 0.08 * side, -1.56 * side, 'YXZ'));
      this.finalQuat.copy(anchorQuat).multiply(this.adjust);

      this.tmpOffset.set(0.036 * side, -0.010, -0.104).applyQuaternion(anchorQuat);
      this.rootObj.position.copy(anchorPos).add(this.tmpOffset);
      this.rootObj.quaternion.copy(this.finalQuat);
      this.rootObj.visible = true;
    }
  });

  window.SVRWatchUI = {
    setState: function (nextState) {
      Object.assign(UI_STATE, nextState || {});
      drawWatchUI(UI_STATE);
    }
  };
})();
