(function () {
  const WATCH_LAYOUT = {
    title: 'SVR POKER',
    subtitle: 'QUEST WRIST UI',
    pot: '15,200',
    stack: '68,500',
    cards: ['A♠', 'K♠'],
    board: ['9♥', '7♠', '10♦', '6♣'],
    buttons: ['FOLD', 'CALL', 'RAISE', 'ALL IN']
  };

  const THREE = AFRAME.THREE;
  const V3A = new THREE.Vector3();
  const V3B = new THREE.Vector3();
  const V3C = new THREE.Vector3();
  const Q1 = new THREE.Quaternion();
  const Q2 = new THREE.Quaternion();
  const M1 = new THREE.Matrix4();
  const S1 = new THREE.Vector3(1, 1, 1);

  function isQuestBrowser() {
    return /OculusBrowser|Quest/i.test(navigator.userAgent || '');
  }

  function sceneInVR(scene) {
    return !!scene && scene.is && scene.is('vr-mode');
  }

  function getCanvas() {
    return document.getElementById('watchCanvas');
  }

  function getDiag() {
    return document.getElementById('diag');
  }

  function setDiag(text) {
    const el = getDiag();
    if (el) el.textContent = text;
  }

  function drawWatchUI(state) {
    const canvas = getCanvas();
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    const bg = ctx.createLinearGradient(0, 0, w, h);
    bg.addColorStop(0, '#050505');
    bg.addColorStop(1, '#10161f');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = '#7b35ff';
    ctx.lineWidth = 12;
    ctx.strokeRect(10, 10, w - 20, h - 20);

    ctx.fillStyle = '#b37dff';
    ctx.font = 'bold 48px Arial';
    ctx.fillText(state.title, 34, 60);

    ctx.fillStyle = '#8aa6c8';
    ctx.font = '24px Arial';
    ctx.fillText(state.subtitle, 36, 94);

    ctx.fillStyle = '#00ffa2';
    ctx.font = 'bold 60px Arial';
    ctx.fillText(state.stack, 360, 110);

    ctx.fillStyle = '#ffd84e';
    ctx.font = 'bold 28px Arial';
    ctx.fillText('POT ' + state.pot, 36, 144);

    ctx.fillStyle = '#1a7a3a';
    ctx.fillRect(24, 162, w - 48, 90);
    ctx.strokeStyle = '#7be2a0';
    ctx.lineWidth = 4;
    ctx.strokeRect(24, 162, w - 48, 90);

    const cardW = 92;
    const cardH = 126;
    const cardY = 138;
    const startX = 88;
    state.board.forEach(function (card, i) {
      const x = startX + i * 118;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, cardY, cardW, cardH);
      ctx.strokeStyle = '#202020';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, cardY, cardW, cardH);
      ctx.fillStyle = /♥|♦/.test(card) ? '#d92d2d' : '#101010';
      ctx.font = 'bold 44px Arial';
      ctx.fillText(card, x + 14, cardY + 74);
    });

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('HAND', 36, 322);

    state.cards.forEach(function (card, i) {
      const x = 120 + i * 112;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, 270, 92, 96);
      ctx.strokeStyle = '#202020';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, 270, 92, 96);
      ctx.fillStyle = /♥|♦/.test(card) ? '#d92d2d' : '#101010';
      ctx.font = 'bold 42px Arial';
      ctx.fillText(card, x + 16, 330);
    });

    const buttonColors = ['#3751ff', '#14b36b', '#f2a300', '#d92d2d'];
    state.buttons.forEach(function (label, i) {
      const x = 390 + i * 150;
      const y = 282;
      const width = i === 3 ? 152 : 132;
      ctx.fillStyle = buttonColors[i];
      ctx.fillRect(x, y, width, 62);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, 62);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px Arial';
      ctx.fillText(label, x + 18, y + 39);
    });
  }

  function getHandTrackingState(el) {
    const handComp = el.components['hand-tracking-controls'];
    const tracked = el.components['tracked-controls'];
    const trackedWebXR = el.components['tracked-controls-webxr'];
    const scene = el.sceneEl;
    const frame = scene && scene.frame;
    const controller = tracked && tracked.controller;
    const hand = controller && controller.hand;
    const referenceSpace = (handComp && handComp.referenceSpace) || (trackedWebXR && trackedWebXR.system && trackedWebXR.system.referenceSpace);
    return {
      frame,
      controller,
      hand,
      referenceSpace
    };
  }

  function getJointPose(el, jointName) {
    const state = getHandTrackingState(el);
    if (!state.frame || !state.hand || !state.referenceSpace || !state.hand.get) return null;
    const joint = state.hand.get(jointName);
    if (!joint) return null;
    const pose = state.frame.getJointPose(joint, state.referenceSpace);
    if (!pose || !pose.transform) return null;
    return pose;
  }

  function getWristAnchor(el) {
    const wristPose = getJointPose(el, 'wrist');
    const indexBase = getJointPose(el, 'index-finger-metacarpal');
    const pinkyBase = getJointPose(el, 'pinky-finger-metacarpal');
    const scene = el.sceneEl;
    const cameraObj = scene && scene.camera && scene.camera.el ? scene.camera.el.object3D : null;
    if (!wristPose || !indexBase || !pinkyBase || !cameraObj) return null;

    const wt = wristPose.transform;
    const it = indexBase.transform;
    const pt = pinkyBase.transform;

    const handSide = ((el.getAttribute('hand-tracking-controls') || {}).hand) || 'left';
    const sideSign = handSide === 'left' ? 1 : -1;

    const wrist = new THREE.Vector3(wt.position.x, wt.position.y, wt.position.z);
    const index = new THREE.Vector3(it.position.x, it.position.y, it.position.z);
    const pinky = new THREE.Vector3(pt.position.x, pt.position.y, pt.position.z);
    const knuckleCenter = index.clone().add(pinky).multiplyScalar(0.5);

    const cameraPos = cameraObj.getWorldPosition(new THREE.Vector3());
    const toCamera = cameraPos.clone().sub(wrist).normalize();

    const acrossPalmRaw = index.clone().sub(pinky).normalize();
    const acrossPalm = sideSign === 1 ? acrossPalmRaw : acrossPalmRaw.clone().multiplyScalar(-1);
    const armBack = wrist.clone().sub(knuckleCenter).normalize();

    // Place the watch behind the wrist toward the forearm, then bias it slightly toward the viewer.
    const pos = wrist.clone()
      .add(armBack.clone().multiplyScalar(0.10))
      .add(toCamera.clone().multiplyScalar(0.018))
      .add(acrossPalm.clone().multiplyScalar(0.01));

    // Keep the screen facing the player while the long side runs along the forearm.
    const zAxis = toCamera.clone();
    let xAxis = armBack.clone().projectOnPlane(zAxis).normalize();
    if (xAxis.lengthSq() < 0.0001) xAxis = armBack.clone().normalize();
    let yAxis = new THREE.Vector3().crossVectors(zAxis, xAxis).normalize();
    if (yAxis.lengthSq() < 0.0001) yAxis = acrossPalm.clone().normalize();
    if (yAxis.dot(acrossPalm) < 0) yAxis.multiplyScalar(-1);
    xAxis = new THREE.Vector3().crossVectors(yAxis, zAxis).normalize();

    M1.makeBasis(xAxis, yAxis, zAxis);
    Q1.setFromRotationMatrix(M1);

    return {
      position: pos,
      quaternion: Q1.clone()
    };
  }

  function getPalmFallback(el) {
    const wristPose = getJointPose(el, 'wrist');
    const scene = el.sceneEl;
    const cameraObj = scene && scene.camera && scene.camera.el ? scene.camera.el.object3D : null;
    if (!wristPose || !cameraObj) return null;

    const wt = wristPose.transform;
    const handSide = ((el.getAttribute('hand-tracking-controls') || {}).hand) || 'left';
    const sideSign = handSide === 'left' ? 1 : -1;

    const wrist = new THREE.Vector3(wt.position.x, wt.position.y, wt.position.z);
    const cameraPos = cameraObj.getWorldPosition(new THREE.Vector3());
    const toCamera = cameraPos.clone().sub(wrist).normalize();

    const pos = wrist.clone()
      .add(new THREE.Vector3(0.018 * sideSign, 0.012, -0.07))
      .add(toCamera.clone().multiplyScalar(0.016));

    const xAxis = new THREE.Vector3(0, 1, 0).cross(toCamera).normalize();
    const yAxis = new THREE.Vector3().crossVectors(toCamera, xAxis).normalize();
    M1.makeBasis(xAxis, yAxis, toCamera);
    Q1.setFromRotationMatrix(M1);

    return {
      position: pos,
      quaternion: Q1.clone()
    };
  }

  AFRAME.registerComponent('quest-hand-gate', {
    init: function () {
      const el = this.el;
      const scene = el.sceneEl;
      const sync = function () {
        const on = isQuestBrowser() && sceneInVR(scene);
        el.object3D.visible = on;
      };
      scene.addEventListener('enter-vr', sync);
      scene.addEventListener('exit-vr', sync);
      setTimeout(sync, 0);
    }
  });

  AFRAME.registerComponent('forearm-watch', {
    schema: {
      side: { default: 'left' }
    },

    init: function () {
      if (this.data.side !== 'left') return;

      drawWatchUI(WATCH_LAYOUT);

      const root = document.createElement('a-entity');
      root.setAttribute('class', 'forearm-watch-root');
      root.setAttribute('visible', 'false');

      const shell = document.createElement('a-box');
      shell.setAttribute('width', '0.19');
      shell.setAttribute('height', '0.07');
      shell.setAttribute('depth', '0.012');
      shell.setAttribute('color', '#080808');
      shell.setAttribute('material', 'metalness:0.85; roughness:0.3');
      root.appendChild(shell);

      const glass = document.createElement('a-plane');
      glass.setAttribute('width', '0.172');
      glass.setAttribute('height', '0.056');
      glass.setAttribute('position', '0 0 0.0072');
      glass.setAttribute('material', 'src:#watchCanvas; shader:flat; transparent:false; side:double');
      root.appendChild(glass);

      const leftClamp = document.createElement('a-box');
      leftClamp.setAttribute('width', '0.025');
      leftClamp.setAttribute('height', '0.092');
      leftClamp.setAttribute('depth', '0.02');
      leftClamp.setAttribute('position', '-0.106 0 0');
      leftClamp.setAttribute('color', '#111111');
      root.appendChild(leftClamp);

      const rightClamp = document.createElement('a-box');
      rightClamp.setAttribute('width', '0.025');
      rightClamp.setAttribute('height', '0.092');
      rightClamp.setAttribute('depth', '0.02');
      rightClamp.setAttribute('position', '0.106 0 0');
      rightClamp.setAttribute('color', '#111111');
      root.appendChild(rightClamp);

      const glow = document.createElement('a-plane');
      glow.setAttribute('width', '0.182');
      glow.setAttribute('height', '0.066');
      glow.setAttribute('position', '0 0 0.004');
      glow.setAttribute('material', 'color:#702eff; shader:flat; opacity:0.12; transparent:true; side:double');
      root.appendChild(glow);

      this.el.sceneEl.appendChild(root);
      this.root = root;
      this.rootObj = root.object3D;
      this.lastAnchorMode = '';

      const scene = this.el.sceneEl;
      const sync = () => {
        const on = isQuestBrowser() && sceneInVR(scene);
        this.rootObj.visible = on;
        setDiag(on ? 'SVR WATCH: QUEST ACTIVE' : 'SVR WATCH: VR OFF');
      };

      scene.addEventListener('enter-vr', sync);
      scene.addEventListener('exit-vr', sync);
      setTimeout(sync, 0);
    },

    tick: function () {
      if (!this.rootObj) return;
      const scene = this.el.sceneEl;
      const on = isQuestBrowser() && sceneInVR(scene);
      this.rootObj.visible = on;
      if (!on) return;

      const cameraObj = scene.camera && scene.camera.el ? scene.camera.el.object3D : null;
      if (!cameraObj) return;

      let anchor = getWristAnchor(this.el);
      let mode = 'wrist-joint';

      if (!anchor) {
        anchor = getPalmFallback(this.el);
        mode = anchor ? 'palm-fallback' : 'camera-fallback';
      }

      if (!anchor) {
        this.rootObj.visible = false;
        if (this.lastAnchorMode !== 'hidden') {
          setDiag('SVR WATCH: WAITING FOR LEFT WRIST');
          this.lastAnchorMode = 'hidden';
        }
        return;
      }

      this.rootObj.visible = true;
      this.rootObj.position.copy(anchor.position);
      this.rootObj.quaternion.copy(anchor.quaternion);
      this.rootObj.scale.copy(S1);

      if (mode !== this.lastAnchorMode) {
        const label = mode === 'wrist-joint'
          ? 'SVR WATCH: HARD WRIST LOCK'
          : 'SVR WATCH: WRIST SAFE FALLBACK';
        setDiag(label);
        this.lastAnchorMode = mode;
      }
    }
  });

  window.SVRWatchUI = {
    setState: function (nextState) {
      Object.assign(WATCH_LAYOUT, nextState || {});
      drawWatchUI(WATCH_LAYOUT);
    }
  };
})();
