export function runModLock({ sceneTargets = {}, audioDisabled = true, privateSceneMode = true } = {}){
  const requiredTargets = [
    'lobby','table','seat',
    'reiki','reikiRoom','pga','pgaRoom','legends','legendRoom',
    'sponsor','sponsorRoom','smoker','smokerRoom','scorpion','scorpionVip'
  ];
  const missingTargets = requiredTargets.filter((key)=>!sceneTargets?.[key]?.pos);
  const privateTargetKeys = ['reikiRoom','pgaRoom','legendRoom','sponsorRoom','smokerRoom','scorpion','scorpionVip'];
  const privateTargets = {};
  privateTargetKeys.forEach((key)=>{
    const p = sceneTargets?.[key]?.pos;
    privateTargets[key] = p ? { x: Number(p.x.toFixed(2)), z: Number(p.z.toFixed(2)) } : null;
  });
  const storefrontTargetKeys = ['reiki','pga','legends','sponsor','smoker'];
  const storefrontTargets = {};
  storefrontTargetKeys.forEach((key)=>{
    const p = sceneTargets?.[key]?.pos;
    storefrontTargets[key] = p ? { x: Number(p.x.toFixed(2)), z: Number(p.z.toFixed(2)) } : null;
  });
  const audit = {
    build: 'FULL-GAMEPLAY-POLISH-SEAT-CHIP-SKY-LOCK',
    lockedAt: new Date().toISOString(),
    ok: missingTargets.length === 0 && audioDisabled === true && privateSceneMode === true,
    audioDisabled: audioDisabled === true,
    privateSceneMode: privateSceneMode === true,
    missingTargets,
    storefrontTargets,
    privateTargets,
    notes: [
      'Lobby contains aligned storefront portals only.',
      'Store/private rooms are isolated teleport scenes outside the lobby floor plan.',
      'Music/audio remains disabled.',
      'Player seat target is locked at table edge.',
      'Poker demo uses flat chips, visible bet flights, winner chip sweep, and left-first dealing.',
      'Moon, Mars, and visible star band are forced above the skyline with textures.'
    ]
  };
  window.SVR_MOD_LOCK = {
    noMusic: true,
    oneControllerMovement: true,
    triggerTeleportOnly: true,
    storefrontAlignment: true,
    privateStoreScenes: true,
    seatEdgeLock: true,
    flatChipMovement: true,
    leftFirstDeal: true,
    skylineSkyVisible: true
  };
  window.SVR_MOD_AUDIT = audit;
  window.SVR_AUDIO_DISABLED = true;
  window.SVR_PRIVATE_SCENES_READY = audit.ok;
  return audit;
}
