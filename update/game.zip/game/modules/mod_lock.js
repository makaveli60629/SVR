export function runModLock({ sceneTargets = {}, audioDisabled = true, privateSceneMode = true } = {}){
  const requiredTargets = [
    'lobby','table','seat',
    'reiki','reikiRoom','pga','pgaRoom','legends','legendRoom',
    'sponsor','sponsorRoom','smoker','smokerRoom','scorpion','scorpionVip'
  ];
  const missingTargets = requiredTargets.filter((key)=>!sceneTargets?.[key]?.pos);
  const privateTargetKeys = ['reikiRoom','pgaRoom','legendRoom','sponsorRoom','smokerRoom','scorpion','scorpionVip'];
  const privateTargets = {};
  privateTargetKeys.forEach((key)=>{
    const p = sceneTargets?.[key]?.pos;
    privateTargets[key] = p ? { x: Number(p.x.toFixed(2)), z: Number(p.z.toFixed(2)) } : null;
  });
  const storefrontTargetKeys = ['reiki','pga','legends','sponsor','smoker'];
  const storefrontTargets = {};
  storefrontTargetKeys.forEach((key)=>{
    const p = sceneTargets?.[key]?.pos;
    storefrontTargets[key] = p ? { x: Number(p.x.toFixed(2)), z: Number(p.z.toFixed(2)) } : null;
  });
  const audit = {
    build: 'STOREFRONT-ALIGN-PRIVATE-SCENES-LOCK',
    lockedAt: new Date().toISOString(),
    ok: missingTargets.length === 0 && audioDisabled === true && privateSceneMode === true,
    audioDisabled: audioDisabled === true,
    privateSceneMode: privateSceneMode === true,
    missingTargets,
    storefrontTargets,
    privateTargets,
    notes: [
      'Lobby contains aligned storefront portals only.',
      'Store/private rooms are isolated teleport scenes outside the lobby floor plan.',
      'Music/audio remains disabled.'
    ]
  };
  window.SVR_MOD_LOCK = {
    noMusic: true,
    oneControllerMovement: true,
    triggerTeleportOnly: true,
    storefrontAlignment: true,
    privateStoreScenes: true
  };
  window.SVR_MOD_AUDIT = audit;
  window.SVR_AUDIO_DISABLED = true;
  window.SVR_PRIVATE_SCENES_READY = audit.ok;
  return audit;
}
