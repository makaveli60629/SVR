// SVR Poker — Module Lock + Boot Audit
// This module is intentionally tiny and non-invasive. It records the current stable
// feature baseline and checks the hub/private-room teleport registry at boot.

export const SVR_MOD_LOCK = Object.freeze({
  buildId: 'SVR-MOD-LOCK-HUBS-PRIVATE-ROOMS-2026-05-06',
  version: 'next-phase-mod-lock-01',
  lockedAt: '2026-05-06',
  lockedModules: Object.freeze({
    noMusic: true,
    oneControllerMovement: true,
    fortyFiveDegreeSnapTurn: true,
    triggerReleaseTeleport: true,
    pinchLeapTeleportDisabled: true,
    watchSceneButtons: true,
    scorpionPokerRoom: true,
    playerPokerControls: true,
    hubPrivateRoomTeleport: true
  }),
  requiredSceneTargets: Object.freeze([
    'lobby',
    'table',
    'seat',
    'reiki',
    'reikiRoom',
    'pga',
    'pgaRoom',
    'legends',
    'legendRoom',
    'sponsor',
    'sponsorRoom',
    'smoker',
    'smokerRoom',
    'scorpion',
    'scorpionVip'
  ]),
  controls: Object.freeze({
    desktop: '1-9/P/V/B/O/U scene jumps, J sit, L leave, T teleport, F/C/R/H poker',
    quest: 'Either controller moves/snap-turns; trigger-release teleports only when TP is armed; finger pinch no longer teleports',
    watch: 'Lobby/Table/Seat/Reiki/Zen/PGA/PGA VIP/Legend/Legend VIP/Sponsor/Sponsor VIP/Smoker/Lounge/Scorpion/Scorpion VIP'
  })
});

function muteElement(el){
  try{
    if (typeof el.pause === 'function') el.pause();
    el.muted = true;
    el.volume = 0;
    el.autoplay = false;
    el.loop = false;
    el.removeAttribute?.('autoplay');
    el.removeAttribute?.('src');
    el.load?.();
  }catch(_err){ /* no-op safety */ }
}

export function forceNoAudio(documentRef = globalThis.document){
  try{
    documentRef?.querySelectorAll?.('audio, video')?.forEach(muteElement);
  }catch(_err){ /* no-op safety */ }
  globalThis.SVR_AUDIO_DISABLED = true;
  return true;
}

export function auditSceneTargets(sceneTargets = {}){
  const missing = [];
  const ready = [];
  for (const key of SVR_MOD_LOCK.requiredSceneTargets){
    const rec = sceneTargets?.[key];
    if (rec?.pos) ready.push(key);
    else missing.push(key);
  }
  return {
    buildId: SVR_MOD_LOCK.buildId,
    ok: missing.length === 0,
    ready,
    missing,
    requiredCount: SVR_MOD_LOCK.requiredSceneTargets.length,
    readyCount: ready.length
  };
}

export function installModLocks({ sceneTargets = {}, log = console.log, documentRef = globalThis.document } = {}){
  forceNoAudio(documentRef);
  const audit = auditSceneTargets(sceneTargets);
  globalThis.SVR_MOD_LOCK = SVR_MOD_LOCK;
  globalThis.SVR_MOD_AUDIT = audit;
  try{
    documentRef?.body?.setAttribute?.('data-svr-mod-lock', SVR_MOD_LOCK.buildId);
    documentRef?.body?.setAttribute?.('data-svr-audio-disabled', 'true');
  }catch(_err){ /* no-op */ }
  if (audit.ok) log?.(`[MOD LOCK] ${SVR_MOD_LOCK.buildId}: ${audit.readyCount}/${audit.requiredCount} scene targets ready.`);
  else log?.(`[MOD LOCK] Missing scene targets: ${audit.missing.join(', ')}`);
  return audit;
}
