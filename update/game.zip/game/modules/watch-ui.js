(function () {
  const WATCH_LAYOUT = {
    title: 'SVR POKER',
    subtitle: 'FOREARM HUD',
    pot: '15,200',
    stack: '68,500',
    cards: ['A♠', 'K♠'],
    board: ['9♥', '7♠', '10♦', '6♣'],
    buttons: ['FOLD', 'CALL', 'RAISE', 'ALL IN']
  };

  function getCanvas() {
    return document.getElementById('watchCanvas');
  }

  function drawWatchUI(state) {
    const canvas = getCanvas();
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    const bg = ctx.createLinearGradient(0, 0, w, h);
    bg.addColorStop(0, '#050509');
    bg.addColorStop(1, '#111a25');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = '#8f44ff';
    ctx.lineWidth = 12;
    ctx.strokeRect(10, 10, w - 20, h - 20);

    ctx.fillStyle = '#d9b7ff';
    ctx.font = 'bold 50px Arial';
    ctx.fillText(state.title, 34, 60);

    ctx.fillStyle = '#8aa6c8';
    ctx.font = '24px Arial';
    ctx.fillText(state.subtitle, 36, 94);

    ctx.fillStyle = '#00ffa2';
    ctx.font = 'bold 60px Arial';
    ctx.fillText(state.stack, 360, 110);

    ctx.fillStyle = '#ffd84e';
    ctx.font = 'bold 28px Arial';
    ctx.fillText('POT ' + state.pot, 36, 144);

    ctx.fillStyle = '#145d33';
    ctx.fillRect(24, 162, w - 48, 90);
    ctx.strokeStyle = '#7be2a0';
    ctx.lineWidth = 4;
    ctx.strokeRect(24, 162, w - 48, 90);

    const cardW = 92;
    const cardH = 126;
    const cardY = 138;
    const startX = 88;
    state.board.forEach(function (card, i) {
      const x = startX + i * 118;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, cardY, cardW, cardH);
      ctx.strokeStyle = '#202020';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, cardY, cardW, cardH);
      ctx.fillStyle = /♥|♦/.test(card) ? '#d92d2d' : '#101010';
      ctx.font = 'bold 44px Arial';
      ctx.fillText(card, x + 14, cardY + 74);
    });

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('HAND', 36, 322);

    state.cards.forEach(function (card, i) {
      const x = 120 + i * 112;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, 270, 92, 96);
      ctx.strokeStyle = '#202020';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, 270, 92, 96);
      ctx.fillStyle = /♥|♦/.test(card) ? '#d92d2d' : '#101010';
      ctx.font = 'bold 42px Arial';
      ctx.fillText(card, x + 16, 330);
    });

    const buttonColors = ['#3751ff', '#14b36b', '#f2a300', '#d92d2d'];
    state.buttons.forEach(function (label, i) {
      const x = 390 + i * 150;
      const y = 282;
      const width = i === 3 ? 152 : 132;
      ctx.fillStyle = buttonColors[i];
      ctx.fillRect(x, y, width, 62);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, 62);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px Arial';
      ctx.fillText(label, x + 18, y + 39);
    });
  }

  window.SVRWatchUI = {
    setState: function (nextState) {
      Object.assign(WATCH_LAYOUT, nextState || {});
      drawWatchUI(WATCH_LAYOUT);
    },
    draw: function () {
      drawWatchUI(WATCH_LAYOUT);
    }
  };

  window.addEventListener('DOMContentLoaded', function () {
    drawWatchUI(WATCH_LAYOUT);
  });
})();
