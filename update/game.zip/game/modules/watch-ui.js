(function () {
  const WATCH_LAYOUT = {
    title: 'SCARLETT VR POKER',
    subtitle: 'QUEST FOREARM COMMAND',
    pot: '15,200',
    stack: '68,500',
    cards: ['A♠', 'K♠'],
    board: ['9♥', '7♠', '10♦', '6♣'],
    buttons: ['FOLD', 'CHECK', 'CALL', 'ALL IN'],
    options: ['MENU', 'VIEW', 'AUTO', 'STORE'],
    blind: '500 / 1,000',
    seat: 'SEAT 01',
    brand: 'ALL IN'
  };

  const logoImage = new Image();
  let logoReady = false;
  logoImage.onload = function () {
    logoReady = true;
    drawWatchUI(WATCH_LAYOUT);
  };
  logoImage.src = 'assets/logo.png';

  function getCanvas() {
    return document.getElementById('watchCanvas');
  }

  function roundRect(ctx, x, y, width, height, radius, fill, stroke) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
    if (fill) ctx.fill();
    if (stroke) ctx.stroke();
  }

  function drawCard(ctx, card, x, y, width, height) {
    ctx.fillStyle = '#f7fbff';
    roundRect(ctx, x, y, width, height, 12, true, false);
    ctx.strokeStyle = '#151922';
    ctx.lineWidth = 2;
    roundRect(ctx, x, y, width, height, 12, false, true);

    ctx.fillStyle = /♥|♦/.test(card) ? '#dc3761' : '#111827';
    ctx.font = 'bold 32px Arial';
    ctx.fillText(card, x + 14, y + 48);
  }

  function drawButton(ctx, label, x, y, width, height, accent, subline) {
    const grad = ctx.createLinearGradient(x, y, x + width, y + height);
    grad.addColorStop(0, accent);
    grad.addColorStop(1, '#101520');
    ctx.fillStyle = grad;
    ctx.shadowColor = accent;
    ctx.shadowBlur = 16;
    roundRect(ctx, x, y, width, height, 15, true, false);
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#f4f8ff';
    ctx.lineWidth = 1.5;
    roundRect(ctx, x, y, width, height, 15, false, true);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px Arial';
    ctx.fillText(label, x + 14, y + 27);
    if (subline) {
      ctx.fillStyle = '#b5c7db';
      ctx.font = '12px Arial';
      ctx.fillText(subline, x + 14, y + 45);
    }
  }

  function drawChip(ctx, text, x, y, width, accent) {
    ctx.fillStyle = 'rgba(9,14,22,0.92)';
    ctx.strokeStyle = accent;
    ctx.lineWidth = 1.5;
    roundRect(ctx, x, y, width, 28, 14, true, true);
    ctx.fillStyle = '#eaf2ff';
    ctx.font = 'bold 13px Arial';
    ctx.fillText(text, x + 12, y + 19);
  }

  function drawWatchUI(state) {
    const canvas = getCanvas();
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    const bg = ctx.createLinearGradient(0, 0, w, h);
    bg.addColorStop(0, '#04060d');
    bg.addColorStop(0.55, '#0a1020');
    bg.addColorStop(1, '#16111d');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = '#934dff';
    ctx.lineWidth = 10;
    roundRect(ctx, 8, 8, w - 16, h - 16, 26, false, true);

    const inner = ctx.createLinearGradient(0, 0, w, 0);
    inner.addColorStop(0, 'rgba(108,40,255,0.22)');
    inner.addColorStop(1, 'rgba(37,190,255,0.16)');
    ctx.fillStyle = inner;
    roundRect(ctx, 20, 20, w - 40, h - 40, 20, true, false);

    ctx.strokeStyle = 'rgba(142,198,255,0.28)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      const y = 34 + i * 56;
      ctx.beginPath();
      ctx.moveTo(26, y);
      ctx.lineTo(w - 26, y);
      ctx.stroke();
    }

    ctx.fillStyle = '#0b101b';
    ctx.strokeStyle = '#6be6ff';
    ctx.lineWidth = 2;
    roundRect(ctx, 28, 28, 230, 146, 22, true, true);

    if (logoReady) {
      ctx.drawImage(logoImage, 42, 34, 102, 102);
    }

    ctx.fillStyle = '#f3f7ff';
    ctx.font = 'bold 28px Arial';
    ctx.fillText('SCARLETT', 136, 72);
    ctx.font = 'bold 22px Arial';
    ctx.fillText('VR POKER', 136, 102);
    ctx.fillStyle = '#92a8c6';
    ctx.font = '16px Arial';
    ctx.fillText(state.subtitle, 136, 126);

    drawChip(ctx, state.seat, 136, 138, 78, '#8c54ff');
    drawChip(ctx, state.brand, 218, 138, 68, '#4be4ff');

    ctx.fillStyle = '#eef5ff';
    ctx.font = 'bold 26px Arial';
    ctx.fillText(state.title, 286, 58);
    ctx.fillStyle = '#8fb6e0';
    ctx.font = '16px Arial';
    ctx.fillText('POT', 286, 84);
    ctx.fillText('STACK', 450, 84);
    ctx.fillText('BLINDS', 670, 84);

    ctx.fillStyle = '#ffd45f';
    ctx.font = 'bold 38px Arial';
    ctx.fillText(state.pot, 286, 118);
    ctx.fillStyle = '#63ffc9';
    ctx.fillText(state.stack, 450, 118);
    ctx.fillStyle = '#c9d7ff';
    ctx.fillText(state.blind, 670, 118);

    ctx.fillStyle = '#103b26';
    ctx.strokeStyle = '#62e89f';
    ctx.lineWidth = 3;
    roundRect(ctx, 286, 136, 696, 88, 18, true, true);

    const boardStartX = 326;
    state.board.forEach(function (card, i) {
      drawCard(ctx, card, boardStartX + i * 118, 149, 88, 62);
    });

    ctx.fillStyle = '#d6e8ff';
    ctx.font = 'bold 17px Arial';
    ctx.fillText('BOARD', 286, 165);

    ctx.fillStyle = '#0c1220';
    ctx.strokeStyle = '#7b45ff';
    roundRect(ctx, 28, 188, 240, 166, 20, true, true);

    ctx.fillStyle = '#eef5ff';
    ctx.font = 'bold 18px Arial';
    ctx.fillText('PLAYER HAND', 44, 214);

    state.cards.forEach(function (card, i) {
      drawCard(ctx, card, 44 + i * 102, 232, 86, 106);
    });

    drawChip(ctx, 'TRACKING: LOCK', 44, 312, 134, '#4be4ff');
    drawChip(ctx, 'QUEST HUD', 182, 312, 86, '#8c54ff');

    const optionAccents = ['#43a6ff', '#8e4dff', '#17c97f', '#f0ab25'];
    state.options.forEach(function (label, i) {
      const x = 286 + i * 170;
      drawButton(ctx, label, x, 240, 150, 52, optionAccents[i], 'OPTION');
    });

    const actionAccents = ['#3557ff', '#14a66b', '#f0a11c', '#e63658'];
    const actionNotes = ['Exit hand', 'Stay in pot', 'Match wager', 'Max pressure'];
    state.buttons.forEach(function (label, i) {
      const x = 286 + i * 170;
      drawButton(ctx, label, x, 302, 150, 58, actionAccents[i], actionNotes[i]);
    });
  }

  window.SVRWatchUI = {
    setState: function (nextState) {
      Object.assign(WATCH_LAYOUT, nextState || {});
      drawWatchUI(WATCH_LAYOUT);
    },
    draw: function () {
      drawWatchUI(WATCH_LAYOUT);
    }
  };

  window.addEventListener('DOMContentLoaded', function () {
    drawWatchUI(WATCH_LAYOUT);
  });
})();
