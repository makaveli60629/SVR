export function createDebugStats({ renderer, scene, camera, el, label = "ROOM" }) {
  let visible = false;
  let accum = 0;
  let frames = 0;
  let fps = 0;

  function toggle(force){
    visible = typeof force === "boolean" ? force : !visible;
    if (el) el.style.display = visible ? "block" : "none";
  }

  function update(dt, leftHand, rightHand){
    frames += 1;
    accum += dt;
    if (accum >= 0.5){
      fps = frames / accum;
      frames = 0;
      accum = 0;

      if (!visible || !el) return;

      const info = renderer.info;
      const heap = performance?.memory
        ? `${(performance.memory.usedJSHeapSize / 1048576).toFixed(1)} / ${(performance.memory.jsHeapSizeLimit / 1048576).toFixed(0)} MB`
        : "n/a";
      const cam = `${camera.position.x.toFixed(2)}, ${camera.position.y.toFixed(2)}, ${camera.position.z.toFixed(2)}`;
      const left = leftHand?.joints ? "yes" : "no";
      const right = rightHand?.joints ? "yes" : "no";
      const xr = renderer.xr.isPresenting ? "XR" : "DESKTOP";

      el.textContent = [
        `${label}`,
        `mode      ${xr}`,
        `fps       ${fps.toFixed(1)}`,
        `heap      ${heap}`,
        `draws     ${info.render.calls}`,
        `tris      ${info.render.triangles}`,
        `lines     ${info.render.lines}`,
        `points    ${info.render.points}`,
        `geoms     ${info.memory.geometries}`,
        `textures  ${info.memory.textures}`,
        `children  ${scene.children.length}`,
        `camera    ${cam}`,
        `leftHand  ${left}`,
        `rightHand ${right}`,
        `keys      1=joints  2=stats`,
      ].join("\n");
    }
  }

  toggle(false);
  return { toggle, update, isVisible: ()=>visible };
}
