(function () {
  const THREE = AFRAME.THREE;

  function makeWindowTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#0a0d14';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    for (let y = 6; y < canvas.height - 6; y += 12) {
      for (let x = 6; x < canvas.width - 6; x += 12) {
        if (Math.random() > 0.58) {
          const lit = Math.random() > 0.4;
          ctx.fillStyle = lit ? (Math.random() > 0.5 ? '#b891ff' : '#ffd6a8') : '#10141e';
          ctx.fillRect(x, y, 6, 7);
        }
      }
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(1.2, 3.2);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  AFRAME.registerComponent('lobby-skyline', {
    init: function () {
      const group = new THREE.Group();
      const windowTex = makeWindowTexture();
      const sideMat = new THREE.MeshStandardMaterial({
        color: '#202531',
        map: windowTex,
        emissiveMap: windowTex,
        emissive: '#6752c7',
        emissiveIntensity: 0.55,
        roughness: 0.92,
        metalness: 0.05
      });
      const roofMat = new THREE.MeshStandardMaterial({
        color: '#262c38',
        roughness: 0.96,
        metalness: 0.03
      });

      const defs = [
        { x: -84, z: -146, w: 18, h: 72, d: 18 },
        { x: -58, z: -136, w: 14, h: 96, d: 14 },
        { x: -34, z: -150, w: 16, h: 58, d: 16 },
        { x: 30, z: -148, w: 16, h: 54, d: 16 },
        { x: 54, z: -134, w: 14, h: 94, d: 14 },
        { x: 80, z: -144, w: 18, h: 76, d: 18 },
        { x: -112, z: -170, w: 22, h: 110, d: 22 },
        { x: 112, z: -170, w: 22, h: 112, d: 22 },
        { x: 0, z: -182, w: 44, h: 38, d: 20 }
      ];

      defs.forEach((b, i) => {
        const geo = new THREE.BoxGeometry(b.w, b.h, b.d);
        const mats = [sideMat, sideMat, roofMat, roofMat, sideMat, sideMat];
        const mesh = new THREE.Mesh(geo, mats);
        mesh.position.set(b.x, b.h / 2, b.z);
        mesh.castShadow = false;
        mesh.receiveShadow = false;
        group.add(mesh);

        if (i !== 8) {
          const crown = new THREE.Mesh(
            new THREE.BoxGeometry(b.w * 0.56, Math.max(6, b.h * 0.12), b.d * 0.56),
            new THREE.MeshStandardMaterial({ color: '#30394a', emissive: '#6d52d7', emissiveIntensity: 0.22, roughness: 0.9 })
          );
          crown.position.set(b.x, b.h + Math.max(3.5, b.h * 0.06), b.z);
          group.add(crown);
        }
      });

      const haze = new THREE.Mesh(
        new THREE.PlaneGeometry(260, 84),
        new THREE.MeshBasicMaterial({ color: '#1d1039', transparent: true, opacity: 0.16, depthWrite: false })
      );
      haze.position.set(0, 26, -190);
      group.add(haze);

      this.el.object3D.add(group);
    }
  });
})();
