// SVR Poker audio hard-disable module
// Purpose: remove all music/autoplay paths while keeping old callers safe.
export function createAudioPlaylist(){
  const state = { enabled: false, primed: false, trackTitle: 'Music removed', error: null };
  const notify = () => {};
  return {
    async prime(){ state.primed = false; notify(); return false; },
    async start(){ state.enabled = false; notify(); return false; },
    async stop(){ state.enabled = false; notify(); return false; },
    async toggle(){ state.enabled = false; notify(); return false; },
    async next(){ state.enabled = false; notify(); return false; },
    tick(){},
    getState(){ return { ...state }; }
  };
}
