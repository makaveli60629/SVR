export function createAudioPlaylist({ tracks = [], onState = ()=>{} } = {}){
  let index = 0;
  let enabled = false;
  let primed = false;
  let audio = null;

  function current(){ return tracks[index] || null; }

  function state(){
    const track = current();
    return {
      enabled,
      primed,
      trackIndex: index,
      trackTitle: track?.title || "No Track",
      trackCount: tracks.length
    };
  }

  function emit(){ onState(state()); }

  function ensureAudio(){
    if (audio || !tracks.length) return audio;
    audio = new Audio(current().url);
    audio.loop = true;
    audio.preload = "auto";
    audio.playsInline = true;
    audio.crossOrigin = "anonymous";
    audio.volume = 0.9;
    audio.muted = true;
    return audio;
  }

  async function prime(){
    if (!tracks.length) return false;
    const el = ensureAudio();
    try{
      await el.play();
      primed = true;
      el.muted = true;
      emit();
      return true;
    }catch(_err){
      emit();
      return false;
    }
  }

  function bindUnlocks(){
    const once = async ()=>{
      await prime();
      window.removeEventListener("pointerdown", once);
      window.removeEventListener("touchstart", once);
      window.removeEventListener("keydown", once);
    };
    window.addEventListener("pointerdown", once, { passive: true });
    window.addEventListener("touchstart", once, { passive: true });
    window.addEventListener("keydown", once);
    setTimeout(()=>prime(), 60);
  }

  function loadCurrent(keepPlaying = false){
    const el = ensureAudio();
    if (!el) return;
    const wasPlaying = keepPlaying || !el.paused;
    el.src = current().url;
    el.load();
    if (primed || enabled || wasPlaying){
      el.play().then(()=>{
        el.muted = !enabled;
      }).catch(()=>{});
    }
    emit();
  }

  async function toggle(){
    if (!tracks.length){ emit(); return false; }
    const el = ensureAudio();
    if (!primed) await prime();
    enabled = !enabled;
    if (enabled){
      el.muted = false;
      await el.play().catch(()=>{});
    }else{
      el.muted = true;
      el.pause();
    }
    emit();
    return enabled;
  }

  async function next(){
    if (!tracks.length) return;
    index = (index + 1) % tracks.length;
    loadCurrent(enabled);
    if (enabled && audio){
      audio.muted = false;
      await audio.play().catch(()=>{});
    }
  }

  function stop(){
    enabled = false;
    if (audio){
      audio.muted = true;
      audio.pause();
    }
    emit();
  }

  bindUnlocks();
  emit();
  return { toggle, next, stop, getState: state, prime };
}
