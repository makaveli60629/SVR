export function createAudioPlaylist({ tracks = [], onState = ()=>{} } = {}){
  let index = 0;
  let enabled = false;
  let audio = null;

  function current(){
    return tracks[index] || null;
  }

  function emit(){
    const track = current();
    onState({
      enabled,
      trackIndex: index,
      trackTitle: track?.title || "No Track",
      trackCount: tracks.length
    });
  }

  function ensureAudio(){
    if (audio || !tracks.length) return audio;
    audio = new Audio(current().url);
    audio.loop = true;
    audio.volume = 0.45;
    audio.preload = "auto";
    audio.addEventListener("ended", ()=>{
      if (enabled) next();
    });
    return audio;
  }

  function loadCurrent(){
    if (!audio || !tracks.length) return;
    const wasPlaying = !audio.paused;
    audio.src = current().url;
    audio.load();
    if (enabled || wasPlaying){
      audio.play().catch(()=>{});
    }
    emit();
  }

  async function toggle(){
    if (!tracks.length){
      emit();
      return false;
    }
    const el = ensureAudio();
    enabled = !enabled;
    if (enabled){
      await el.play().catch(()=>{});
    } else {
      el.pause();
    }
    emit();
    return enabled;
  }

  function next(){
    if (!tracks.length) return;
    index = (index + 1) % tracks.length;
    ensureAudio();
    loadCurrent();
  }

  function prev(){
    if (!tracks.length) return;
    index = (index - 1 + tracks.length) % tracks.length;
    ensureAudio();
    loadCurrent();
  }

  function stop(){
    enabled = false;
    if (audio) audio.pause();
    emit();
  }

  function getState(){
    const track = current();
    return {
      enabled,
      trackIndex: index,
      trackTitle: track?.title || "No Track",
      trackCount: tracks.length
    };
  }

  emit();
  return { toggle, next, prev, stop, getState };
}
