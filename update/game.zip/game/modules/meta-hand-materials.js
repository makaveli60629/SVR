(function () {
  const THREE = AFRAME.THREE;
  const loader = new THREE.TextureLoader();

  const TEXTURE_SET = {
    color: loader.load('assets/textures/HAND_C.png'),
    normal: loader.load('assets/textures/HAND_N.png'),
    spec: loader.load('assets/textures/HAND_S.png')
  };

  TEXTURE_SET.color.colorSpace = THREE.SRGBColorSpace;
  TEXTURE_SET.normal.colorSpace = THREE.NoColorSpace;
  TEXTURE_SET.spec.colorSpace = THREE.NoColorSpace;

  Object.values(TEXTURE_SET).forEach(function (tex) {
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.anisotropy = 4;
    tex.needsUpdate = true;
  });

  function applyHandMaterial(root) {
    let applied = false;
    root.traverse(function (obj) {
      if (!obj.isMesh) return;
      const material = new THREE.MeshStandardMaterial({
        color: '#ffffff',
        map: TEXTURE_SET.color,
        normalMap: TEXTURE_SET.normal,
        roughnessMap: TEXTURE_SET.spec,
        roughness: 0.96,
        metalness: 0.0,
        transparent: false,
        side: THREE.DoubleSide,
        skinning: !!obj.isSkinnedMesh
      });
      obj.material = material;
      obj.castShadow = false;
      obj.receiveShadow = false;
      applied = true;
    });
    return applied;
  }

  AFRAME.registerComponent('meta-hand-skin', {
    init: function () {
      this.applied = false;
      this.frames = 0;
      this.tryApply = this.tryApply.bind(this);
      this.el.addEventListener('object3dset', this.tryApply);
      setTimeout(this.tryApply, 0);
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.tryApply);
    },

    tryApply: function () {
      this.applied = applyHandMaterial(this.el.object3D) || this.applied;
    },

    tick: function () {
      if (this.applied) return;
      this.frames += 1;
      if (this.frames % 20 === 0) this.tryApply();
    }
  });
})();
