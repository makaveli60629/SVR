(function () {
  const THREE = AFRAME.THREE;
  const loader = new THREE.TextureLoader();

  const TEXTURE_SET = {
    color: loader.load('assets/textures/HAND_C.png'),
    normal: loader.load('assets/textures/HAND_N.png'),
    surface: loader.load('assets/textures/HAND_S.png')
  };

  TEXTURE_SET.color.colorSpace = THREE.SRGBColorSpace;
  TEXTURE_SET.normal.colorSpace = THREE.NoColorSpace;
  TEXTURE_SET.surface.colorSpace = THREE.NoColorSpace;

  Object.values(TEXTURE_SET).forEach(function (tex) {
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.anisotropy = 4;
    tex.flipY = false;
    tex.needsUpdate = true;
  });

  function shouldSkip(obj) {
    let node = obj;
    while (node) {
      if (node.userData && node.userData.svrSkipHandMaterial) return true;
      node = node.parent;
    }
    return false;
  }

  function getTargetMeshes(root) {
    const targets = [];
    root.traverse(function (obj) {
      if (!obj.isMesh || shouldSkip(obj)) return;
      const name = String(obj.name || '').toLowerCase();
      if (!obj.isSkinnedMesh && !/hand|wrist|finger|thumb|index|pinky|middle|ring/i.test(name)) return;
      targets.push(obj);
    });
    return targets;
  }

  function applyHandMaterial(root) {
    const targets = getTargetMeshes(root);
    if (!targets.length) return false;

    targets.forEach(function (obj) {
      const material = new THREE.MeshStandardMaterial({
        color: '#f3dfd1',
        map: TEXTURE_SET.color,
        normalMap: TEXTURE_SET.normal,
        roughnessMap: TEXTURE_SET.surface,
        metalness: 0.0,
        roughness: 0.96,
        side: THREE.FrontSide,
        skinning: !!obj.isSkinnedMesh,
        emissive: '#120804',
        emissiveIntensity: 0.03
      });
      material.normalScale = new THREE.Vector2(0.42, 0.42);
      obj.material = material;
      obj.castShadow = false;
      obj.receiveShadow = false;
    });
    return true;
  }

  AFRAME.registerComponent('meta-hand-skin', {
    init: function () {
      this.applied = false;
      this.frames = 0;
      this.tryApply = this.tryApply.bind(this);
      this.el.addEventListener('object3dset', this.tryApply);
      setTimeout(this.tryApply, 0);
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.tryApply);
    },

    tryApply: function () {
      this.applied = applyHandMaterial(this.el.object3D) || this.applied;
    },

    tick: function () {
      if (this.applied) return;
      this.frames += 1;
      if (this.frames % 20 === 0) this.tryApply();
    }
  });
})();
