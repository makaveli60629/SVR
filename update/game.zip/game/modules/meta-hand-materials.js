(function () {
  const THREE = AFRAME.THREE;
  const loader = new THREE.TextureLoader();

  const TEXTURE_SET = {
    color: loader.load('assets/textures/HAND_C.png'),
    normal: loader.load('assets/textures/HAND_N.png')
  };

  TEXTURE_SET.color.colorSpace = THREE.SRGBColorSpace;
  TEXTURE_SET.normal.colorSpace = THREE.NoColorSpace;

  Object.values(TEXTURE_SET).forEach(function (tex) {
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.anisotropy = 4;
    tex.needsUpdate = true;
  });

  function makeAlphaMapFromTexture(texture) {
    const canvas = document.createElement('canvas');
    canvas.width = texture.image.width;
    canvas.height = texture.image.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(texture.image, 0, 0);
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = img.data;
    for (let i = 0; i < data.length; i += 4) {
      const brightness = Math.max(data[i], data[i + 1], data[i + 2]);
      const alpha = brightness > 18 ? 255 : 0;
      data[i] = alpha;
      data[i + 1] = alpha;
      data[i + 2] = alpha;
      data[i + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
    const alphaTex = new THREE.CanvasTexture(canvas);
    alphaTex.wrapS = THREE.ClampToEdgeWrapping;
    alphaTex.wrapT = THREE.ClampToEdgeWrapping;
    alphaTex.colorSpace = THREE.NoColorSpace;
    alphaTex.needsUpdate = true;
    return alphaTex;
  }

  let alphaMap = null;
  if (TEXTURE_SET.color.image && TEXTURE_SET.color.image.width) {
    alphaMap = makeAlphaMapFromTexture(TEXTURE_SET.color);
  } else {
    TEXTURE_SET.color.addEventListener('update', function () {
      alphaMap = makeAlphaMapFromTexture(TEXTURE_SET.color);
    });
  }

  function shouldSkip(obj) {
    let node = obj;
    while (node) {
      if (node.userData && node.userData.svrSkipHandMaterial) return true;
      node = node.parent;
    }
    return false;
  }

  function applyHandMaterial(root) {
    let applied = false;
    root.traverse(function (obj) {
      if (!obj.isMesh || shouldSkip(obj)) return;
      if (!obj.isSkinnedMesh && !/hand|wrist|finger|thumb|index|pinky|middle|ring/i.test(String(obj.name || ''))) return;

      const material = new THREE.MeshStandardMaterial({
        color: '#f2dbc9',
        map: TEXTURE_SET.color,
        normalMap: TEXTURE_SET.normal,
        roughness: 0.92,
        metalness: 0.0,
        transparent: true,
        alphaMap: alphaMap || null,
        alphaTest: 0.35,
        side: THREE.FrontSide,
        skinning: !!obj.isSkinnedMesh,
        emissive: '#140806',
        emissiveIntensity: 0.06
      });
      material.normalScale = new THREE.Vector2(0.35, 0.35);
      obj.material = material;
      obj.castShadow = false;
      obj.receiveShadow = false;
      applied = true;
    });
    return applied;
  }

  AFRAME.registerComponent('meta-hand-skin', {
    init: function () {
      this.applied = false;
      this.frames = 0;
      this.tryApply = this.tryApply.bind(this);
      this.el.addEventListener('object3dset', this.tryApply);
      setTimeout(this.tryApply, 0);
    },

    remove: function () {
      this.el.removeEventListener('object3dset', this.tryApply);
    },

    tryApply: function () {
      this.applied = applyHandMaterial(this.el.object3D) || this.applied;
    },

    tick: function () {
      if (this.applied) return;
      this.frames += 1;
      if (this.frames % 20 === 0) this.tryApply();
    }
  });
})();
