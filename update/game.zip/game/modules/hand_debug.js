import * as THREE from "three";

const JOINT_NAMES = [
  "wrist",
  "thumb-metacarpal", "thumb-phalanx-proximal", "thumb-phalanx-distal", "thumb-tip",
  "index-finger-metacarpal", "index-finger-phalanx-proximal", "index-finger-phalanx-intermediate", "index-finger-phalanx-distal", "index-finger-tip",
  "middle-finger-metacarpal", "middle-finger-phalanx-proximal", "middle-finger-phalanx-intermediate", "middle-finger-phalanx-distal", "middle-finger-tip",
  "ring-finger-metacarpal", "ring-finger-phalanx-proximal", "ring-finger-phalanx-intermediate", "ring-finger-phalanx-distal", "ring-finger-tip",
  "pinky-finger-metacarpal", "pinky-finger-phalanx-proximal", "pinky-finger-phalanx-intermediate", "pinky-finger-phalanx-distal", "pinky-finger-tip",
];

export function createJointDebug({ scene }) {
  const root = new THREE.Group();
  root.visible = false;
  scene.add(root);

  const makeMarker = (hex)=> new THREE.Mesh(
    new THREE.SphereGeometry(0.012, 10, 10),
    new THREE.MeshBasicMaterial({ color: hex, depthWrite: false })
  );

  const leftMarkers = new Map();
  const rightMarkers = new Map();
  for (const name of JOINT_NAMES){
    const left = makeMarker(0xb48cff);
    const right = makeMarker(0x6cf6ff);
    left.visible = false;
    right.visible = false;
    root.add(left, right);
    leftMarkers.set(name, left);
    rightMarkers.set(name, right);
  }

  function sync(hand, markers){
    for (const [name, marker] of markers.entries()){
      const joint = hand?.joints?.[name];
      if (!root.visible || !joint){
        marker.visible = false;
        continue;
      }
      joint.getWorldPosition(marker.position);
      marker.visible = true;
    }
  }

  function update(leftHand, rightHand){
    sync(leftHand, leftMarkers);
    sync(rightHand, rightMarkers);
  }

  function toggle(force){
    root.visible = typeof force === "boolean" ? force : !root.visible;
    if (!root.visible){
      for (const marker of leftMarkers.values()) marker.visible = false;
      for (const marker of rightMarkers.values()) marker.visible = false;
    }
  }

  return { update, toggle, isVisible: ()=>root.visible };
}
