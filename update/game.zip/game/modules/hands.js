import { XRHandModelFactory } from "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/webxr/XRHandModelFactory.js";

export function createHands({ scene, renderer, log=console.log }) {
  const factory = new XRHandModelFactory();
  const raw=[];
  let left=null, right=null;

  for (let i=0;i<2;i++){
    const h=renderer.xr.getHand(i);
    h.add(factory.createHandModel(h,"mesh"));
    scene.add(h);
    raw.push(h);
    h.addEventListener("connected",(evt)=>{
      const handed=evt?.data?.handedness;
      log("Hand connected", i, handed||"unknown");
      if (handed==="left") left=h;
      if (handed==="right") right=h;
    });
  }
  return { getLeft:()=>left||raw[0], getRight:()=>right||raw[1]||raw[0] };
}
