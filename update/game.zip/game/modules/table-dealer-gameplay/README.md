Phase G module: dealer/table demo controls and visible cards/chips.
