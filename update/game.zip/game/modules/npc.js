
export function initNPC(){
 console.log("NPC Eric seated at table")
}
