Phase I release-lock scaffold for deploy-safe business build.
