# Phase K — Enter VR Button Lock

This phase restores the Meta Quest/WebXR launch path.

## Required runtime items
- `renderer.xr.enabled = true`
- `VRButton.createButton(renderer)`
- `renderer.setAnimationLoop(render)`
- controller select handlers

## Quest test
Open the deployed `/game/` page in the Meta browser. The `ENTER VR` button should appear.
