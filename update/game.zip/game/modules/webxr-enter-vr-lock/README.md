WebXR Enter VR remains enabled with VRButton and renderer.setAnimationLoop.
