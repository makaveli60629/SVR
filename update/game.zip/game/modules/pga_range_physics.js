import * as THREE from "three";

const TMP_A = new THREE.Vector3();
const TMP_B = new THREE.Vector3();
const TMP_C = new THREE.Vector3();
const TMP_Q = new THREE.Quaternion();

function makeClubVisual(){
  const group = new THREE.Group();
  group.name = "phase4-controller-golf-club";
  group.visible = false;
  const shaftMat = new THREE.MeshStandardMaterial({
    color: 0xdaf2ff,
    roughness: 0.22,
    metalness: 0.65,
    emissive: 0x6ee7ff,
    emissiveIntensity: 0.16
  });
  const gripMat = new THREE.MeshStandardMaterial({
    color: 0x161616,
    roughness: 0.72,
    metalness: 0.05
  });
  const headMat = new THREE.MeshStandardMaterial({
    color: 0xf1f1f1,
    roughness: 0.24,
    metalness: 0.78,
    emissive: 0xbffaff,
    emissiveIntensity: 0.09
  });

  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.032, 0.28, 14), gripMat);
  grip.rotation.x = Math.PI * 0.5;
  grip.position.set(0, 0, -0.08);
  group.add(grip);

  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 1.05, 16), shaftMat);
  shaft.rotation.x = Math.PI * 0.5;
  shaft.position.set(0, -0.09, -0.62);
  group.add(shaft);

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.12, 0.16), headMat);
  head.name = "phase4-club-head";
  head.position.set(0.20, -0.18, -1.16);
  head.rotation.y = -0.12;
  group.add(head);

  const strike = new THREE.Mesh(
    new THREE.RingGeometry(0.12, 0.17, 32),
    new THREE.MeshBasicMaterial({ color: 0xa7ffd1, transparent: true, opacity: 0.55, depthWrite: false, side: THREE.DoubleSide })
  );
  strike.name = "phase4-club-strike-ring";
  strike.position.copy(head.position);
  strike.rotation.x = Math.PI * 0.5;
  group.add(strike);

  group.userData.head = head;
  return group;
}

function makeShotTrail(){
  const mat = new THREE.MeshBasicMaterial({ color: 0xa7ffd1, transparent: true, opacity: 0.0, depthWrite: false, side: THREE.DoubleSide });
  const mesh = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(0, 0.1, -0.4),
    new THREE.Vector3(0, 0.05, -0.8)
  ]), 18, 0.018, 6, false), mat);
  mesh.name = "phase4-golf-shot-trail";
  mesh.visible = false;
  return mesh;
}

function makePhase4Board(){
  const canvas = document.createElement("canvas");
  canvas.width = 1152;
  canvas.height = 640;
  const ctx = canvas.getContext("2d");
  const g = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
  g.addColorStop(0, "#041208");
  g.addColorStop(1, "#082c13");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = "rgba(167,255,209,.92)";
  ctx.lineWidth = 14;
  ctx.strokeRect(28, 28, canvas.width - 56, canvas.height - 56);
  ctx.textAlign = "center";
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 70px system-ui, Arial";
  ctx.fillText("PGA RANGE PHYSICS", canvas.width / 2, 118);
  ctx.fillStyle = "#a7ffd1";
  ctx.font = "bold 38px system-ui, Arial";
  ctx.fillText("Controller = club • Hit ball • Drive • Chip • Putt", canvas.width / 2, 190);
  ctx.fillStyle = "#eafff4";
  ctx.font = "32px system-ui, Arial";
  ctx.fillText("Quest: swing either controller through the ball", canvas.width / 2, 290);
  ctx.fillText("Desktop test: K = demo shot • X = reset ball", canvas.width / 2, 348);
  ctx.fillText("Targets detect drive lane, chip ring, and putting cup", canvas.width / 2, 406);
  ctx.fillStyle = "#fff1b8";
  ctx.font = "bold 34px system-ui, Arial";
  ctx.fillText("Phase 4 playable scaffold — ready for tuning", canvas.width / 2, 500);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  const board = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 2.0), new THREE.MeshBasicMaterial({ map: tex, transparent: true, side: THREE.DoubleSide, depthWrite: false }));
  board.name = "phase4-pga-range-physics-board";
  board.position.set(0, 2.55, -0.95);
  return board;
}

function isVectorFinite(v){
  return Number.isFinite(v.x) && Number.isFinite(v.y) && Number.isFinite(v.z);
}

export function createPgaRangePhysics({ scene, camera, renderer, log = console.log } = {}){
  const state = {
    ready: false,
    enabled: true,
    pga: null,
    root: null,
    ball: null,
    rangeRoot: null,
    rest: new THREE.Vector3(-0.45, 0.39, 1.40),
    velocity: new THREE.Vector3(),
    club: null,
    trail: null,
    lastHeadLocal: null,
    lastHeadWorld: null,
    cooldown: 0,
    hits: 0,
    lastShot: "Ready",
    lastSpeed: 0,
    inRange: false,
    lastStatusAt: 0
  };

  function findData(){
    const root = scene?.userData?._privateScenes?.pga?.root || null;
    const pga = root?.userData?.phase2?.pga || null;
    const ball = pga?.movingBall || null;
    if (!root || !pga || !ball) return false;
    state.root = root;
    state.pga = pga;
    state.ball = ball;
    state.rangeRoot = ball.parent || root;
    if (!state.ready){
      pga.phase4Physics = true;
      if (pga.ghostClub) pga.ghostClub.visible = false;
      state.rest.copy(ball.position);
      ball.position.copy(state.rest);
      ball.userData.phase4GolfBall = true;
      state.velocity.set(0, 0, 0);
      state.club = makeClubVisual();
      scene.add(state.club);
      state.trail = makeShotTrail();
      state.rangeRoot.add(state.trail);
      const board = makePhase4Board();
      root.add(board);
      const teeGlow = new THREE.Mesh(
        new THREE.RingGeometry(0.22, 0.31, 40),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.45, depthWrite: false, side: THREE.DoubleSide })
      );
      teeGlow.name = "phase4-tee-reset-ring";
      teeGlow.rotation.x = -Math.PI * 0.5;
      teeGlow.position.copy(state.rest).setY(0.232);
      state.rangeRoot.add(teeGlow);
      root.userData.phase4 = root.userData.phase4 || {};
      root.userData.phase4.pgaPhysics = state;
      scene.userData.SVR_PHASE4_PGA_RANGE_PHYSICS_READY = true;
      state.ready = true;
      log?.("[PHASE 4] PGA range physics initialized");
    }
    return true;
  }

  function getHeadWorld(){
    const camObj = scene?.userData?._camera || camera;
    camObj?.getWorldPosition?.(TMP_A);
    state.inRange = !!(state.root && TMP_A.distanceTo(state.root.getWorldPosition(TMP_B)) < 9.0);
    const right = arguments[0]?.rightController || null;
    const left = arguments[0]?.leftController || null;
    const controller = right || left;
    if (!controller) return null;
    controller.getWorldPosition(TMP_A);
    controller.getWorldQuaternion(TMP_Q);
    // Approximate club head offset from the controller grip.
    TMP_C.set(0.20, -0.18, -1.16).applyQuaternion(TMP_Q).add(TMP_A);
    return TMP_C.clone();
  }

  function resetBall(){
    if (!findData()) return;
    state.ball.position.copy(state.rest);
    state.velocity.set(0, 0, 0);
    state.ball.visible = true;
    state.lastShot = "Ball reset";
    if (state.trail){ state.trail.visible = false; state.trail.material.opacity = 0; }
  }

  function setShot(dirLocal, power = 3.0, loft = 0.34, label = "Shot"){
    if (!findData()) return;
    const d = dirLocal.clone();
    if (d.lengthSq() < 0.0001 || !isVectorFinite(d)) d.set(0, 0, -1);
    d.normalize();
    // Bias all shots downrange so side/back swings cannot launch into the player.
    d.z = Math.min(d.z, -0.45);
    d.normalize();
    const p = THREE.MathUtils.clamp(power, 1.0, 7.0);
    state.velocity.set(d.x * p, loft * p, d.z * p);
    state.cooldown = 0.45;
    state.hits += 1;
    state.lastShot = label;
    state.lastSpeed = p;
    if (state.trail){
      state.trail.visible = true;
      state.trail.position.copy(state.ball.position);
      state.trail.rotation.y = Math.atan2(d.x, d.z);
      state.trail.material.opacity = 0.50;
    }
  }

  function demoDrive(){
    setShot(new THREE.Vector3(0.05, 0, -1), 5.2, 0.42, "Demo drive");
  }

  function demoChip(){
    setShot(new THREE.Vector3(0.45, 0, -1), 3.3, 0.58, "Demo chip");
  }

  function demoPutt(){
    setShot(new THREE.Vector3(-0.88, 0, -0.48), 1.4, 0.04, "Demo putt");
  }

  let keysBound = false;
  function bindKeys(){
    if (keysBound) return;
    keysBound = true;
    window.addEventListener("keydown", (e)=>{
      if (e.repeat) return;
      if (e.code === "KeyK") demoDrive();
      if (e.code === "KeyX") resetBall();
      if (e.code === "KeyY") demoChip();
      if (e.code === "KeyM") demoPutt();
    });
  }
  bindKeys();

  function updateBall(dt){
    const ball = state.ball;
    if (!ball) return;
    if (state.velocity.lengthSq() > 0.00001){
      ball.position.addScaledVector(state.velocity, dt);
      state.velocity.y -= 3.2 * dt;
      const groundY = state.rest.y;
      if (ball.position.y <= groundY){
        ball.position.y = groundY;
        if (state.velocity.y < 0) state.velocity.y *= -0.18;
        state.velocity.x *= Math.exp(-2.2 * dt);
        state.velocity.z *= Math.exp(-2.2 * dt);
      } else {
        state.velocity.x *= Math.exp(-0.34 * dt);
        state.velocity.z *= Math.exp(-0.34 * dt);
      }
      ball.rotation.x += -state.velocity.z * dt * 8;
      ball.rotation.z += state.velocity.x * dt * 8;
      if (Math.abs(state.velocity.x) + Math.abs(state.velocity.y) + Math.abs(state.velocity.z) < 0.08){
        state.velocity.set(0,0,0);
      }
    }
    if (ball.position.z < -3.7 || Math.abs(ball.position.x) > 2.65){
      state.lastShot = "Out of range — reset";
      resetBall();
    }
    // Putting cup detection from phase 2 scaffold.
    const cup = new THREE.Vector3(-1.82, state.rest.y, -0.38);
    const planar = Math.hypot(ball.position.x - cup.x, ball.position.z - cup.z);
    if (planar < 0.20 && state.velocity.length() < 0.55){
      ball.position.copy(cup);
      state.velocity.set(0,0,0);
      state.lastShot = "Putt holed";
    }
  }

  function updateClubVisual(headWorld, controller){
    if (!state.club) return;
    if (!headWorld || !controller || !state.inRange){
      state.club.visible = false;
      return;
    }
    state.club.visible = true;
    controller.getWorldPosition(state.club.position);
    controller.getWorldQuaternion(state.club.quaternion);
  }

  function update(dt = 0.016, { leftController = null, rightController = null, statusCb = null } = {}){
    if (!findData()) return;
    state.cooldown = Math.max(0, state.cooldown - dt);
    const controller = rightController || leftController || null;
    const headWorld = getHeadWorld({ leftController, rightController });
    updateClubVisual(headWorld, controller);

    if (headWorld){
      const headLocal = state.rangeRoot.worldToLocal(headWorld.clone());
      const prev = state.lastHeadLocal;
      if (prev){
        const move = headLocal.clone().sub(prev);
        const speed = move.length() / Math.max(dt, 0.001);
        const dist = headLocal.distanceTo(state.ball.position);
        if (state.inRange && state.cooldown <= 0 && dist < 0.34 && speed > 1.35){
          const dir = move.clone().normalize();
          const power = THREE.MathUtils.clamp(speed * 0.64, 1.25, 6.2);
          const loft = power > 3.8 ? 0.40 : power > 2.2 ? 0.26 : 0.06;
          setShot(dir, power, loft, power > 3.8 ? "Controller drive" : power > 2.2 ? "Controller chip" : "Controller putt");
        }
      }
      state.lastHeadLocal = headLocal;
      state.lastHeadWorld = headWorld.clone();
    }

    updateBall(dt);
    if (state.trail?.visible){
      state.trail.material.opacity = Math.max(0, state.trail.material.opacity - dt * 0.75);
      if (state.trail.material.opacity <= 0.02) state.trail.visible = false;
    }

    const now = performance.now();
    if (state.inRange && statusCb && now - state.lastStatusAt > 900){
      state.lastStatusAt = now;
      statusCb(`PGA Range: ${state.lastShot} • hits ${state.hits} • K drive / X reset`);
    }
  }

  function getState(){
    return {
      ready: state.ready,
      hits: state.hits,
      lastShot: state.lastShot,
      lastSpeed: state.lastSpeed,
      inRange: state.inRange
    };
  }

  window.SVR_PGA_RANGE_PHASE4 = { resetBall, demoDrive, demoChip, demoPutt, getState };
  return { update, resetBall, demoDrive, demoChip, demoPutt, getState };
}
