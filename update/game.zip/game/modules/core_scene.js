import * as THREE from "three";
import { VRButton } from "three/addons/webxr/VRButton.js";
import { CONFIG } from "./config.js";

export function createCore({ containerId="app", spectatorCanvasId="spectatorCanvas" } = {}) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x030309);
  scene.fog = new THREE.FogExp2(0x05050c, 0.0075);

  const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.03, 1200);
  camera.position.set(CONFIG.SPAWN.x, CONFIG.SPAWN.y, CONFIG.SPAWN.z);
  camera.rotation.order = "YXZ";
  camera.rotation.y = CONFIG.SPAWN.yaw;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.15));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.xr.enabled = true;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.9;
  renderer.shadowMap.enabled = false;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  document.getElementById(containerId).appendChild(renderer.domElement);

  const vrButton = VRButton.createButton(renderer, {
    requiredFeatures: ["local-floor"],
    optionalFeatures: ["bounded-floor", "hand-tracking"]
  });
  (document.getElementById("vrButtonSlot") || document.body).appendChild(vrButton);

  const spectatorCanvas = document.getElementById(spectatorCanvasId);
  const spectatorRenderer = new THREE.WebGLRenderer({ canvas: spectatorCanvas, antialias: true, alpha: false, powerPreference: "high-performance" });
  spectatorRenderer.setPixelRatio(1);
  spectatorRenderer.setSize(spectatorCanvas.clientWidth || 320, spectatorCanvas.clientHeight || 180, false);
  spectatorRenderer.outputColorSpace = THREE.SRGBColorSpace;
  spectatorRenderer.toneMapping = THREE.ACESFilmicToneMapping;
  spectatorRenderer.toneMappingExposure = 0.9;

  const spectatorCamera = new THREE.PerspectiveCamera(52, (spectatorCanvas.clientWidth || 320) / (spectatorCanvas.clientHeight || 180), 0.1, 1200);
  spectatorCamera.position.set(4.8, 3.2, 5.6);

  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    const w = spectatorCanvas.clientWidth || 320;
    const h = spectatorCanvas.clientHeight || 180;
    spectatorCamera.aspect = w / h;
    spectatorCamera.updateProjectionMatrix();
    spectatorRenderer.setSize(w, h, false);
  });

  const hemi = new THREE.HemisphereLight(0xe7e4ff, 0x06060d, 0.72);
  scene.add(hemi);

  const key = new THREE.DirectionalLight(0xf7f6ff, 1.2);
  key.position.set(8, 16, 9);
  key.castShadow = false;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 0.1;
  key.shadow.camera.far = 48;
  key.shadow.camera.left = -14;
  key.shadow.camera.right = 14;
  key.shadow.camera.top = 14;
  key.shadow.camera.bottom = -14;
  scene.add(key);

  const tableLight = new THREE.PointLight(0xfff4de, 0.28, 24, 2);
  tableLight.position.set(0, 3.2, 0.2);
  scene.add(tableLight);

  const accentLight = new THREE.PointLight(0x6cc1ff, 0.12, 34, 2);
  accentLight.position.set(-8, 5, -12);
  scene.add(accentLight);

  const carpetLight = new THREE.PointLight(0x7c1127, 0.08, 20, 2);
  carpetLight.position.set(0, 2.6, 5.8);
  scene.add(carpetLight);

  return { scene, camera, renderer, spectatorCamera, spectatorRenderer };
}
