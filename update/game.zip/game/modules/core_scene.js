import * as THREE from "three";
import { VRButton } from "three/addons/webxr/VRButton.js";
import { CONFIG } from "./config.js";

export function createCore({ containerId = "app", spectatorCanvasId = "spectatorCanvas", previewOnly = false } = {}) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x030309);
  scene.fog = new THREE.FogExp2(0x05050c, 0.0065);

  const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.03, 1200);
  camera.position.set(CONFIG.SPAWN.x, CONFIG.SPAWN.y, CONFIG.SPAWN.z);
  camera.rotation.order = "YXZ";
  camera.rotation.y = CONFIG.SPAWN.yaw;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, previewOnly ? 1 : 1.1));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.xr.enabled = !previewOnly;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.9;
  renderer.shadowMap.enabled = false;
  document.getElementById(containerId).appendChild(renderer.domElement);

  if (!previewOnly) {
    const vrButton = VRButton.createButton(renderer, {
      requiredFeatures: ["local-floor"],
      optionalFeatures: ["bounded-floor", "hand-tracking"],
    });
    (document.getElementById("vrButtonSlot") || document.body).appendChild(vrButton);
  }

  const spectatorCanvas = document.getElementById(spectatorCanvasId);
  const spectatorRenderer = new THREE.WebGLRenderer({ canvas: spectatorCanvas, antialias: true, alpha: false, powerPreference: "high-performance" });
  spectatorRenderer.setPixelRatio(1);
  spectatorRenderer.setSize(spectatorCanvas.clientWidth || 320, spectatorCanvas.clientHeight || 180, false);
  spectatorRenderer.outputColorSpace = THREE.SRGBColorSpace;
  spectatorRenderer.toneMapping = THREE.ACESFilmicToneMapping;
  spectatorRenderer.toneMappingExposure = 0.95;

  const spectatorCamera = new THREE.PerspectiveCamera(52, (spectatorCanvas.clientWidth || 320) / (spectatorCanvas.clientHeight || 180), 0.1, 1200);
  spectatorCamera.position.set(4.8, 3.2, 5.6);

  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    const w = spectatorCanvas.clientWidth || 320;
    const h = spectatorCanvas.clientHeight || 180;
    spectatorCamera.aspect = w / h;
    spectatorCamera.updateProjectionMatrix();
    spectatorRenderer.setSize(w, h, false);
  });

  scene.add(new THREE.HemisphereLight(0xe7e4ff, 0x05060c, 0.68));

  const key = new THREE.DirectionalLight(0xf7f6ff, 1.02);
  key.position.set(8, 16, 9);
  scene.add(key);

  const tableLight = new THREE.PointLight(0xfff4de, 0.18, 18, 2);
  tableLight.position.set(0, 3.1, 0.1);
  scene.add(tableLight);

  const accentLight = new THREE.PointLight(0x6c7cff, 0.08, 30, 2);
  accentLight.position.set(-8, 4.5, -12);
  scene.add(accentLight);

  return { scene, camera, renderer, spectatorCamera, spectatorRenderer };
}
