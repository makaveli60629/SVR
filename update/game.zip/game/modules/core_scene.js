import * as THREE from "three";
import { VRButton } from "three/addons/webxr/VRButton.js";
import { CONFIG } from "./config.js";

export function createCore({ containerId="app", spectatorCanvasId="spectatorCanvas" } = {}) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x000000);
  scene.fog = new THREE.FogExp2(0x05030a, 0.018);

  const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.03, 1200);
  camera.position.set(CONFIG.SPAWN.x, CONFIG.SPAWN.y, CONFIG.SPAWN.z);
  camera.rotation.order = "YXZ";
  camera.rotation.y = CONFIG.SPAWN.yaw;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.xr.enabled = true;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  document.getElementById(containerId).appendChild(renderer.domElement);
  document.body.appendChild(VRButton.createButton(renderer, {
    requiredFeatures: ["local-floor"],
    optionalFeatures: ["bounded-floor", "hand-tracking"]
  }));

  const spectatorCanvas = document.getElementById(spectatorCanvasId);
  const spectatorRenderer = new THREE.WebGLRenderer({ canvas: spectatorCanvas, antialias: true, alpha: false, powerPreference: "high-performance" });
  spectatorRenderer.setPixelRatio(1);
  spectatorRenderer.setSize(spectatorCanvas.clientWidth || 320, spectatorCanvas.clientHeight || 180, false);
  spectatorRenderer.outputColorSpace = THREE.SRGBColorSpace;
  spectatorRenderer.toneMapping = THREE.ACESFilmicToneMapping;
  spectatorRenderer.toneMappingExposure = 1.0;

  const spectatorCamera = new THREE.PerspectiveCamera(58, (spectatorCanvas.clientWidth || 320) / (spectatorCanvas.clientHeight || 180), 0.1, 1200);
  spectatorCamera.position.set(6, 4, 6);

  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    const w = spectatorCanvas.clientWidth || 320;
    const h = spectatorCanvas.clientHeight || 180;
    spectatorCamera.aspect = w / h;
    spectatorCamera.updateProjectionMatrix();
    spectatorRenderer.setSize(w, h, false);
  });

  const hemi = new THREE.HemisphereLight(0xece8ff, 0x06070d, 1.15);
  scene.add(hemi);

  const key = new THREE.DirectionalLight(0xffffff, 2.4);
  key.position.set(10, 18, 8);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.near = 0.1;
  key.shadow.camera.far = 60;
  key.shadow.camera.left = -18;
  key.shadow.camera.right = 18;
  key.shadow.camera.top = 18;
  key.shadow.camera.bottom = -18;
  scene.add(key);

  const rim = new THREE.PointLight(0xb48cff, 3.8, 60, 2);
  rim.position.set(0, 6.5, 0);
  scene.add(rim);

  return { scene, camera, renderer, spectatorCamera, spectatorRenderer };
}
