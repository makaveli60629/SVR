export const PGA_HUB_CONFIG = Object.freeze({
  name: "Juan Espejo PGA Hub",
  wallZone: "south-east",
  anchorAngle: Math.PI * 0.25,
  portalHref: "./scorpion/",
  accent: 0xff4958
});
