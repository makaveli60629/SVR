import * as THREE from "three";

function makeCanvasTexture(painter, width = 1024, height = 1024){
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  painter(ctx, width, height);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}

function roundRect(ctx, x, y, w, h, r){
  const rr = Math.min(r, w * 0.5, h * 0.5);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function drawWrappedText(ctx, text, x, y, maxWidth, lineHeight, maxLines = 99){
  const words = String(text || "").split(/\s+/);
  let line = "";
  let yy = y;
  let lines = 0;
  for (const word of words){
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line){
      ctx.fillText(line, x, yy);
      line = word;
      yy += lineHeight;
      lines += 1;
      if (lines >= maxLines) break;
    } else {
      line = test;
    }
  }
  if (line && lines < maxLines) ctx.fillText(line, x, yy);
  return yy;
}

function panelMat(texture, opacity = 1, depthTest = false){
  return new THREE.MeshBasicMaterial({
    map: texture,
    transparent: true,
    opacity,
    side: THREE.DoubleSide,
    depthWrite: false,
    depthTest,
    toneMapped: false
  });
}

function emissiveMat(color, emissive = color, intensity = 0.35, roughness = 0.45, metalness = 0.12){
  return new THREE.MeshStandardMaterial({ color, roughness, metalness, emissive, emissiveIntensity: intensity });
}

function makeHubHeaderTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    const g = ctx.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, '#090205');
    g.addColorStop(0.35, '#2a0610');
    g.addColorStop(1, '#080204');
    ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#ff4458'; ctx.lineWidth = 18; roundRect(ctx, 28, 28, w-56, h-56, 34); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,230,235,0.95)'; ctx.lineWidth = 7; roundRect(ctx, 56, 56, w-112, h-112, 24); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff'; ctx.font = '900 118px Arial'; ctx.fillText('JUAN ESPEJO PGA HUB', w/2, 122);
    ctx.fillStyle = '#ffccd3'; ctx.font = '800 46px Arial'; ctx.fillText('GOLF LESSONS • TRAINING • ACADEMY • VR DRIVING RANGE', w/2, 218);
  }, 2200, 320);
}

function makeHubInfoTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    const grad = ctx.createLinearGradient(0,0,w,h);
    grad.addColorStop(0, '#060304'); grad.addColorStop(0.72, '#1a0509'); grad.addColorStop(1, '#050304');
    ctx.fillStyle = grad; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#ff4358'; ctx.lineWidth = 16; roundRect(ctx, 28, 28, w-56, h-56, 42); ctx.stroke();
    ctx.fillStyle = 'rgba(255,67,88,0.18)'; roundRect(ctx, 72, 70, w-144, 120, 24); ctx.fill();
    ctx.fillStyle = '#ff9aa6'; ctx.font = '900 44px Arial'; ctx.fillText('PGA PROFESSIONAL SPOTLIGHT', 100, 146);
    ctx.fillStyle = '#ffffff'; ctx.font = '900 76px Arial'; ctx.fillText('JUAN E. ESPEJO', 100, 270);
    ctx.fillStyle = '#ffd8dd'; ctx.font = '800 38px Arial'; ctx.fillText('Reserved professional golf training hub', 100, 330);
    ctx.fillStyle = '#ff7d8c'; ctx.font = '900 42px Arial'; ctx.fillText('FRONT HUB PURPOSE', 100, 435);
    ctx.fillStyle = '#f7f1f3'; ctx.font = '600 34px Arial';
    let y = drawWrappedText(ctx,
      'This lobby-facing PGA area stays visible as the public storefront: profile, lessons, sponsor placement, and entry to the full VR driving range room.',
      100, 495, w-200, 46, 6);
    y += 78;
    ctx.fillStyle = '#ff7d8c'; ctx.font = '900 40px Arial'; ctx.fillText('FEATURES', 100, y);
    y += 58;
    ctx.fillStyle = '#ffffff'; ctx.font = '700 35px Arial';
    ['• Private golf lessons', '• Swing fundamentals', '• Beginner training', '• Sponsor-ready ad wall', '• Teleport to PGA Driving Range room'].forEach(line=>{ ctx.fillText(line, 108, y); y += 52; });
    ctx.fillStyle = 'rgba(255,255,255,0.08)'; roundRect(ctx, 80, h-205, w-160, 126, 26); ctx.fill();
    ctx.strokeStyle = 'rgba(255,120,136,0.65)'; ctx.lineWidth = 5; roundRect(ctx, 80, h-205, w-160, 126, 26); ctx.stroke();
    ctx.fillStyle = '#ffffff'; ctx.font = '900 45px Arial'; ctx.fillText('ENTER RANGE FROM WATCH OR PGA RANGE BUTTON', 115, h-124);
  }, 1300, 1500);
}

function makePortraitCardTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    ctx.fillStyle = '#080304'; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#ff4358'; ctx.lineWidth = 18; roundRect(ctx, 26, 26, w-52, h-52, 42); ctx.stroke();
    ctx.fillStyle = 'rgba(255,67,88,0.18)'; roundRect(ctx, 70, 65, w-140, 105, 24); ctx.fill();
    ctx.textAlign = 'center'; ctx.fillStyle = '#ffccd3'; ctx.font = '900 40px Arial'; ctx.fillText('PROFILE IMAGE', w/2, 132);
    ctx.fillStyle = '#ffffff'; ctx.font = '900 54px Arial'; ctx.fillText('JUAN ESPEJO', w/2, h-150);
    ctx.fillStyle = '#ffd6dc'; ctx.font = '800 34px Arial'; ctx.fillText('PGA HUB LEAD', w/2, h-96);
  }, 900, 1300);
}

function makeRangePortalTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    const g = ctx.createRadialGradient(w/2,h/2,20,w/2,h/2,w/2);
    g.addColorStop(0, 'rgba(120,255,185,0.72)');
    g.addColorStop(0.54, 'rgba(18,110,52,0.58)');
    g.addColorStop(1, 'rgba(2,12,7,0.96)');
    ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#78ffb8'; ctx.lineWidth = 18; ctx.beginPath(); ctx.arc(w/2,h/2,w*0.42,0,Math.PI*2); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.72)'; ctx.lineWidth = 7; ctx.beginPath(); ctx.arc(w/2,h/2,w*0.29,0,Math.PI*2); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff'; ctx.font = '900 70px Arial'; ctx.fillText('PGA RANGE', w/2, h/2-25);
    ctx.fillStyle = '#d8ffe8'; ctx.font = '800 38px Arial'; ctx.fillText('ROOM PORTAL', w/2, h/2+60);
  }, 1024,1024);
}

function makeRangeHeaderTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    ctx.fillStyle = '#031006'; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#70ff9e'; ctx.lineWidth = 14; roundRect(ctx, 26, 26, w-52, h-52, 30); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff'; ctx.font = '900 108px Arial'; ctx.fillText('SVR PGA DRIVING RANGE', w/2, 130);
    ctx.fillStyle = '#bdffd3'; ctx.font = '800 46px Arial'; ctx.fillText('OWN ROOM SCENE • TEE BAY • DISTANCE TARGETS • SPONSOR BANNERS', w/2, 235);
  }, 2200, 330);
}


function makeGolfTutorialTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    const g = ctx.createLinearGradient(0,0,w,h);
    g.addColorStop(0, '#031509'); g.addColorStop(0.58, '#071016'); g.addColorStop(1, '#03050a');
    ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#82ffac'; ctx.lineWidth = 14; roundRect(ctx, 24, 24, w-48, h-48, 34); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.70)'; ctx.lineWidth = 4; roundRect(ctx, 54, 54, w-108, h-108, 22); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff'; ctx.font = '900 78px Arial'; ctx.fillText('QUICK GOLF TUTORIAL', w/2, 100);
    ctx.fillStyle = '#bfffd1'; ctx.font = '800 34px Arial'; ctx.fillText('Grab the club • square your stance • swing through the ball', w/2, 165);
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = '#ffffff'; ctx.font = '800 42px Arial';
    const lines = [
      '1. Stand on the blue foot markers, shoulders square to the lane.',
      '2. VR: hold right GRIP/SQUEEZE to grab the club handle.',
      '3. Keep your head steady and bring the club back slowly.',
      '4. Swing through the ball toward the green target lane.',
      '5. Release grip to drop the club. Press RESET BALL to tee it again.',
      'Desktop fallback: G = grab/drop, SPACE = hit, R = reset, H = hide help.'
    ];
    let y = 245;
    lines.forEach((line, i)=>{
      ctx.fillStyle = i === 5 ? '#bce8ff' : '#f4fff7';
      ctx.font = i === 5 ? '800 34px Arial' : '800 36px Arial';
      drawWrappedText(ctx, line, 78, y, w-156, 46, 2);
      y += i === 5 ? 62 : 76;
    });
    ctx.fillStyle = 'rgba(130,255,172,0.16)'; roundRect(ctx, 70, h-135, w-140, 78, 22); ctx.fill();
    ctx.fillStyle = '#ffffff'; ctx.font = '900 38px Arial'; ctx.textAlign = 'center';
    ctx.fillText('REAL-FEEL MODE: gravity, drag, lift assist, carry yards, club speed', w/2, h-86);
  }, 1500, 980);
}

function makeGolfScoreTexture(stats = {}){
  const carry = Number.isFinite(stats.carryYards) ? Math.round(stats.carryYards) : 0;
  const club = Number.isFinite(stats.clubSpeed) ? Math.round(stats.clubSpeed) : 0;
  const ball = Number.isFinite(stats.ballSpeed) ? Math.round(stats.ballSpeed) : 0;
  const launch = Number.isFinite(stats.launchDeg) ? Math.round(stats.launchDeg) : 0;
  const mode = stats.message || 'Ready: grab club and swing';
  return makeCanvasTexture((ctx,w,h)=>{
    ctx.fillStyle = '#041007'; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#70ff9e'; ctx.lineWidth = 10; roundRect(ctx,18,18,w-36,h-36,24); ctx.stroke();
    ctx.fillStyle = '#ffffff'; ctx.font = '900 52px Arial'; ctx.textAlign='center'; ctx.fillText('PGA RANGE SIM', w/2, 72);
    ctx.fillStyle = '#caffd9'; ctx.font = '800 27px Arial'; ctx.fillText(mode, w/2, 118);
    const labels = [['CARRY', carry + ' yd'], ['CLUB', club + ' mph'], ['BALL', ball + ' mph'], ['LAUNCH', launch + '°']];
    ctx.textAlign='left';
    labels.forEach((row, i)=>{
      const x = 58 + (i % 2) * 470;
      const y = 198 + Math.floor(i / 2) * 116;
      ctx.fillStyle = 'rgba(112,255,158,0.12)'; roundRect(ctx, x-18, y-66, 380, 86, 18); ctx.fill();
      ctx.fillStyle = '#aafcc3'; ctx.font = '900 28px Arial'; ctx.fillText(row[0], x, y-22);
      ctx.fillStyle = '#ffffff'; ctx.font = '900 52px Arial'; ctx.fillText(row[1], x+155, y-22);
    });
    ctx.textAlign='center'; ctx.fillStyle='#9bd4ff'; ctx.font='800 25px Arial';
    ctx.fillText('VR grip/squeeze = grab club  •  release = drop  •  H = help', w/2, h-42);
  }, 1000, 500);
}

function makePostureTexture(label = 'POSTURE READY'){
  return makeCanvasTexture((ctx,w,h)=>{
    ctx.fillStyle = '#050911'; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#7ad7ff'; ctx.lineWidth = 9; roundRect(ctx,18,18,w-36,h-36,22); ctx.stroke();
    ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillStyle='#ffffff'; ctx.font='900 54px Arial'; ctx.fillText(label, w/2, h/2-20);
    ctx.fillStyle='#b8e8ff'; ctx.font='800 27px Arial'; ctx.fillText('Feet on markers • head still • swing through target', w/2, h/2+44);
  }, 900, 300);
}

function makeFairwayMuralTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    const sky = ctx.createLinearGradient(0,0,0,h*0.55);
    sky.addColorStop(0,'#09203a'); sky.addColorStop(0.48,'#174b7c'); sky.addColorStop(1,'#c3ecff');
    ctx.fillStyle = sky; ctx.fillRect(0,0,w,h);
    ctx.fillStyle = '#183b2a';
    ctx.beginPath(); ctx.moveTo(0,h*0.62);
    for(let i=0;i<=18;i++) ctx.lineTo(i*w/18, h*0.57 + Math.sin(i*0.9)*34);
    ctx.lineTo(w,h); ctx.lineTo(0,h); ctx.closePath(); ctx.fill();
    const fw = ctx.createLinearGradient(0,h*0.62,0,h);
    fw.addColorStop(0,'#1fa45b'); fw.addColorStop(1,'#0d5129');
    ctx.fillStyle=fw; ctx.beginPath(); ctx.moveTo(w*0.42,h); ctx.quadraticCurveTo(w*0.48,h*0.72,w*0.50,h*0.58); ctx.quadraticCurveTo(w*0.58,h*0.74,w*0.67,h); ctx.closePath(); ctx.fill();
    for(let i=0;i<80;i++){
      const x=Math.random()*w, y=h*0.60+Math.random()*h*0.38;
      ctx.fillStyle=`rgba(${40+Math.random()*50|0},${120+Math.random()*100|0},${55+Math.random()*45|0},${0.18+Math.random()*0.22})`;
      ctx.fillRect(x,y,8+Math.random()*28,2+Math.random()*5);
    }
    ctx.fillStyle='rgba(255,255,255,0.75)';
    for(let i=0;i<8;i++){
      ctx.beginPath(); ctx.ellipse(120+i*240, 90+Math.sin(i)*28, 80, 18, Math.sin(i)*0.2, 0, Math.PI*2); ctx.fill();
    }
  }, 1800, 900);
}

function makeResetTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    ctx.fillStyle='#041007'; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle='#ffdf70'; ctx.lineWidth=10; roundRect(ctx,18,18,w-36,h-36,26); ctx.stroke();
    ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillStyle='#ffffff'; ctx.font='900 76px Arial'; ctx.fillText('RESET BALL', w/2, h/2-10);
    ctx.fillStyle='#ffefb5'; ctx.font='800 31px Arial'; ctx.fillText('R KEY OR WATCH/SCREEN BUTTON LATER', w/2, h/2+62);
  }, 800, 300);
}

function makeDistanceTexture(label){
  return makeCanvasTexture((ctx,w,h)=>{
    ctx.fillStyle = '#061008'; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#75ff9e'; ctx.lineWidth = 12; roundRect(ctx, 20,20,w-40,h-40,24); ctx.stroke();
    ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillStyle='#ffffff'; ctx.font='900 88px Arial'; ctx.fillText(label, w/2, h/2-8);
    ctx.fillStyle='#caffd9'; ctx.font='800 32px Arial'; ctx.fillText('TARGET', w/2, h/2+66);
  }, 700, 360);
}

function makeSponsorTexture(title, subtitle){
  return makeCanvasTexture((ctx,w,h)=>{
    const g = ctx.createLinearGradient(0,0,w,h);
    g.addColorStop(0, '#07070e'); g.addColorStop(1, '#11121a');
    ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle = '#7ad7ff'; ctx.lineWidth = 10; roundRect(ctx,18,18,w-36,h-36,24); ctx.stroke();
    ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillStyle='#ffffff'; ctx.font='900 62px Arial'; ctx.fillText(title, w/2, h/2-26);
    ctx.fillStyle='#b8e8ff'; ctx.font='800 30px Arial'; ctx.fillText(subtitle, w/2, h/2+42);
  }, 900, 360);
}

function loadPortraitTexture(){
  const loader = new THREE.TextureLoader();
  const tex = loader.load('./assets/ui/juan-espejo.jpg');
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

export function addPgaHub(scene, { radius = 26, wallHeight = 6.6, log = console.log } = {}){
  try {
    const anchorAngle = Math.PI * 0.75; // southwest wall; local front faces lobby center
    const inward = new THREE.Vector3(-Math.cos(anchorAngle), 0, -Math.sin(anchorAngle));
    const tangent = new THREE.Vector3(-Math.sin(anchorAngle), 0, Math.cos(anchorAngle));
    const wallInset = radius - 0.18;

    const group = new THREE.Group();
    group.name = 'PGA_FRONT_HUB_LOCKED_VISIBLE';
    group.position.set(Math.cos(anchorAngle) * wallInset, 0, Math.sin(anchorAngle) * wallInset);
    group.position.addScaledVector(tangent, -0.18);
    group.lookAt(group.position.clone().add(inward));

    const wallMat = emissiveMat(0x060407, 0x1d0710, 0.22, 0.72, 0.06);
    const redMat = emissiveMat(0xff4058, 0x74101b, 0.80, 0.22, 0.35);
    const greenMat = emissiveMat(0x17823c, 0x0b3f1d, 0.24, 0.84, 0.0);
    const ropeMat = emissiveMat(0x7e1722, 0x3d0910, 0.2, 0.75, 0.05);

    const backWall = new THREE.Mesh(new THREE.BoxGeometry(14.4, 6.95, 0.14), wallMat);
    backWall.position.set(0, 3.42, 0.06);
    backWall.renderOrder = 1;
    group.add(backWall);

    const glow = new THREE.Mesh(new THREE.PlaneGeometry(14.1, 6.65), new THREE.MeshBasicMaterial({ color: 0xff304a, transparent: true, opacity: 0.045, side: THREE.DoubleSide, depthWrite: false, depthTest: false }));
    glow.position.set(0, 3.42, -0.42); glow.renderOrder = 20; group.add(glow);

    const frameY = 3.42;
    const leftPost = new THREE.Mesh(new THREE.BoxGeometry(0.20, 6.78, 0.18), redMat); leftPost.position.set(-6.95, frameY, -0.52); group.add(leftPost);
    const rightPost = leftPost.clone(); rightPost.position.x = 6.95; group.add(rightPost);
    const topRail = new THREE.Mesh(new THREE.BoxGeometry(14.05, 0.20, 0.18), redMat); topRail.position.set(0, 6.78, -0.52); group.add(topRail);
    const bottomRail = topRail.clone(); bottomRail.position.y = 0.16; group.add(bottomRail);

    const header = new THREE.Mesh(new THREE.PlaneGeometry(12.7, 1.02), panelMat(makeHubHeaderTexture(), 1, false));
    header.position.set(0, 6.05, -0.68); header.renderOrder = 50; group.add(header);

    const info = new THREE.Mesh(new THREE.PlaneGeometry(6.25, 4.62), panelMat(makeHubInfoTexture(), 1, false));
    info.position.set(-3.35, 3.36, -0.70); info.renderOrder = 51; group.add(info);

    const portraitBack = new THREE.Mesh(new THREE.PlaneGeometry(3.75, 4.64), panelMat(makePortraitCardTexture(), 1, false));
    portraitBack.position.set(3.45, 3.36, -0.705); portraitBack.renderOrder = 51; group.add(portraitBack);

    const portrait = new THREE.Mesh(new THREE.PlaneGeometry(2.75, 2.75), panelMat(loadPortraitTexture(), 1, false));
    portrait.position.set(3.45, 3.78, -0.735); portrait.renderOrder = 56; group.add(portrait);

    const portraitFrame = new THREE.Mesh(new THREE.RingGeometry(1.49, 1.58, 64), new THREE.MeshBasicMaterial({ color: 0xff6070, transparent: true, opacity: 0.92, side: THREE.DoubleSide, depthWrite: false, depthTest: false }));
    portraitFrame.position.set(3.45, 3.78, -0.745); portraitFrame.renderOrder = 57; group.add(portraitFrame);

    const deck = new THREE.Mesh(new THREE.BoxGeometry(12.7, 0.07, 2.10), emissiveMat(0x17070c, 0x25080e, 0.10, 0.84, 0.05));
    deck.position.set(0, 0.04, -1.04); group.add(deck);
    const green = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.035, 1.24), greenMat); green.position.set(0, 0.105, -1.08); group.add(green);

    const portalPad = new THREE.Mesh(new THREE.CircleGeometry(0.92, 64), panelMat(makeRangePortalTexture(), 0.94, false));
    portalPad.rotation.x = -Math.PI * 0.5; portalPad.position.set(0, 0.14, -1.08); portalPad.renderOrder = 58; group.add(portalPad);

    // Small stanchions mark this as the front entry, not the range room itself.
    const postXs = [-3.3, 3.3]; const postZs = [-0.22, -1.92];
    postXs.forEach(x => postZs.forEach(z => {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.78, 14), redMat); post.position.set(x, 0.39, z); group.add(post);
      const cap = new THREE.Mesh(new THREE.SphereGeometry(0.07, 14, 12), redMat); cap.position.set(x, 0.80, z); group.add(cap);
    }));
    postXs.forEach(x => { const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, Math.abs(postZs[0]-postZs[1]), 10), ropeMat); rope.rotation.x = Math.PI*0.5; rope.position.set(x,0.74,(postZs[0]+postZs[1])*0.5); group.add(rope); });

    const fillA = new THREE.PointLight(0xff4058, 2.8, 13, 2.0); fillA.position.set(-2.8, 4.8, -1.15); group.add(fillA);
    const fillB = new THREE.PointLight(0xffd2d8, 1.8, 12, 2.0); fillB.position.set(3.4, 4.7, -1.10); group.add(fillB);
    const fillC = new THREE.PointLight(0x70ff9e, 1.35, 8, 2.0); fillC.position.set(0, 0.85, -1.4); group.add(fillC);

    scene.add(group);
    const box = new THREE.Box3().setFromObject(group); group.position.y -= box.min.y;
    group.updateWorldMatrix(true, true);

    const hubTarget = group.localToWorld(new THREE.Vector3(0, 0, -4.2));
    const hubLook = group.localToWorld(new THREE.Vector3(0, 2.25, -0.72));
    const rangePortalTarget = group.localToWorld(new THREE.Vector3(0, 0, -2.0));

    scene.userData._pgaHub = { group, header, portraitFrame, portalPad, fillA, fillB, fillC, inward, anchorAngle, hubTarget, hubLook, rangePortalTarget };
    return scene.userData._pgaHub;
  } catch (err) {
    log('[pga_hub] failed to build', err?.message || err);
    return null;
  }
}

function addWall(group, width, height, depth, x, y, z, mat){
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), mat);
  mesh.position.set(x,y,z);
  group.add(mesh);
  return mesh;
}

function addTargetRing(group, x, z, r, color, label){
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.35, metalness: 0.10, emissive: color, emissiveIntensity: 0.42 });
  const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.035, 10, 96), mat);
  ring.rotation.x = Math.PI * 0.5;
  ring.position.set(x, 0.09, z);
  group.add(ring);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.85, 0.74), panelMat(makeDistanceTexture(label), 1, false));
  sign.position.set(x, 1.05, z - r - 0.35);
  sign.renderOrder = 40;
  group.add(sign);
  return ring;
}

export function addPgaDrivingRangeRoom(scene, { log = console.log } = {}){
  try {
    const group = new THREE.Group();
    group.name = 'PGA_DRIVING_RANGE_PRIVATE_ROOM_SCENE';
    // Private scene room: parked far outside the lobby and hidden until the player chooses PGA Range.
    // This keeps the driving range out of the visible lobby while preserving a fast same-scene teleport.
    group.position.set(0, 0, -220);
    group.rotation.y = 0;
    group.visible = false;

    const wallMat = emissiveMat(0x07100b, 0x06190d, 0.25, 0.72, 0.04);
    const turfMat = emissiveMat(0x176e35, 0x092e18, 0.18, 0.92, 0.0);
    const laneMat = emissiveMat(0x2fa54e, 0x0e431d, 0.12, 0.96, 0.0);
    const trimMat = emissiveMat(0x7aff9f, 0x135f2c, 0.55, 0.35, 0.18);
    const darkMat = emissiveMat(0x06080a, 0x080c11, 0.12, 0.78, 0.04);

    addWall(group, 15.8, 0.08, 27.5, 0, 0.04, -4.4, turfMat);
    addWall(group, 4.2, 0.10, 2.2, 0, 0.11, 7.15, darkMat);
    addWall(group, 2.8, 0.08, 25.8, 0, 0.145, -4.9, laneMat);
    addWall(group, 16.1, 4.2, 0.18, 0, 2.1, -18.2, wallMat);
    addWall(group, 0.18, 4.2, 27.6, -8.05, 2.1, -4.4, wallMat);
    addWall(group, 0.18, 4.2, 27.6, 8.05, 2.1, -4.4, wallMat);
    addWall(group, 16.1, 0.18, 27.6, 0, 4.2, -4.4, new THREE.MeshStandardMaterial({ color: 0x0a1010, roughness: 0.88, metalness: 0.03, transparent: true, opacity: 0.36, emissive: 0x051414, emissiveIntensity: 0.10 }));

    const fairwayMural = new THREE.Mesh(new THREE.PlaneGeometry(15.55, 7.2), panelMat(makeFairwayMuralTexture(), 1, false));
    fairwayMural.position.set(0, 2.55, -18.08);
    fairwayMural.renderOrder = 36;
    group.add(fairwayMural);

    const header = new THREE.Mesh(new THREE.PlaneGeometry(11.8, 1.22), panelMat(makeRangeHeaderTexture(), 1, false));
    header.position.set(0, 3.65, -17.98); header.renderOrder = 45; group.add(header);

    const tutorial = new THREE.Mesh(new THREE.PlaneGeometry(5.35, 3.50), panelMat(makeGolfTutorialTexture(), 0.97, false));
    tutorial.position.set(-5.05, 2.15, 6.38);
    tutorial.rotation.y = Math.PI * 0.09;
    tutorial.renderOrder = 65;
    group.add(tutorial);

    const scoreboard = new THREE.Mesh(new THREE.PlaneGeometry(5.15, 2.58), panelMat(makeGolfScoreTexture(), 1, false));
    scoreboard.position.set(4.95, 2.55, 6.42);
    scoreboard.rotation.y = -Math.PI * 0.10;
    scoreboard.renderOrder = 66;
    group.add(scoreboard);

    const posturePanel = new THREE.Mesh(new THREE.PlaneGeometry(4.1, 1.38), panelMat(makePostureTexture('POSTURE READY'), 1, false));
    posturePanel.position.set(0, 1.75, 7.62);
    posturePanel.rotation.y = Math.PI;
    posturePanel.renderOrder = 67;
    group.add(posturePanel);

    const resetPad = new THREE.Mesh(new THREE.PlaneGeometry(1.65, 0.62), panelMat(makeResetTexture(), 1, false));
    resetPad.position.set(2.35, 0.62, 6.65);
    resetPad.rotation.x = -Math.PI * 0.18;
    resetPad.renderOrder = 70;
    group.add(resetPad);

    const exitSign = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 1.05), panelMat(makeSponsorTexture('EXIT TO LOBBY', 'USE WATCH PGA OR LOBBY BUTTON'), 1, false));
    exitSign.position.set(0, 2.55, 7.74);
    exitSign.rotation.y = Math.PI;
    exitSign.renderOrder = 46;
    group.add(exitSign);

    // Tee station
    const teeMat = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.12, 2.25), emissiveMat(0x101314, 0x040707, 0.14, 0.62, 0.08));
    teeMat.position.set(0, 0.20, 6.65); group.add(teeMat);
    const teeGreen = new THREE.Mesh(new THREE.BoxGeometry(2.22, 0.05, 1.34), laneMat); teeGreen.position.set(0, 0.295, 6.52); group.add(teeGreen);
    const footMat = new THREE.MeshStandardMaterial({ color: 0x64c8ff, roughness: 0.36, metalness: 0.08, emissive: 0x134a75, emissiveIntensity: 0.45, transparent: true, opacity: 0.88 });
    [-0.48, 0.48].forEach((x)=>{
      const foot = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.032, 0.84), footMat);
      foot.position.set(x, 0.345, 6.84);
      foot.rotation.y = x < 0 ? -0.08 : 0.08;
      foot.name = x < 0 ? 'left-foot-marker' : 'right-foot-marker';
      group.add(foot);
    });
    const shoulderLine = new THREE.Mesh(new THREE.BoxGeometry(1.72, 0.025, 0.05), new THREE.MeshStandardMaterial({ color: 0x88ddff, roughness: 0.35, metalness: 0.08, emissive: 0x114a75, emissiveIntensity: 0.28 }));
    shoulderLine.position.set(0, 0.38, 6.30);
    group.add(shoulderLine);
    const swingPath = new THREE.Mesh(new THREE.TorusGeometry(0.92, 0.018, 8, 96, Math.PI * 1.15), new THREE.MeshBasicMaterial({ color: 0xfff1a0, transparent: true, opacity: 0.56, depthWrite: false }));
    swingPath.position.set(0, 0.52, 5.92);
    swingPath.rotation.set(Math.PI * 0.52, 0, Math.PI * 0.92);
    group.add(swingPath);
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.09, 24, 16), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.62, metalness: 0.0 })); ball.position.set(0, 0.405, 5.88); group.add(ball);
    const tee = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.038, 0.16, 12), new THREE.MeshStandardMaterial({ color: 0xf4f0df, roughness: 0.62 })); tee.position.set(0, 0.34, 5.88); group.add(tee);

    // Interactive club rig. It starts on the rack and can be attached to the right controller/hand.
    const clubRig = new THREE.Group();
    clubRig.name = 'PGA_INTERACTIVE_CLUB_RIG';
    clubRig.position.set(-1.55, 0.88, 6.28);
    clubRig.rotation.set(0.18, 0.0, -0.62);
    const club = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 1.55, 12), new THREE.MeshStandardMaterial({ color: 0xcbd0d8, roughness: 0.30, metalness: 0.62 }));
    club.position.set(0, -0.28, 0);
    clubRig.add(club);
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.36, 14), new THREE.MeshStandardMaterial({ color: 0x0b0c0e, roughness: 0.62, metalness: 0.18 }));
    grip.position.set(0, 0.48, 0);
    clubRig.add(grip);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.10, 0.46), new THREE.MeshStandardMaterial({ color: 0x111417, roughness: 0.42, metalness: 0.35 }));
    head.position.set(0, -1.12, -0.12);
    clubRig.add(head);
    const sweetSpot = new THREE.Mesh(new THREE.SphereGeometry(0.045, 14, 10), new THREE.MeshBasicMaterial({ color: 0xfff2a0, transparent: true, opacity: 0.82, depthWrite: false }));
    sweetSpot.position.set(0, -1.12, -0.37);
    clubRig.add(sweetSpot);
    group.add(clubRig);

    const rings = [
      addTargetRing(group, 0, -3.0, 1.05, 0x7aff9f, '75 YD'),
      addTargetRing(group, -3.2, -8.7, 1.25, 0xffd563, '125 YD'),
      addTargetRing(group, 3.1, -12.8, 1.45, 0xff6576, '175 YD')
    ];

    const sponsorLeft = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 1.28), panelMat(makeSponsorTexture('SVRPOKER.COM', 'GOLF SPONSOR BAY'), 1, false));
    sponsorLeft.position.set(-7.94, 2.48, -6.0); sponsorLeft.rotation.y = Math.PI * 0.5; sponsorLeft.renderOrder = 42; group.add(sponsorLeft);
    const sponsorRight = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 1.28), panelMat(makeSponsorTexture('PGA LESSONS', 'BOOKING READY PANEL'), 1, false));
    sponsorRight.position.set(7.94, 2.48, -10.8); sponsorRight.rotation.y = -Math.PI * 0.5; sponsorRight.renderOrder = 42; group.add(sponsorRight);

    // Side trim lines
    [-7.8, 7.8].forEach(x => {
      const trim = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.10, 26.9), trimMat);
      trim.position.set(x, 0.18, -4.4); group.add(trim);
    });
    [-1.45, 1.45].forEach(x => {
      const line = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.08, 23.5), new THREE.MeshStandardMaterial({ color: 0xdcffe6, roughness: 0.75, metalness: 0.0, emissive: 0x2bcf62, emissiveIntensity: 0.18 }));
      line.position.set(x, 0.20, -5.15); group.add(line);
    });

    const lightA = new THREE.PointLight(0x92ffb4, 2.6, 16, 2.0); lightA.position.set(0, 3.2, 4.8); group.add(lightA);
    const lightB = new THREE.PointLight(0xc4ffd3, 2.2, 18, 2.0); lightB.position.set(0, 3.7, -8.5); group.add(lightB);
    const lightC = new THREE.PointLight(0x75a6ff, 1.0, 14, 2.0); lightC.position.set(-4.8, 2.8, -12.0); group.add(lightC);

    scene.add(group);
    group.updateWorldMatrix(true, true);
    const target = group.localToWorld(new THREE.Vector3(0, 0, 7.2));
    const look = group.localToWorld(new THREE.Vector3(0, 1.45, -4.8));
    const roomCenter = group.localToWorld(new THREE.Vector3(0, 0, -4.2));
    const boundCorners = [
      new THREE.Vector3(-7.65, 0, 7.40),
      new THREE.Vector3( 7.65, 0, 7.40),
      new THREE.Vector3(-7.65, 0, -17.75),
      new THREE.Vector3( 7.65, 0, -17.75)
    ].map(v => group.localToWorld(v));
    const bounds = boundCorners.reduce((acc, v)=>({
      minX: Math.min(acc.minX, v.x),
      maxX: Math.max(acc.maxX, v.x),
      minZ: Math.min(acc.minZ, v.z),
      maxZ: Math.max(acc.maxZ, v.z)
    }), { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity });
    scene.userData._pgaRangeRoom = {
      group, target, look, roomCenter, bounds, rings, lightA, lightB, lightC, header,
      tutorial, scoreboard, posturePanel, resetPad, ball, tee, clubRig, clubHead: head, sweetSpot,
      privateRoom: true, golfReady: true, simStats: { message: 'Ready: grab club and swing', carryYards: 0, clubSpeed: 0, ballSpeed: 0, launchDeg: 14 }
    };
    return scene.userData._pgaRangeRoom;
  } catch (err) {
    log('[pga_range_room] failed to build', err?.message || err);
    return null;
  }
}


function replaceTextureOnPanel(mesh, tex){
  if (!mesh?.material || !tex) return;
  const old = mesh.material.map;
  mesh.material.map = tex;
  mesh.material.needsUpdate = true;
  if (old && old !== tex) old.dispose?.();
}

function initGolfSim(room){
  if (room.golfSim) return room.golfSim;
  const ballStart = room.ball?.position?.clone?.() || new THREE.Vector3(0, 0.405, 5.88);
  const clubStartPos = room.clubRig?.position?.clone?.() || new THREE.Vector3(-1.55, 0.88, 6.28);
  const clubStartRot = room.clubRig?.quaternion?.clone?.() || new THREE.Quaternion();
  const sim = {
    gravity: 9.80665,
    dragK: 0.018,
    liftK: 0.35,
    yardScale: 8.5,
    grabbed: false,
    desktopGrabbed: false,
    flying: false,
    landed: false,
    flightTime: 0,
    ballStart,
    clubStartPos,
    clubStartRot,
    velocity: new THREE.Vector3(),
    lastHeadLocal: null,
    lastScoreUpdate: 0,
    lastHitAt: 0,
    helpVisible: true,
    sourceName: 'none',
    tempA: new THREE.Vector3(),
    tempB: new THREE.Vector3(),
    tempC: new THREE.Vector3(),
    tempQ: new THREE.Quaternion(),
    groupQInv: new THREE.Quaternion(),
    clubTiltQ: new THREE.Quaternion().setFromEuler(new THREE.Euler(-0.58, 0.0, 0.08)),
    stats: Object.assign({ message: 'Ready: grab club and swing', carryYards: 0, clubSpeed: 0, ballSpeed: 0, launchDeg: 14 }, room.simStats || {})
  };
  sim.resetBall = ()=>{
    if (!room.ball) return;
    room.ball.position.copy(sim.ballStart);
    room.ball.visible = true;
    sim.velocity.set(0,0,0);
    sim.flying = false;
    sim.landed = false;
    sim.flightTime = 0;
    sim.stats.carryYards = 0;
    sim.stats.ballSpeed = 0;
    sim.stats.message = 'Ball reset: grab club and swing';
    replaceTextureOnPanel(room.scoreboard, makeGolfScoreTexture(sim.stats));
  };
  sim.resetClub = ()=>{
    if (!room.clubRig) return;
    room.clubRig.position.copy(sim.clubStartPos);
    room.clubRig.quaternion.copy(sim.clubStartRot);
    sim.grabbed = false;
    sim.desktopGrabbed = false;
    sim.sourceName = 'none';
  };
  sim.toggleHelp = ()=>{
    sim.helpVisible = !sim.helpVisible;
    if (room.tutorial) room.tutorial.visible = sim.helpVisible;
  };
  sim.updateScore = (message = null)=>{
    if (message) sim.stats.message = message;
    replaceTextureOnPanel(room.scoreboard, makeGolfScoreTexture(sim.stats));
  };
  sim.updatePosture = (label)=>{
    replaceTextureOnPanel(room.posturePanel, makePostureTexture(label));
  };
  const onKey = (e)=>{
    if (!room.group?.visible) return;
    if (e.repeat) return;
    if (e.code === 'KeyR') sim.resetBall();
    if (e.code === 'KeyH') sim.toggleHelp();
    if (e.code === 'KeyG') {
      sim.desktopGrabbed = !sim.desktopGrabbed;
      sim.grabbed = sim.desktopGrabbed;
      sim.sourceName = sim.grabbed ? 'desktop' : 'none';
      sim.updateScore(sim.grabbed ? 'Desktop club grabbed: press SPACE to hit' : 'Club dropped');
    }
    if (e.code === 'Space') {
      e.preventDefault?.();
      const v = new THREE.Vector3((Math.random() - 0.5) * 0.35, 0.18, -7.5);
      sim.hitBall(v, 24);
    }
  };
  window.addEventListener('keydown', onKey);
  sim.dispose = ()=> window.removeEventListener('keydown', onKey);

  sim.hitBall = (clubVelLocal, forcedClubSpeed = null)=>{
    if (!room.ball || sim.flying || performance.now() - sim.lastHitAt < 700) return false;
    const rawClubSpeed = forcedClubSpeed ?? clubVelLocal.length();
    const clubSpeed = THREE.MathUtils.clamp(rawClubSpeed, 4.5, 42);
    const side = THREE.MathUtils.clamp(clubVelLocal.x * 0.10, -0.34, 0.34);
    const forward = Math.max(Math.abs(clubVelLocal.z), 1.0);
    const launchDeg = THREE.MathUtils.clamp(10 + clubSpeed * 0.20 + Math.max(clubVelLocal.y, 0) * 1.2, 11, 22);
    const launch = THREE.MathUtils.degToRad(launchDeg);
    const ballSpeed = THREE.MathUtils.clamp(clubSpeed * 1.48 + 3.5, 10, 62);
    const horizontal = Math.cos(launch) * ballSpeed;
    sim.velocity.set(side * ballSpeed, Math.sin(launch) * ballSpeed, -horizontal);
    // Keep the shot inside the private room scale while preserving the feeling of speed.
    sim.velocity.multiplyScalar(0.20);
    sim.flying = true;
    sim.landed = false;
    sim.flightTime = 0;
    sim.lastHitAt = performance.now();
    sim.stats.clubSpeed = clubSpeed * 2.23694;
    sim.stats.ballSpeed = ballSpeed * 2.23694;
    sim.stats.launchDeg = launchDeg;
    sim.stats.message = 'Shot launched: tracking carry';
    sim.updateScore();
    if (room.tutorial) room.tutorial.visible = false;
    sim.helpVisible = false;
    return true;
  };

  room.golfSim = sim;
  return sim;
}

function getPoseSource(rightController, rightHand){
  if (rightController) return { obj: rightController, kind: 'controller', grab: (rightController.userData?.squeeze || 0) > 0.32 || (rightController.userData?.trigger || 0) > 0.62 };
  const wrist = rightHand?.joints?.wrist || null;
  if (wrist) return { obj: wrist, kind: 'hand', grab: true };
  return null;
}

export function updatePgaGolfSimulator(scene, dt = 0.016, controls = {}){
  const room = scene?.userData?._pgaRangeRoom;
  if (!room?.group?.visible || !room.golfReady) return;
  const sim = initGolfSim(room);
  const { camera, rightController = null, rightHand = null, statusCb = null } = controls;
  const group = room.group;
  group.updateWorldMatrix(true, true);
  group.getWorldQuaternion(sim.groupQInv).invert();

  // Posture guide: simple, fast, readable. It rewards being near the tee and facing down range.
  let postureLabel = 'POSTURE READY';
  if (camera){
    const headWorld = sim.tempA;
    const headLocal = sim.tempB;
    camera.getWorldPosition(headWorld);
    headLocal.copy(headWorld);
    group.worldToLocal(headLocal);
    const teeDist = Math.hypot(headLocal.x, headLocal.z - 6.82);
    postureLabel = teeDist < 1.35 ? 'STANCE GOOD' : 'STEP ON MARKERS';
  }
  if (performance.now() - (sim.lastPostureAt || 0) > 900){
    sim.lastPostureAt = performance.now();
    sim.updatePosture(postureLabel);
  }

  const src = getPoseSource(rightController, rightHand);
  const isVrGrab = !!src?.grab;
  if (src?.obj && isVrGrab && !sim.flying){
    sim.grabbed = true;
    sim.sourceName = src.kind;
    const srcWorld = sim.tempA;
    src.obj.getWorldPosition(srcWorld);
    const local = sim.tempB.copy(srcWorld);
    group.worldToLocal(local);
    local.y -= 0.42;
    local.z -= 0.18;
    room.clubRig.position.lerp(local, 0.82);

    const srcQWorld = src.obj.getWorldQuaternion ? src.obj.getWorldQuaternion(sim.tempQ) : sim.tempQ.identity();
    const localQ = sim.groupQInv.clone().multiply(srcQWorld).multiply(sim.clubTiltQ);
    room.clubRig.quaternion.slerp(localQ, 0.68);
  } else if (sim.grabbed && sim.sourceName !== 'desktop'){
    sim.resetClub();
  }

  if (sim.desktopGrabbed && !sim.flying){
    const t = performance.now() * 0.001;
    room.clubRig.position.set(-0.42 + Math.sin(t * 2.0) * 0.18, 1.08 + Math.sin(t * 3.0) * 0.05, 6.28 + Math.cos(t * 2.0) * 0.18);
    room.clubRig.rotation.set(0.25 + Math.sin(t*2.0)*0.22, 0.0, -0.40 + Math.cos(t*2.0)*0.25);
  }

  room.clubHead.updateWorldMatrix(true, false);
  const headWorld = sim.tempA;
  const headLocal = sim.tempB;
  room.clubHead.getWorldPosition(headWorld);
  headLocal.copy(headWorld);
  group.worldToLocal(headLocal);
  if (sim.lastHeadLocal){
    const velLocal = sim.tempC.copy(headLocal).sub(sim.lastHeadLocal).multiplyScalar(1 / Math.max(dt, 0.001));
    const distToBall = headLocal.distanceTo(room.ball.position);
    if (!sim.flying && distToBall < 0.34 && velLocal.length() > 1.4 && velLocal.z < -0.35){
      sim.hitBall(velLocal);
      statusCb?.('Golf shot launched');
    }
    sim.stats.clubSpeed = THREE.MathUtils.lerp(sim.stats.clubSpeed || 0, velLocal.length() * 2.23694, 0.12);
  }
  sim.lastHeadLocal = headLocal.clone();

  if (sim.flying && room.ball){
    sim.flightTime += dt;
    // Scaled projectile physics: standard gravity, plus simple velocity-dependent drag and small lift assist for golf-ball feel.
    sim.velocity.y -= sim.gravity * 0.20 * dt;
    const speed = sim.velocity.length();
    if (speed > 0.0001){
      const drag = Math.exp(-sim.dragK * speed * dt);
      sim.velocity.multiplyScalar(drag);
      const lift = Math.max(0, 1.35 - sim.flightTime * 0.34) * sim.liftK * dt;
      sim.velocity.y += lift;
    }
    room.ball.position.addScaledVector(sim.velocity, dt);
    const carry = Math.max(0, (sim.ballStart.z - room.ball.position.z) * sim.yardScale);
    sim.stats.carryYards = carry;
    if (room.ball.position.y <= sim.ballStart.y && sim.flightTime > 0.18){
      room.ball.position.y = sim.ballStart.y;
      sim.flying = false;
      sim.landed = true;
      sim.stats.message = `Landed: ${Math.round(carry)} yd carry`;
      sim.updateScore();
      statusCb?.(sim.stats.message);
    } else if (performance.now() - sim.lastScoreUpdate > 220){
      sim.lastScoreUpdate = performance.now();
      sim.updateScore();
    }
    if (room.ball.position.z < -17.2 || Math.abs(room.ball.position.x) > 7.3){
      room.ball.position.x = THREE.MathUtils.clamp(room.ball.position.x, -7.2, 7.2);
      room.ball.position.z = Math.max(room.ball.position.z, -17.2);
      room.ball.position.y = sim.ballStart.y;
      sim.flying = false;
      sim.landed = true;
      sim.stats.message = `Target wall: ${Math.round(sim.stats.carryYards)} yd`;
      sim.updateScore();
    }
  }
}

export function tickPgaHub(scene, t = 0){
  const hub = scene?.userData?._pgaHub;
  if (!hub) return;
  if (hub.portraitFrame?.material) hub.portraitFrame.material.opacity = 0.78 + Math.sin(t * 1.8) * 0.08;
  if (hub.portalPad?.material) hub.portalPad.material.opacity = 0.84 + Math.sin(t * 2.2) * 0.08;
  if (hub.fillA) hub.fillA.intensity = 2.8 + Math.sin(t * 1.1) * 0.16;
  if (hub.fillB) hub.fillB.intensity = 1.8 + Math.sin(t * 1.0 + 0.7) * 0.12;
  if (hub.fillC) hub.fillC.intensity = 1.35 + Math.sin(t * 1.3 + 1.1) * 0.12;
}

export function tickPgaRangeRoom(scene, t = 0){
  const room = scene?.userData?._pgaRangeRoom;
  if (!room) return;
  room.rings?.forEach((ring, i)=>{
    if (ring.material) ring.material.emissiveIntensity = 0.34 + Math.sin(t * (1.2 + i*0.22) + i) * 0.10;
  });
  if (room.lightA) room.lightA.intensity = 2.55 + Math.sin(t * 1.15) * 0.14;
  if (room.lightB) room.lightB.intensity = 2.10 + Math.sin(t * 0.95 + 0.7) * 0.14;
  if (room.lightC) room.lightC.intensity = 1.00 + Math.sin(t * 1.35 + 1.7) * 0.10;
}
