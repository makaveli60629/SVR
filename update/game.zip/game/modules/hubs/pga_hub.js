import * as THREE from 'three';

function makeCanvasTexture(draw, width = 1024, height = 1024){
  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d');
  draw(ctx, width, height);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}
function roundRect(ctx, x, y, w, h, r){
  const rr = Math.min(r, w*0.5, h*0.5);
  ctx.beginPath(); ctx.moveTo(x+rr,y); ctx.arcTo(x+w,y,x+w,y+h,rr); ctx.arcTo(x+w,y+h,x,y+h,rr); ctx.arcTo(x,y+h,x,y,rr); ctx.arcTo(x,y,x+w,y,rr); ctx.closePath();
}
function wrap(ctx, text, x, y, maxWidth, lh){
  const words=text.split(/\s+/); let line='', yy=y;
  for(const word of words){ const test = line ? `${line} ${word}` : word; if (ctx.measureText(test).width > maxWidth && line){ ctx.fillText(line,x,yy); line=word; yy+=lh; } else line=test; }
  if (line) ctx.fillText(line,x,yy); return yy;
}
function plateTexture(title, subtitle, accent='#72bdff'){return makeCanvasTexture((ctx,w,h)=>{
  const grad=ctx.createLinearGradient(0,0,w,h); grad.addColorStop(0,'#080b12'); grad.addColorStop(1,'#0e1321'); ctx.fillStyle=grad; roundRect(ctx,0,0,w,h,38); ctx.fill(); ctx.strokeStyle=accent; ctx.lineWidth=14; roundRect(ctx,16,16,w-32,h-32,28); ctx.stroke();
  ctx.textAlign='center'; ctx.fillStyle='#f7fbff'; ctx.font='700 112px Arial'; ctx.fillText(title,w/2,162); ctx.fillStyle=accent; ctx.font='600 56px Arial'; ctx.fillText(subtitle,w/2,242);
},1500,330);} 
function infoTexture(){return makeCanvasTexture((ctx,w,h)=>{
  const grad=ctx.createLinearGradient(0,0,0,h); grad.addColorStop(0,'#0a0d12'); grad.addColorStop(1,'#07070b'); ctx.fillStyle=grad; roundRect(ctx,0,0,w,h,36); ctx.fill(); ctx.strokeStyle='#72bdff'; ctx.lineWidth=12; roundRect(ctx,14,14,w-28,h-28,28); ctx.stroke();
  ctx.fillStyle='#ffefef'; ctx.font='700 54px Arial'; ctx.fillText('JUAN E. ESPEJO', 44, 86);
  ctx.fillStyle='#d7ecff'; ctx.font='600 24px Arial'; ctx.fillText('PGA-inspired VR golf training hub', 44, 122);
  ctx.fillStyle='#7dc7ff'; ctx.font='700 26px Arial'; ctx.fillText('ABOUT', 44, 176);
  ctx.fillStyle='#ffffff'; ctx.font='600 22px Arial'; let y = wrap(ctx, 'Lessons, fundamentals, practice sessions, and VR golf showcase frontage aligned to the lobby wall.', 44, 214, w-88, 30);
  y += 52; ctx.fillStyle='#7dc7ff'; ctx.font='700 26px Arial'; ctx.fillText('FEATURES', 44, y); y += 38;
  ctx.fillStyle='#ffffff'; ctx.font='600 22px Arial';
  for (const line of ['• Practice green portal','• Beginner and advanced lessons','• PGA profile presentation','• Sponsor-ready frontage']){ ctx.fillText(line, 52, y); y += 30; }
},900,860); }
function reservedTexture(){ return makeCanvasTexture((ctx,w,h)=>{ ctx.fillStyle='rgba(14,8,8,0.96)'; roundRect(ctx,0,0,w,h,26); ctx.fill(); ctx.strokeStyle='#ff5a66'; ctx.lineWidth=10; roundRect(ctx,10,10,w-20,h-20,18); ctx.stroke(); ctx.textAlign='center'; ctx.fillStyle='#ffffff'; ctx.font='700 58px Arial'; ctx.fillText('RESERVED FOR', w/2, 90); ctx.fillStyle='#ff818a'; ctx.font='700 72px Arial'; ctx.fillText('JUAN ESPEJO', w/2, 176); }, 1200, 240); }
function portalTexture(){ return makeCanvasTexture((ctx,w,h)=>{ const grad=ctx.createRadialGradient(w/2,h/2,10,w/2,h/2,w*0.45); grad.addColorStop(0,'rgba(255,255,255,0.98)'); grad.addColorStop(0.28,'rgba(114,189,255,0.92)'); grad.addColorStop(0.72,'rgba(24,62,111,0.42)'); grad.addColorStop(1,'rgba(0,0,0,0)'); ctx.fillStyle=grad; ctx.fillRect(0,0,w,h); ctx.textAlign='center'; ctx.fillStyle='#ffffff'; ctx.font='700 116px Arial'; ctx.fillText('ENTER VR GOLF', w/2, h/2+40); },1024,1024); }
function loadTexture(url){return new Promise(resolve=>{ new THREE.TextureLoader().load(url, t=>{t.colorSpace=THREE.SRGBColorSpace; t.anisotropy=8; resolve(t);}, undefined, ()=>resolve(null)); });}

export async function addPgaHub(scene, { radius }){
  const group = new THREE.Group();
  const angle = Math.PI * 0.28;
  const wallPos = new THREE.Vector3(Math.cos(angle) * (radius - 0.48), 0, Math.sin(angle) * (radius - 0.48));
  group.position.copy(wallPos);
  group.lookAt(0,0,0);
  const frameMat = new THREE.MeshStandardMaterial({ color: 0x0f1724, roughness: 0.38, metalness: 0.22, emissive: 0x13365a, emissiveIntensity: 0.72 });
  const trimMat = new THREE.MeshStandardMaterial({ color: 0x73bcff, roughness: 0.18, metalness: 0.22, emissive: 0x295a8e, emissiveIntensity: 0.9 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xcbe7ff, roughness: 0.08, transmission: 0.88, transparent: true, opacity: 0.15 });
  const turfMat = new THREE.MeshStandardMaterial({ color: 0x215032, roughness: 0.96, metalness: 0.02, emissive: 0x0b1d13, emissiveIntensity: 0.08 });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x081018, roughness: 0.8, metalness: 0.08 });

  const width = 8.8, depth = 4.6, height = 5.2;
  const platform = new THREE.Mesh(new THREE.BoxGeometry(width, 0.12, depth), darkMat);
  platform.position.set(0,0.06,-depth*0.45); group.add(platform);
  const wall = new THREE.Mesh(new THREE.BoxGeometry(width, height, 0.18), frameMat); wall.position.set(0,height*0.5,0); group.add(wall);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(width+0.3, 0.18, depth+0.2), frameMat); roof.position.set(0,height+0.08,-depth*0.5); group.add(roof);
  const sideL = new THREE.Mesh(new THREE.BoxGeometry(0.16,height,depth), frameMat); sideL.position.set(-width*0.5+0.08,height*0.5,-depth*0.5); group.add(sideL); const sideR = sideL.clone(); sideR.position.x *= -1; group.add(sideR);
  const glassL = new THREE.Mesh(new THREE.PlaneGeometry(depth, height-0.6), glassMat); glassL.rotation.y=Math.PI/2; glassL.position.set(-width*0.5+0.18,height*0.52,-depth*0.5); group.add(glassL); const glassR = glassL.clone(); glassR.position.x *= -1; group.add(glassR);

  const header = new THREE.Mesh(new THREE.PlaneGeometry(4.2,0.95), new THREE.MeshBasicMaterial({ map: plateTexture('VR GOLF PGA HUB','Lessons • Practice • Profile', '#73bcff'), transparent:true }));
  header.position.set(0,height-0.55,0.11); group.add(header);
  const info = new THREE.Mesh(new THREE.PlaneGeometry(3.15,3.95), new THREE.MeshBasicMaterial({ map: infoTexture(), transparent:true }));
  info.position.set(-1.35,2.2,-depth*0.72+0.03); group.add(info);
  const badge = new THREE.Mesh(new THREE.RingGeometry(0.62,0.94,48), trimMat); badge.position.set(2.1,3.28,-depth*0.71+0.03); group.add(badge);
  const center = new THREE.Mesh(new THREE.CircleGeometry(0.58,40), new THREE.MeshBasicMaterial({ color:0x0b0f15, transparent:true, opacity:0.92 })); center.position.copy(badge.position).setZ(badge.position.z+0.01); group.add(center);
  const badgeText = new THREE.Mesh(new THREE.PlaneGeometry(1.0,0.5), new THREE.MeshBasicMaterial({ map: makeCanvasTexture((ctx,w,h)=>{ctx.fillStyle='transparent'; ctx.fillRect(0,0,w,h); ctx.textAlign='center'; ctx.fillStyle='#ffffff'; ctx.font='700 120px Arial'; ctx.fillText('PGA', w/2, 144);}, 800,300), transparent:true })); badgeText.position.copy(badge.position).setZ(badge.position.z+0.02); group.add(badgeText);
  const portraitTex = await loadTexture(new URL('../../assets/ui/juan-espejo.jpg', import.meta.url).toString());
  if (portraitTex){ const portrait = new THREE.Mesh(new THREE.PlaneGeometry(1.75,2.25), new THREE.MeshBasicMaterial({ map: portraitTex, transparent:true })); portrait.position.set(2.1,1.82,-depth*0.71+0.03); group.add(portrait); }
  const plaque = new THREE.Mesh(new THREE.PlaneGeometry(3.2,0.66), new THREE.MeshBasicMaterial({ map: reservedTexture(), transparent:true })); plaque.position.set(1.2,0.74,-depth*0.71+0.03); group.add(plaque);

  const turf = new THREE.Mesh(new THREE.BoxGeometry(width*0.48,0.04,1.9), turfMat); turf.position.set(0,0.08,-depth+0.85); group.add(turf);
  const portal = new THREE.Mesh(new THREE.CircleGeometry(0.88,48), new THREE.MeshBasicMaterial({ map: portalTexture(), transparent:true, opacity:0.95, side:THREE.DoubleSide })); portal.rotation.x=-Math.PI/2; portal.position.set(0,0.09,-depth+0.86); group.add(portal);
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.76,1.02,64), trimMat); ring.rotation.x=-Math.PI/2; ring.position.copy(portal.position).setY(0.075); group.add(ring);
  const line = new THREE.Mesh(new THREE.BoxGeometry(0.06,0.02,1.4), new THREE.MeshBasicMaterial({ color: 0xffffff })); line.position.set(0,0.10,-depth+0.86); group.add(line);
  const ball = new THREE.Mesh(new THREE.SphereGeometry(0.11,18,18), new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.88 })); ball.position.set(0.2,0.14,-depth+0.72); group.add(ball);
  const club = new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,1.2,10), new THREE.MeshStandardMaterial({ color:0x7c8895, roughness:0.38, metalness:0.72 })); club.position.set(2.95,0.72,-depth+1.55); club.rotation.z = 0.22; group.add(club);

  scene.add(group);
  const worldPortal = group.localToWorld(new THREE.Vector3(0,0,-depth+0.86));
  return { group, portal: { center: worldPortal, radius: 1.06, url: './sandbox/' } };
}
