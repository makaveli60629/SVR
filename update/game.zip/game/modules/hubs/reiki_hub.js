export const REIKI_HUB_CONFIG = Object.freeze({
  name: "Trueitive Reiki Hub",
  wallZone: "south",
  anchorAngle: -Math.PI * 0.24,
  portalHref: "./reiki/",
  accent: 0x42d392
});
