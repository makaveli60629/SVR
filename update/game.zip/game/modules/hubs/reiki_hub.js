import * as THREE from 'three';

function makeCanvasTexture(draw, width = 1024, height = 1024){
  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d');
  draw(ctx, width, height);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

function roundRect(ctx, x, y, w, h, r){
  const rr = Math.min(r, w*0.5, h*0.5);
  ctx.beginPath();
  ctx.moveTo(x+rr, y);
  ctx.arcTo(x+w, y, x+w, y+h, rr);
  ctx.arcTo(x+w, y+h, x, y+h, rr);
  ctx.arcTo(x, y+h, x, y, rr);
  ctx.arcTo(x, y, x+w, y, rr);
  ctx.closePath();
}

function drawWrappedText(ctx, text, x, y, maxWidth, lineHeight){
  const words = text.split(/\s+/);
  let line = '';
  let yy = y;
  for (const word of words){
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line){
      ctx.fillText(line, x, yy);
      line = word;
      yy += lineHeight;
    } else {
      line = test;
    }
  }
  if (line) ctx.fillText(line, x, yy);
  return yy;
}

function labelTexture(title, subtitle, accent='#78ffd2'){
  return makeCanvasTexture((ctx,w,h)=>{
    const grad = ctx.createLinearGradient(0,0,w,h);
    grad.addColorStop(0, '#08100d');
    grad.addColorStop(1, '#091017');
    ctx.fillStyle = grad;
    roundRect(ctx, 0, 0, w, h, 42);
    ctx.fill();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 16;
    roundRect(ctx, 18, 18, w-36, h-36, 34);
    ctx.stroke();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#f5fffb';
    ctx.font = '700 122px Arial';
    ctx.fillText(title, w/2, 168);
    ctx.fillStyle = accent;
    ctx.font = '600 56px Arial';
    ctx.fillText(subtitle, w/2, 250);
  }, 1500, 340);
}

function infoTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    const grad = ctx.createLinearGradient(0,0,0,h);
    grad.addColorStop(0, '#091015');
    grad.addColorStop(1, '#06080d');
    ctx.fillStyle = grad;
    roundRect(ctx, 0, 0, w, h, 34);
    ctx.fill();
    ctx.strokeStyle = '#6cffb3';
    ctx.lineWidth = 12;
    roundRect(ctx, 14, 14, w-28, h-28, 28);
    ctx.stroke();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#f8fffd';
    ctx.font = '700 84px Arial';
    ctx.fillText('TRUEITIVE.COM', w/2, 110);
    ctx.fillStyle = '#d6fff0';
    ctx.font = '600 34px Arial';
    ctx.fillText('Holistic Healing & Wellness', w/2, 154);
    ctx.fillStyle = '#ffffff';
    ctx.font = '700 44px Arial';
    ctx.fillText('Book an Appointment', w/2, 242);
    ctx.fillStyle = 'rgba(255,255,255,0.82)';
    ctx.font = '600 24px Arial';
    ctx.fillText('Find your state • profile session • wellness support', w/2, 282);
    ctx.fillStyle = 'rgba(124,255,203,0.18)';
    roundRect(ctx, 160, 340, w-320, 100, 24);
    ctx.fill();
    ctx.strokeStyle = '#58ffb0';
    ctx.lineWidth = 8;
    roundRect(ctx, 160, 340, w-320, 100, 24);
    ctx.stroke();
    ctx.fillStyle = '#7dffb2';
    ctx.font = '700 42px Arial';
    ctx.fillText('ENTER REIKI VR', w/2, 404);
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.font = '600 22px Arial';
    ctx.fillText('Step into the portal to begin', w/2, 438);

    ctx.fillStyle = '#d7fff2';
    ctx.font = '700 34px Arial';
    ctx.fillText('Intro Offer', w/2, 520);
    ctx.fillStyle = '#ffffff';
    ctx.font = '700 86px Arial';
    ctx.fillText('50% OFF', w/2, 612);
    ctx.fillStyle = '#d7fff2';
    ctx.font = '600 28px Arial';
    ctx.fillText('Reiki • meditation • founder-led wellness', w/2, 660);
  }, 1100, 760);
}

function founderTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    const grad = ctx.createLinearGradient(0,0,w,h);
    grad.addColorStop(0,'#090d0f');
    grad.addColorStop(1,'#13100f');
    ctx.fillStyle = grad;
    roundRect(ctx, 0, 0, w, h, 30);
    ctx.fill();
    ctx.strokeStyle = '#94ffd2';
    ctx.lineWidth = 10;
    roundRect(ctx, 12, 12, w-24, h-24, 24);
    ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.font = '700 64px Arial';
    ctx.fillText('Meet the Founder', 48, 90);
    ctx.fillStyle = '#d9fff3';
    ctx.font = '600 24px Arial';
    let y = 148;
    y = drawWrappedText(ctx,
      'Shyona Royston founded Trueitive Holistic Healing & Wellness in 2016. Founder-led Reiki, meditation, massage support, and holistic wellness guidance.',
      48, y, w-96, 34);
    y += 50;
    ctx.fillStyle = '#75ffb5';
    ctx.font = '700 28px Arial';
    ctx.fillText('Reserved for Approval', 48, y);
    y += 54;
    ctx.fillStyle = '#ffffff';
    ctx.font = '600 22px Arial';
    drawWrappedText(ctx,
      'Founder-led wellness network • book appointment • find your state • enter Reiki VR portal',
      48, y, w-96, 32);
  }, 880, 980);
}

function portalTexture(){
  return makeCanvasTexture((ctx,w,h)=>{
    ctx.clearRect(0,0,w,h);
    const grad = ctx.createRadialGradient(w/2,h/2,10,w/2,h/2,w*0.45);
    grad.addColorStop(0,'rgba(255,255,255,0.98)');
    grad.addColorStop(0.22,'rgba(124,255,203,0.95)');
    grad.addColorStop(0.64,'rgba(34,117,88,0.55)');
    grad.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0,0,w,h);
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255,255,255,0.95)';
    ctx.font = '700 120px Arial';
    ctx.fillText('ENTER REIKI', w/2, h/2+36);
  }, 1024, 1024);
}

function loadTexture(url){
  return new Promise((resolve)=>{
    new THREE.TextureLoader().load(url, (tex)=>{
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      resolve(tex);
    }, undefined, ()=>resolve(null));
  });
}

export async function addReikiHub(scene, { radius, wallHeight }){
  const group = new THREE.Group();
  const angle = Math.PI * 0.72;
  const inward = new THREE.Vector3(-Math.cos(angle), 0, -Math.sin(angle));
  const tangent = new THREE.Vector3(-Math.sin(angle), 0, Math.cos(angle));
  const wallPos = new THREE.Vector3(Math.cos(angle) * (radius - 0.5), 0, Math.sin(angle) * (radius - 0.5));
  group.position.copy(wallPos);
  group.lookAt(0, 0, 0);

  const frameMat = new THREE.MeshStandardMaterial({ color: 0x10231c, roughness: 0.42, metalness: 0.22, emissive: 0x0d3e2d, emissiveIntensity: 0.68 });
  const trimMat = new THREE.MeshStandardMaterial({ color: 0x7bffd0, roughness: 0.22, metalness: 0.18, emissive: 0x1e8b65, emissiveIntensity: 1.08 });
  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xb7fff1, roughness: 0.06, transmission: 0.94, transparent: true, opacity: 0.18, thickness: 0.02 });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x07100d, roughness: 0.86, metalness: 0.06, emissive: 0x07150e, emissiveIntensity: 0.2 });
  const carpetMat = new THREE.MeshStandardMaterial({ color: 0x42101a, roughness: 0.96, metalness: 0.02, emissive: 0x1b050b, emissiveIntensity: 0.12 });

  const width = 9.8;
  const depth = 5.4;
  const height = 5.4;
  const front = 2.4;

  const platform = new THREE.Mesh(new THREE.BoxGeometry(width, 0.12, depth), darkMat);
  platform.position.set(0, 0.06, -depth*0.45);
  group.add(platform);
  const carpet = new THREE.Mesh(new THREE.BoxGeometry(width*0.64, 0.025, depth*0.90), carpetMat);
  carpet.position.set(0, 0.08, -depth*0.48);
  group.add(carpet);

  const wall = new THREE.Mesh(new THREE.BoxGeometry(width, height, 0.18), frameMat);
  wall.position.set(0, height*0.5, 0);
  group.add(wall);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(width + 0.34, 0.18, depth + 0.24), frameMat);
  roof.position.set(0, height + 0.08, -depth*0.5);
  group.add(roof);

  const sideL = new THREE.Mesh(new THREE.BoxGeometry(0.16, height, depth), frameMat);
  sideL.position.set(-width*0.5 + 0.08, height*0.5, -depth*0.5);
  group.add(sideL);
  const sideR = sideL.clone(); sideR.position.x *= -1; group.add(sideR);
  const glassL = new THREE.Mesh(new THREE.PlaneGeometry(depth, height-0.6), glassMat);
  glassL.rotation.y = Math.PI/2;
  glassL.position.set(-width*0.5 + 0.18, height*0.52, -depth*0.5);
  group.add(glassL);
  const glassR = glassL.clone(); glassR.position.x *= -1; group.add(glassR);

  const reikiHeader = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 0.95), new THREE.MeshBasicMaterial({ map: labelTexture('REIKI HUB', 'Meditation • Healing • Founder-led', '#7cffc8'), transparent: true }));
  reikiHeader.position.set(0, height-0.55, 0.11);
  group.add(reikiHeader);

  const centerPanel = new THREE.Mesh(new THREE.PlaneGeometry(2.7, 4.0), new THREE.MeshBasicMaterial({ map: infoTexture(), transparent: true }));
  centerPanel.position.set(0, 2.15, -depth*0.72 + 0.03);
  group.add(centerPanel);

  const founderPanel = new THREE.Mesh(new THREE.PlaneGeometry(2.45, 4.0), new THREE.MeshBasicMaterial({ map: founderTexture(), transparent: true }));
  founderPanel.position.set(-width*0.31, 2.15, -depth*0.72 + 0.03);
  group.add(founderPanel);

  const founderPortraitTex = await loadTexture(new URL('../../assets/ui/trueitive-founder.png', import.meta.url).toString());
  if (founderPortraitTex){
    const portrait = new THREE.Mesh(new THREE.PlaneGeometry(1.65, 2.05), new THREE.MeshBasicMaterial({ map: founderPortraitTex, transparent: true }));
    portrait.position.set(width*0.31, 1.95, -depth*0.72 + 0.03);
    group.add(portrait);
  }

  const logoTex = await loadTexture(new URL('../../assets/ui/trueitive-logo.png', import.meta.url).toString());
  if (logoTex){
    const logo = new THREE.Mesh(new THREE.PlaneGeometry(1.12, 0.74), new THREE.MeshBasicMaterial({ map: logoTex, transparent: true }));
    logo.position.set(0, 3.72, -depth*0.70 + 0.04);
    group.add(logo);
  }

  const plaqueTex = labelTexture('WELLNESS PARTNER', 'Trueitive founder-led network', '#7cffc8');
  const plaque = new THREE.Mesh(new THREE.PlaneGeometry(3.5, 0.82), new THREE.MeshBasicMaterial({ map: plaqueTex, transparent: true }));
  plaque.position.set(0, 4.70, 0.11);
  group.add(plaque);


  const displayBar = new THREE.Mesh(new THREE.BoxGeometry(width*0.78, 0.06, 0.08), new THREE.MeshStandardMaterial({ color: 0x9fffe1, roughness: 0.16, metalness: 0.24, emissive: 0x54ffc0, emissiveIntensity: 0.95 }));
  displayBar.position.set(0, 3.28, -depth*0.52);
  group.add(displayBar);
  const beautyLightL = new THREE.PointLight(0x7cffc8, 7.5, 9, 2.0);
  beautyLightL.position.set(-2.8, 2.8, -2.2);
  group.add(beautyLightL);
  const beautyLightR = new THREE.PointLight(0x7cffc8, 7.5, 9, 2.0);
  beautyLightR.position.set(2.8, 2.8, -2.2);
  group.add(beautyLightR);

  const portalPad = new THREE.Mesh(new THREE.CircleGeometry(0.92, 48), new THREE.MeshBasicMaterial({ map: portalTexture(), transparent: true, opacity: 0.95, side: THREE.DoubleSide }));
  portalPad.rotation.x = -Math.PI/2;
  portalPad.position.set(0, 0.085, -2.75);
  group.add(portalPad);

  const ring = new THREE.Mesh(new THREE.RingGeometry(0.74, 1.05, 64), trimMat);
  ring.rotation.x = -Math.PI/2;
  ring.position.copy(portalPad.position).setY(0.075);
  group.add(ring);

  const ropeMat = new THREE.MeshStandardMaterial({ color: 0xa6152f, roughness: 0.55, metalness: 0.12, emissive: 0x420611, emissiveIntensity: 0.4 });
  const postMat = new THREE.MeshStandardMaterial({ color: 0x6c7480, roughness: 0.28, metalness: 0.52 });
  const ropePts = [
    [-1.6,-1.6],[-1.6,-2.8],[1.6,-2.8],[1.6,-1.6]
  ];
  for (const [x,z] of ropePts){
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.05,0.76,12), postMat);
    post.position.set(x,0.38,z);
    group.add(post);
  }
  const ropes = [
    [[-1.6,-1.6],[-1.6,-2.8]], [[-1.6,-2.8],[-0.82,-2.8]], [[0.82,-2.8],[1.6,-2.8]], [[1.6,-2.8],[1.6,-1.6]]
  ];
  for (const [[x1,z1],[x2,z2]] of ropes){
    const len = Math.hypot(x2-x1,z2-z1);
    const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,len,10), ropeMat);
    rope.position.set((x1+x2)/2,0.56,(z1+z2)/2);
    rope.rotation.z = Math.PI/2;
    rope.rotation.y = Math.atan2(x2-x1,z2-z1);
    group.add(rope);
  }

  scene.add(group);
  const worldPortal = group.localToWorld(new THREE.Vector3(0, 0, -2.75));
  return {
    group,
    portal: { center: worldPortal, radius: 1.12, url: './reiki/' }
  };
}
