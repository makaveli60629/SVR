import * as THREE from "three";
import { CONFIG } from "./config.js";
import { getIndexTipWorld, isPinching } from "./gesture_utils.js";

export function createInteractionSystem({ camera, renderer, playerRig, seats, watch, teleport, log=console.log }) {
  const raycaster = new THREE.Raycaster();
  const mouse = new THREE.Vector2();
  const hoverColor = new THREE.Color(0xe8dcff);
  const defaultColor = new THREE.Color(0xffffff);

  let desktopPointer = { x: 0, y: 0 };

  window.addEventListener("pointermove", (e) => {
    desktopPointer.x = (e.clientX / window.innerWidth) * 2 - 1;
    desktopPointer.y = -(e.clientY / window.innerHeight) * 2 + 1;
  });

  function nearestSeat(headPos) {
    let best = seats[0];
    let bestD = Infinity;
    for (const seat of seats) {
      const dx = headPos.x - seat.anchor.x;
      const dz = headPos.z - seat.anchor.z;
      const d = dx * dx + dz * dz;
      if (d < bestD) {
        best = seat;
        bestD = d;
      }
    }
    return best;
  }

  function applyAction(action) {
    if (action === "teleport") {
      const next = teleport.toggle();
      watch.setState({ teleportEnabled: next });
      log("Teleport toggled", next);
      return;
    }
    if (action === "seat") {
      if (playerRig.isSeated()) {
        playerRig.standUp();
        watch.setState({ seated: false });
      } else {
        const seat = nearestSeat(playerRig.getHeadWorld());
        playerRig.enterSeat(seat);
        watch.setState({ seated: true });
      }
      return;
    }
    if (action === "reset") {
      playerRig.resetToSpawn();
      watch.setState({ seated: false, teleportEnabled: false });
      teleport.setEnabled(false);
    }
  }

  function enterSeatIndex(index) {
    const seat = seats.find((s) => s.index === index);
    if (!seat) return;
    playerRig.enterSeat(seat);
    watch.setState({ seated: true });
  }

  document.addEventListener("keydown", (e) => {
    if (e.code === "KeyT") {
      applyAction("teleport");
    }
    if (e.code === "KeyE") {
      applyAction("seat");
    }
    if (e.code === "KeyR") {
      applyAction("reset");
    }
    if (/Digit[1-6]/.test(e.code)) {
      enterSeatIndex(Number(e.code.slice(-1)) - 1);
    }
  });

  window.addEventListener("click", () => {
    if (renderer.xr.isPresenting) return;
    raycaster.setFromCamera({ x: desktopPointer.x, y: desktopPointer.y }, camera);
    const objects = [...watch.buttons, ...seats.map((s) => s.hit)];
    const hit = raycaster.intersectObjects(objects, false)[0];
    if (!hit) return;
    if (hit.object.userData.action) applyAction(hit.object.userData.action);
    if (hit.object.userData.type === "seat") enterSeatIndex(hit.object.userData.index);
  });

  const controllerQuat = new THREE.Quaternion();
  const controllerDir = new THREE.Vector3();
  const controllerPos = new THREE.Vector3();

  function update({ xrPresenting, rightController, rightHand }) {
    watch.buttons.forEach((b) => { b.material.color.copy(defaultColor); });
    seats.forEach((seat) => { seat.hit.material.opacity = 0.001; });

    if (!xrPresenting) return;

    let hoverButton = null;
    let hoverSeat = null;

    if (rightController && !teleport.isEnabled()) {
      rightController.getWorldPosition(controllerPos);
      rightController.getWorldQuaternion(controllerQuat);
      controllerDir.set(0, 0, -1).applyQuaternion(controllerQuat).normalize();
      raycaster.set(controllerPos, controllerDir);
      const hit = raycaster.intersectObjects([...watch.buttons, ...seats.map((s) => s.hit)], false)[0];
      if (hit?.object?.userData?.action) hoverButton = hit.object;
      if (hit?.object?.userData?.type === "seat") hoverSeat = hit.object;
      const rayLine = rightController.getObjectByName("ray");
      if (rayLine) {
        rayLine.visible = true;
        rayLine.material.color.set(teleport.isEnabled() ? 0x65ffe0 : 0xb48cff);
        rayLine.scale.z = hit ? Math.max(0.25, hit.distance) : 4;
      }
      const selecting = !!rightController.userData.selecting;
      if (selecting && !rightController.userData.actionLatch) {
        rightController.userData.actionLatch = true;
        if (hoverButton) applyAction(hoverButton.userData.action);
        if (hoverSeat) enterSeatIndex(hoverSeat.userData.index);
      }
      if (!selecting) rightController.userData.actionLatch = false;
    }

    if (rightHand && !hoverButton && !hoverSeat && !teleport.isEnabled()) {
      const tip = getIndexTipWorld(rightHand, new THREE.Vector3());
      if (tip) {
        for (const button of watch.buttons) {
          const world = button.getWorldPosition(new THREE.Vector3());
          if (tip.distanceTo(world) < CONFIG.HAND_BUTTON_DIST) hoverButton = button;
        }
        for (const seat of seats) {
          const world = seat.hit.getWorldPosition(new THREE.Vector3());
          const horizontal = new THREE.Vector3(tip.x, world.y, tip.z);
          if (horizontal.distanceTo(world) < 0.56 && Math.abs(tip.y - world.y) < 0.7) hoverSeat = seat.hit;
        }
      }
      const pinching = isPinching(rightHand);
      if (pinching && !rightHand.userData.actionLatch) {
        rightHand.userData.actionLatch = true;
        if (hoverButton) applyAction(hoverButton.userData.action);
        if (hoverSeat) enterSeatIndex(hoverSeat.userData.index);
      }
      if (!pinching) rightHand.userData.actionLatch = false;
    }

    if (hoverButton) hoverButton.material.color.copy(hoverColor);
    if (hoverSeat) hoverSeat.material.opacity = 0.09;
  }

  return { update, applyAction, enterSeatIndex };
}
