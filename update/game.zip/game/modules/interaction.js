import * as THREE from "three";
import { CONFIG } from "./config.js";
import { getIndexTipWorld, isPinching } from "./gesture_utils.js";

export function createInteractionSystem({ scene, camera, renderer, playerRig, seats, watch, teleport, tableProps = [], log=console.log }) {
  const raycaster = new THREE.Raycaster();
  const hoverColor = new THREE.Color(0xe8dcff);
  const defaultColor = new THREE.Color(0xffffff);
  const tableCenter = new THREE.Vector3(CONFIG.TABLE_CENTER.x, 0, CONFIG.TABLE_CENTER.z);
  const up = new THREE.Vector3(0, 1, 0);
  const cameraForward = new THREE.Vector3();
  const tmp = new THREE.Vector3();
  const tmp2 = new THREE.Vector3();
  const controllerQuat = new THREE.Quaternion();
  const controllerDir = new THREE.Vector3();
  const controllerPos = new THREE.Vector3();

  let desktopPointer = { x: 0, y: 0 };
  let heldProp = null;
  let heldMode = null;
  let lastActionAt = 0;
  const hoverWorld = new THREE.Vector3();
  const hoverWorld2 = new THREE.Vector3();
  const hoverWorld3 = new THREE.Vector3();

  window.addEventListener("pointermove", (e) => {
    desktopPointer.x = (e.clientX / window.innerWidth) * 2 - 1;
    desktopPointer.y = -(e.clientY / window.innerHeight) * 2 + 1;
  });

  function nearestSeat(headPos) {
    let best = seats[0];
    let bestD = Infinity;
    for (const seat of seats) {
      const dx = headPos.x - seat.anchor.x;
      const dz = headPos.z - seat.anchor.z;
      const d = dx * dx + dz * dz;
      if (d < bestD) {
        best = seat;
        bestD = d;
      }
    }
    return best;
  }

  function clearPropHover() {
    tableProps.forEach((prop) => {
      prop.userData.hovered = false;
      if (prop.material?.emissiveIntensity !== undefined && !prop.userData.held) {
        prop.material.emissiveIntensity = prop.userData.baseEmissive;
      }
      prop.scale.setScalar(prop.userData.held ? 1.02 : 1);
    });
  }

  function setPropHover(prop) {
    clearPropHover();
    if (!prop || prop === heldProp) return;
    prop.userData.hovered = true;
    if (prop.material?.emissiveIntensity !== undefined) prop.material.emissiveIntensity = 1.35;
    prop.scale.setScalar(1.03);
  }

  function applyAction(action) {
    const now = performance.now();
    if (now - lastActionAt < CONFIG.ACTION_COOLDOWN_MS) return;
    lastActionAt = now;
    if (action === "teleport") {
      const next = teleport.toggle();
      watch.setState({ teleportEnabled: next });
      log("Teleport toggled", next);
      return;
    }
    if (action === "seat") {
      if (playerRig.isSeated()) {
        playerRig.standUp();
        watch.setState({ seated: false });
      } else {
        const seat = nearestSeat(playerRig.getHeadWorld());
        playerRig.enterSeat(seat);
        watch.setState({ seated: true });
      }
      return;
    }
    if (action === "reset") {
      playerRig.resetToSpawn();
      watch.setState({ seated: false, teleportEnabled: false });
      teleport.setEnabled(false);
      releaseHeldProp();
    }
  }

  function enterSeatIndex(index) {
    const seat = seats.find((s) => s.index === index);
    if (!seat) return;
    playerRig.enterSeat(seat);
    watch.setState({ seated: true });
  }

  function canDropOnTable(pos) {
    const dx = pos.x - tableCenter.x;
    const dz = pos.z - tableCenter.z;
    return ((dx * dx) / (CONFIG.TABLE_RADIUS_X * CONFIG.TABLE_RADIUS_X)) + ((dz * dz) / (CONFIG.TABLE_RADIUS_Z * CONFIG.TABLE_RADIUS_Z)) <= 1.04;
  }

  function clampPointToTable(pos) {
    const next = pos.clone();
    const dx = next.x - tableCenter.x;
    const dz = next.z - tableCenter.z;
    const norm = Math.sqrt(((dx * dx) / (CONFIG.TABLE_RADIUS_X * CONFIG.TABLE_RADIUS_X)) + ((dz * dz) / (CONFIG.TABLE_RADIUS_Z * CONFIG.TABLE_RADIUS_Z)));
    if (norm > 1) {
      next.x = tableCenter.x + (dx / norm) * CONFIG.TABLE_RADIUS_X * 0.96;
      next.z = tableCenter.z + (dz / norm) * CONFIG.TABLE_RADIUS_Z * 0.96;
    }
    return next;
  }

  function rememberTablePose(prop) {
    prop.userData.lastTablePosition = prop.position.clone();
    prop.userData.lastTableQuaternion = prop.quaternion.clone();
  }

  function placePropOnSurface(prop, pos) {
    const next = canDropOnTable(pos)
      ? clampPointToTable(pos)
      : (prop.userData.lastTablePosition?.clone() || prop.userData.basePosition.clone());
    prop.position.copy(next);
    if (prop.userData.kind === "chip") {
      prop.position.y = CONFIG.TABLE_TOP_Y + prop.geometry.parameters.height * 0.5;
    } else {
      prop.position.y = CONFIG.TABLE_TOP_Y + 0.007;
    }
    rememberTablePose(prop);
  }

  function grabProp(prop, mode) {
    if (!prop) return;
    if (heldProp && heldProp !== prop) releaseHeldProp();
    heldProp = prop;
    heldMode = mode;
    prop.userData.held = true;
    prop.userData.hovered = false;
    scene.attach(prop);
    prop.scale.setScalar(1.02);
    if (prop.material?.emissiveIntensity !== undefined) prop.material.emissiveIntensity = 1.5;
    log("Grabbed", prop.userData.label, mode);
  }

  function releaseHeldProp() {
    if (!heldProp) return;
    const current = heldProp;
    const pos = current.getWorldPosition(new THREE.Vector3());
    placePropOnSurface(current, pos);
    if (current.userData.kind === "card") {
      current.rotation.x = 0;
      current.rotation.z = 0;
    }
    current.userData.held = false;
    current.scale.setScalar(1);
    if (current.material?.emissiveIntensity !== undefined) current.material.emissiveIntensity = current.userData.baseEmissive;
    current.userData.basePosition = current.position.clone();
    current.userData.baseQuaternion = current.quaternion.clone();
    rememberTablePose(current);
    log("Dropped", current.userData.label);
    heldProp = null;
    heldMode = null;
  }

  function updateHeldDesktop() {
    if (!heldProp) return;
    camera.getWorldDirection(cameraForward);
    const target = camera.position.clone().add(cameraForward.multiplyScalar(CONFIG.TABLE_PROP_HOLD_DISTANCE));
    target.y = Math.max(0.8, camera.position.y - 0.12);
    heldProp.position.lerp(target, 0.38);
    heldProp.quaternion.slerp(camera.quaternion, 0.24);
  }

  function updateHeldController(rightController) {
    if (!heldProp || !rightController) return;
    rightController.getWorldPosition(controllerPos);
    rightController.getWorldQuaternion(controllerQuat);
    controllerDir.set(0, 0, -1).applyQuaternion(controllerQuat).normalize();
    const target = controllerPos.clone().add(controllerDir.multiplyScalar(CONFIG.TABLE_PROP_CONTROLLER_DISTANCE));
    heldProp.position.lerp(target, 0.45);
    heldProp.quaternion.slerp(controllerQuat, 0.32);
  }

  function updateHeldHand(rightHand) {
    if (!heldProp || !rightHand) return;
    const tip = getIndexTipWorld(rightHand, tmp);
    const wrist = rightHand.joints?.wrist;
    if (!tip || !wrist) return;
    wrist.getWorldPosition(tmp2);
    const dir = tip.clone().sub(tmp2).normalize();
    const target = tip.clone().add(dir.multiplyScalar(0.04));
    heldProp.position.lerp(target, 0.5);
    heldProp.lookAt(target.clone().add(dir));
  }

  function handleDesktopClick() {
    if (renderer.xr.isPresenting) return;
    raycaster.setFromCamera({ x: desktopPointer.x, y: desktopPointer.y }, camera);
    const objects = [...tableProps, ...watch.buttons, ...seats.map((s) => s.hit)];
    const hit = raycaster.intersectObjects(objects, false)[0];
    if (!hit) return;
    if (hit.object.userData.type === "table-prop") {
      if (heldProp === hit.object) releaseHeldProp();
      else grabProp(hit.object, "desktop");
      return;
    }
    if (heldProp) releaseHeldProp();
    if (hit.object.userData.action) applyAction(hit.object.userData.action);
    if (hit.object.userData.type === "seat") enterSeatIndex(hit.object.userData.index);
  }

  document.addEventListener("keydown", (e) => {
    if (e.code === "KeyT") applyAction("teleport");
    if (e.code === "KeyE") applyAction("seat");
    if (e.code === "KeyR") applyAction("reset");
    if (e.code === "KeyG") releaseHeldProp();
    if (/Digit[1-6]/.test(e.code)) enterSeatIndex(Number(e.code.slice(-1)) - 1);
  });

  window.addEventListener("click", handleDesktopClick);

  function update({ xrPresenting, rightController, rightHand }) {
    watch.buttons.forEach((b) => { b.material.color.copy(defaultColor); });
    seats.forEach((seat) => { seat.hit.material.opacity = 0.001; });
    clearPropHover();

    if (!xrPresenting) {
      if (heldMode === "desktop") updateHeldDesktop();
      return;
    }

    let hoverButton = null;
    let hoverSeat = null;
    let hoverProp = null;

    if (rightController && !teleport.isEnabled()) {
      rightController.getWorldPosition(controllerPos);
      rightController.getWorldQuaternion(controllerQuat);
      controllerDir.set(0, 0, -1).applyQuaternion(controllerQuat).normalize();
      raycaster.set(controllerPos, controllerDir);
      const hit = raycaster.intersectObjects([...tableProps, ...watch.buttons, ...seats.map((s) => s.hit)], false)[0];
      if (hit?.object?.userData?.action) hoverButton = hit.object;
      if (hit?.object?.userData?.type === "seat") hoverSeat = hit.object;
      if (hit?.object?.userData?.type === "table-prop") hoverProp = hit.object;
      const rayLine = rightController.getObjectByName("ray");
      if (rayLine) {
        rayLine.visible = true;
        rayLine.material.color.set(teleport.isEnabled() ? 0x65ffe0 : 0xb48cff);
        rayLine.scale.z = hit ? Math.max(0.25, hit.distance) : 4;
      }

      const selecting = !!rightController.userData.selecting;
      if (heldProp && heldMode === "controller") {
        updateHeldController(rightController);
        if (!selecting && rightController.userData.holdLatch) {
          rightController.userData.holdLatch = false;
          releaseHeldProp();
        }
      } else {
        if (selecting && !rightController.userData.actionLatch) {
          rightController.userData.actionLatch = true;
          if (hoverProp) {
            grabProp(hoverProp, "controller");
            rightController.userData.holdLatch = true;
          } else if (hoverButton) {
            applyAction(hoverButton.userData.action);
          } else if (hoverSeat) {
            enterSeatIndex(hoverSeat.userData.index);
          }
        }
        if (!selecting) rightController.userData.actionLatch = false;
      }
    }

    if (rightHand && !teleport.isEnabled()) {
      const tip = getIndexTipWorld(rightHand, new THREE.Vector3());
      if (tip) {
        if (!hoverButton) {
          for (const button of watch.buttons) {
            const world = button.getWorldPosition(hoverWorld);
            if (tip.distanceTo(world) < CONFIG.HAND_BUTTON_DIST) hoverButton = button;
          }
        }
        if (!hoverSeat) {
          for (const seat of seats) {
            const world = seat.hit.getWorldPosition(hoverWorld2);
            hoverWorld3.set(tip.x, world.y, tip.z);
            if (hoverWorld3.distanceTo(world) < 0.56 && Math.abs(tip.y - world.y) < 0.7) hoverSeat = seat.hit;
          }
        }
        if (!hoverProp) {
          for (const prop of tableProps) {
            const world = prop.getWorldPosition(hoverWorld);
            if (tip.distanceTo(world) < CONFIG.TABLE_PROP_HAND_DIST) hoverProp = prop;
          }
        }
      }

      const pinching = isPinching(rightHand);
      if (heldProp && heldMode === "hand") {
        updateHeldHand(rightHand);
        if (!pinching && rightHand.userData.holdLatch) {
          rightHand.userData.holdLatch = false;
          releaseHeldProp();
        }
      } else {
        if (pinching && !rightHand.userData.actionLatch) {
          rightHand.userData.actionLatch = true;
          if (hoverProp) {
            grabProp(hoverProp, "hand");
            rightHand.userData.holdLatch = true;
          } else if (hoverButton) {
            applyAction(hoverButton.userData.action);
          } else if (hoverSeat) {
            enterSeatIndex(hoverSeat.userData.index);
          }
        }
        if (!pinching) rightHand.userData.actionLatch = false;
      }
    }

    if (hoverButton) hoverButton.material.color.copy(hoverColor);
    if (hoverSeat) hoverSeat.material.opacity = 0.09;
    if (hoverProp) setPropHover(hoverProp);
  }

  return { update, applyAction, enterSeatIndex, releaseHeldProp };
}
