export const SPONSORS=[
{id:"svr",name:"SVR POKER",tagline:"LIVE VR POKER LOUNGE",color:"#7f3cff"},
{id:"trueitive",name:"TRUEITIVE",tagline:"HOLISTIC HEALING HUB",color:"#0e5a4c"},
{id:"pga",name:"JUAN ESPEJO PGA",tagline:"GOLF TRAINING HUB",color:"#2d5a13"},
{id:"sponsor",name:"SPONSOR SLOT",tagline:"READY FOR PARTNER ADS",color:"#5b2b7f"}];
export function nextSponsor(currentIndex){return(currentIndex+1)%SPONSORS.length;}
