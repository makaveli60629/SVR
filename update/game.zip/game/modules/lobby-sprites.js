(function () {
  const THREE = AFRAME.THREE;

  function glowTexture(inner, outer) {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    const g = ctx.createRadialGradient(128, 128, 6, 128, 128, 118);
    g.addColorStop(0, inner);
    g.addColorStop(0.28, outer);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 256, 256);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  AFRAME.registerComponent('lobby-sprites', {
    init: function () {
      this.group = new THREE.Group();
      this.sprites = [];
      const textures = [
        glowTexture('rgba(255,170,255,1)', 'rgba(190,80,255,0.75)'),
        glowTexture('rgba(255,210,255,1)', 'rgba(255,80,185,0.7)'),
        glowTexture('rgba(230,180,255,1)', 'rgba(110,70,255,0.7)')
      ];
      const defs = [
        { x: -10, y: 4.5, z: -14, s: 2.9 },
        { x: 9, y: 5.8, z: -12, s: 2.4 },
        { x: -18, y: 7.2, z: -24, s: 3.4 },
        { x: 20, y: 8.6, z: -26, s: 2.8 }
      ];
      defs.forEach((d, i) => {
        const mat = new THREE.SpriteMaterial({
          map: textures[i % textures.length],
          color: 0xffffff,
          transparent: true,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
          opacity: 0.82
        });
        const sprite = new THREE.Sprite(mat);
        sprite.position.set(d.x, d.y, d.z);
        sprite.scale.set(d.s, d.s, 1);
        sprite.userData.baseY = d.y;
        sprite.userData.phase = i * 1.27;
        this.group.add(sprite);
        this.sprites.push(sprite);
      });
      this.el.object3D.add(this.group);
    },
    tick: function (time) {
      const t = time * 0.001;
      this.sprites.forEach((sprite, i) => {
        sprite.position.y = sprite.userData.baseY + Math.sin(t * 0.7 + sprite.userData.phase) * 1.2;
        sprite.material.opacity = 0.64 + Math.sin(t * 1.8 + i) * 0.18;
        const s = sprite.scale.x;
        const pulse = 1 + Math.sin(t * 1.5 + sprite.userData.phase) * 0.05;
        sprite.scale.set(s * pulse, s * pulse, 1);
      });
    }
  });
})();
