
(function(){

const canvas=document.getElementById('matrix');
const ctx=canvas.getContext('2d');

function resize(){
canvas.width=window.innerWidth;
canvas.height=window.innerHeight;
}
resize();
window.addEventListener('resize',resize);

const letters="SVRPOKER0123456789#$%&";
const size=16;
let cols=Math.floor(canvas.width/size);
let drops=Array(cols).fill(1);

function draw(){

ctx.fillStyle="rgba(0,0,0,.15)";
ctx.fillRect(0,0,canvas.width,canvas.height);

ctx.fillStyle="#8a3dff";
ctx.font=size+"px monospace";

for(let i=0;i<drops.length;i++){

let text=letters[Math.floor(Math.random()*letters.length)];
ctx.fillText(text,i*size,drops[i]*size);

if(drops[i]*size>canvas.height&&Math.random()>.97){
drops[i]=0;
}

drops[i]++;

}

requestAnimationFrame(draw);

}

draw();

})();
