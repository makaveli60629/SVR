
AFRAME.registerComponent('watch-ui',{
 init:function(){
   console.log("Watch UI Ready");
 }
});
