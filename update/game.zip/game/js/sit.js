
AFRAME.registerComponent('sit-system',{
 init:function(){
   console.log("Sit system active");
 }
});
