(() => {
  const rig = document.getElementById('rig');
  const camera = document.getElementById('camera');
  const speed = 0.065;
  const keys = new Set();

  function move(dx, dz) {
    const rotY = THREE.MathUtils.degToRad(camera.object3D.rotation.y * 180 / Math.PI);
    const sin = Math.sin(rotY), cos = Math.cos(rotY);
    rig.object3D.position.x += dx * cos - dz * sin;
    rig.object3D.position.z += dz * cos + dx * sin;
  }

  window.addEventListener('keydown', e => keys.add(e.key.toLowerCase()));
  window.addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));

  function tick() {
    let dx = 0, dz = 0;
    if (keys.has('w') || keys.has('arrowup')) dz -= speed;
    if (keys.has('s') || keys.has('arrowdown')) dz += speed;
    if (keys.has('a') || keys.has('arrowleft')) dx -= speed;
    if (keys.has('d') || keys.has('arrowright')) dx += speed;
    if (dx || dz) move(dx, dz);
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);

  if (window.matchMedia('(pointer:coarse)').matches && window.nipplejs) {
    const zone = document.getElementById('joystickZone');
    const manager = nipplejs.create({
      zone,
      mode: 'static',
      position: { left: '90px', bottom: '90px' },
      color: 'purple',
      size: 120
    });
    let joy = { x: 0, y: 0 };
    manager.on('move', (_, data) => {
      if (!data || !data.vector) return;
      joy.x = data.vector.x;
      joy.y = data.vector.y;
    });
    manager.on('end', () => joy = { x: 0, y: 0 });

    function joyTick() {
      if (Math.abs(joy.x) > 0.05 || Math.abs(joy.y) > 0.05) {
        move(joy.x * speed * 0.8, -joy.y * speed * 0.8);
      }
      requestAnimationFrame(joyTick);
    }
    requestAnimationFrame(joyTick);
  }
})();
