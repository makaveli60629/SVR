
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,0.1,1000);
camera.position.set(0,1.7,8);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
document.body.appendChild(renderer.domElement);

/* Lighting */

const ambient = new THREE.AmbientLight(0xffffff,1.2);
scene.add(ambient);

const neon = new THREE.PointLight(0x8A2BE2,6,100);
neon.position.set(0,6,0);
scene.add(neon);

const moonLight = new THREE.DirectionalLight(0xffffff,1);
moonLight.position.set(-10,20,-20);
scene.add(moonLight);

/* Floor */

const floorGeo = new THREE.PlaneGeometry(100,100);
const floorMat = new THREE.MeshStandardMaterial({
color:0x111111,
metalness:0.6,
roughness:0.2
});

const floor = new THREE.Mesh(floorGeo,floorMat);
floor.rotation.x = -Math.PI/2;
scene.add(floor);

/* Poker Table */

const tableGeo = new THREE.CylinderGeometry(2.2,2.2,0.2,32);
const tableMat = new THREE.MeshStandardMaterial({color:0x004400});
const table = new THREE.Mesh(tableGeo,tableMat);

table.position.y = 0.75;
scene.add(table);

/* Eric Placeholder */

const ericGeo = new THREE.BoxGeometry(0.6,1.6,0.6);
const ericMat = new THREE.MeshStandardMaterial({color:0x888888});
const eric = new THREE.Mesh(ericGeo,ericMat);

eric.position.set(0,1.6,-2);
scene.add(eric);

/* Skyline */

for(let i=0;i<40;i++){
 const bGeo = new THREE.BoxGeometry(1,Math.random()*6+2,1);
 const bMat = new THREE.MeshStandardMaterial({color:0x222244});
 const b = new THREE.Mesh(bGeo,bMat);
 b.position.set((Math.random()*40)-20,b.geometry.parameters.height/2,-30);
 scene.add(b);
}

/* Moon */

const moonGeo = new THREE.SphereGeometry(3,32,32);
const moonMat = new THREE.MeshBasicMaterial({color:0xffffff});
const moon = new THREE.Mesh(moonGeo,moonMat);
moon.position.set(-15,15,-40);
scene.add(moon);

/* Animation */

function animate(){
 requestAnimationFrame(animate);
 table.rotation.y += 0.002;
 renderer.render(scene,camera);
}

animate();

window.addEventListener("resize",()=>{
 camera.aspect = window.innerWidth/window.innerHeight;
 camera.updateProjectionMatrix();
 renderer.setSize(window.innerWidth,window.innerHeight);
});
