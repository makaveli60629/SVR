
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';
import { VRButton } from 'https://cdn.jsdelivr.net/npm/three@0.161/examples/jsm/webxr/VRButton.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,0.1,1000);
camera.position.set(0,1.7,18);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.xr.enabled = true;

document.body.appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer));

/* Lighting */

const ambient = new THREE.AmbientLight(0xffffff,1.6);
scene.add(ambient);

const neon = new THREE.PointLight(0x8A2BE2,10,300);
neon.position.set(0,12,0);
scene.add(neon);

/* Floor */

const floorGeo = new THREE.PlaneGeometry(300,300);
const floorMat = new THREE.MeshStandardMaterial({color:0x111111,metalness:.7,roughness:.2});
const floor = new THREE.Mesh(floorGeo,floorMat);
floor.rotation.x = -Math.PI/2;
scene.add(floor);

/* Walls */

const wallMaterial = new THREE.MeshStandardMaterial({color:0x111122});

function createWall(x,z,rot){
 const wallGeo = new THREE.PlaneGeometry(300,40);
 const wall = new THREE.Mesh(wallGeo,wallMaterial);
 wall.position.set(x,20,z);
 wall.rotation.y = rot;
 scene.add(wall);
}

createWall(0,-150,0);
createWall(0,150,Math.PI);
createWall(-150,0,Math.PI/2);
createWall(150,0,-Math.PI/2);

/* Poker tables */

function createTable(x,z){
 const geo = new THREE.CylinderGeometry(2.2,2.2,.25,32);
 const mat = new THREE.MeshStandardMaterial({color:0x004400});
 const table = new THREE.Mesh(geo,mat);
 table.position.set(x,.8,z);
 scene.add(table);
}

createTable(0,0);
createTable(8,-6);
createTable(-8,-6);
createTable(0,-12);

/* NPC placeholder */

const npcGeo = new THREE.BoxGeometry(.6,1.6,.6);
const npcMat = new THREE.MeshStandardMaterial({color:0xaaaaaa});
const npc = new THREE.Mesh(npcGeo,npcMat);
npc.position.set(0,1.6,-2);
scene.add(npc);

/* Skyline */

for(let i=0;i<120;i++){
 const g = new THREE.BoxGeometry(1,Math.random()*12+3,1);
 const m = new THREE.MeshStandardMaterial({color:0x222244});
 const b = new THREE.Mesh(g,m);
 b.position.set((Math.random()*120)-60,b.geometry.parameters.height/2,-80);
 scene.add(b);
}

/* Moon with texture */

const loader = new THREE.TextureLoader();
const moonTex = loader.load('../assets/textures/moon_texture.png');

const moonGeo = new THREE.SphereGeometry(6,32,32);
const moonMat = new THREE.MeshBasicMaterial({map:moonTex});
const moon = new THREE.Mesh(moonGeo,moonMat);
moon.position.set(-40,30,-120);
scene.add(moon);

/* Moon glow sprite */

const spriteMap = loader.load('../assets/textures/moon_texture.png');
const spriteMaterial = new THREE.SpriteMaterial({
 map: spriteMap,
 color: 0xffffff,
 transparent:true,
 opacity:0.4
});

const glow = new THREE.Sprite(spriteMaterial);
glow.scale.set(30,30,1);
glow.position.copy(moon.position);
scene.add(glow);

/* Desktop movement */

document.addEventListener("keydown",(e)=>{
if(e.key==="w") camera.position.z -= 1;
if(e.key==="s") camera.position.z += 1;
if(e.key==="a") camera.position.x -= 1;
if(e.key==="d") camera.position.x += 1;
});

renderer.setAnimationLoop(()=>{
 renderer.render(scene,camera);
});

window.addEventListener("resize",()=>{
 camera.aspect = window.innerWidth/window.innerHeight;
 camera.updateProjectionMatrix();
 renderer.setSize(window.innerWidth,window.innerHeight);
});
