
let scene,camera,renderer;

init();

function init(){

document.getElementById("diag").innerHTML="SVR Poker loading world";

scene = {objects:[]}; // simplified scene stub

camera = {x:0,y:1.7,z:8};

renderer = {};
document.body.appendChild(VRButton.createButton());

spawnPlayer();
createCasino();
createMoon();
createSkyline();

animate();

}

function spawnPlayer(){

camera.x=0;
camera.y=1.7;
camera.z=10;

}

function createCasino(){

console.log("casino floor");

}

function createMoon(){

console.log("moon system");

}

function createSkyline(){

console.log("skyline system");

}

function animate(){

setInterval(()=>{

// rotation placeholder

},16);

}

document.addEventListener("keydown",(e)=>{

if(e.key==="w") camera.z-=1;
if(e.key==="s") camera.z+=1;
if(e.key==="a") camera.x-=1;
if(e.key==="d") camera.x+=1;

});
