
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';
import { VRButton } from 'https://cdn.jsdelivr.net/npm/three@0.161/examples/jsm/webxr/VRButton.js';

import { initTeleport } from './modules/teleport.js';
import { initHands } from './modules/hands.js';
import { initTables } from './modules/tables.js';
import { initNPC } from './modules/npc.js';
import { initMultiplayer } from './modules/multiplayer.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,0.1,1000);
camera.position.set(0,1.7,14);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.xr.enabled = true;

document.body.appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer));

/* lighting */

const ambient = new THREE.AmbientLight(0xffffff,1.5);
scene.add(ambient);

const neon = new THREE.PointLight(0x8A2BE2,8,150);
neon.position.set(0,10,0);
scene.add(neon);

/* floor */

const floorGeo = new THREE.PlaneGeometry(200,200);
const floorMat = new THREE.MeshStandardMaterial({color:0x111111,metalness:.6,roughness:.2});
const floor = new THREE.Mesh(floorGeo,floorMat);
floor.rotation.x = -Math.PI/2;
scene.add(floor);

/* modules */

initTeleport(scene);
initHands(scene);
initTables(scene);
initNPC(scene);
initMultiplayer();

/* skyline */

for(let i=0;i<80;i++){
 const g = new THREE.BoxGeometry(1,Math.random()*10+3,1);
 const m = new THREE.MeshStandardMaterial({color:0x222244});
 const b = new THREE.Mesh(g,m);
 b.position.set((Math.random()*100)-50,b.geometry.parameters.height/2,-60);
 scene.add(b);
}

/* moon */

const moonGeo = new THREE.SphereGeometry(5,32,32);
const moonMat = new THREE.MeshBasicMaterial({color:0xffffff});
const moon = new THREE.Mesh(moonGeo,moonMat);
moon.position.set(-30,25,-80);
scene.add(moon);

renderer.setAnimationLoop(()=>{
 renderer.render(scene,camera);
});

window.addEventListener("resize",()=>{
 camera.aspect = window.innerWidth/window.innerHeight;
 camera.updateProjectionMatrix();
 renderer.setSize(window.innerWidth,window.innerHeight);
});
