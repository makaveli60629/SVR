
let scene, camera, renderer, moon;

init();
animate();

function init(){

scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);

/* Safe spawn location */
camera.position.set(0,1.7,10);

renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.xr.enabled = true;

document.body.appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer));

/* Lighting */
const ambient = new THREE.AmbientLight(0xffffff,2);
scene.add(ambient);

/* Floor */
const floorGeo = new THREE.PlaneGeometry(200,200);
const floorMat = new THREE.MeshStandardMaterial({color:0x111111});
const floor = new THREE.Mesh(floorGeo,floorMat);
floor.rotation.x = -Math.PI/2;
scene.add(floor);

/* Poker table */
const tableGeo = new THREE.CylinderGeometry(3,3,.3,64);
const tableMat = new THREE.MeshStandardMaterial({color:0x004400});
const table = new THREE.Mesh(tableGeo,tableMat);
table.position.set(0,1,0);
scene.add(table);

/* Players */
function player(x,z){
 const geo = new THREE.CapsuleGeometry(.4,1.2,4,8);
 const mat = new THREE.MeshStandardMaterial({color:0x8888ff});
 const p = new THREE.Mesh(geo,mat);
 p.position.set(x,1.6,z);
 scene.add(p);
}

player(2,1);
player(-2,1);

/* Skyline */
for(let i=0;i<60;i++){
 const h = Math.random()*20+10;
 const g = new THREE.BoxGeometry(2,h,2);
 const m = new THREE.MeshStandardMaterial({color:0x1a1a3a});
 const b = new THREE.Mesh(g,m);
 b.position.set((Math.random()*200)-100,h/2,-120);
 scene.add(b);
}

/* Moon */
const moonGeo = new THREE.SphereGeometry(12,32,32);
const moonMat = new THREE.MeshBasicMaterial({color:0xffffff});
moon = new THREE.Mesh(moonGeo,moonMat);
moon.position.set(-60,80,-200);
scene.add(moon);

/* Desktop movement */
document.addEventListener("keydown",(e)=>{
 if(e.key==="w") camera.position.z -= 1;
 if(e.key==="s") camera.position.z += 1;
 if(e.key==="a") camera.position.x -= 1;
 if(e.key==="d") camera.position.x += 1;
});

window.addEventListener("resize",()=>{
 camera.aspect = window.innerWidth/window.innerHeight;
 camera.updateProjectionMatrix();
 renderer.setSize(window.innerWidth,window.innerHeight);
});

}

function animate(){

renderer.setAnimationLoop(()=>{

 moon.rotation.y += 0.0006;

 renderer.render(scene,camera);

});

}
