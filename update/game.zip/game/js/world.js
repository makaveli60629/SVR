
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';
import { VRButton } from 'https://cdn.jsdelivr.net/npm/three@0.161/examples/jsm/webxr/VRButton.js';
import { initHands } from './modules/hands.js';
import { initTeleport } from './modules/teleport.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,0.1,1000);

/* FIXED SPAWN POSITION — NOT INSIDE TABLE */
camera.position.set(0,1.7,6);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.xr.enabled = true;

document.body.appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer));

/* LIGHT */

const light = new THREE.AmbientLight(0xffffff,1.5);
scene.add(light);

/* FLOOR */

const floorGeo = new THREE.PlaneGeometry(200,200);
const floorMat = new THREE.MeshStandardMaterial({color:0x111111});
const floor = new THREE.Mesh(floorGeo,floorMat);
floor.rotation.x = -Math.PI/2;
scene.add(floor);

/* TABLE */

const tableGeo = new THREE.CylinderGeometry(2.2,2.2,.25,32);
const tableMat = new THREE.MeshStandardMaterial({color:0x004400});
const table = new THREE.Mesh(tableGeo,tableMat);

table.position.set(0,1,0);
scene.add(table);

/* HANDS + TELEPORT */

initHands(renderer,scene);
initTeleport(renderer,scene,camera);

/* DESKTOP WALK */

document.addEventListener("keydown",(e)=>{

if(e.key==="w") camera.position.z -= 1;
if(e.key==="s") camera.position.z += 1;
if(e.key==="a") camera.position.x -= 1;
if(e.key==="d") camera.position.x += 1;

});

renderer.setAnimationLoop(()=>{

renderer.render(scene,camera);

});

window.addEventListener("resize",()=>{

camera.aspect = window.innerWidth/window.innerHeight;
camera.updateProjectionMatrix();
renderer.setSize(window.innerWidth,window.innerHeight);

});
