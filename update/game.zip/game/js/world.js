
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';
import { VRButton } from 'https://cdn.jsdelivr.net/npm/three@0.161/examples/jsm/webxr/VRButton.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,0.1,1000);
camera.position.set(0,1.7,20);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.xr.enabled = true;

document.body.appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer));

const loader = new THREE.TextureLoader();

/* Lighting */

const ambient = new THREE.AmbientLight(0xffffff,1.4);
scene.add(ambient);

const moonLight = new THREE.PointLight(0xffffff,4,600);
scene.add(moonLight);

const neon = new THREE.PointLight(0x8A2BE2,8,200);
neon.position.set(0,10,0);
scene.add(neon);

/* Floor */

const floorGeo = new THREE.PlaneGeometry(300,300);
const floorMat = new THREE.MeshStandardMaterial({color:0x111111,metalness:.7,roughness:.2});
const floor = new THREE.Mesh(floorGeo,floorMat);
floor.rotation.x = -Math.PI/2;
scene.add(floor);

/* Walls (shorter) */

const wallMat = new THREE.MeshStandardMaterial({color:0x111122});

function wall(x,z,r){

 const geo = new THREE.PlaneGeometry(300,12);
 const m = new THREE.Mesh(geo,wallMat);

 m.position.set(x,6,z);
 m.rotation.y = r;

 scene.add(m);

}

wall(0,-150,0);
wall(0,150,Math.PI);
wall(-150,0,Math.PI/2);
wall(150,0,-Math.PI/2);

/* Skyline */

for(let i=0;i<140;i++){

 const h = Math.random()*25+10;

 const g = new THREE.BoxGeometry(2,h,2);
 const m = new THREE.MeshStandardMaterial({color:0x1c1c3c});

 const b = new THREE.Mesh(g,m);

 b.position.set((Math.random()*200)-100,h/2,-120);

 scene.add(b);

}

/* Moon */

const moonTex = loader.load('../assets/textures/moon.png');

const moonGeo = new THREE.SphereGeometry(10,32,32);
const moonMat = new THREE.MeshBasicMaterial({map:moonTex});

const moon = new THREE.Mesh(moonGeo,moonMat);
moon.position.set(-60,80,-160);

scene.add(moon);

moonLight.position.copy(moon.position);

/* Purple upward particles */

const spriteMap = loader.load('../assets/textures/purple_glow.png');

const particles = [];

for(let i=0;i<120;i++){

 const mat = new THREE.SpriteMaterial({map:spriteMap,transparent:true,opacity:0.5});
 const sprite = new THREE.Sprite(mat);

 sprite.scale.set(1.2,1.2,1.2);
 sprite.position.set((Math.random()*40)-20,Math.random()*20, (Math.random()*40)-20);

 scene.add(sprite);

 particles.push(sprite);

}

/* Poker table (better shape) */

function pokerTable(x,z){

 const group = new THREE.Group();

 const topGeo = new THREE.CylinderGeometry(3,3,.3,64);
 const topMat = new THREE.MeshStandardMaterial({color:0x004400});
 const top = new THREE.Mesh(topGeo,topMat);
 top.position.y = 1;

 const baseGeo = new THREE.CylinderGeometry(.8,1,1,32);
 const baseMat = new THREE.MeshStandardMaterial({color:0x222222});
 const base = new THREE.Mesh(baseGeo,baseMat);

 group.add(top);
 group.add(base);

 group.position.set(x,0,z);

 scene.add(group);

}

pokerTable(0,0);
pokerTable(8,-8);
pokerTable(-8,-8);

/* Players */

function player(x,z){

 const geo = new THREE.CapsuleGeometry(.4,1.2,4,8);
 const mat = new THREE.MeshStandardMaterial({color:0x8888ff});

 const p = new THREE.Mesh(geo,mat);

 p.position.set(x,1.6,z);

 scene.add(p);

}

player(1,2);
player(-1,2);
player(2,-2);
player(-2,-2);

/* Movement */

document.addEventListener("keydown",(e)=>{

 if(e.key==="w") camera.position.z -= 1;
 if(e.key==="s") camera.position.z += 1;
 if(e.key==="a") camera.position.x -= 1;
 if(e.key==="d") camera.position.x += 1;

});

/* Animate */

renderer.setAnimationLoop(()=>{

 moon.rotation.y += 0.0008;

 particles.forEach(p=>{

  p.position.y += 0.02;

  if(p.position.y>25) p.position.y=0;

 });

 renderer.render(scene,camera);

});

window.addEventListener("resize",()=>{

 camera.aspect = window.innerWidth/window.innerHeight;
 camera.updateProjectionMatrix();
 renderer.setSize(window.innerWidth,window.innerHeight);

});
