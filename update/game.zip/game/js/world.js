
let scene,camera,renderer,moon;

window.addEventListener("load",init);

function init(){

document.getElementById("diag").innerHTML="SVR World Running";

scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,0.1,1000);
camera.position.set(0,2,12);

renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);

document.body.appendChild(renderer.domElement);

window.addEventListener("resize",()=>{
camera.aspect = window.innerWidth/window.innerHeight;
camera.updateProjectionMatrix();
renderer.setSize(window.innerWidth,window.innerHeight);
});

const light = new THREE.AmbientLight(0xffffff,2);
scene.add(light);

/* floor */

const floor = new THREE.Mesh(
new THREE.PlaneGeometry(500,500),
new THREE.MeshStandardMaterial({color:0x111111})
);

floor.rotation.x = -Math.PI/2;
scene.add(floor);

/* poker table */

const table = new THREE.Mesh(
new THREE.CylinderGeometry(3,3,0.4,64),
new THREE.MeshStandardMaterial({color:0x006600})
);

table.position.set(0,1,0);
scene.add(table);

/* skyline */

for(let i=0;i<40;i++){
let h = Math.random()*20+10;

let b = new THREE.Mesh(
new THREE.BoxGeometry(2,h,2),
new THREE.MeshStandardMaterial({color:0x1a1a3a})
);

b.position.set((Math.random()*120)-60,h/2,-120);
scene.add(b);
}

/* moon */

moon = new THREE.Mesh(
new THREE.SphereGeometry(10,32,32),
new THREE.MeshBasicMaterial({color:0xffffff})
);

moon.position.set(-40,60,-150);
scene.add(moon);

animate();

}

function animate(){

requestAnimationFrame(animate);

moon.rotation.y += 0.001;

renderer.render(scene,camera);

}
