
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';

export function initTables(scene){

function createTable(x,z){

const geo = new THREE.CylinderGeometry(2.2,2.2,.25,32);
const mat = new THREE.MeshStandardMaterial({color:0x004400});
const table = new THREE.Mesh(geo,mat);

table.position.set(x,.8,z);
scene.add(table);

}

createTable(0,0);
createTable(6,-6);
createTable(-6,-6);

console.log("Poker tables loaded");

}
