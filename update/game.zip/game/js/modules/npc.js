
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';

export function initNPC(scene){

const geo = new THREE.BoxGeometry(.6,1.6,.6);
const mat = new THREE.MeshStandardMaterial({color:0xaaaaaa});

const npc = new THREE.Mesh(geo,mat);
npc.position.set(0,1.6,-2);

scene.add(npc);

console.log("NPC Eric placeholder loaded");

}
