
export function initMultiplayer(){

console.log("Multiplayer architecture ready (stub)");

}
