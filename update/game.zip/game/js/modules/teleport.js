
function teleport(){
console.log("teleport triggered");
}
