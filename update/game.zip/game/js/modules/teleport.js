
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';

export function initTeleport(renderer,scene,camera){

const controller = renderer.xr.getController(0);
scene.add(controller);

const rayGeo = new THREE.BufferGeometry().setFromPoints([
 new THREE.Vector3(0,0,0),
 new THREE.Vector3(0,0,-6)
]);

const rayMat = new THREE.LineBasicMaterial({color:0xaa00ff});
const ray = new THREE.Line(rayGeo,rayMat);

controller.add(ray);

/* simple teleport */

controller.addEventListener("selectstart",()=>{

 const dir = new THREE.Vector3(0,0,-1).applyQuaternion(controller.quaternion);

 camera.position.add(dir.multiplyScalar(3));

});

}
