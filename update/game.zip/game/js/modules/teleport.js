
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';

export function initTeleport(scene){

const markerGeo = new THREE.RingGeometry(.25,.35,32);
const markerMat = new THREE.MeshBasicMaterial({color:0x8A2BE2,side:THREE.DoubleSide});
const marker = new THREE.Mesh(markerGeo,markerMat);

marker.rotation.x = -Math.PI/2;
marker.position.set(0,.01,2);

scene.add(marker);

console.log("Teleport system initialized");

}
