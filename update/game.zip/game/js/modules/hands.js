
function initHands(){
console.log("meta hands ready");
}
