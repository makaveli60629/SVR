
export function initHands(scene){

console.log("VR hands placeholder initialized");

}
