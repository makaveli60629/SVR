
import { XRHandModelFactory } from 'https://cdn.jsdelivr.net/npm/three@0.161/examples/jsm/webxr/XRHandModelFactory.js';

export function initHands(renderer,scene){

const factory = new XRHandModelFactory();

const hand1 = renderer.xr.getHand(0);
hand1.add(factory.createHandModel(hand1,"mesh"));
scene.add(hand1);

const hand2 = renderer.xr.getHand(1);
hand2.add(factory.createHandModel(hand2,"mesh"));
scene.add(hand2);

console.log("Meta Quest hand tracking enabled");

}
