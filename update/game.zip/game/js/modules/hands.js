
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js';

export function initHands(renderer,scene){

const controller1 = renderer.xr.getController(0);
const controller2 = renderer.xr.getController(1);

const geo = new THREE.SphereGeometry(.05,16,16);
const mat = new THREE.MeshBasicMaterial({color:0x8844ff});

const hand1 = new THREE.Mesh(geo,mat);
const hand2 = new THREE.Mesh(geo,mat);

controller1.add(hand1);
controller2.add(hand2);

scene.add(controller1);
scene.add(controller2);

}
