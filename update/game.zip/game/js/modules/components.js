import { CONFIG, CHAIRS } from './config.js';
import { polarToXZ, lookAtYawDegrees, setStatus, setTeleportState } from './helpers.js';

const ARC_POINTS = [];

function createGlowRing(color = '#b380ff') {
  const ring = document.createElement('a-ring');
  ring.setAttribute('radius-inner', 0.42);
  ring.setAttribute('radius-outer', 0.64);
  ring.setAttribute('rotation', '-90 0 0');
  ring.setAttribute('material', `color: ${color}; shader: flat; opacity: 0.65; transparent: true; side: double`);
  ring.classList.add('chair-glow');
  return ring;
}

function attachSimpleHandVisual(el, side) {
  const palm = document.createElement('a-sphere');
  palm.setAttribute('radius', 0.045);
  palm.setAttribute('position', side === 'left' ? '0.015 -0.015 0.01' : '-0.015 -0.015 0.01');
  palm.setAttribute('material', 'color: #9f7fff; emissive: #5b2cff; emissiveIntensity: 0.45; roughness: 0.4');
  el.appendChild(palm);

  const finger = document.createElement('a-box');
  finger.setAttribute('depth', 0.08);
  finger.setAttribute('height', 0.02);
  finger.setAttribute('width', 0.045);
  finger.setAttribute('position', side === 'left' ? '0.02 0 0.045' : '-0.02 0 0.045');
  finger.setAttribute('material', 'color: #c9b0ff; emissive: #4f25cc; emissiveIntensity: 0.3; roughness: 0.5');
  el.appendChild(finger);
}

function buildSkyline() {
  const root = document.getElementById('skylineRoot');
  for (let i = 0; i < 52; i++) {
    const angle = (i / 52) * Math.PI * 2;
    const radius = 17 + (i % 5) * 0.6;
    const h = 4 + (i % 9) * 1.2;
    const box = document.createElement('a-box');
    box.setAttribute('position', `${Math.sin(angle) * radius} ${h / 2} ${Math.cos(angle) * radius}`);
    box.setAttribute('depth', 1.3 + (i % 3) * 0.35);
    box.setAttribute('width', 1.2 + (i % 4) * 0.3);
    box.setAttribute('height', h.toFixed(2));
    box.setAttribute('material', 'color: #0d0c16; roughness: 0.9; metalness: 0.05; emissive: #1d1030; emissiveIntensity: 0.18');
    root.appendChild(box);

    if (i % 2 === 0) {
      const lightStrip = document.createElement('a-box');
      lightStrip.setAttribute('position', `${Math.sin(angle) * radius} ${Math.min(h - 0.5, 2.2 + (i % 4) * 1.4)} ${Math.cos(angle) * radius}`);
      lightStrip.setAttribute('depth', 1.45);
      lightStrip.setAttribute('width', 0.08);
      lightStrip.setAttribute('height', Math.max(0.8, h * 0.45));
      lightStrip.setAttribute('material', 'color: #b380ff; emissive: #7a35ff; emissiveIntensity: 0.65; shader: flat; opacity: 0.72; transparent: true');
      root.appendChild(lightStrip);
    }
  }

  const moon = document.createElement('a-sphere');
  moon.setAttribute('radius', 2.25);
  moon.setAttribute('position', '-14 18 -30');
  moon.setAttribute('segments-width', 28);
  moon.setAttribute('segments-height', 18);
  moon.setAttribute('material', 'src: #moonTex; roughness: 1; metalness: 0; emissive: #151525; emissiveIntensity: 0.12');
  root.appendChild(moon);

  const mars = document.createElement('a-sphere');
  mars.setAttribute('radius', 1.35);
  mars.setAttribute('position', '16 15 -26');
  mars.setAttribute('material', 'color: #a54e36; emissive: #4b130d; emissiveIntensity: 0.18; roughness: 0.95');
  root.appendChild(mars);

  const north = document.createElement('a-text');
  north.setAttribute('value', 'NORTH');
  north.setAttribute('position', '0 0.06 8.6');
  north.setAttribute('rotation', '-90 180 0');
  north.setAttribute('align', 'center');
  north.setAttribute('color', '#8f6ce0');
  north.setAttribute('width', 6);
  root.appendChild(north);
}

function buildTable() {
  const root = document.getElementById('tableRoot');

  const felt = document.createElement('a-cylinder');
  felt.setAttribute('radius', CONFIG.table.radius);
  felt.setAttribute('height', 0.06);
  felt.setAttribute('position', `0 ${CONFIG.table.height} 0`);
  felt.setAttribute('material', 'src: #tableLogo; roughness: 0.88; metalness: 0.02');
  root.appendChild(felt);

  const rim = document.createElement('a-torus');
  rim.setAttribute('radius', CONFIG.table.radius - 0.04);
  rim.setAttribute('radius-tubular', 0.13);
  rim.setAttribute('rotation', '90 0 0');
  rim.setAttribute('position', `0 ${CONFIG.table.height + 0.055} 0`);
  rim.setAttribute('material', 'color: #111111; roughness: 0.4; metalness: 0.15; emissive: #1b0d23; emissiveIntensity: 0.1');
  root.appendChild(rim);

  const body = document.createElement('a-cylinder');
  body.setAttribute('radius', 1.26);
  body.setAttribute('height', 0.74);
  body.setAttribute('position', '0 0.45 0');
  body.setAttribute('material', 'color: #1a1a1f; roughness: 0.7; metalness: 0.1');
  root.appendChild(body);

  const base = document.createElement('a-cylinder');
  base.setAttribute('radius', 0.7);
  base.setAttribute('height', 0.12);
  base.setAttribute('position', '0 0.06 0');
  base.setAttribute('material', 'color: #101014; roughness: 0.8; metalness: 0.08');
  root.appendChild(base);
}

function buildChairs(sceneEl) {
  const root = document.getElementById('chairsRoot');
  const state = sceneEl.systems['svr-state'];

  CHAIRS.forEach((chair, idx) => {
    const p = polarToXZ(CONFIG.chairRadius, chair.angle);
    const chairEl = document.createElement('a-entity');
    chairEl.setAttribute('position', `${p.x.toFixed(3)} 0 ${p.z.toFixed(3)}`);
    chairEl.setAttribute('rotation', `0 ${180 + chair.angle} 0`);
    chairEl.classList.add('clickable');
    chairEl.dataset.chairId = chair.id;
    chairEl.dataset.seatIndex = String(idx);
    chairEl.setAttribute('svr-seat', `seat-index: ${idx}`);

    const glow = createGlowRing();
    glow.setAttribute('position', '0 0.015 0');
    chairEl.appendChild(glow);

    const seat = document.createElement('a-cylinder');
    seat.setAttribute('radius', 0.34);
    seat.setAttribute('height', 0.08);
    seat.setAttribute('position', `0 ${CONFIG.chairHeight} 0`);
    seat.setAttribute('material', 'color: #202028; roughness: 0.72; metalness: 0.08');
    chairEl.appendChild(seat);

    const base = document.createElement('a-cylinder');
    base.setAttribute('radius', 0.08);
    base.setAttribute('height', 0.54);
    base.setAttribute('position', '0 0.27 0');
    base.setAttribute('material', 'color: #16161d; roughness: 0.7');
    chairEl.appendChild(base);

    const back = document.createElement('a-box');
    back.setAttribute('width', 0.58);
    back.setAttribute('height', 0.6);
    back.setAttribute('depth', 0.08);
    back.setAttribute('position', '0 0.85 -0.28');
    back.setAttribute('material', 'color: #252530; roughness: 0.68; metalness: 0.06; emissive: #140d20; emissiveIntensity: 0.08');
    chairEl.appendChild(back);

    const tag = document.createElement('a-text');
    tag.setAttribute('value', idx === 0 ? 'PLAYER' : 'SEAT');
    tag.setAttribute('align', 'center');
    tag.setAttribute('width', 2.4);
    tag.setAttribute('position', '0 0.09 0');
    tag.setAttribute('rotation', '-90 180 0');
    tag.setAttribute('color', idx === 0 ? '#d6b36a' : '#b380ff');
    chairEl.appendChild(tag);

    root.appendChild(chairEl);
    state.chairEls.push(chairEl);
  });
}

function buildDealer() {
  const root = document.getElementById('dealerRoot');
  const dealer = document.createElement('a-entity');
  dealer.setAttribute('fbx-model', '#ericModel');
  dealer.setAttribute('position', '0 0 -2.05');
  dealer.setAttribute('rotation', '0 0 0');
  dealer.setAttribute('scale', '0.0053 0.0053 0.0053');
  root.appendChild(dealer);

  const dealerGlow = document.createElement('a-cylinder');
  dealerGlow.setAttribute('radius', 0.5);
  dealerGlow.setAttribute('height', 0.04);
  dealerGlow.setAttribute('position', '0 0.02 -2.05');
  dealerGlow.setAttribute('material', 'color: #8f5cff; emissive: #5d1cff; emissiveIntensity: 0.4; opacity: 0.45; transparent: true; shader: flat');
  root.appendChild(dealerGlow);
}

AFRAME.registerSystem('svr-state', {
  init() {
    this.teleportArmed = false;
    this.teleportTarget = null;
    this.activeSeatIndex = 0;
    this.rigEl = null;
    this.camRootEl = null;
    this.leftHandEl = null;
    this.rightHandEl = null;
    this.watchEl = null;
    this.markerEl = null;
    this.arcLine = null;
    this.arcMaterial = new THREE.LineBasicMaterial({ color: 0xd3a8ff, transparent: true, opacity: 0.92 });
    this.arcGeometry = new THREE.BufferGeometry();
    this.arcLine = new THREE.Line(this.arcGeometry, this.arcMaterial);
    this.arcLine.visible = false;
    this.chairEls = [];
  },
  setTeleportArmed(v) {
    this.teleportArmed = !!v;
    setTeleportState(this.teleportArmed);
    setStatus(this.teleportArmed ? 'Teleport armed from watch' : 'Teleport off');
    if (!this.teleportArmed) {
      this.teleportTarget = null;
      if (this.markerEl) this.markerEl.setAttribute('visible', false);
      if (this.arcLine) this.arcLine.visible = false;
    }
  },
  toggleTeleport() {
    this.setTeleportArmed(!this.teleportArmed);
  },
  standUp() {
    if (!this.rigEl) return;
    const { x, y, z, rotY } = CONFIG.spawn;
    this.rigEl.setAttribute('position', `${x} ${y} ${z}`);
    this.rigEl.setAttribute('rotation', `0 ${rotY} 0`);
    this.activeSeatIndex = 0;
    setStatus('Standing at spawn');
  },
  sitAt(seatIndex) {
    const chair = CHAIRS[seatIndex];
    if (!chair || !this.rigEl) return;
    this.rigEl.setAttribute('position', `${chair.seatX} ${CONFIG.chairSeatY} ${chair.seatZ}`);
    this.rigEl.setAttribute('rotation', `0 ${chair.lookY} 0`);
    if (this.camRootEl) this.camRootEl.setAttribute('position', `0 ${CONFIG.seatEyeHeight} 0`);
    this.activeSeatIndex = seatIndex;
    setStatus(`Seated at ${chair.id}`);
  },
  resetEyeHeight() {
    if (this.camRootEl) this.camRootEl.setAttribute('position', '0 1.65 0');
  },
  teleportToTarget() {
    if (!this.teleportArmed || !this.teleportTarget || !this.rigEl) return;
    const t = this.teleportTarget;
    this.resetEyeHeight();
    this.rigEl.setAttribute('position', `${t.x.toFixed(3)} 0 ${t.z.toFixed(3)}`);
    this.setTeleportArmed(false);
    setStatus('Teleported');
  },
  updateArc() {
    if (!this.rightHandEl || !this.arcLine || !this.teleportArmed) {
      if (this.arcLine) this.arcLine.visible = false;
      return;
    }
    const handObj = this.rightHandEl.object3D;
    if (!handObj) return;
    const start = new THREE.Vector3();
    handObj.getWorldPosition(start);
    start.y += 0.02;

    const intersection = this.rightHandEl.components.raycaster?.getIntersection(document.getElementById('teleportFloor'));
    if (!intersection) {
      this.teleportTarget = null;
      if (this.markerEl) this.markerEl.setAttribute('visible', false);
      this.arcLine.visible = false;
      return;
    }
    const end = intersection.point.clone();
    this.teleportTarget = { x: end.x, z: end.z };

    if (this.markerEl) {
      this.markerEl.setAttribute('position', `${end.x.toFixed(3)} 0.03 ${end.z.toFixed(3)}`);
      this.markerEl.setAttribute('visible', true);
    }

    ARC_POINTS.length = 0;
    for (let i = 0; i < CONFIG.teleportArcSegments; i++) {
      const t = i / (CONFIG.teleportArcSegments - 1);
      const p = start.clone().lerp(end, t);
      const lift = Math.sin(Math.PI * t) * CONFIG.teleportArcHeight;
      p.y += lift;
      ARC_POINTS.push(p.x, p.y, p.z);
    }
    this.arcGeometry.setAttribute('position', new THREE.Float32BufferAttribute(ARC_POINTS, 3));
    this.arcGeometry.computeBoundingSphere();
    this.arcLine.visible = true;
  }
});

AFRAME.registerComponent('svr-game', {
  init() {
    const sceneEl = this.el;
    const state = sceneEl.systems['svr-state'];

    state.rigEl = document.getElementById('rig');
    state.camRootEl = document.getElementById('camRoot');
    state.leftHandEl = document.getElementById('leftHand');
    state.rightHandEl = document.getElementById('rightHand');

    buildSkyline();
    buildTable();
    buildChairs(sceneEl);
    buildDealer();

    const markerRoot = document.getElementById('markerRoot');
    const marker = document.createElement('a-ring');
    marker.id = 'teleportMarker';
    marker.setAttribute('radius-inner', 0.28);
    marker.setAttribute('radius-outer', 0.42);
    marker.setAttribute('rotation', '-90 0 0');
    marker.setAttribute('material', 'color: #d3a8ff; emissive: #8b4bff; emissiveIntensity: 0.72; shader: flat; opacity: 0.82; transparent: true; side: double');
    marker.setAttribute('visible', 'false');
    markerRoot.appendChild(marker);
    state.markerEl = marker;

    sceneEl.object3D.add(state.arcLine);

    state.rightHandEl.addEventListener('triggerup', () => {
      if (state.teleportArmed && state.teleportTarget) state.teleportToTarget();
    });

    document.getElementById('teleportFloor').addEventListener('click', (evt) => {
      if (!state.teleportArmed) return;
      const point = evt?.detail?.intersection?.point;
      if (!point) return;
      state.teleportTarget = { x: point.x, z: point.z };
      state.teleportToTarget();
    });

    window.addEventListener('keydown', (e) => {
      const key = e.key.toLowerCase();
      if (key === 't') state.toggleTeleport();
      if (key === 'f') { state.resetEyeHeight(); state.standUp(); }
      if (key === 'r') { state.resetEyeHeight(); state.standUp(); }
    });

    setTeleportState(false);
    setStatus('Scene ready');
  },
  tick() {
    const state = this.el.systems['svr-state'];
    state.updateArc();
    state.chairEls.forEach((chairEl, idx) => {
      const glow = chairEl.querySelector('.chair-glow');
      if (!glow) return;
      const t = performance.now() * 0.0024 + idx;
      const active = idx === state.activeSeatIndex;
      const opacity = active ? 0.95 : 0.35 + (Math.sin(t) * 0.08 + 0.08);
      glow.setAttribute('material', `color: ${active ? '#e2c389' : '#b380ff'}; shader: flat; opacity: ${opacity.toFixed(3)}; transparent: true; side: double`);
    });
  }
});

AFRAME.registerComponent('svr-hand', {
  schema: { side: { default: 'right' } },
  init() {
    attachSimpleHandVisual(this.el, this.data.side);
    if (this.data.side === 'right') {
      this.el.setAttribute('line', 'color: #caa2ff; opacity: 0.95');
    }
  }
});

AFRAME.registerComponent('svr-seat', {
  schema: { seatIndex: { type: 'int', default: 0 } },
  init() {
    this.el.addEventListener('click', () => {
      const state = this.el.sceneEl.systems['svr-state'];
      state.sitAt(this.data.seatIndex);
    });
  }
});

AFRAME.registerComponent('svr-watch', {
  init() {
    const sceneEl = this.el.sceneEl;
    const state = sceneEl.systems['svr-state'];
    state.watchEl = this.el;

    const frame = document.createElement('a-box');
    frame.setAttribute('width', 0.18);
    frame.setAttribute('height', 0.11);
    frame.setAttribute('depth', 0.016);
    frame.setAttribute('material', 'color: #07070b; metalness: 0.25; roughness: 0.45; emissive: #140d20; emissiveIntensity: 0.25');
    this.el.appendChild(frame);

    const screen = document.createElement('a-plane');
    screen.setAttribute('width', 0.166);
    screen.setAttribute('height', 0.096);
    screen.setAttribute('position', '0 0 0.0091');
    screen.setAttribute('material', 'color: #11111a; emissive: #34145b; emissiveIntensity: 0.35; opacity: 0.95; transparent: true');
    this.el.appendChild(screen);

    const title = document.createElement('a-text');
    title.setAttribute('value', 'SVR');
    title.setAttribute('position', '0 0.038 0.0102');
    title.setAttribute('align', 'center');
    title.setAttribute('width', 0.36);
    title.setAttribute('color', '#e9ddff');
    this.el.appendChild(title);

    const buttons = [
      { label: 'TP', x: -0.055, action: 'teleport' },
      { label: 'ST', x: 0, action: 'stand' },
      { label: 'HM', x: 0.055, action: 'home' }
    ];

    buttons.forEach(btn => {
      const b = document.createElement('a-plane');
      b.setAttribute('width', 0.045);
      b.setAttribute('height', 0.03);
      b.setAttribute('position', `${btn.x} -0.016 0.0105`);
      b.setAttribute('material', 'color: #241131; emissive: #6628b8; emissiveIntensity: 0.35; opacity: 0.94; transparent: true');
      b.classList.add('clickable');
      b.dataset.action = btn.action;
      const txt = document.createElement('a-text');
      txt.setAttribute('value', btn.label);
      txt.setAttribute('align', 'center');
      txt.setAttribute('width', 0.24);
      txt.setAttribute('position', '0 0 0.001');
      txt.setAttribute('color', '#f4ebff');
      b.appendChild(txt);
      b.addEventListener('click', () => {
        if (btn.action === 'teleport') state.toggleTeleport();
        if (btn.action === 'stand') { state.resetEyeHeight(); state.standUp(); }
        if (btn.action === 'home') { state.resetEyeHeight(); state.standUp(); }
      });
      this.el.appendChild(b);
    });
  },
  tick() {
    const leftHand = document.getElementById('leftHand');
    if (!leftHand) return;
    const obj = leftHand.object3D;
    const watch = this.el.object3D;
    obj.getWorldPosition(watch.position);
    obj.getWorldQuaternion(watch.quaternion);
    watch.position.x += 0.05;
    watch.position.y += 0.02;
    watch.position.z += 0.05;
    watch.rotateX(-1.25);
    watch.rotateZ(0.35);
  }
});
