export const CONFIG = {
  spawn: { x: 0, y: 0, z: 4.1, rotY: 180 },
  table: { radius: 1.55, height: 0.84 },
  chairRadius: 2.08,
  chairHeight: 0.52,
  chairSeatY: 0.0,
  seatEyeHeight: 1.2,
  teleportArcSegments: 20,
  teleportArcHeight: 1.2,
  colors: {
    purple: '#b380ff',
    purpleStrong: '#d3a8ff',
    purpleDark: '#2a1137',
    floor: '#050508',
    floorCenter: '#0b0810',
    gold: '#d6b36a'
  }
};

export const CHAIRS = [
  { id: 'south', angle: 0,   seatX: 0,    seatZ: 2.02,  lookY: 180 },
  { id: 'southwest', angle: 55, seatX: 1.62, seatZ: 1.2, lookY: 235 },
  { id: 'southeast', angle: -55, seatX: -1.62, seatZ: 1.2, lookY: 125 },
  { id: 'northwest', angle: 125, seatX: 1.62, seatZ: -1.2, lookY: 305 },
  { id: 'northeast', angle: -125, seatX: -1.62, seatZ: -1.2, lookY: 55 },
  { id: 'dealerSideOff', angle: 180, seatX: 0, seatZ: -2.05, lookY: 0 }
];
