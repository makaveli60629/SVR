export function setStatus(text){
  const el = document.getElementById('status');
  if (el) el.textContent = text;
}

export function setTeleportState(isOn){
  const el = document.getElementById('teleportState');
  if (el) el.textContent = `Teleport: ${isOn ? 'ARMED' : 'OFF'}`;
}

export function polarToXZ(radius, degrees){
  const r = degrees * Math.PI / 180;
  return { x: Math.sin(r) * radius, z: Math.cos(r) * radius };
}

export function lookAtYawDegrees(fromX, fromZ, toX, toZ){
  return Math.atan2(toX - fromX, toZ - fromZ) * 180 / Math.PI;
}
