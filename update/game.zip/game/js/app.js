import './modules/config.js';
import './modules/helpers.js';
import './modules/components.js';

window.addEventListener('DOMContentLoaded', () => {
  const scene = document.querySelector('a-scene');
  if (!scene.hasLoaded) {
    scene.addEventListener('loaded', () => {
      const status = document.getElementById('status');
      if (status) status.textContent = 'Loaded';
    }, { once: true });
  }
});
