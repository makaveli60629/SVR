
AFRAME.registerComponent('teleportable', {
  init: function () {
    this.el.addEventListener('click', () => {
      const rig = document.getElementById('rig');
      rig.setAttribute('position', this.el.getAttribute('position'));
    });
  }
});
