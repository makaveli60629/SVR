# Phase AN — Poker Action Controls Lock

Added watch CALL / RAISE / FOLD plus desktop C/R/F fallback. Preserved lobby routes, Camera 3, Reiki, PGA, Sponsor, Legends, and Scorpion scenes. Site untouched.
