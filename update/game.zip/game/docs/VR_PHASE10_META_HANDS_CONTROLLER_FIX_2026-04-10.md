SVR Poker VR Phase 10 — Meta hands + controller locomotion fix

Changes
- Removed camera-mounted fake arms shell.
- Removed camera-locked quick-watch fallback.
- Removed tracked-hand watch overlay to stop screen-stuck objects.
- Meta hands remain the primary in-world hand presentation.
- Added more robust controller axis handling using thumbstickmoved and axismove.
- Added Oculus Touch fallback bindings alongside Meta Touch bindings.
- Added controller cursor enable/disable on connect/disconnect for ray clicks and teleport pads.
- Preserved stable VR boot path, standing spawn, south seat, Reiki hub, PGA hub, and ad wall.

Testing
- With Meta hand tracking on, no fake arms/watch should stick to the screen.
- With controllers active, left stick should move and right stick should snap-turn.
- Point controller rays at floor teleport pads or world buttons and press trigger to move.
