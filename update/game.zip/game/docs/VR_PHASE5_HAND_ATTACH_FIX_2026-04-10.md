SVR Poker VR Phase 5 — Hand Attachment Fix

What changed
- replaced floating hand/controller setup with separate controller fallback and tracked-hand entities
- added left and right hand-tracking-controls entities so hands follow real hand poses in WebXR
- kept controller laser fallback for interaction, movement, and snap-turn
- moved the watch onto the left tracked hand so it stays attached to the wrist path instead of floating from the controller root
- preserved standing spawn, south seat, teleport pads, Reiki, PGA, and sponsor wall

Testing
- on Quest hand-tracking: hands should appear attached to the real hands
- on controllers: controller rays should still work for movement and snap-turn
- watch should stay on the left wrist path in hand-tracking mode
