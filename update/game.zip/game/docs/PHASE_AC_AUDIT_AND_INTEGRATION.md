# Phase AC — Audit + Texture / Original Lobby Integration

## Audit result
- Current live base is booting after the `svrStatus` fix.
- Prior boot failures came from unsafe status binding and an external XR controller-model dependency.
- Original assets exist in SVR-main.zip, but the full package is too large for a 25MB game.zip.
- This phase integrates a selected original texture subset under the 25MB limit.

## Integrated
- Table felt texture
- Floor/cloth texture
- Leather table/chair texture
- Moon diffuse texture
- Table logo texture
- Original table.glb staged for a later loader phase

## Runtime safety
Uses only Three.js TextureLoader at runtime. GLB/FBX loaders are not added yet so the lobby stays boot-safe.

Open `/game/?v=phase-ac&t=003`.
