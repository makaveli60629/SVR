# Phase — Lobby return + Reiki + PGA + local 07 audio

Build: 20260410G-LOBBY-RETURN-AUDIO

## Base
- Restored from uploaded `game-audit-repo-source-lock.zip` as the active game-only lobby baseline.

## Included
- Main lobby restored from source-lock baseline
- Reiki room preserved
- Scorpion room preserved
- PGA hub preserved in lobby
- PGA room route added at `/game/pga/`
- Fist-near-face hand teleport preserved
- Watch baseline preserved from source-lock runtime
- Local `07.mp3` added under `assets/audio/07.mp3` with a HUD Music toggle

## Intent
- Return the game lobby/runtime only
- Keep website untouched
- Keep modular room structure for later upgrades
