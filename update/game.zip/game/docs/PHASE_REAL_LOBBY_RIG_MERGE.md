SVR Poker - Real Lobby Rig Merge Test

This pass moves the working dealer + seated player bot layout out of the isolated calibration scene and into a larger lobby shell based on the original SVR-main style layout.

What this pass does:
- preserves a south/front open player seat
- merges dealer and seated bot layout into a larger lobby shell
- keeps Eric as a visible scale reference
- adds simple Reiki and PGA wall markers for orientation
- keeps the package self-contained for update/game.zip deployment

What this pass does not claim:
- final animation retargeting
- final table materials
- full original branded lobby restoration
- final room/module polish
