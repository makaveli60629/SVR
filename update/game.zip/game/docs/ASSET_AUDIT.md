# SVR Poker — Consolidated Build Asset Audit

## Baseline audited
- Current working `game.zip` recovery shell
- `game_phase54_watch_anchor.zip`
- `SVR-main.zip`
- `ChatGPT_SVR_Poker_Operator_Manifest_2026-03-29.md`

## Key findings
- The current working recovery shell booted, but the shipped Phase 56 package was not actually self-contained: it referenced `assets/textures/logo.png` and `assets/textures/logo-table.png` even though those assets were missing from that zip.
- Historical repo source and shipped runtime are still diverged. The repo `game/index.html` is an older prototype and was not used as the runtime base.
- The safest path remains the boot-safe recovery shell plus restoration/polish, not a restart.

## Assets included in this build
- `game/assets/textures/logo.png` — resized local logo for splash/watch/moon branding
- `game/assets/textures/logo-table.png` — resized local table logo texture

## Runtime design choices
- No FBX or GLTF file is required at boot.
- All demo-critical geometry is built from A-Frame primitives.
- Historical art-heavy content was not made boot-critical.
- CDN A-Frame fallback remains in place because no trusted local A-Frame runtime was available in the uploaded archives.

## Remaining asset gaps
- No validated dealer/NPC animated asset path was restored into boot.
- No restored full historical environment textures were made required for startup.
- Cards/chips remain stylized demo props rather than final art assets.
