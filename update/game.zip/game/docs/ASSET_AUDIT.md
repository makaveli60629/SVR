SVR Poker phase 56 audit

Key findings:
- The current shipped game pack is still the recovery lobby shell, not the full historical lobby restore.
- The prior watch pass referenced rightHand without declaring it, which can break runtime input/watch logic.
- The deploy workflow overlays update/game.zip onto build/game, so a self-contained game zip remains the safest short-term path.
- This phase keeps the stable boot flow and patches watch/controller/deal logic only.
