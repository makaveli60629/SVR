# SVR Poker — Phase 57 Asset Audit

## Baseline audited
- Current working `game.zip` recovery shell
- `game_phase54_watch_anchor.zip`
- `SVR-main.zip`
- `ChatGPT_SVR_Poker_Operator_Manifest_2026-03-29.md`

## Key findings
- The current working runtime is still the recovery shell, so the safest path remains controlled restore-and-polish rather than swapping runtime bases.
- Historical repo source and shipped runtime are still diverged. The repo `game/index.html` is not the live runtime base.
- The historical archive contains useful safe texture assets that can improve the lobby without making boot depend on FBX or GLTF content.

## Assets included in this build
- `game/assets/textures/logo.png`
- `game/assets/textures/logo-table.png`
- `game/assets/textures/tablefelt.png` — restored from `SVR-main.zip`
- `game/assets/textures/moon_diffuse.png` — restored from `SVR-main.zip`

## Runtime design choices
- No FBX or GLTF file is required at boot.
- All demo-critical geometry is still built from A-Frame primitives.
- Historical textures were merged in, but historical model files remain non-boot-critical.
- CDN A-Frame fallback remains in place because no trusted local A-Frame runtime was available in the uploaded archives.

## Remaining asset gaps
- No validated dealer/NPC animated asset path was restored into boot.
- The recovery shell still needs a deeper lobby art merge if headset stability remains solid.
- Cards/chips remain stylized demo props rather than final gameplay art.
