Phase 51 audit:
- Fixed XR rig mismatch by separating desktop eye height from VR local-floor mode.
- Watch now anchors from the tracked left hand/controller in VR and falls back to camera space on desktop.
- Added local logo asset for splash screen and watch branding.
- Expanded table card layout for player/community demo interaction.
- Current build is still the stable recovery lobby shell, not the full historical lobby restore.
