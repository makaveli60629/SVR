# ASSET AUDIT

- Boot path remains single-file and A-Frame only.
- Added Quest hand-tracking entities for visible Meta hands.
- Added controller thumbstick locomotion fallback in the same file.
- Lowered default eye heights to reduce the too-tall camera feel.
- This phase is still the recovery/stable lobby shell, not the full original lobby restore.
