# SVR Poker — Phase 63 Asset Audit

## Baseline audited
- Uploaded `game_chat_only_copy.zip` exact-shell recovery source
- Current `game.zip` recovery package
- `SVR-main.zip` repo backup

## Key findings
- The uploaded chat-only build remains the closest stable source for the preferred lobby shell.
- The primitive table path is currently safer than the recent broken high-table GLB path.
- Preview mode is safest when kept separate from the playable game page.

## Assets included in this build
- `game/assets/textures/logo.png`
- `game/assets/textures/logo-table.png`
- `game/assets/textures/tablefelt.png`
- `game/assets/textures/moon_diffuse.png`
- `game/assets/models/eric.fbx`

## Runtime design choices
- The exact shell baseline is locked for future refinement work.
- No full-screen splash gate blocks normal entry.
- CAM 3 remains a preview-only browser spectator render.
- Demo-critical geometry remains safe to boot from A-Frame primitives.
