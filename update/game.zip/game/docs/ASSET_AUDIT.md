# Stable Boot Audit

## What changed
- Removed external FBX loader dependency from boot path.
- Removed module import chain from boot path.
- Replaced dealer FBX with a safe in-scene stand-in so the scene boots even when model loading is unreliable.
- Kept watch, chair glow, teleport, skyline, moon, and seating in one file.

## Why
The previous package had multiple boot-risk points at startup:
- external loader dependency
- FBX asset dependency
- module import dependency
- chained scene component initialization

This pass prioritizes boot reliability first.
