SVR Poker Phase 48 audit

This pack keeps the boot-safe single-file scene path and avoids FBX boot dependencies.
Included features:
- left wrist watch with TP / ST / HM
- watch-only teleport
- visible teleport arc and landing marker
- glowing chairs with seat snap
- right trigger fallback for Quest controllers
- safe chip stack and card lift/drop demo
- static dealer reference stand-in
