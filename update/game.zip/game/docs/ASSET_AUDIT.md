# SVR Poker — Phase 59 Asset Audit

## Baseline audited
- Current working `game.zip` recovery shell from phase 58
- `SVR-main.zip`
- `ChatGPT_SVR_Poker_Operator_Manifest_2026-03-29.md`

## Key findings
- The current safe runtime remains the boot-safe recovery shell, so this pass stays on that base.
- Historical source and shipped runtime are still diverged, so this pass avoids risky source-level scene replacement.
- A spectator/progress camera can be added safely without introducing boot-critical model dependencies.

## Assets included in this build
- `game/assets/textures/logo.png`
- `game/assets/textures/logo-table.png`
- `game/assets/textures/tablefelt.png`
- `game/assets/textures/moon_diffuse.png`
- `game/assets/textures/leather_dark.jpg`
- `game/assets/textures/cloth_diffuse.jpg`

## Runtime design choices
- No FBX or GLTF file is required at boot.
- Demo-critical geometry is still built from A-Frame primitives.
- CAM 3 is renderer-based and uses the existing runtime scene rather than a second duplicated scene.
- CDN A-Frame fallback remains in place because no trusted local A-Frame runtime was available in the uploaded archives.

## Remaining asset gaps
- No validated dealer/NPC animated asset path was restored into boot.
- Lobby is still a polished recovery shell rather than a full historical scene restore.
- Cards/chips remain demo props rather than final gameplay assets.
