# Phase AK — Scene Fit + Feature Lock

## Status
This build is based on the Phase AJ lobby audit package and keeps the boot-safe lobby path.

## Ready right now
- Main larger lobby shell
- Poker table area with open player seat target
- Eric/dealer reference and seated bot ring
- Reiki storefront and deeper Zen Den target
- PGA hub storefront target
- Legend wall / leaderboard-about-tourney boards
- Sponsor/store wall target
- Scorpion room target
- Earth, Moon, and Mars skyline set
- Camera 3 / live preview path via cam3.html and preview/autocam parameters
- 07.mp3, Reiki hub audio, and SVR After Dark playlist
- Desktop quick scene buttons and wrist quick-jump actions
- Meta hands plus Quest controller fallback locomotion/grab path

## Fit audit result
The scenes are present as fitted targets in the same world build. They are not separate loading screens. The current structure uses one stable lobby world and jumps to scene zones so the game avoids black-screen scene-load failures.

## Next production features
1. Poker gameplay lock: cards, chip stacks, table state, dealer prompts.
2. Dealer rig polish: Eric seated/standing dealer pose, arm reach, card-deal motion.
3. Watch final polish: larger hit areas, simpler buttons, no flipped text.
4. Quest polish: lower draw load, fewer duplicate particles, no shimmer.
5. Business layer: sponsor rotation, donation/community mission boards, hub info panels.

## Install
Replace update/game.zip with this package, commit, and push.
