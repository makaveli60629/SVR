# Phase 4 — PGA Range Physics

## Build label
PHASE-4-PGA-PHYSICS

## Scope
Game-only update. Site untouched.

## Added
- `game/modules/pga_range_physics.js`
- Controller-as-club visual in the private PGA Range.
- Ball hit detection from either Quest controller.
- Simple driving, chipping, and putting ball physics.
- Ball reset support.
- Desktop test shortcuts:
  - `K` = demo drive
  - `Y` = demo chip
  - `M` = demo putt
  - `X` = reset ball
- Phase 4 range instruction board.
- Runtime marker: `window.SVR_PGA_RANGE_PHASE4`.
- Scene marker: `scene.userData.SVR_PHASE4_PGA_RANGE_PHYSICS_READY`.

## Preserved locks
- No music / no audio payload.
- One-controller movement.
- 45-degree snap turn.
- Trigger-release teleport.
- Pinch leap disabled.
- Seat edge lock.
- Flat poker chips / visible bet movement.
- Left-first card dealing.
- Freestanding lobby storefront hubs.
- Phase 2 private module scenes.
- Phase 3 high moon, Mars, and starfield routing lock.

## Testing checklist
1. Enter the private PGA Range from the PGA storefront.
2. Use either Quest controller and swing through the ball.
3. Confirm the club guide appears while in the PGA Range.
4. Confirm the ball moves downrange and resets if it leaves the playable range.
5. On desktop, press `K` for a demo drive and `X` to reset the ball.

## Next phase recommendation
Phase 5 should refine the Reiki Grove private world and complete the meditation environment with denser trees, calmer lighting, seating markers, and stronger moon/star ambience.
