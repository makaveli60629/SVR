# Repo Notes Manifest — 2026-04-10G

## Locked game-only baseline
- Source package: `game-audit-repo-source-lock.zip`
- Added: `game/pga/` from room-network package
- Added local music asset: `game/assets/audio/07.mp3`

## Active routes
- `/game/` main lobby
- `/game/reiki/` Reiki room
- `/game/scorpion/` Scorpion room
- `/game/pga/` PGA room

## Preserved requirements
- Fist teleport remains active as fallback
- Watch stays on the source-lock baseline
- Website was not modified
