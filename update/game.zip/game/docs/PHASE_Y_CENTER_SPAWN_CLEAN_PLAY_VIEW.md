# Phase Y — Center Spawn + Clean Play View

This build keeps the working Phase X lobby and fixes the view composition.

## Fixed
- Starting camera moved farther back
- Table centered in the initial view
- View button now restores the centered table view
- Desktop HUD footprint reduced
- VR unsupported does not block the playable lobby
- Camera 3 remains preview-only

Open `/game/?v=phase-y`.
