# Phase M Refined

Refined mobile HUD, visible betting buttons, dealer deal animation, Enter VR preserved.

Open `/game/?v=phase-m-refined`.
