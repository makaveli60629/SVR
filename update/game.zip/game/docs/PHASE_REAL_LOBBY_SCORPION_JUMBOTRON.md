Build: 20260408-real-lobby-jumbotron-scorpion

Changes:
- Root /game/ remains the real lobby baseline.
- Added a Scorpion Room route at /game/sandbox/ and labeled it in the HUD.
- Added a Jumbotron button that opens the provided YouTube playlist in an overlay after user interaction.
- Preserved the separate Reiki room route at /game/reiki/.
- Startup uses the stable lobby main.js path with no seated-state boot crash.
