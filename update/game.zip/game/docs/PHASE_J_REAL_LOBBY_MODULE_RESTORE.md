# Phase J — Real Lobby Module Restore

## Added
- Larger visible lobby scaffold
- North / Claudia-side lock marker
- Eric dealer rig anchor slot with visible hand anchors
- Real module slots for:
  - Trueitive Reiki
  - Juan Espejo PGA
- Lobby Module Check button
- Deploy asset manifest
- Camera 3 live preview preserved
- Poker engine and sponsor system preserved

## Controls
- S: sit/stand
- T: teleport arc
- D: deal demo
- C: chip demo
- E: poker engine test
- A: rotate sponsor
- L: lobby module check
- R: reset view

## Next
Phase K should merge optimized real assets:
- Eric FBX/GLB
- real lobby visual assets
- Trueitive logo
- PGA signage/profile assets
- 07.mp3 when available
