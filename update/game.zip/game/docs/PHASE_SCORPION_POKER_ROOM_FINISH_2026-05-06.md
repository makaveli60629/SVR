# Phase — Scorpion Poker Room Finish Pass

## Scope
Game-only update. Site files were not touched.

## Fixed / added
- Rebuilt Scorpion Room as an actual poker room destination.
- Added a dedicated Scorpion poker table with felt, chips, cards, seating, and glow markers.
- Added a large glass city-view wall with a looking-down high-overlook effect.
- Added procedural city-depth buildings outside the Scorpion Room glass so the room feels above the skyline without shipping a huge city model.
- Added Scorpion room signs and status panels designed to stay readable.
- Raised Moon and Mars above and behind the skyline, keeping them visible but outside the city buildings.
- Removed unapproved wellness-brand text and image references from this package.
- Replaced removed wellness branding with generic approved-placeholder Reiki Wellness Hub copy.

## Controls preserved
- Desktop bottom button: Scorpion
- Keyboard quick jump: 8
- Watch button: SCORPION

## Package notes
- No Manhattan or oversized city FBX/OBJ was added, preserving the <25 MB GitHub-safe target.
- City view is procedural in code.
- JS syntax checked with `node --check`.
