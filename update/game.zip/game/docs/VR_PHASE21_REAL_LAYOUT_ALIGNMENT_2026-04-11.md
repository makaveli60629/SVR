# VR Phase 21 — Real Layout Alignment
- Tightened room proportions toward the larger real-lobby direction.
- Pulled the table and south seat staging into a cleaner player approach path.
- Repositioned Reiki and PGA hub anchors to read more like side-wall destinations instead of distant edges.
- Pushed the main window wall back and widened its framing for a stronger skyline read.
- Kept Meta hands only, no watch, no fake arms, controller move/snap-turn, and floor-target teleport.
