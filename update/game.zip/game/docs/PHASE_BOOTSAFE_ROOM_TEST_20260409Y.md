Build: 20260409Y-BOOTSAFE-ROOM-TEST

Purpose:
- restore a boot-safe lobby baseline after repeated world_skyline helper regressions
- preserve the main lobby, Reiki room, Scorpion room, and jumbotron overlay
- provide a clean room-test package before reapplying Reiki/PGA visual edits in smaller audited passes

What is intentionally preserved:
- /game/ main lobby
- /game/reiki/ room route
- /game/sandbox/ Scorpion room route
- lobby jumbotron overlay button and playlist flow

What is intentionally not included:
- later Reiki storefront overlays
- later skyline sponsor/banner experiments
- later helper chains that caused boot failures
