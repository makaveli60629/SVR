# Phase: Teleport Freeze + Finger-Leap Fix

Date: 2026-05-06
Scope: game-only hotfix

## Problem fixed
Quest hand pinching could accidentally trigger teleport release after the watch TP button or during hand tracking. This caused sudden leaps and could make the player feel frozen/stuck while the XR reference space was resetting.

## Fixes
- Disabled hand pinch-release teleport by default.
- Disabled fist-near-face teleport toggle by default.
- Kept watch TP toggle visible and safe.
- Kept controller trigger teleport: arm TP, aim at floor, hold trigger, release to teleport.
- Added arming grace period after TP toggles so button presses cannot instantly fire a jump.
- Added tp.isEnabled() so the watch shows the correct TP SAFE / TP ARMED state.
- Cleared teleport target/hold state after cancel, failed teleport, or successful teleport.
- Updated watch messages to remove confusing fist/pinch teleport instructions.

## Controls after this fix
- Watch quick scene buttons still work.
- Keyboard T still toggles teleport in desktop mode.
- Quest controllers: use watch TP or controller toggle, aim, hold trigger, release.
- Hand pinching no longer teleports the player.

## Preserved
- Scorpion poker room
- Player poker controls
- Moon and Mars high behind skyline
- Watch HUD and poker buttons
- Site untouched
