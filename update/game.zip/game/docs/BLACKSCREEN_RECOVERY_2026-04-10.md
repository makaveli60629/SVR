SVR Poker black-screen recovery build

Purpose
- Remove all external 3D/CDN dependencies from the boot path.
- Guarantee a visible lobby scene on first load.
- Preserve SVR style direction: night skyline, purple neon, poker table, Reiki hub, PGA hub, ad wall.

What this build changes
- Replaces the failing dependency-based boot scene with a self-contained canvas renderer.
- Adds camera jumps for main lobby, poker table, Reiki hub, PGA hub, and ad wall.
- Keeps the update zip very small and deploy-safe.

Why the previous build failed
- The screen remained at the original HTML boot text, which indicates the module boot path never advanced.
- This recovery build avoids that entire failure path.
