SVR Poker VR Phase 4 — watch, teleport, and seat polish

What changed
- Added left wrist quick-watch panel with lobby/table/seat/stand shortcuts
- Added floor teleport pads for lobby, table, seat, Reiki, PGA, and ads
- Kept standing spawn as the baseline
- Added clearer sit button at the open south seat
- Preserved stable WebXR boot path, movement, and 45-degree snap turn
- Preserved Reiki hub, PGA hub, sponsor wall, table, chips, and cards

Controls
- Enter VR for headset mode
- Left thumbstick / WASD to move
- Right thumbstick / Q and E to snap turn
- Keyboard shortcuts: 1 lobby, 2 table, 3 seat, 4 Reiki, 5 PGA, 6 ads
