# Phase F — 3D Camera Live View Lock

Camera 3 is now always on as a live preview/debug view. Main view remains controllable. The overlay shows table, seats, hubs, skyline, moon and Mars while the user navigates.
