# Release Notes — Phase 46

Phase 46 is the final gameplay cleanup pass before the full debug sweep. The main change is cleaner chip/card handling so demo props stay playable and easier to reset during testing.
