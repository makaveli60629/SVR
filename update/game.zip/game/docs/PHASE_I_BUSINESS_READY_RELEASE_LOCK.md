# Phase I — Business-Ready Release Lock

## Added
- Release-lock manifest
- Sponsor/ad registry scaffold
- Rotate Sponsor button
- Table UI formatter module
- Release badge in scene
- Camera 3 live preview preserved
- Phase H poker engine preserved

## Controls
- S: sit/stand
- T: teleport arc
- D: deal demo
- C: chip demo
- E: poker engine test
- A: rotate sponsor
- R: reset view

## Next
Phase J should restore real lobby assets/modules, rig Eric dealer, wire production table UI, and replace the marker storefronts with the real Reiki/PGA modules.
