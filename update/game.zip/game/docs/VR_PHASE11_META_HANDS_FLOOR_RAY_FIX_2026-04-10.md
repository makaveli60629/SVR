SVR Poker VR Phase 11 — Meta Hands Only + Floor Ray Fix

What changed
- removed watch and fake arms from the visible VR path
- kept Meta hand tracking as the only visible hand presentation
- hid controller models with model:false
- kept controller fallback for left-stick movement and right-stick snap turn
- changed controller targeting feedback to floor markers
- removed the floating controller-top targeting ring

Why
The prior phase still felt wrong in-headset because the visible target cue was tied to the controller origin instead of reading like a floor teleport target.

Expected result
- no watch
- no fake arms
- Meta hands only
- controller target cue appears on the floor at the ray hit position
