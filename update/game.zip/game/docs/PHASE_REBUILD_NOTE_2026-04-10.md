# Next-phase lite rebuild

This is a lightweight, deploy-safe `update/game.zip` reconstructed from the uploaded `SVR-main.zip` baseline on 2026-04-10.

It is intended as an under-25MB overlay pack. Heavy unchanged assets already present in the repo were intentionally omitted to stay within the size limit.

Included:
- game HTML/JS/CSS/source files
- small textures and support assets
- docs note

Omitted from this overlay:
- large unchanged model/texture binaries already present in the base repo build
