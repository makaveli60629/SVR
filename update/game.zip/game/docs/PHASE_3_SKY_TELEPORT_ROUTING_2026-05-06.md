# Phase 3 — Sky + Teleport Routing Polish

## Build Goal
This phase locks the sky presentation and route clarity after the Phase 1 storefront restoration and Phase 2 private module scaffold.

## Completed
- Raised Moon and Mars much higher above the city skyline.
- Pushed Moon and Mars deeper behind the skyline so they do not touch or intersect buildings.
- Increased Moon and Mars halo size, brightness, and glow intensity.
- Added a stronger high star band above and behind the skyline.
- Increased star visibility while keeping draw count Quest-safe.
- Added return-to-lobby visual rings/signage inside private rooms.
- Added a runtime routing lock marker at `scene.userData._phase3RoutingLock`.
- Updated build labels to `PHASE-3-SKY-ROUTES`.

## Preserved Locks
- No music or audio payload.
- Unapproved wellness sponsor references remain removed.
- One-controller movement remains preserved.
- 45-degree snap turn remains preserved.
- Trigger-release teleport remains preserved.
- Pinch-leap teleport remains disabled.
- Storefronts remain freestanding hub portals.
- Private scenes remain separate destinations.
- Seat edge lock, flat chips, bet movement, and left-first dealing remain preserved.

## Test Checklist
1. Load the lobby and look upward above the city skyline.
2. Confirm Moon and Mars sit high in the sky and do not cut through buildings.
3. Confirm stars are visible above the skyline.
4. Use the watch or bottom buttons to enter Reiki Grove, PGA Range, Smoker Lounge, and VR Store Room.
5. Use Lobby button or keyboard `1` to return from a private scene.
6. Confirm no music plays.

## Next Phase Recommendation
Phase 4 should begin the playable PGA module: controller-as-club, ball hit detection, driving-range shot response, chipping, and putting.
