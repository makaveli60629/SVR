# VR Phase 19 — Table and Seat Reintegration

This phase keeps the stable VR baseline and pushes the table/seat area closer to the real poker-lobby feel.

## Changes
- strengthened table presence
- added more visible chips and cards
- tightened the south seat lane
- increased south seat glow/readability
- added a simple dealer reference marker
- slightly increased locomotion speed
- preserved Meta hands only
- preserved no-watch / no-fake-arms baseline
