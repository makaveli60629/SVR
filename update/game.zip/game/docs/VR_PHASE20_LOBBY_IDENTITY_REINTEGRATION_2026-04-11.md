# VR Phase 20 — Lobby Identity Reintegration

This phase continues the return from the recovery scaffold toward the user's larger real lobby identity.

Changes:
- stronger hero branding and window wall scale
- wider Trueitive Reiki wall read
- wider Juan Espejo PGA wall read
- stronger sponsor / feature stage
- clearer room-side identity accents
- slightly stronger movement speed
- Meta hands only
- no watch
- no fake arms
- controller fallback for movement, snap turn, and floor-target teleport
