SVR Poker VR Phase 12

Goals
- Keep Meta hands only.
- Keep watch and fake arms removed.
- Improve left-stick movement reliability.
- Make teleport pads easier to hit in VR.
- Keep the stable VR recovery boot path.

Included
- Faster locomotion tuning
- Larger teleport pads
- Brighter floor destination cue
- Stable room / table / Reiki / PGA / ads layout
