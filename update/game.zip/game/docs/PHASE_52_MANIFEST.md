# SVR Poker — Phase 52 Manifest

## Goals
- remove CAM 3 from the normal game launch screen
- keep CAM 3 only in preview mode and cam3.html
- reduce blinking / pulse intensity across the real lobby
- keep the real lobby as the locked baseline
- move spawn forward on the player side so it is not far behind the table

## Lock-ins
- real lobby remains the main stabilized baseline
- real 52-card Texas Hold'em autoplay demo remains active
- preview-only live spectator path remains available through preview mode

## Preview URLs
- ./game/cam3.html
- ./game/index.html?preview=1&cam=broadcast
