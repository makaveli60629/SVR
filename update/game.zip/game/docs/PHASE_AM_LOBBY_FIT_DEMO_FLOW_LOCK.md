# Phase AM — Lobby Fit + Demo Flow Lock

## Audit result
- Site untouched.
- Existing Phase AL poker hand reset retained.
- Scene targets remain fitted for lobby, table, seat, Reiki, Zen Den, PGA, legends, sponsor, and scorpion.
- Camera 3 / director preview remains separate from the player view.

## New fix in this package
- Added an in-world Phase AM readiness board near the lobby approach.
- Board lists what is currently ready so testing orientation is clear in headset and desktop.
- Slightly widened Camera 3 orbit for cleaner lobby preview framing.
- Updated boot status text to Phase AM.

## Next production features
1. Eric dealer rig polish and card-deal arm timing.
2. Player decision buttons: check, call, raise, fold.
3. Watch hit-area and controller-trigger interaction hardening.
4. Quest performance pass: material count, texture size, shimmer/z-fighting cleanup.
5. Sponsor board rotation and business-ready ad slots.
