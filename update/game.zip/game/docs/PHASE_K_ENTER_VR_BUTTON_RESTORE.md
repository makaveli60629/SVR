# Phase K — Enter VR Button Restore

## Main fix
The Enter VR button was missing because the lightweight scene did not enable WebXR and did not add Three.js `VRButton`.

## Added
- `renderer.xr.enabled = true`
- `VRButton.createButton(renderer)`
- `renderer.setAnimationLoop(render)`
- Quest controller select fallback
- WebXR lock module
- manifest update

## Test
1. Push this zip as `update/game.zip`.
2. Open the game page in Meta Quest Browser.
3. Confirm `ENTER VR` appears.
4. Press `ENTER VR`.
5. Left controller select = sit/stand.
6. Right controller select = teleport arc.
