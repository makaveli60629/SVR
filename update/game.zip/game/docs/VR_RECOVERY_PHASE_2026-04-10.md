SVR Poker VR Recovery Phase

This package replaces the 2D recovery fallback with a boot-safe WebXR/A-Frame scene.

Included:
- Real VR / WebXR scene
- Standing spawn baseline
- South seat sit/stand controls
- Quest controller thumbstick locomotion
- Right-hand snap turn (45 degrees)
- Reiki hub, PGA hub, and ad wall markers
- Visible table with logo felt
- Local logo textures included in package

Notes:
- Deploy as update/game.zip only.
- This pack avoids heavy external asset chains and uses primitives for boot safety.
- Website content is not modified.
