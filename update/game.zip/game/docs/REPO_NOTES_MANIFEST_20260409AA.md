Repo Notes Manifest — 20260409AA

Working baseline:
- started from the boot-safe 20260409Y lobby package

Locked in this pass:
- lobby remains the main hub
- Reiki and Scorpion rooms remain active routes
- PGA stays modular as a separate hub module
- sponsor towers are treated as skyline marketing modules, not core gameplay blockers
- visual smoothing changes should prefer lower blinking over extra pulse effects
