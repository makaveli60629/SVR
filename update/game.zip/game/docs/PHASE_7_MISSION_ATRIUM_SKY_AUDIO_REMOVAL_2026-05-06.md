# Phase 7 — Mission Atrium Refinement, Audio Removal, Moon/Mars Visibility

## Requested fixes
- Refined the mission/tournament/charity wall after visual feedback.
- Removed the old three-panel mission look from the south wall.
- Removed audio autoplay/music behavior and deleted audio assets from this game package.
- Repositioned Moon and Mars closer/lower/brighter so they should be visible above the skyline.

## Lobby mission area
- Replaced the prior ABOUT / TOURNEY / LEADERBOARD wall with a single premium SVR Community Impact atrium.
- Added larger presentation scale, marble/gold pillars, gold mission pad, rail detail, and cleaner explanatory text.
- Messaging now clearly explains sponsor-funded tournaments, prize paths, and verified giveback for shelter pets, homeless outreach, families in need, and wellness causes.

## Audio lock
- No MP3 payload included.
- No autoplay on XR session start.
- Music keys removed.
- Mission pad now displays mission details instead of changing tracks.

## Sky lock
- Moon and Mars moved closer to the playable lobby view.
- Moon and Mars enlarged and given emissive lift/halo scaling.
- Intended to be visible when looking above the city skyline instead of disappearing behind walls or being too far away.

## Preserved
- PGA realism range scaffold.
- Driving range and chip/putt teleport shortcuts.
- Reiki, PGA, Scorpion, Sponsor, table, and seat routing.
- One-controller movement, 45-degree snap turn, trigger-release teleport, and pinch-leap disabled.
- Site untouched.
