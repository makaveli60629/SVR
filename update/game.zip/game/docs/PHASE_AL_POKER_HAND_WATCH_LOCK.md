# Phase AL — Poker Hand + Watch Lock

## Audit result
This package keeps the Phase AK scene-fit baseline and adds the next production fix without touching the site.

## Changes
- Exposes the live poker demo controller to the main runtime.
- Adds a NEW HAND command to the wrist watch.
- Adds desktop keyboard fallback: `H` starts a fresh demo hand.
- Keeps fitted scene jumps: Lobby, Table, Seat, Reiki, Zen Den, PGA, Legend, Sponsor, Scorpion.
- Keeps Quest controller fallback, Meta hand tracking, Camera 3 live preview, and 07.mp3 playlist path.

## Test order
1. Load the lobby and verify it does not black-screen.
2. Enter VR.
3. Open the wrist watch and press NEW HAND.
4. Confirm cards clear and a new poker hand starts.
5. Test quick jumps to Reiki, PGA, Sponsor, and Scorpion.

## Locked baseline
- Do not replace the lobby shell.
- Preserve the south/front player seat.
- Preserve the current watch baseline.
- Preserve Camera 3 as live preview only.
