# Phase: GitHub Lobby Rebase Merge

This update zip rebases the playable game overlay on the richer GitHub lobby structure instead of the temporary shell-test scene.

## Included
- GitHub-style lobby modules
- real table stage with felt and animated cards
- Eric as dealer
- 4 seated player bots
- south/front seat left open
- Reiki and PGA wall markers
- compressed runtime textures for deploy-safe packaging

## Notes
- This pass drops the old shell-test debug overlay.
- It keeps the update self-contained for the repository workflow that deploys `update/game.zip`.
- It is a restore/rebase pass, not the final full polish pass.
