# SVR Poker — Phase 53 Manifest

## Focus
Polished real-lobby lock with watch stability and lower flicker.

## Changes
- lowered pulsing and opacity swings across the lobby
- added crown ring, sponsor banners, and perimeter columns for a fuller finished lobby feel
- reduced renderer/shadow cost to help avoid freezing on device
- stabilized watch pose with smoothing and larger buttons
- added action cooldowns to stop repeated watch presses
- wrapped core subsystems in recovery guards so one runtime fault does not kill the loop

## Locked behavior
- real 52-card Texas Hold'em autoplay demo remains active
- CAM 3 remains preview-only
- watch handles teleport / seat / reset
