# SVR Poker — Phase 63 Changelog

## Focus of this pass
- lock the uploaded exact shell as the working baseline
- preserve the red carpet lobby layout
- keep preview-only CAM 3 separated from gameplay
- preserve watch, controller, teleport, and card demo modules

## What changed
- locked the closest uploaded lobby shell as the baseline for future work
- preserved the safer primitive table path instead of the broken high GLB table path
- kept the skyline, red carpet run, planters, side matrix wall, legend wall, and store frontage
- kept CAM 3 preview-only on `preview.html`, `cam3.html`, or `index.html?preview=1`
- preserved the moving auto-director camera for preview mode
- preserved teleport arm/disarm behavior and hidden controller lines until teleport is armed
- preserved enlarged watch buttons and tighter watch anchor offsets
- refreshed manifests so future work stays locked to this shell and modular package structure
