# SVR Poker — Phase 63 Changelog

## Focus of this pass
- strengthen the desktop-side operator view
- keep CAM 3 always visible but make it controllable
- mirror demo state into the world for easier show-and-tell

## What changed
- added CAM 3 lock controls:
  - `Auto`
  - `Orbit`
  - `Dealer`
  - `Overhead`
- added a browser-side `Demo Loop` toggle
- added a session timer to the HUD and CAM 3 panel
- added a floating in-world **Live Status Board** over the dealer side
- mirrored stage, pot, input source, seating state, and CAM 3 mode to that board
- kept the compact live dock and boot-safe loader intact
- refreshed docs/manifests for this phase
