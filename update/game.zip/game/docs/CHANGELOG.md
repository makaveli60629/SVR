# SVR Poker — Phase 64 Changelog

## Focus of this pass
- strengthen the desktop-side operator view again
- add a follow camera so observers can track player motion
- add a director loop that sequences visible table progress

## What changed
- added CAM 3 `Follow` mode
- added a browser-side `Director` loop toggle
- director loop sequences seat, deal, bet, reset, and camera changes
- added a new HUD and CAM 3 director state readout
- expanded CAM 3 auto-cycle to include follow mode
- added keyboard controls `4` for follow and `P` for director loop
- refreshed docs/manifests for this phase
