# SVR Poker — Phase 59 Changelog

## Focus of this pass
- keep the stable loader and XR baseline intact
- add an always-on third-camera desktop mirror view for progress monitoring
- preserve the current demo table readability work while improving spectator visibility

## What changed
- added an always-on **CAM 3** desktop spectator preview window on the page
- CAM 3 uses a safe orbiting wide view over the table and lobby shell
- CAM 3 is separate from the main player camera so the demo can still be played normally
- preserved the existing table board, dealer tray, betting spots, chair polish, and watch logic
- refreshed docs/manifests for this phase

## What was preserved
- direct scene-mount boot path
- manual Open Lobby / Enter VR controls
- watch anchor priority:
  1. left hand
  2. right controller
  3. hidden
- left-thumbstick movement
- right-thumbstick snap turn
- sit / stand flow
- deal-cycle button and keyboard fallback
