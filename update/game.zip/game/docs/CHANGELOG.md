# SVR Poker — Consolidated Build Changelog

## P0 — preserve and audit
- Unpacked the current runtime `game.zip`
- Confirmed it was a recovery shell
- Confirmed the package was missing referenced texture assets
- Compared against `game_phase54_watch_anchor.zip` and `SVR-main.zip`

## P1 — XR rig stabilization
- Kept the current boot-safe runtime shell instead of replacing it
- Preserved floor-space Quest setup and direct scene mount
- Added explicit watch-anchor child entities for left hand and right controller
- Added persistent controller proxy geometry

## P2 — watch/input system
- Rebuilt the watch as a local primitive UI shell
- Added deterministic watch anchoring:
  - left hand
  - right controller
  - otherwise hidden
- Preserved `TP`, `ST`, `HM`

## P3 — movement, seating, teleport
- Preserved left-thumbstick movement
- Added right-thumbstick snap-turn
- Added stand-to-safe-position behavior
- Added visible teleport marker and segmented arc
- Kept desktop teleport click path

## P4 — lobby restore merge
- Kept the recovery shell as the runtime base
- Expanded the lobby shell with walls, skyline, signage, and branded billboards
- Kept moon/planet identity and branded table felt
- Avoided boot-critical FBX/GLTF dependencies

## P5 — demo gameplay pass
- Added visible player and board cards
- Added visible chip stacks
- Added deal-cycle button and keyboard fallback
- Preserved simple lift/drop interaction for props

## P6 — polish/package
- Restored local logo assets into the zip
- Improved splash screen text and branding
- Added docs/manifests/install notes
