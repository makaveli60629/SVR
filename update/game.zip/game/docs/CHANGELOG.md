# SVR Poker — Phase 62 Changelog

## Focus of this pass
- keep CAM 3 always visible
- add clearer desktop-visible proof of progress
- preserve the stable loader and XR baseline

## What changed
- kept the compact live control dock from phase 61
- added a **Live actions** browser-side event log
- added a simple **action rail** near the player edge of the table
  - `CHECK`
  - `BET +20`
  - `RESET`
- action rail updates the pot and event log for easier demo monitoring
- refreshed docs/manifests for this phase
