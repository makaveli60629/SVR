# SVR Poker — Phase 58 Changelog

## Focus of this pass
- improve demo readability without risking the stable loader
- make the table feel more intentional for a one-shot demo
- refresh docs while preserving the current XR baseline

## What changed
- added a **live demo-state board** on the far wall that updates with preflop/flop/turn/river/reset states
- restored two additional historical textures:
  - `leather_dark.jpg`
  - `cloth_diffuse.jpg`
- textured the **chair seats/backs** and **table pedestal/trim**
- added a **dealer tray** with clear `DECK` and `DISC` staging blocks
- added clearer **betting spot rings** and a dealer-button marker on the felt
- added a floor **north / dealer side** strip for orientation
- added subtle animation polish to the moon brand plane and Reiki room shell
- upgraded the temporary watch shell styling without changing anchor priority or control mapping
- refreshed docs/manifests for this phase

## What was preserved
- direct scene-mount boot path
- manual Open Lobby / Enter VR controls
- watch anchor priority:
  1. left hand
  2. right controller
  3. hidden
- left-thumbstick movement
- right-thumbstick snap turn
- sit / stand flow
- deal-cycle button and keyboard fallback
