# SVR Poker — Phase 62 Changelog

## Focus of this pass
- recover the closest uploaded lobby shell
- move CAM 3 to preview-only mode
- restore skyline, carpet, side matrix wall, legend wall, and store frontage
- keep the safer watch/controller/teleport behavior

## What changed
- used the uploaded `game_chat_only_copy.zip` as the primary lobby baseline
- kept the stable primitive table instead of the broken high GLB table path
- added a red carpet run with planters
- added a side matrix wall, legend wall, and store frontage
- made CAM 3 preview-only on `preview.html`, `cam3.html`, or `index.html?preview=1`
- strengthened the auto-director camera with obvious moving shots
- auto-cycles the table deal state for a live preview feel
- disarms teleport after a teleport completes
- hides controller laser lines until teleport is armed
- enlarged watch buttons and tightened watch anchor offsets
