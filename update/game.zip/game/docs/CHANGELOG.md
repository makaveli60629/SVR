# SVR Poker — Phase 57 Changelog

## Focus of this pass
- polish the recovery shell without replacing the stable loader
- merge safe historical texture assets
- improve branded lobby readability
- harden right-hand teleport targeting

## What changed
- added restored historical textures:
  - `tablefelt.png`
  - `moon_diffuse.png`
- upgraded the table top from a flat color/logo-only surface to a textured felt + logo overlay layout
- changed the moon from logo-only fill to a textured moon with a separate floating brand sign
- added a simple glass `Reiki` sponsor room shell
- added a north/dealer-side marker
- added a pot marker on the table
- updated HUD/splash text for this phase
- hardened active-ray selection so right-hand teleport targeting prefers valid tracked poses and valid right-controller tracking rather than loose visibility checks
- tightened controller proxy visibility so proxies show only during VR controller use

## What was preserved
- direct scene-mount boot path
- manual Open Lobby / Enter VR controls
- watch anchor priority:
  1. left hand
  2. right controller
  3. hidden
- left-thumbstick movement
- right-thumbstick snap turn
- sit / stand flow
- deal-cycle button and keyboard fallback
