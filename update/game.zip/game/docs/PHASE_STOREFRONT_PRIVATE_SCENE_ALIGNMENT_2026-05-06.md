# Phase: Storefront Alignment + Private Scene Isolation

## Goal
Move the actual store/hub rooms out of the lobby and keep the lobby as a clean storefront hallway with teleport portals.

## Fixed
- Replaced visible lobby hub room buildouts with aligned storefront portal panels.
- Added private, teleport-only scenes for:
  - Zen Den / Reiki private scene
  - PGA VIP private scene
  - Legend VIP private scene
  - Sponsor Room private scene
  - Smoker Lounge private scene
  - Scorpion Poker Room private scene
  - Scorpion VIP private scene
- Moved Scorpion Poker Room to a private scene coordinate instead of building the full room inside the lobby.
- Kept storefront portals in the lobby so players can see the storefront brand direction without the full scene taking up lobby space.
- Expanded movement clamp so Quest users can move after teleporting into private scenes.
- Added boot audit/mod lock for storefront + private scene targets.
- Music/audio remains removed.

## Runtime locks
- `window.SVR_MOD_LOCK.storefrontAlignment = true`
- `window.SVR_MOD_LOCK.privateStoreScenes = true`
- `window.SVR_PRIVATE_SCENES_READY = true` when all targets load
- `window.SVR_AUDIO_DISABLED = true`

## Storefronts in lobby
- Reiki Storefront
- PGA Storefront
- Legend Storefront
- Sponsor Storefront
- Smoker Storefront
- Scorpion Storefront

## Private scenes
- Zen Den
- PGA VIP
- Legend VIP
- Sponsor Room
- Smoker Lounge
- Scorpion Poker Room
- Scorpion VIP

## Controls preserved
- One-controller movement
- 45-degree snap turn
- Trigger-release teleport only when TP is armed
- Finger-pinch leap disabled
- Watch buttons
- Bottom scene buttons
- Player poker controls
- No music/no autoplay
