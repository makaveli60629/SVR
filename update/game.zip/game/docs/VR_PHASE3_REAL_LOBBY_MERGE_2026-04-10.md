SVR Poker VR Phase 3 — real lobby merge pass

What changed
- Upgraded the stable VR recovery build into a more room-like lobby.
- Improved central table scale, platforming, chip/card presence, and seat readability.
- Rebuilt the Reiki and PGA sponsor hubs as cleaner storefront walls with entry pads.
- Reworked the sponsor ad wall so it reads more clearly in VR.
- Preserved standing spawn, south seat guidance, controller movement, and snap turn.
- Kept the package small and deploy-safe to avoid another black-screen regression.

Controls
- Move: left thumbstick or WASD
- Snap turn: right thumbstick or Q / E
- Buttons in world: Sit, Stand, Play, Table, Lobby, Reiki, PGA, Ads
