# Phase — Player Control + Gameplay Lock

## Purpose
Turn the poker table from spectator-mode into a playable demo loop.

## Added
- Player action pauses during each street.
- Desktop controls:
  - F = fold
  - C = call
  - R = raise
  - H = force next hand
- Watch controls show FOLD / CALL / RAISE during the player's turn.
- Watch HUD now shows pot, player cards, evaluated hand name, and current action prompt.
- Player chip stack starts at $1000 and updates on call/raise/win.
- Showdown records player win/loss/fold result.

## Preserved
- Teleport arc and watch TP button from prior phase.
- Scorpion Room poker destination.
- Moon and Mars high/behind skyline.
- Controller locomotion and 45-degree snap turn.
- Game-only update; site untouched.

## Notes
This is still offline demo poker. The next phase should focus on physical chip/card interaction and jumbotron saved-hand feed.
