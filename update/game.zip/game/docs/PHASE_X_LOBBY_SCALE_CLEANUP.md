# Phase X — Lobby Scale + Visual Cleanup Restore

This build preserves the Phase W working boot/render fix and cleans the oversized debug geometry.

## Fixed
- Table/felt scaled down
- Cards/chips reduced
- Dealer marker reduced
- Chairs moved closer to usable table proportions
- Lobby room proportions improved
- VR unsupported message no longer blocks lobby play
- Camera 3 remains optional live preview only

Open `/game/?v=phase-x`.
