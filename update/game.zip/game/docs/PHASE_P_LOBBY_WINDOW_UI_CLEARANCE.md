# Phase P — Lobby Window + UI Clearance

Moves labels away from buttons, adds Clear UI, and adds a visible lobby/training room window. Open `/game/?v=phase-p`.
