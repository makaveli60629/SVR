# VR Phase 17 — Fine Tune and Lock

This pack is the Phase D lock pass on top of the restored larger-lobby shell.

## Focus
- keep the stable VR boot path
- keep Meta hands only
- keep no watch and no fake arms
- make south seat staging easier to read
- enlarge floor teleport pads
- improve sponsor wall readability
- tighten the room into a cleaner locked baseline for the next real-lobby refinements

## Changes
- increased locomotion speed slightly for testing
- enlarged floor teleport pads
- enlarged seat and navigation buttons
- brightened ad wall lighting
- widened the front navigation lane
- updated signage to reflect the lock pass

## Deploy
Replace update/game.zip with this pack and push to main.
