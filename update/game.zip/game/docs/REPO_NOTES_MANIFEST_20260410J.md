# Repo Notes Manifest — 20260410J

- Main lobby source: uploaded `game.zip`
- Room-route source: `game-audit-repo-source-lock.zip` + stable `pga` room
- Audio source: local `assets/audio/07.mp3`
- Keep future work game-only
- Preserve watch and fist teleport from the lobby baseline unless explicitly changed
- Preserve room routes as modular folders:
  - `game/reiki/`
  - `game/scorpion/`
  - `game/pga/`
