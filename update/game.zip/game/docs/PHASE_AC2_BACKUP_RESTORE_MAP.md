# Phase AC2 — Backup Lobby Asset Audit + Safe Restore Map
## Backup audited
- File: `SVR-main (3).zip`
- Size: `96,817,695` bytes
- Files scanned: `1392`

## Immediate findings
- Backup contains the original repo structure under `SVR-main/`.
- `node_modules` and backend folders are present and must not be merged into `update/game.zip`.
- Original game assets are present under `SVR-main/game/assets/` and original modules under `SVR-main/game/modules/`.
- This phase stages only a safe subset and creates a restore map. It does not replace the working visible lobby.

## Safe staged files
- `SVR-main/game/assets/textures/tablefelt.png` → `assets/backup_audit/tablefelt.png` (3,083,224 bytes)
- `SVR-main/game/assets/textures/logo-table.png` → `assets/backup_audit/logo-table.png` (1,415,937 bytes)
- `SVR-main/game/assets/textures/moon_final_diffuse.png` → `assets/backup_audit/moon_final_diffuse.png` (1,974,047 bytes)
- `SVR-main/game/assets/models/table.glb` → `assets/backup_audit/table.glb` (1,707,400 bytes)
- `SVR-main/game/modules/real-table-stage.js` → `assets/backup_audit/real-table-stage.js` (5,135 bytes)
- `SVR-main/game/modules/lobby-floor.js` → `assets/backup_audit/lobby-floor.js` (2,913 bytes)
- `SVR-main/game/modules/lobby-skyline.js` → `assets/backup_audit/lobby-skyline.js` (3,027 bytes)
- `SVR-main/game/modules/lobby-signage.js` → `assets/backup_audit/lobby-signage.js` (2,404 bytes)
- `SVR-main/game/modules/meta-hand-materials.js` → `assets/backup_audit/meta-hand-materials.js` (2,135 bytes)
- `SVR-main/game/modules/quest-watch.js` → `assets/backup_audit/quest-watch.js` (13,223 bytes)
- `SVR-main/game/modules/watch-ui.js` → `assets/backup_audit/watch-ui.js` (4,769 bytes)
- `SVR-main/game/modules/forearm-device.js` → `assets/backup_audit/forearm-device.js` (10,282 bytes)

## Largest relevant backup assets
- `SVR-main/game/assets/textures/HAND_N.png` — 5,083,778 bytes
- `SVR-main/game/assets/textures/logo.png` — 4,546,355 bytes
- `SVR-main/game/assets/textures/tablefelt.png` — 3,083,224 bytes
- `SVR-main/game/assets/textures/HAND_S.png` — 2,769,652 bytes
- `SVR-main/game/assets/textures/HAND_C.png` — 2,730,763 bytes
- `SVR-main/game/assets/textures/moon_final_diffuse.png` — 1,974,047 bytes
- `SVR-main/game/assets/models/table.glb` — 1,707,400 bytes
- `SVR-main/game/assets/textures/logo-table.png` — 1,415,937 bytes
- `SVR-main/game/assets/textures/moon_final_bump.png` — 492,100 bytes
- `SVR-main/game/assets/audio/07.mp3` — 2 bytes
- `SVR-main/game/assets/audio/cry.mp3` — 2 bytes
- `SVR-main/game/assets/audio/falls.mp3` — 2 bytes
- `SVR-main/game/assets/audio/timeless.mp3` — 2 bytes
- `SVR-main/logo.png` — 0 bytes
- `SVR-main/site/logo.png` — 0 bytes

## Next restore order
1. Keep the boot-safe lobby and status fix locked.
2. Add a texture loader that falls back to procedural colors when an asset path fails.
3. Apply original table/felt/logo/moon textures first.
4. Add `table.glb` behind a loader gate only after texture loading is verified.
5. Then restore lobby modules: floor, skyline, signage, watch, hands.
6. Only after that, restore Eric/dealer rig assets.

## Locked safety rules
- Keep every phase under 25 MB.
- Do not ship `node_modules`.
- Do not break the current visible lobby boot path.
- Camera 3 remains optional preview only.
