# SVR Poker — Phase 45 Manifest

Build: 20260329-P45

## Focus
Release prep and stability lock.

## Changes
- keeps CAM 3 always on
- keeps splash/loader removed
- adds safer desktop room clamping
- adds safer teleport landing clamp so jumps avoid the table core
- adds cleaner stand-up pushback so the player does not remain buried in the chair
- keeps watch TP / SEAT / RST
- keeps right-controller fallback and hand pinch interaction
- keeps chair glow, table props, and lobby polish

## Test order
1. Spawn in and move around the room boundary.
2. Toggle teleport and confirm the landing ring stays out of the table center.
3. Sit, then stand, and confirm you step back cleanly from the chair.
4. Grab and drop a chip and a card.
5. Check CAM 3 while moving and using the watch.

## Remaining
- Phase 46: final gameplay cleanup
- Final debug pass: full path test and issue sweep
