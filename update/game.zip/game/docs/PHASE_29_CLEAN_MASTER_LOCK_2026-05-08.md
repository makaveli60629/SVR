# Phase 29 — Clean Master Lock

This build locks the business-safe foundation before new features.

## Changes

- Removed unapproved wellness sponsor runtime assets and text.
- Replaced sponsor-specific Reiki text with neutral wellness hub language.
- Removed dealer body model loading and animation code.
- Preserved invisible button/deal source logic for card movement.
- Preserved six-seat table layout with the south/front player seat open.
- Replaced model-dependent seated NPCs with lightweight neutral seated bots.
- Removed raw FBX payloads from the web runtime package.
- Added `MODULE_REGISTRY.json` and `PROJECT_STATE_LOCK.json`.
- Kept the site untouched.
- Kept the ZIP under 25 MB.

## Permanent Lock

Dealer presentation remains off permanently unless a future approved module deliberately adds non-dealer seated player avatars.

## Next

1. PGA controller club module.
2. Physical chip/card grab module.
3. Multiplayer prototype adapter.
