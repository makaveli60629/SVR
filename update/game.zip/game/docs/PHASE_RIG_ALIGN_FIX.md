Phase: Rig Align Fix

Changes:
- reduced table shell and primitive overlay size
- moved camera back for readable framing
- switched FBX bot loading to explicit custom loader using THREE.FBXLoader and direct file paths
- realigned dealer, four seated players, and Eric reference around the smaller table
- kept south/front player seat open
