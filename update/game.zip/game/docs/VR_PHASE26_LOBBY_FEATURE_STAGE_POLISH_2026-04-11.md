# VR Phase 26 — Lobby Feature-Stage Polish

## Goal
Tighten the restored larger-lobby baseline so the front room, sponsor stage, and branded partner presentation read more like a finished SVR Poker destination.

## Changes
- strengthened sponsor / feature-stage presentation
- refined center front-lane accents
- slightly increased movement speed
- enlarged floor teleport targets again
- preserved Meta hands only
- preserved no-watch / no-fake-arms rule
- preserved controller fallback locomotion and snap turn

## Notes
This remains a game-only overlay pack intended for update/game.zip.
