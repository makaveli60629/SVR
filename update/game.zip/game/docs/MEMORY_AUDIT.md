# SVR Poker — Memory Audit

## Active project rules preserved in this build
- Final deliverable stays `game.zip`.
- Keep the package under 25 MB.
- Include PowerShell commands in every deliverable.
- Preserve a modular package structure with docs/manifests.
- Do not redo already completed work if it can be restored or merged.
- Demo stability is more important than feature ambition.
- Quest is the primary target; desktop is secondary.
- Right controller is the watch fallback when controllers are active.
- If no valid watch anchor exists, the watch must hide rather than float in world space.

## Runtime behavior targeted here
- Boot-safe scene loader preserved
- Local logo assets restored into the package
- Watch anchor priority:
  1. left tracked hand
  2. right controller
  3. hidden
- Left-thumbstick movement retained as the main VR locomotion baseline
- Right-trigger release commits teleport when armed
- Chair glow and sit/stand baseline retained
