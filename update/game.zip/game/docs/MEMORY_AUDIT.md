# SVR Poker — Memory Audit

## Active project rules preserved in this build
- Final deliverable stays `game.zip`.
- Keep the package under 25 MB.
- Include PowerShell commands in every deliverable.
- Preserve a modular package structure with docs/manifests.
- Do not redo already completed work if it can be restored or merged.
- Demo stability is more important than feature ambition.
- Quest is the primary target; desktop is secondary.
- Right controller is the watch fallback when controllers are active.
- If no valid watch anchor exists, the watch must hide rather than float in world space.
- `Reiki` spelling is preserved.

## Runtime behavior targeted here
- Boot-safe scene loader preserved
- CAM 3 spectator view remains always visible during boot on desktop
- Compact dock remains non-blocking
- Browser-side event log helps monitor progress without hiding CAM 3
- Watch anchor priority remains left hand, then right controller, then hidden
