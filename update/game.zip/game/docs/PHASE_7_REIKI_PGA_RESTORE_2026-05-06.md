# Phase 7 — Old Reiki Hub Restore + PGA Source Merge

## Completed
- Restored the older full Reiki lobby hub as the lobby-facing Reiki storefront.
- Kept Trueitive/unapproved sponsor branding out of runtime scene content.
- Preserved the private Reiki Grove meditation scene.
- Merged the uploaded PGA real-feel range source into the active game package.
- Added the uploaded PGA driving range private module with instruction boards, tee station, ball, club rig, target rings, scoreboard, and desktop/VR simulator controls.
- Added private-scene visibility routing so the PGA range room appears when entering `pgaRoom` and stays hidden from the lobby otherwise.

## PGA controls
- VR: controller grip/squeeze grabs the club and swing-through hits the ball.
- Desktop: `G` grabs/drops club, `Space` hits, `R` resets the ball, `H` toggles help.
- Navigation: `P` or `0` enters PGA Range.

## Preserved locks
- No music / no MP3 payload.
- One-controller movement.
- 45 degree snap turn.
- Trigger-release teleport.
- Finger-pinch leap disabled.
- Seat edge lock.
- Flat chip movement and left-first card dealing.
- Site untouched.
