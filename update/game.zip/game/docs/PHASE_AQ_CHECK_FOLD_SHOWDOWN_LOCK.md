# Phase AQ — Check / Fold Showdown Lock

- Added CHECK to the wrist watch.
- Added desktop fallback: X = CHECK.
- Preserved H/C/R/F fallbacks.
- Fold now marks the player folded for the current hand.
- A folded YOU hand cannot receive showdown payout.
- Bankroll protection remains locked.
- Camera 3 live preview preserved.
- Scene jump routes preserved.
- Site untouched.
