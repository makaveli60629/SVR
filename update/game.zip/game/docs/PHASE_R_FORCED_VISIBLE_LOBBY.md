# Phase R — Forced Visible Lobby

Forces a bright, visible lobby directly into the camera view and preserves VR entry. Test `/game/?v=phase-r`.
