# SVR Poker Phase 49

## Focus
Extended the autoplay Texas Hold'em demo so the table now reads more like a live poker hand.

## Changes
- moved default spawn farther back from the table
- added dealer button, small blind, and big blind markers
- added animated center pot stack that grows with action
- added preflop / flop / turn / river action events
- kept real 52-card dealing and showdown evaluation
- added preview.html helper that opens the clean CAM 3 preview

## Controls
- N = force next hand
- ?preview=1 = clean CAM 3 fullscreen preview
- preview.html = direct clean preview helper
