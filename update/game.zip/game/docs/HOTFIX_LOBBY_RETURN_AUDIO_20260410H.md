# Hotfix — Lobby return audio boot fix

Build: 20260410H-LOBBY-RETURN-AUDIO-HOTFIX

Fixes:
- moved local audio initialization to occur after renderer creation
- prevents main.js from aborting before the skyline room builds
- preserves lobby, Reiki room, Scorpion room, PGA room, watch, fist teleport, and local 07.mp3 support
