# Phase H — Poker Engine Upgrade

## Added
- Full five-card hand category evaluator:
  - High Card
  - Pair
  - Two Pair
  - Three of a Kind
  - Straight
  - Flush
  - Full House
  - Four of a Kind
  - Straight Flush
- Best 5 out of 7 evaluation
- Showdown ranking and tie winners
- Side-pot calculation
- Pot resolution by eligible players
- Legal minimum raise helper
- Poker engine test button in scene

## Preserved
- Camera 3 live preview
- Seat/stand control
- Teleport arc control
- Deal demo
- Chip demo
- Eric dealer slot marker
- Reiki and PGA markers

## Next
Phase I should connect the poker engine to a cleaner table UI, add sponsor/ad modules, and create a release-lock manifest.
