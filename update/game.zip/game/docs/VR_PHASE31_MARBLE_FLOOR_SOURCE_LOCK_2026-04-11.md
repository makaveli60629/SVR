# VR Phase 31 — Marble Floor + Source Lock Restore

## Permanent floor correction
- Removed the wrong floor texture permanently.
- Replaced the lobby base floor with a clean marble texture.
- Replaced low floor strips using the wrong floor treatment with matching marble accents.

## Source lock
User supplied:
- `SVR-main (2).zip` as the latest full update backup baseline
- `game-audit-repo-source-lock.zip` as the source/audit donor pack

These are now the preferred donor/reference sources for further real-lobby stabilization work.

## Preserved
- Meta hands only
- no watch
- no fake arms
- left-stick move
- right-stick 45 degree snap turn
- floor-target teleport
- site untouched
