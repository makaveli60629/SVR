# SVR Poker Phase 47

- fixed spawn by forcing reset-to-spawn on boot, XR start, and XR end
- moved base spawn farther back from the table
- added clean preview mode with `?preview=1`
- preview mode shows only CAM 3 fullscreen with no HUD/buttons/help overlays
- CAM 3 remains a live local spectator render, not a network socket stream
- cards/chips remain demo props only; this build does not include full poker logic
