# VR Phase 8 — Player Arms Shell (2026-04-10)

This phase mounts the uploaded `arms.glb` as a first-person player arm shell.

## Changes
- Added `game/assets/models/arms.glb`
- Attached the mesh to the player rig as a body/arm shell
- Body shell follows head yaw so it feels attached instead of floating
- Kept Meta hand tracking enabled at the wrists
- Kept controller fallback as rays only
- Kept stable VR locomotion, seat, Reiki, PGA, and ad wall flow

## Goal
Make the player feel more like an in-world avatar / NPC body without breaking the stable VR boot path.
