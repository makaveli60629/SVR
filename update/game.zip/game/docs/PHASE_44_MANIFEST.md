# SVR Poker Phase 44 Manifest

Build: 20260329-P44

## Focus
- world and lobby polish
- CAM 3 remains always on
- no blocking splash screen
- preserve watch, teleport, chair glow, and controller fallback

## Added
- polished skyline with animated neon bands and billboards
- procedural moon and earth textures with soft glow
- upper-room aurora rings and brighter star accents
- Reiki lounge glass suite using the correct spelling
- two lobby information kiosks for demo messaging
- slightly wider CAM 3 orbit for cleaner overview shots

## Preserved
- watch TP / SEAT / RST
- right-controller watch fallback
- visible teleport arc and landing ring
- grab/drop for chips and cards
- active chair glow
