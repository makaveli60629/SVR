# Phase W — Status Binding Crash Fix

Fixes the live error:

`Cannot create property 'textContent' on string ''`

Root cause: the browser treated `status` as `window.status`, a string, not the status div.

## Fix
- Status element renamed to `svrStatus`
- `setStatus()` now uses `document.getElementById("svrStatus")`
- UI hide/show also uses explicit lookup
- Phase V boot-first lobby render preserved

Open `/game/?v=phase-w`.
