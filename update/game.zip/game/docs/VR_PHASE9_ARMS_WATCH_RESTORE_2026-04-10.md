SVR Poker VR Phase 9 — Arms + Watch Restore

Fixes
- Bundles uploaded arms.glb inside game/assets/models/arms.glb
- Mounts player arms shell directly under the camera so arms stay visible in first person
- Keeps left tracked-hand watch
- Adds a visible quick-watch fallback near the camera so the watch remains usable even if the wrist anchor is not visible

Notes
- This phase preserves the stable VR recovery base and Meta hand support.
- The quick-watch is a temporary visibility safeguard while the true wrist rig is refined.
