# Phase Z — Production Lobby Polish + Clean Test View

This phase preserves the working Phase Y centered lobby and adds a cleaner production test view.

## Changed
- Clean test view activates on boot
- VR unsupported visual obstruction reduced
- Table/felt/path/window colors toned down
- Subtle table shadow added
- Hub labels cleaned
- Desktop HUD compacted
- Camera 3 remains preview-only

Open `/game/?v=phase-z`.
