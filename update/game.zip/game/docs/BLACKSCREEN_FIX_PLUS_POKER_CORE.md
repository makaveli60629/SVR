# Black Screen Fix + Poker Core Module Merge

This deploy package starts from the lean black-screen-safe runtime package and merges the next-phase modular poker core into `game/core` and `game/debug`.

## Runtime safety
- Keeps required boot/runtime assets from the lean GitHub-safe build:
  - `game/index.html`
  - `game/assets/models/table.glb`
  - `game/assets/models/player.glb`
  - `game/assets/models/npc_sitting.fbx`
  - `game/assets/models/moon.fbx`
  - `game/assets/texture/tablefelt.png`
- Preserves existing scripts/systems used by the boot page.
- Adds poker logic as separate modules without replacing the active lobby boot path.

## New poker modules
- `game/core/deck.js`
- `game/core/tableState.js`
- `game/core/bettingRound.js`
- `game/core/handEvaluator.js`
- `game/core/showdown.js`
- `game/debug/simulateRound.js`
- `game/debug/testHands.js`

## Known gap
`handEvaluator.js` is still a foundation/high-card placeholder. Full Texas Hold'em ranking and side-pot logic are the next gameplay phase.
