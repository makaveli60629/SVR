# SVR Poker — Mod Lock + Next Phase

## Status
This package locks the current stable modules and adds a runtime boot audit so the current work is easier to preserve before the next feature pass.

## Locked modules
- No music / no autoplay / no MP3 payload
- One-controller movement
- 45 degree snap turn
- Trigger-release teleport only while TP is armed
- Finger-pinch leap teleport disabled
- Watch scene buttons
- Scorpion poker room
- Player poker controls
- Hub + private-room teleports

## Required teleport targets
- Lobby
- Table
- Seat
- Reiki
- Zen Den private room
- PGA
- PGA VIP private room
- Legend
- Legend VIP private room
- Sponsor
- Sponsor private room
- Smoker Lounge
- Smoker Lounge private room
- Scorpion poker room
- Scorpion VIP private room

## Runtime audit
Added:

```text
game/modules/mod_lock.js
```

The module checks the scene target registry at boot and writes these values to the browser runtime:

```text
window.SVR_MOD_LOCK
window.SVR_MOD_AUDIT
window.SVR_AUDIO_DISABLED
```

This is non-invasive. It does not replace the game systems. It verifies the locked state and forces any stray audio/video elements to remain muted.

## Next recommended phase
Physical VR polish:
- card peek interaction
- chip push interaction
- saved-hand replay feed to private-room jumbotrons
- final Quest performance reduction pass
