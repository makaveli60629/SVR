# SVR Poker — Hub Private Room Teleport Audit

## Requested fixes
- Audit current game package for blockers.
- Remove all music completely.
- Make all major hubs and their private rooms available from bottom buttons and watch teleport buttons.
- Preserve one-controller movement and teleport safety.

## Audit findings fixed in this package
1. **Music still existed in the previous package**
   - Found packaged MP3 files under `game/assets/audio/`.
   - Found desktop and XR session music-start code still wired.
   - Found watch music buttons still present.
   - Fix: removed the audio folder and MP3 payload, replaced audio module with a hard no-op, removed music buttons and hotkeys.

2. **Private room teleport coverage was incomplete**
   - Bottom nav only exposed basic hubs plus Reiki private room.
   - Watch only exposed the older scene list.
   - Fix: added teleport targets and watch/bottom buttons for private rooms.

3. **Readable sign back-face helper had stale duplicate logic**
   - The canvas sign helper had duplicate material setup code from prior hotfix work.
   - Fix: replaced it with a clean single-pass helper.

4. **Scene target list lacked smoke/lounge and VIP room targets**
   - Fix: added procedural private hub room targets for PGA VIP, Legend VIP, Sponsor Room, Smoker Lounge Room, and Scorpion VIP.

## Teleport destinations now exposed
- Lobby
- Table
- Seat
- Reiki hub
- Zen Den private room
- PGA hub
- PGA VIP private room
- Legend hub
- Legend VIP private room
- Sponsor hub
- Sponsor private room
- Smoker Lounge public entry
- Smoker Lounge private room
- Scorpion poker room
- Scorpion VIP private room

## Controls preserved
- Either controller can move and snap-turn.
- 45 degree snap turn preserved.
- Pinch-leap teleport remains disabled.
- Trigger-release teleport remains the safe teleport path when TP is armed.
- Poker controls F/C/R/H preserved.

## Music status
- No packaged MP3 files remain.
- No `assets/audio/` folder remains.
- Audio module is a no-op safety stub so stale callers cannot start sound.
- Watch music buttons removed.
- Desktop music hotkeys removed.
- XR session audio start removed.
