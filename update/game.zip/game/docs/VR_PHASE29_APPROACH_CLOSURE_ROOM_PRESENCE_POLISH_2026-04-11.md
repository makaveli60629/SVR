# VR Phase 29 — Approach Closure and Room Presence Polish

This phase continues the stable VR baseline and focuses on making the room read more like a connected lobby instead of separate islands.

## Changes
- tightened the center approach lane
- brightened floor-target arrival feedback
- enlarged controller floor pointers
- moved Reiki and PGA arrival targets slightly inward
- improved sponsor-stage floor read
- strengthened side-entry and front-room cues

## Locked rules
- Meta hands only
- no watch
- no fake arms
- left-stick move
- right-stick 45 degree snap turn
- floor-target teleport

## Deploy
Replace `update/game.zip` with this package and push to `main`.
