# Exact Shell Lock

This package locks the uploaded `game_chat_only_copy.zip` lobby shell as the working baseline.

## Locked lobby elements
- red carpet run
- skyline behind the table
- side matrix wall
- legend wall
- store frontage
- central table area and chair ring

## Preserved runtime modules
- preview-only CAM 3
- watch controls
- controller fallback
- teleport arm / release flow
- card demo state and HUD
- package docs and manifest

## Rule for future work
Refine this shell. Do not swap to a different room shell unless the user explicitly requests it.
