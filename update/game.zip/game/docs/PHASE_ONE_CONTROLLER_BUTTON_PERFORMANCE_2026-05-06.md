# Phase — One Controller Movement + Button/Performance Refinement

## Goal
Make either Quest controller capable of full movement so the player does not need both controllers active at the same time.

## Controller movement changes
- Either left or right controller thumbstick/pad can now drive locomotion.
- Either controller can snap-turn with a hard horizontal flick.
- One-controller mode supports:
  - forward/back movement
  - diagonal movement
  - side movement while vertical input is present
  - 45-degree snap turn from either controller
- Movement step is clamped to reduce Quest frame spikes and accidental jumps.

## Teleport preservation
- Finger-pinch teleport remains disabled to stop accidental leaps.
- Watch TP still arms teleport.
- Controller trigger-release teleport still works from either controller.
- Teleport reset and aiming visuals remain from the previous safety phase.

## Watch/button refinement
- Watch update now accepts controller proxies as input.
- Controller trigger can act as a press source for watch buttons when hand tracking is unavailable.
- Watch display text now reflects one-controller readiness.
- Existing poker buttons remain preserved: Fold / Call / Raise / Next Hand.

## Performance pass
- Quest render pixel ratio reduced slightly for smoother frame pacing.
- XR framebuffer scale guarded at a Quest-safe value.
- Tone exposure lowered slightly to reduce glare and GPU spikes.
- Dynamic shadows remain disabled.

## Preserved systems
- Scorpion poker room
- Moon and Mars high skyline placement
- Teleport freeze fix
- Player poker control phase
- Watch scene buttons
- Site untouched
