# VR Phase 22 — Interaction Polish

This pass stays on the stable VR baseline and focuses on interaction clarity.

## Changes
- Increased default locomotion speed
- Enlarged floor teleport pads
- Enlarged floor target rings for controller rays
- Brightened teleport readability
- Enlarged Sit / Stand / Play and nav buttons
- Pulled the south seat staging point slightly closer
- Kept Meta hands only
- No watch
- No fake arms

## Goal
Make movement, seat access, and controller-based world interaction easier while preserving the larger real-lobby return path.
