# SVR Poker Phase 55 Manifest

- Auto-directed preview camera added for `cam3.html` and `?preview=1`.
- Normal game screen no longer shows the large help overlay.
- Build string updated to Phase 55.
- This phase does **not** claim an exact original-lobby restore. For the exact older lobby shell, a backup package is still the safest source.
