# Phase Q — VR Entry + Lobby Boot Lock

Adds a manual Enter VR button, preserves Three.js VRButton, restores a visible lobby immediately, and adds a UI hide button.

Test in Meta Quest Browser with `/game/?v=phase-q`.
