# SVR Poker VR Phase 15 — True Lobby System Merge

This phase continues the return from the recovery scaffold toward the larger real lobby.

## Focus
- preserve the stable VR boot path
- keep Meta hands only
- keep no watch and no fake arms
- merge working locomotion and seat flow into a stronger true-lobby shell
- push Reiki, PGA, and sponsor spaces closer to the intended wall-zone layout

## Changes
- stronger larger-shell room depth
- added support columns and navigation lanes
- restored a visible south seat staging area
- added sit / stand / play buttons at the open player seat
- added framed Reiki and PGA entry markers
- strengthened sponsor wall structure
- kept left-stick movement, right-stick snap turn, and floor-target teleport logic

## Notes
This is still a game-only overlay build for update/game.zip.
The site is untouched.
