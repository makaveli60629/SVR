# Phase U — Cross-Platform Controls Lock

## Covered
- Meta Quest WebXR entry
- Meta Quest controller select/squeeze support
- Meta hand-tracking-ready pinch hooks
- Android touch joystick + HUD buttons
- PC WASD / arrows / mouse drag / keyboard shortcuts

## Preserved
- Clean main lobby camera
- Camera 3 only as optional Live Preview
- Enter VR
- Hide UI
- Visible lobby render lock

Open `/game/?v=phase-u`.
