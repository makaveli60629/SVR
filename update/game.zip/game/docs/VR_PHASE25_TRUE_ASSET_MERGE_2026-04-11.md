# VR Phase 25 — True Asset Merge

This pass builds on the locked larger-lobby baseline and merges back more of the branded room language without changing the current working rules.

## Preserved
- Meta hands only
- No watch
- No fake arms
- Left-stick movement
- Right-stick 45 degree snap turn
- Floor-target teleport
- Game-only update zip deploy path

## Added
- Stronger Reiki alcove framing
- Stronger PGA alcove framing
- Deeper sponsor back-wall structure
- Cleaner front-lane finish accents
- Additional window-wall trim and skyline finish cues

## Goal
Push the room closer to the user's original branded lobby direction while keeping the stable VR boot path alive.
