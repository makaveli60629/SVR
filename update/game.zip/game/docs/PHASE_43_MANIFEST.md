# SVR Poker — Phase 43 Manifest

Build: `20260329-P43`

## Goal
Table gameplay polish without breaking the lighter modular build.

## Delivered
- seated anchor moved slightly inward for a cleaner player eye-line
- table gameplay pass with draggable chips and cards
- desktop lift/drop flow: click to grab, click again or press `G` to drop
- XR controller fallback: right trigger grabs props, release drops
- hand-pinch fallback near props
- CAM 3 remains always on
- no splash/loader block added back in

## Keep locked
- watch remains the primary teleport/seat/reset path
- right controller stays the fallback for interaction in XR
- modular structure stays intact for later debug phases

## Test order
1. spawn and sit in the nearest chair
2. verify eye-line feels closer to the table
3. click a chip stack or card on desktop and drop it with `G`
4. in XR, use right trigger to grab a chip/card and release to drop
5. confirm teleport arc and watch buttons still work
