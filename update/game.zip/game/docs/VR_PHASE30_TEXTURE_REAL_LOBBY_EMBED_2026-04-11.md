# SVR Poker VR Phase 30 — Texture and Real-Lobby Embed

This pass keeps the stable VR boot path and adds back real surface textures and more of the original-lobby material feel.

Included:
- textured moon using original moon diffuse/bump
- textured cloth floor and center lane
- textured front window-wall framing
- textured Trueitive Reiki and PGA alcove backings
- textured sponsor back wall
- textured table surround and felt reinforcement
- Meta hands only
- no watch
- no fake arms
- left-stick move
- right-stick 45 degree snap turn
- floor-target teleport

This is the texture/embed pass on top of the locked VR baseline.
