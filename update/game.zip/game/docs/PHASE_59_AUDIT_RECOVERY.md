# SVR Poker — Phase 59 Audit + Recovery

## What was audited
- Current modular game backup (`game.zip` uploaded in this chat)
- Uploaded repo backup (`SVR-main.zip`)
- Existing phase manifests in `game/docs/`
- Current public GitHub repo workflow behavior

## Findings fixed in this phase
1. **Watch XR runtime bug**
   - `watch.js` used undeclared variables during wrist pose update.
   - This could break XR/watch behavior and contribute to Quest boot/runtime failures.
   - Fixed by rebuilding the wrist fit/orientation path.

2. **Quest boot path simplified**
   - Hand mesh model loading was removed from startup.
   - The build now uses raw XR hands/controllers only, which is lighter.

3. **Preview path separated from gameplay path**
   - `preview=1` now boots a clean spectator-only render path.
   - The normal game page no longer runs the preview camera render loop.

4. **Lobby rebuild/refine**
   - Restored red carpet promenade
   - North skyline window
   - Matrix wall moved off the table sightline
   - Legend wall restored to the side
   - Store frontage restored
   - Reiki lounge kept with correct spelling

5. **Repo asset merge**
   - Added repo asset support for `table.glb`, `tablefelt.png`, and moon textures.
   - Table now attempts GLB load first and falls back safely if needed.

6. **Blink reduction**
   - Removed most pulse animation from the room shell and chair glow.
   - Slowed Matrix refresh.
   - Reduced emissive spikes and extra render overhead.

## Remaining known limitations
- This is still a rebuild from the available backups, not a byte-perfect restore of a missing lobby snapshot that was not present in the uploaded archives.
- The poker flow remains an autoplay Texas Hold'em demo, not full manual betting multiplayer.

## Deploy
Replace `update/game.zip` with this package, then push to `main`.
