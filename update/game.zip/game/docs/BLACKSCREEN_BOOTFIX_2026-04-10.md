# Black screen boot fix

This pack fixes the black-screen boot issue caused by the lightweight overlay missing runtime assets referenced by `game/index.html`.

Added back into the overlay:
- `game/assets/texture/tablefelt.png`
- `game/assets/models/table.glb`
- `game/assets/models/player.glb`
- `game/assets/models/npc_sitting.fbx`
- `game/assets/models/moon.fbx`

Also replaced `game/index.html` with a boot-safe scene that:
- keeps a visible floor and skyline even if model loads fail
- shows a fallback table if the GLB does not load
- reports boot status in-screen
- keeps sane lighting and camera positioning
