# SVR Poker — Phase 42 Interaction Lock

Build: `20260328-P42`

## Goal
Ship the next playable phase as a stable, self-contained game overlay focused on interaction lock instead of fragile asset streaming.

## What changed
- replaced the old prototype game page with a cleaner modular Three.js/WebXR build
- removed splash/loader blocking behavior
- added **CAM 3 always on** spectator preview in the lower-right corner
- added a self-contained skyline poker room with table, dealer stand-in, moon, earth, stars, and neon skyline
- added **active glowing chairs** with seat snapping
- added a readable **watch UI** with three buttons:
  - `TP` toggle teleport
  - `SEAT` sit/stand
  - `RST` reset to spawn
- teleport is controlled from the **watch button**, not the fist gesture
- added **right-controller fallback** for watch interaction and teleport release
- added visible teleport **pointer + ring + arc**
- kept **snap turn at 45°** for the right stick
- added desktop fallback:
  - `T` teleport
  - `E` sit/stand
  - `R` reset
  - `1-6` seat selection

## Files in this pack
- `game/index.html`
- `game/main.js`
- `game/modules/*`
- `game/assets/logo_table.png`
- `game/docs/PHASE_42_MANIFEST.md`

## Test order
1. load the game page and confirm CAM 3 is visible immediately
2. verify the room renders with no splash blocking the page
3. desktop test:
   - WASD movement
   - `T` toggles teleport state
   - `E` sits and stands
   - `1-6` picks chairs
4. Quest hand test:
   - watch appears on left wrist
   - right-hand pinch can hit TP / SEAT / RST
5. Quest controller test:
   - watch appears with controller fallback
   - right trigger activates watch buttons
   - right trigger release completes teleport when TP is armed
   - right stick snap turns in 45° increments

## Packaging note
This phase is intentionally code-heavy and asset-light so the shipped `game.zip` stays well under the 25 MB limit.
