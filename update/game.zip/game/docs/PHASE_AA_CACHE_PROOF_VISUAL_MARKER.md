# Phase AA — Cache Proof Visual Marker

This build is intentionally obvious. It confirms whether the new `update/game.zip` is really live.

## Must appear
- Top UI: `PHASE AA LIVE - CACHE TEST`
- 3D sign: `PHASE AA LIVE - NEW ZIP ACTIVE`
- Yellow animated beacon ring
- Purple-tinted background

If these do not appear, the site is serving an older cached zip or the new zip was not deployed.
