SVR Poker - Phase Rig Scale Tune

- reduced table shell and proxy radii
- tightened stool ring around resized table
- moved dealer and seated players inward
- added Eric standing reference for visual scale correction
- preserved open south/front seat for testing
