# Phase L — Real VR Interaction Lock

## Added
- Controller ray grab/drop
- Desktop click pickup/drop fallback
- Interactable cards and chips
- Eric idle hand movement scaffold
- Seat/stand preserved
- Teleport arc preserved
- Enter VR preserved
- Camera 3 live view preserved outside VR

## Quest controls
- Aim controller at a chip/card
- Press and hold select/trigger to grab
- Release to drop
- Left select toggles sit/stand if not grabbing
- Right select toggles teleport arc if not grabbing

## Desktop controls
- Click chip/card to pick up
- Click again to drop
- S: sit/stand
- T: teleport arc
- D: deal demo
- C: chip demo
- E: poker engine test
- A: rotate sponsor
- L: lobby module check
- R: reset

## Next
Phase M should add real dealer dealing animation and connect picked cards/chips into betting/turn state.
