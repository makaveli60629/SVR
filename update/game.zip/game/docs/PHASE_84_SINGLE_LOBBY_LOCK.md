# Phase 84 — Single Lobby Lock

## Goal
Remove the duplicate / second lobby shell from inside the original SVR lobby while preserving the original lobby baseline.

## Changes
- Kept the original lobby as the only active room shell.
- Disabled the oversized embedded Legend hall mini-lobby.
- Replaced the full Reiki room-in-lobby build with a thin Reiki portal storefront.
- Replaced the full Scorpion room-in-lobby build with a thin Scorpion portal storefront.
- Preserved the poker table, seat logic, watch, teleport, PGA hub marker, sponsor/store wall, skyline, Moon, and Mars.
- Removed lobby music autoplay and audio payloads.
- Removed unapproved Reiki sponsor/founder strings and live media payloads from runtime.
- Removed desktop bottom buttons for Table and Zen Den to reduce duplicate-lobby navigation confusion.

## Locked Rules
- Website/site untouched.
- Game-side only.
- Original lobby preserved.
- Private experiences must not be physically embedded as full rooms inside the lobby.
- Lobby should contain only portal/storefront markers for private destinations.
- Package must remain under 25 MB.
