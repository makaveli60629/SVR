# VR Phase 28 — Navigation and Hub-Approach Polish

This pass keeps the stable larger-lobby VR baseline and focuses on making the room easier to move through.

## Preserved
- Meta hands only
- No watch
- No fake arms
- Left-stick movement
- Right-stick 45 degree snap turn
- Floor-target teleport
- Game-only update zip deploy path

## Changed
- widened the center navigation lane
- enlarged floor teleport targets again
- enlarged teleport flash feedback
- nudged the south seat approach slightly closer
- pulled Reiki and PGA approach targets slightly inward
- strengthened lane and hub-entry floor cues
- modestly increased locomotion speed

## Goal
Make the room feel less like a guided shell and more like a usable live lobby with clearer movement paths.
