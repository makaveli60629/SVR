# Phase G — Table + Dealer Gameplay Pass

This phase preserves the visible scene recovery, seat/teleport lock, and Camera 3 live view, then adds demo gameplay controls.

## Added
- Deal Demo button
- Chip Demo button
- keyboard shortcuts:
  - S sit/stand
  - T teleport arc
  - D deal demo
  - C chip demo
  - R reset view
- Eric dealer slot marker
- visible table/felt/cards/chips
- Camera 3 always-on live preview

## Not final yet
- Eric is still a slot/reference marker, not a fully animated rig.
- Poker evaluator is still the modular foundation, not the final Texas Hold'em engine.
- Multiplayer and sponsor systems are not wired yet.

## Next
Phase H should implement full Texas Hold'em evaluator, showdown tie logic, side pots, and legal raise rules.
