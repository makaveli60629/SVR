# Phase AP — Bankroll + Showdown Lock

## Audit result
CALL / RAISE / FOLD changed the pot, but the player cash display needed to be tied directly into the poker runtime.

## Fix
- CALL deducts player cash.
- RAISE deducts player cash.
- FOLD does not deduct cash.
- If YOU wins showdown, the pot pays into the player bankroll.
- Watch cash display reads live poker bankroll.
- Table status panel shows pot and player cash after actions.

## Preserved
- Main lobby scene routes.
- Reiki / Zen Den / PGA / Sponsor / Scorpion quick jumps.
- Camera 3 live preview.
- 07.mp3 playlist.
- Site untouched.
