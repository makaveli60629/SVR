# SVR Poker — Remaining Issues / Honest Limits

## Not verified in a real headset from this environment
- Final Quest hand-tracking anchor placement
- Final right-controller watch placement
- Final thumbstick behavior on the user's actual Quest hardware
- Final teleport arc comfort/visual feel in-headset

## Still simplified compared with the historical vision
- Dealer is a safe primitive stand-in, not a restored animated NPC
- Lobby is a refined recovery shell, not a full historical asset-for-asset recreation
- Cards/chips are demo props, not a complete poker game system

## Likely next debug targets after user test
- Wrist orientation fine-tuning for the watch
- Controller/hand visibility tuning by Quest mode
- Eye-line fine-tuning for seated table height
- Optional higher-detail lobby art that does not risk boot
