# SVR Poker Phase 50 Manifest

## Focus
Final debug sweep and broadcast preview cleanup.

## Changes
- Added hard safety rescue so the player is pushed back out of the table area if overlap happens.
- Added closer CAM 3 broadcast framing for preview mode.
- Added `cam3.html` as a dedicated clean spectator page.
- Added burn cards before flop, turn, and river in the autoplay Hold'em demo.
- Updated build markers to Phase 50.

## Test
1. Boot desktop and verify spawn is behind the table.
2. Walk into the table edge and confirm you do not get stuck inside it.
3. Open `cam3.html` and verify only CAM 3 is shown.
4. Watch a hand and confirm burn cards appear before flop, turn, and river.
