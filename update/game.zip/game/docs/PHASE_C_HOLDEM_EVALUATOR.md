# Phase C - Texas Hold'em Evaluator + Side Pots

## Purpose
This phase upgrades the poker core without touching the VR lobby boot path.

## Added / Changed
- Full five-card hand category scoring
- Best-five-from-seven Hold'em evaluator
- Tie-ready score comparison
- Side-pot builder
- Side-pot payout splitter
- Debug tests for straight flush, full house, wheel straight, flush, and side pots

## Safety
This phase keeps logic inside `game/core/` and `game/debug/` so the scene boot remains isolated.

## Next Phase
- Wire evaluator output to table UI
- Add legal blind posting and turn order
- Add bot decision strategy
- Add card/chip animations after logic is stable
