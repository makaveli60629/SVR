SVR Poker - Rig Pass Hard Fix

What was fixed:
- Included the actual riggedhumanmale.fbx file inside game/assets/models/rigged/
- Included the actual male_sitting_pose.fbx file inside game/assets/models/poses/
- Preserved the corrected table.glb and scene layout
- Kept the south/front seat open for testing

Root cause of the broken build:
- index.html referenced FBX files that were not packaged into the shipped update/game.zip
- the live deploy therefore fell back to placeholder cylinders only

Next target after verification:
- replace placeholder seat cylinders with real chair geometry
- retarget seated poker poses and dealer idle/deal animations
- restore the true lobby shell and merge the rigged bots into it
