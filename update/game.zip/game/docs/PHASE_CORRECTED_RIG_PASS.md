SVR Poker - Corrected Rig Pass

This update fixes the broken rig staging package that only showed cylinders/placeholders.

What was wrong in the prior rig pass:
- game/index.html referenced assets that were not inside update/game.zip
- missing runtime files included table.fbx, moon.fbx, and eric.fbx
- result: the page fell back to the simple cylinders and labels, which matches the screenshot from testing

What this corrected package includes:
- self-contained game/index.html
- embedded runtime assets actually packaged inside update/game.zip
- table.glb
- riggedhumanmale.fbx for the standing dealer
- male_sitting_pose.fbx for seated player bots
- south/front open player seat preserved
- on-screen loader diagnostics for quick testing

What is still needed for final NPC polish:
- poker-specific deal animation
- seated idle refinements
- chip reach / card peek poses
- final dealer identity decision (rigged male vs Eric vs mixed cast)
