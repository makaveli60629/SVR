# Phase T — Lobby Camera Clean + Live Preview Only

Removes Camera 3 from the normal lobby. Camera 3 is now only an optional live preview/debug camera toggled with the Preview Cam button or P key. Test `/game/?v=phase-t`.
