# Phase AS — Check Action Audit Lock

- Site untouched.
- Camera 3 live preview preserved.
- Scene routes preserved.
- Fixed missing CHECK runtime wiring.
- Watch now has CHECK beside CALL / RAISE / FOLD.
- Desktop fallback: X = CHECK.
- CHECK adds no chips and deducts no bankroll.
