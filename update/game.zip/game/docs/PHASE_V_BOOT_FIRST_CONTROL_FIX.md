# Phase V — Boot First Control Fix

This build removes the external `XRControllerModelFactory` import that could stop the scene before `boot()` runs.

## Preserved
- Meta raw controllers
- Hand pinch hooks
- Android touch joystick
- PC keyboard / mouse
- Clean main lobby camera
- Camera 3 optional preview only

Open `/game/?v=phase-v`.
