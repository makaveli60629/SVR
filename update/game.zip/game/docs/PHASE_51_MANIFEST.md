# Phase 51 — real lobby lock + stabilization

## Goal
Lock the current playable baseline and continue all remaining fixes inside the real lobby instead of a stripped preview state.

## Main changes
- reduced blinking / pulsing intensity across the lobby
- widened spawn safety margin and moved spawn farther back
- reduced lighting/fog exposure spikes
- lifted table overlays and cards slightly to reduce z-fighting flicker
- restored a fuller lobby shell:
  - south entry portal
  - red carpet promenade
  - sponsor mission walls
  - world rings
  - planters
  - existing skyline, moon, earth, Reiki lounge, kiosks, dealer, table, chairs
- kept modular file layout intact

## Locked baseline from this phase forward
- real lobby is now the working baseline
- CAM 3 preview remains available with no HUD on preview mode
- autoplay Texas Hold'em demo remains active with a real 52-card deck
- watch / teleport / seat / reset remain in place
