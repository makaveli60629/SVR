# VR Phase 23 — True Lobby Detail Restore

This phase keeps the stable VR baseline and restores more of the room-finish language so the larger lobby reads less like a recovery shell.

## Preserved
- Meta hands only
- No watch
- No fake arms
- Left-stick movement
- Right-stick 45 degree snap turn
- Floor-target teleport
- Game-only update zip path

## Added
- Front planter/detail accents
- Window-wall trim restoration
- Skyline sparkle and building-light cues
- Stronger table labeling/detail cues
- Clearer south-seat lane read
- Reiki detail accents
- PGA detail accents
- Sponsor stage dressing
- Ceiling beam accents

## Goal
Continue moving toward the original larger-lobby identity without destabilizing the current VR boot path.
