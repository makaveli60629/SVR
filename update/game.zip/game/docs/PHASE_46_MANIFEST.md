# SVR Poker — Phase 46 Manifest

## Focus
Final gameplay cleanup for the public demo build.

## Included
- keeps grabbed chips and cards on the table more reliably when released
- expands the table demo layout with extra chips and cards
- refreshes build metadata to phase 46
- preserves CAM 3, watch controls, chair glow, and teleport fallback

## Test
1. Grab each chip/card and release it near or beyond the table edge.
2. Confirm props return to a clean table position instead of being lost.
3. Confirm watch TP / SEAT / RST still works.
4. Confirm CAM 3 stays live.
