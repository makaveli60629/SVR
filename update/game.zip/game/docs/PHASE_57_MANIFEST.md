# SVR Poker — Phase 57 manifest

## Focus
- move matrix wall off the front table view
- keep preview CAM 3 on director auto-move shots only
- tighten the watch to the wrist and enlarge buttons
- keep teleport on trigger release after TP is armed
- reduce flicker / pulse intensity
- lift demo cards higher and make them more readable
- add BOT chair tags so occupied seats read clearly

## Notes
This phase uses the uploaded backup as reference material, but the backup did not contain one exact ready-to-restore full lobby shell.
The lobby in this pack is a cleaner rebuild aligned to the requested features.
