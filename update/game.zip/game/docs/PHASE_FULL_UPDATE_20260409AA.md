Build: 20260409AA-FULL-UPDATE

Base: 20260409Y boot-safe room test.

What changed:
- kept the boot-safe lobby, Reiki room, Scorpion room, and jumbotron path as the runtime base
- refined the Reiki storefront into a clearer 3-column layout with more spacing and added beauty/display lights
- moved the PGA hub to the southwest side and lowered the portrait/plaque zone so it sits cleaner
- added sponsor-ready skyline towers with a primary TRUEITIVE.COM sponsor tower and a secondary ESPRESSO WITH CREAM tower
- reduced stars, sprite count, and pulsing to make the lobby smoother and less blinky
- brightened the moon texture presentation slightly while preserving orbital motion
- added cache-busting version tags to main lobby module imports
