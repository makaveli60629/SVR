# SVR Poker Recovery Phase Next — 2026-04-10

This package keeps the working self-contained recovery baseline and adds the next visible polish pass.

## What changed
- Added an overview camera and a south-seat preview camera.
- Added a minimap so the lobby flow is easier to understand.
- Added a guided tour mode for faster user onboarding.
- Added high-contrast and reduce-motion toggles.
- Added FPS/performance readout.
- Marked the south/open seat more clearly.
- Improved building ad readability and sponsor rotation.
- Improved Reiki and PGA storefront presentation while keeping the current recovery-safe renderer.
- Kept the package small and deploy-safe.

## Why this phase exists
The live 3D boot path is still unstable. This phase improves usability and presentation without reintroducing the black-screen failure.

## Next target
Merge the real lobby modules back in gradually on top of this visible baseline:
1. stable asset manifest
2. controlled 3D scene re-entry
3. watch / movement / seat systems
4. Reiki + PGA + building ad final art pass
