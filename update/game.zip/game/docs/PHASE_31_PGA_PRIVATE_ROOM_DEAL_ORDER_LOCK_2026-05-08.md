# Phase 31 — PGA Private Room + Deal Order Lock

## Fixed

- Moved PGA controller driving range out of the main lobby into a separate private scene area.
- Added private PGA room shell so the driving range no longer overlaps lobby storefronts or poker table.
- Kept PGA Hub as a lobby storefront/portal only.
- Kept PGA Drive and Chip/Putt as private teleport destinations.
- Kept dealer body permanently disabled.
- Kept five neutral seated bots and one open south/front player seat.
- Added a visible gold D dealer button marker.
- Locked card dealing to start after the D button and proceed left-to-right around the table.

## Controls

- `0` jumps to private PGA Drive.
- `B` performs desktop PGA demo swing.
- `H` advances poker hand.
- Watch buttons preserve PGA Hub / Drive / Chip routing.

## Preserved

- Phase 29 clean master lock.
- No unapproved wellness runtime branding.
- No visible dealer mesh, Eric rig, or FBX runtime payload.
- Site untouched.
- ZIP under 25 MB.
