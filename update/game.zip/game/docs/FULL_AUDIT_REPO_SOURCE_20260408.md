# SVR Poker Full Audit — Repo + Source + Package

## Scope
This audit was run against the active `game.zip` package and the available backup source snapshots in the workspace.

## What was checked
- route entry points for `/game/`, `/game/reiki/`, `/game/scorpion/`, and `/game/sandbox/`
- JavaScript syntax for the main lobby, shared modules, Reiki room, and Scorpion room
- packaged assets referenced by the active runtime
- watch, teleport, portal, and room routing source consistency

## Fixes applied in this audit pass
- added a dedicated `/game/scorpion/` route instead of relying only on `/game/sandbox/`
- updated the lobby HUD Scorpion link to use the dedicated route
- added modular source config files for the PGA and Reiki hubs under `game/modules/hubs/`
- fixed the wrist watch so it now falls back to a camera-relative position when wrist joints are unavailable
- refreshed the build label to distinguish this audited package

## Verified packaged runtime assets
- `game/assets/table/table.fbx`
- `game/assets/npc/eric/eric.fbx`
- `game/assets/ui/logo.png`
- `game/assets/ui/juan-espejo.jpg`
- `game/assets/reiki/plant01.fbx`
- `game/assets/reiki/plant03.fbx`

## Notes
- the active runtime is still the Three.js modular lobby package, not the older A-Frame lobby backup
- the uploaded RAR tree/mountain packs are not part of this GitHub-safe package
- exact in-headset visual alignment still requires Quest-side confirmation after deploy
