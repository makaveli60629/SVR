# Phase C - Visible Scene Recovery

## Purpose
Fix the post-black-screen state where the runtime loads but shows only a dark edge/wire view.

## Fixes
- Adds boot-safe visible procedural lobby.
- Adds brighter Quest/mobile-safe lighting.
- Resets camera to face the table.
- Keeps a procedural table visible even if the GLB loads dark or oversized.
- Loads real table only as a controlled secondary asset.
- Adds chair ring, open south/front seat marker, Eric dealer marker, Reiki/PGA markers, skyline, moon, Mars.
- Keeps poker core modules included but not connected to boot path.

## Status
GitHub-safe deploy package under 25 MB.
