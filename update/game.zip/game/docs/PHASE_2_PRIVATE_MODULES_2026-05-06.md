# Phase 2 — Private Modules Buildout

## Purpose
Phase 2 restores the correct hub architecture: the lobby remains a clean storefront/portal layer, while the full experiences live in private teleport scenes.

## Added / refined

### Reiki Grove private scene
- Added a private meditation grove scaffold.
- Added tree clusters, red path, meditation ring, cushions, private moon, stars, breathing halo, and instruction board.
- No unapproved wellness sponsor branding.

### PGA Range private scene
- Added a golf practice module scaffold.
- Includes driving-range turf, tee box, ball, club guide, targets, putting cup, chipping target, and instruction board.
- Added a visible demo ball flight/roll loop so the range reads as active before full physics is installed.

### Smoker Lounge private scene
- Added couch layout, center table, jumbotron/social board, and soft haze particles.
- Kept it as a private social room, not a lobby wall embed.

### VR Store private scene
- Added avatar/clothing showroom scaffold.
- Includes mannequins, racks, and future clothing/gear instruction board.

## Preserved locks
- No music and no audio folder.
- One-controller movement.
- 45-degree snap turn.
- Trigger-release teleport only when armed.
- Pinch-leap teleport disabled.
- Seat edge lock.
- Flat chip/bet movement and left-first card dealing.
- Freestanding lobby storefronts.

## Next phase recommendation
Phase 3 should focus on the sky/world pass and hub routing polish:
1. Raise moon/Mars higher and improve glow visibility.
2. Make stars denser and clearer above skyline.
3. Reduce scene button clutter and organize watch pages.
4. Improve private-scene return portals.
