# Phase 6 — Smoker Lounge + Scorpion VIP Social Refinement

## Build label
PHASE-6-SOCIAL-VIP

## Scope
This phase refines the private social modules without changing the site or re-embedding hub scenes into the lobby.

## Completed
- Rebuilt the Smoker Lounge private room into a clearer social lounge module.
- Added conversation seating, privacy glow ring, social table, lounge jumbotron, and soft haze.
- Added compliance-facing wording: adult medicinal lounge concept, no sales flow.
- Rebuilt Scorpion VIP into a private city-overlook poker lounge.
- Added VIP seating, replay cards, city glass, neon safety rail, and featured-hand board.
- Preserved the Phase 1 freestanding storefront portal structure.
- Preserved Phase 2 private modules, Phase 3 sky route polish, Phase 4 PGA range physics, and Phase 5 Reiki/VR Store replacement.

## Preserved locks
- No music, no MP3, no audio payload.
- One-controller movement.
- 45-degree snap turn.
- Trigger-release teleport only when TP is armed.
- Finger-pinch leap disabled.
- Player seat edge lock.
- Flat poker chip movement.
- Left-first card dealing.
- Site untouched.

## Runtime markers
- `scene.userData.SVR_PHASE6_SOCIAL_VIP_READY`
- `root.userData.phase6.smoker`
- `root.userData.phase6.scorpionVip`

## Next recommended phase
Phase 7 should focus on full teleport/watch navigation cleanup and route naming simplification so the player sees fewer duplicate buttons and clearer destinations.
