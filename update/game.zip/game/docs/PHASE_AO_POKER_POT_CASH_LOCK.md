# Phase AO — Poker Pot / Cash Lock

- Added shared runtime cash delta hook.
- CALL and RAISE now deduct player cash and add to pot.
- FOLD updates status without deducting cash.
- Watch poker status includes pot and cash after player action.
- Scene jumps, Camera 3, Meta hand/controller fallback, and site isolation preserved.

## Test
Press H for new hand, C for call, R for raise, F for fold. On watch use NEW HAND / CALL / RAISE / FOLD.
