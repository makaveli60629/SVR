# SVR Poker Phase 48 Manifest

## Scope
- Added an autoplay Texas Hold'em demo loop
- Uses a real 52-card deck
- Deals two hole cards to 6 seats, then flop / turn / river
- Evaluates the winning 7-card hand and highlights the winner
- Keeps CAM 3 always on and preview-safe with `?preview=1`

## Controls
- `N` forces the next hand
- Existing TP / SEAT / RST controls remain active

## Notes
- This is a real card / showdown demo pass
- Betting is scripted for presentation, not player-driven yet
