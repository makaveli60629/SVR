# Phase D - True Lobby Visible Restore

Purpose: fix the remaining dark/minimal scene by restoring a bright boot-safe lobby shell and clear camera view.

## Included
- Bright boot-safe renderer setup
- Camera reset facing the table
- Visible floor, walls, table, felt, chair ring, open south/front seat
- Eric dealer rig-slot marker
- Reiki and PGA storefront position markers
- Skyline, ad markers, moon and Mars
- Teleport test pad marker for the next interaction phase
- Existing poker core preserved without forcing UI integration

## Next phase
Phase E - Seat + Teleport Lock.
