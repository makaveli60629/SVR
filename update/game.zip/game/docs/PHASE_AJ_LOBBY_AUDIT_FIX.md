# Phase AJ — Lobby Audit + Corrective Alignment Fix

Build: 20260426-PHASE-AJ-LOBBY-AUDIT-FIX

## Audit findings
- Boot path is valid and the package still contains the modular runtime.
- The lobby carried an older Phase 39 label, making screenshots hard to verify.
- Room radius, spawn distance, and camera target needed a larger true-lobby feel.
- The south player seat needed to remain the guaranteed open player seat.
- Seated bots were allowed to orient toward the active camera, which made the table read wrong from live preview and VR.
- Earth was built but hidden while the new skyline pass expects Moon, Mars, and Earth to be visible.
- The floor logo was too strong and made table/felt inspection harder.
- Ambient sprite counts were high enough to increase Quest shimmer/blink risk.

## Fixes applied
- Updated build label to 20260426-PHASE-AJ-LOBBY-AUDIT-FIX.
- Increased lobby radius from 24 to 27.
- Moved default spawn to the south player approach at z=5.25, facing the table.
- Lowered table baseline to CONFIG.TABLE_TOP_Y = 0.875.
- Rebalanced wall height so the skyline remains visible.
- Reduced ambient sprite/snow counts for steadier frame pacing.
- Repositioned Moon, Mars, and Earth into a more readable skyline range.
- Restored Earth visibility and its low-intensity halo/glow.
- Kept Moon and Mars texture-first with restrained glow.
- Kept the south/front player chair open and renamed it Open South Player Seat.
- Locked seated bots to face the table instead of tracking the camera.
- Softened the floor logo under the table for better felt/table inspection.
- Kept Reiki, PGA, Scorpion, Legends, store wall, music, watch, teleport, hands, controller fallback, and live preview modules.

## Test checklist
1. Load /game/ and confirm the build pill says PHASE-AJ-LOBBY-AUDIT-FIX.
2. Confirm the lobby feels larger, not like a recovery shell.
3. Confirm default spawn faces the table from the south approach.
4. Confirm the south/front player chair is open.
5. Confirm bots face the table and do not pivot toward live preview/camera.
6. Confirm Moon, Mars, and Earth are visible in the skyline.
7. Confirm the table/felt is easier to inspect because the floor logo is softer.
8. Confirm Reiki and PGA hubs are still present.
9. Confirm Quest movement, right-stick snap turn, watch, and teleport still boot.

## Next recommended phase
Phase AK should focus on final visual polish only: table felt UV/scale, chair/player eye-line, Eric dealer dealing pose, and removal of any remaining debug-looking UI after live validation.
