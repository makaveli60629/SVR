# Phase — Scorpion/Smoker Sign Orientation + Moon/Mars Skyline Fix

## Fixed
- Added a readable-sign backface hotfix for canvas-generated sign panels.
- Prevents lounge/store/scorpion text from appearing backwards when viewed from the rear side of a plane.
- Changed text planes from single DoubleSide rendering to paired FrontSide planes so signs stay readable from both sides.
- Raised Moon and Mars high above the skyline path.
- Pushed Moon and Mars farther behind/outside the city skyline so they do not sit inside the building line.
- Kept both planets visible and moving with a smaller, smoother orbit.

## Notes
- This phase is game-only and does not modify the site.
- Package stays under the GitHub 25 MB target.
- Zip permissions are normalized for GitHub Pages deploy.
