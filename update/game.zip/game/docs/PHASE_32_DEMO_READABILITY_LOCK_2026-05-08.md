# Phase 32 — Demo Readability Lock

Date: 2026-05-08

## Purpose

This phase cleans up the demo presentation after the Phase 31 PGA/private-room and deal-order fix. It focuses on visibility, navigation clarity, poker-table readability, and separating the PGA rooms correctly.

## Fixes

- Kept the dealer body removed permanently.
- Kept the rotating gold D dealer button.
- Re-locked card dealing so each hand starts left of the rotating dealer button and continues left-to-right around the table.
- Removed the public Table button from bottom navigation and the wrist watch.
- Kept Seat as the table access route.
- Restored a Reiki Room / meditation-room route without changing the existing Reiki design.
- Split PGA into two private rooms:
  - PGA Drive Range for full-swing controller testing.
  - PGA Chip + Putt Room for short-game practice.
- Improved the PGA storefront layout so the profile image and information panel fit better.
- Added Drive Range and Chip + Putt portal plaques to the PGA hub.
- Added detailed South/About wall boards covering mission, sponsorship, compliance, and SVR overview.
- Added pass/bet line graphics to the poker table.
- Added the SVR logo overlay to the center of the table.
- Rebuilt table chips as flat denomination chips with readable values and colors.
- Enlarged and raised community cards for seated readability.
- Made Moon and Mars closer/brighter so they are visible from the lobby skyline.

## Preserved

- True larger lobby baseline.
- Site untouched.
- No visible dealer mesh.
- Unapproved wellness branding remains removed.
- South/front player seat remains open.
- Five seated NPCs remain around the table.
- Reiki content left unchanged except route/button restoration.
- ZIP under 25 MB.

## Known note

The seated NPCs are still procedural web-safe placeholders, but Phase 32 makes them more human-like. Real high-quality seated characters should be added later as optimized GLB/VRM-style web assets, not raw FBX payloads, to keep deployment stable.
