# Phase O — Watch Hub + Production Table UI

Adds an in-world watch hub panel and stronger table UI state. Open `/game/?v=phase-o`.

Keyboard: W watch, N next street, 1/2/3/4 betting, S sit, T teleport, D deal.
