# SVR Poker — Phase 1 Hub Restoration + Scene Routing Lock

## Build intent
Restore the lobby hub layer so hubs look like freestanding storefront portals again, not embedded wall labels. The lobby now acts as a central mall/portal floor while full experiences remain private scene destinations.

## Fixed in Phase 1

### Lobby hubs restored as freestanding storefronts
- Restored **Reiki Hub** as a clean wellness storefront portal.
- Added **PGA Golf Hub** as a clear golf storefront with turf, ball, tee, and flag visual cues.
- Added **VR Store** storefront for future clothing/avatar switching.
- Preserved **Smoker Lounge**, **Scorpion Poker**, **Legend Hub**, and **Future Sponsor** storefronts.
- Pulled storefronts off the wall so they read as real lobby structures instead of flat embedded labels.
- Replaced the old embedded Reiki wall panel with a neutral skyline/freestanding-hub wall note.

### Private scene routing preserved
- Reiki Hub routes to **Reiki Grove** private scene.
- PGA Golf Hub routes to **PGA Range** private scene.
- VR Store routes to **Store Room** private scene.
- Smoker Lounge routes to **Lounge Room**.
- Scorpion Poker routes to the private poker room / VIP scene.

### Sky refinement started
- Moon and Mars moved higher above the skyline.
- Moon and Mars orbit paths adjusted so they should not clip through city buildings.
- Increased moon/Mars halo and glow intensity.
- Preserved visible star band.

### Locks preserved
- No music/audio payload.
- One-controller movement.
- 45-degree snap turn.
- Trigger-release teleport only when teleport is armed.
- Finger-pinch leap teleport disabled.
- Watch and bottom scene buttons preserved.
- Poker seat/chip/card polish from previous lock preserved.

## Next phases

### Phase 2 — Private scene restoration
- Rebuild private Reiki Grove with trees, meditation ring, moon/stars, and calm environment.
- Build private PGA Range with driving, chipping, and putting layout scaffold.
- Improve private Smoker Lounge and VR Store destination rooms.

### Phase 3 — Golf interaction prototype
- Add controller-as-club visual.
- Add swing speed sampling.
- Add golf ball launch and roll behavior.
- Add tee, chip, and putt practice targets.

### Phase 4 — Sky final pass
- Improve star density and sky contrast.
- Add slow natural orbit and stronger planet material response.
- Ensure moon/Mars remain visible when looking upward from lobby and private scenes.

### Phase 5 — Final hub routing and watch cleanup
- Reduce cluttered navigation labels.
- Add final watch pages/categories for Lobby, Hubs, Private Rooms, and Poker.
- Lock module manifest for production testing.
