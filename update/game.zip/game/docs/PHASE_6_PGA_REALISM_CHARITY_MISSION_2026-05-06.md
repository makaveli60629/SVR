# Phase 6 — PGA Realism + Charity Mission Wall

## Build goal
This phase upgrades the private PGA range direction and the main lobby mission presentation without touching the site.

## PGA range updates
- Removed the flat mountain-picture approach.
- Added a lightweight 3D depth environment using low-poly layered ridges instead of a backdrop image.
- Added a realistic training layout:
  - Driving range bay
  - Combined chipping / putting green
  - Sand bunker lies
  - Rough/fairway transition zones
  - Yardage boards and target rings
  - Club rack with Driver, 7 Iron, Sand Wedge, Chipper, and Putter
  - Visual shot arc and training analytics panel
- Added scene targets:
  - PGA / full range
  - Drive / driving bay
  - Chip/Putt / short-game area

## Lobby mission updates
- Added a larger elegant south-wall mission zone.
- Added two decorative pillars and a premium presentation panel.
- Added a charity / giveback message explaining:
  - sponsor-funded events
  - prize opportunities
  - donations to shelter pets, homeless outreach, and families in need
  - future transparency reporting
- Added a glowing mission music pad.
  - Desktop click/tap on the pad changes the active music track.
  - Keyboard shortcut `0` jumps to the mission wall.

## Cleanup
- Removed old unauthorized outside partner references from source/docs text.
- Removed outside partner UI assets from the game package.
- Disabled old store FBX/GLB loading and removed old store model payload.
- Preserved the lightweight SVR VR Store kiosk fallback.

## Preserved locks
- Site untouched.
- One-controller movement preserved.
- 45-degree snap turn preserved.
- Trigger-release teleport preserved.
- Pinch-leap teleport remains disabled.
- Poker controls preserved.
- Existing Reiki / Scorpion / Smoker / VR Store structure preserved.

## New desktop controls
- `5` = PGA full training range
- `G` = PGA driving bay
- `V` = PGA chip/putt area
- `0` = charity mission wall
- Click the glowing mission pad = show mission details
