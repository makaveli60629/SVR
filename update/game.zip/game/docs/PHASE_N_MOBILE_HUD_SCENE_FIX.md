# Phase N — Mobile HUD + Visible Scene Fix

Fixes overlapping buttons and brightens/resets the scene so testing does not look like a black screen. Open `/game/?v=phase-n`.
