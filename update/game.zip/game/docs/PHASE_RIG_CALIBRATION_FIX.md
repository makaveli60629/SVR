SVR Rig Calibration Fix

Changes in this pass:
- replaced the oversized table shell with a smaller calibration table made from primitives
- opened the center pedestal so dealer and seated bots can be seen and measured
- kept the south/front seat open
- kept Eric visible in-frame as a standing scale reference
- preserved the dealer rigged male and seated player bot FBX assets inside the update package

Purpose:
This is a calibration pass to verify bot/table alignment before merging the final bot layout back into the full lobby.
