# VR Phase 14 — True Lobby Shell Restore

This pack starts the return from the recovery scaffold to the larger real-lobby target.

Included:
- larger cylindrical lobby shell
- stronger skyline window wall
- restored real table model
- table logo surface
- wider Reiki and PGA storefront walls
- sponsor wall cleanup
- Meta hands only
- no watch
- no fake arms
- stable controller locomotion and floor-target teleport fallback
