Phase 50 adds a dedicated CAM 3 page, closer preview framing, burn cards in the live Hold'em demo, and a safety rescue for table overlap.
