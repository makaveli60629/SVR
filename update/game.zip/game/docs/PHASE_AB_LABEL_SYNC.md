# Phase AB — Label Sync + VR Notice Cleanup

This phase fixes mixed labels where the top UI showed Phase Y while the 3D marker showed Phase AA.

## Must show
- Top UI: `PHASE AB: LABEL SYNC`
- 3D marker: `PHASE AB ACTIVE - LABELS SYNCED`

## Also fixed
- Central `VR NOT SUPPORTED` overlay softened
- Manual Enter VR button preserved
- Centered lobby preserved
- Camera 3 remains preview-only

Open `/game/?v=phase-ab&t=002`.
