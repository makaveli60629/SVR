Alignment tidy pass: smaller table footprint, bots pulled inward, dealer moved behind rail, Eric moved closer for scale, captions reduced and pushed out of main frame.
