# Phase B - Interaction Lock

This deploy package is the modular game zip prepared for the next recovery-to-playable pass.

## Included module tracks
- core-lobby-restore
- movement-baseline
- seat-teleport-lock
- table-alignment
- dealer-player-rig
- reiki-pga-restore
- world-atmosphere
- perf-deploy-safe

## Deploy focus
- boot-safe package
- preserve current movement baseline
- preserve seated/teleport/table/dealer modular work path
- keep asset packaging deploy-safe for GitHub Pages overlay flow

## Notes
- This package is built from the current repo game folder and repacked with normal zip permissions.
- FBX runtime assets are included inside the game package.
- This is a deploy package, not a final feature-complete gameplay release.
