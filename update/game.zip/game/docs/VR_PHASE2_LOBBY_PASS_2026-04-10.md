SVR Poker VR Phase 2 lobby pass

Goals:
- keep the new stable VR boot path
- reduce flat fallback feel
- improve room scale and presence
- keep a guaranteed open south seat
- preserve Reiki and PGA identity with cleaner kiosks
- keep sponsor ad wall visible without clutter

Notes:
- self-contained A-Frame build
- uses only shipped logo textures
- low-poly geometry for smoother Quest/browser performance
- standing spawn remains default
