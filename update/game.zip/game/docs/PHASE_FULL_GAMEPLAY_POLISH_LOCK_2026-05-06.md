# Phase Full Gameplay Polish Lock — 2026-05-06

## Scope
This phase converts the current private-scene/storefront build into a stronger playable demo pass while preserving all locked comfort and safety requirements.

## Locked requirements preserved
- Site untouched.
- No music, no MP3 payload, no autoplay path.
- One-controller movement: either controller can move and snap-turn.
- 45 degree snap turn.
- Trigger-release teleport only when teleport is armed.
- Finger-pinch leap teleport remains disabled.
- Watch scene buttons preserved.
- Hub storefronts stay in the lobby as portals only.
- Full store scenes remain private teleport destinations outside the lobby floor plan.

## Fixes in this phase

### Seating / player position
- Seat jump now targets the edge of the table, not the middle/back of the chair.
- The player seat target moves inward toward the table by 0.42m.
- XR seated reference height adjusted to reduce floor/chair sinking.
- Desktop seat camera also moves to the corrected table-edge position.
- `Seat` quick-jump now marks the player as seated and updates the watch status.

### Poker demo gameplay
- Chips are now flat on the table instead of appearing upright/edge-on.
- Player and bot bet actions create visible flying chip movements into the pot.
- Winner resolution creates a visible chip sweep from the pot toward the winner.
- Pot chips are still stacked in the center for readability.
- Demo dealing now starts from the table's left side first instead of the right side.
- Watch HUD continues to show player cards, hand result, pot, call/raise state, and action buttons.

### Skyline / sky objects
- Moon and Mars are repositioned lower and clearer above the city skyline while still behind/outside the skyline view.
- Moon and Mars are larger and emissive enough to read on Quest.
- Depth testing is disabled for Moon/Mars so the skyline wall does not hide them.
- Added a visible star band above the skyline so stars appear in normal player view.
- Star count reduced for performance while keeping a visible sky effect.

### Runtime audit lock
- Updated `mod_lock.js` to expose the phase lock through:
  - `window.SVR_MOD_LOCK`
  - `window.SVR_MOD_AUDIT`
  - `window.SVR_AUDIO_DISABLED`
  - `window.SVR_PRIVATE_SCENES_READY`
- The audit now records seat-edge lock, chip movement lock, left-first deal, and skyline visibility.

## Full gameplay status
Playable demo loop now includes:
- seated player position
- live card dealing
- player Fold / Call / Raise / Next Hand controls
- watch HUD poker actions
- moving chip bet demo
- winner chip sweep demo
- private scene teleports

## Remaining phases to finish

### Phase 1 — VR interaction completion
- Physical card peek.
- Physical chip grab/push.
- Controller trigger interaction with chips/cards.
- Hand tracking grab without accidental teleport.

### Phase 2 — Dealer and bot animation finish
- Seated dealer rig using Eric.
- Dealer arm/card-deal animation.
- Seated bot pose polish.
- Bot chip/card reach animation.

### Phase 3 — release cleanup and GitHub lock
- Remove stale docs/assets.
- Validate all private rooms in Quest.
- Validate GitHub deploy permission path.
- Final release manifest and version tag.

## Test checklist
1. Load game in desktop browser.
2. Press Seat and verify the camera is at the table edge.
3. Press F/C/R/H during poker turns.
4. Watch chips move to the pot during bets.
5. Watch pot chips sweep toward the winner at showdown.
6. Verify first card movement starts from the left-side seats.
7. In Quest, verify Moon, Mars, and stars are visible above the city skyline.
8. Verify private scene teleports still work from bottom buttons and watch buttons.
