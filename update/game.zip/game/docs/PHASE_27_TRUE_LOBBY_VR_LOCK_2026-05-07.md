# Phase 27 — True Lobby VR Lock

## Purpose
This build corrects the game back toward the real SVR lobby instead of a temporary shell. It keeps the larger circular rooftop lobby, poker table, skyline, Moon/Mars/stars, storefront hub layer, wrist watch, Meta hand support, and Quest controller fallback.

## Fixed
- Restored build label/title to Phase 27 True Lobby VR Lock.
- Removed old unapproved third-party wellness branding references from runtime code and package docs/assets.
- Reiki is now a generic SVR Reiki storefront portal plus a private Reiki meditation room.
- PGA is now a storefront portal plus private Drive and Chip/Putt training targets.
- Added a procedural VR Store private room target so the old store FBX/GLB is not required.
- Watch quick routes now include hub portals and private rooms.
- Watch can anchor to real Meta hands or controller hand proxies.
- Controller objects remain hidden while hand-style proxies stay available.
- Teleport is armed from the watch/controller button; fist auto-teleport toggle is disabled to prevent accidental leaps.
- Controller trigger-release teleport still works once TP is armed.
- Right-stick Y movement works even when only the right controller is active; right-stick X remains 45-degree snap turn.
- Audio no longer auto-starts on XR session start; music remains manual via the watch.

## Locked constraints
- Site untouched.
- Ship as update/game.zip.
- Keep package under 25 MB.
- Preserve real lobby + VR-first controls.
