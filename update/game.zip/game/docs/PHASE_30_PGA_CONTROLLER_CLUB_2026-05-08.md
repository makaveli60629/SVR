# Phase 30 — PGA Controller Club Lock

## Purpose
Adds a private PGA driving-range trainer module without changing the main lobby layout.

## Added
- `game/modules/pga_controller_club.js`
- private PGA range surface with tee mat, lane rails, target rings, flag, ball, and shot board
- controller-following club visualization
- right-controller trigger grip baseline
- swing-speed launch calculation
- carry / total distance / ball-speed board
- desktop `B` demo shot fallback
- `0` keyboard shortcut to PGA Drive
- bottom buttons for `PGA Drive` and `Chip/Putt`
- watch buttons for `PGA HUB`, `DRIVE`, and `CHIP`

## Preserved
- Phase 29 Clean Master Lock
- Unapproved wellness branding remains removed
- visible dealer body remains disabled
- six-seat poker layout with open south/front player seat
- neutral seated bots
- site untouched
- ZIP under 25 MB

## Test checklist
1. Lobby loads.
2. PGA Drive button teleports to private range.
3. Press `B` on desktop; golf ball launches and shot board updates.
4. In Quest, hold right trigger to grip the club.
5. Swing through the ball; ball should launch based on controller speed.
6. Watch `DRIVE` and `CHIP` buttons route correctly.
