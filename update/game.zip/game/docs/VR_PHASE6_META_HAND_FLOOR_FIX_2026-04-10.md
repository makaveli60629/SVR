SVR Poker VR Phase 6 - Meta hand floor fix

Changes:
- Hide controller-hand fallback entities by default.
- Show controller rays and low-poly controller hands only when physical controllers connect.
- Keep hand-tracking entities active for Meta hand-tracking mode.
- Preserve left wrist watch anchor and stable VR recovery lobby flow.

Purpose:
Fix the issue where colored controller-hand meshes appeared on the floor while Meta hand tracking was enabled.
