# Phase 28 — PGA Info, Picture, and About Wall Fix

## Fixes

- Rebuilt the Juan Espejo PGA Hub profile texture for larger, cleaner, readable information.
- Replaced the thin/cropped portrait display with a framed portrait-card texture using the existing approved Juan Espejo image.
- Enlarged and repositioned the portrait panel so the face does not appear as a narrow sliver from the lobby angle.
- Updated the PGA hub header subtitle to match the private Drive and Chip/Putt training routes.
- Expanded the lobby ABOUT wall into a more detailed SVR overview covering the VR poker lounge, private rooms, Quest/controller support, replay wall, sponsor spaces, and community mission.
- Updated leaderboard and tournament wall copy for the current modular direction.

## Preserved Locks

- True lobby baseline.
- Site untouched.
- Package under 25 MB.
- VR-first controls, Quest controller fallback, watch routing, and private PGA/Reiki scene routes preserved.
