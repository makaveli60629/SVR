# SVR Poker — Do Not Break Notes

1. Do not replace the direct scene-mount boot path with a fragile custom init gate.
2. Do not remove local logo assets from the zip again.
3. Do not attach the watch to world-space coordinates.
4. Do not use the left controller as the primary watch fallback; the fallback is the right controller.
5. Do not make any FBX/GLTF path boot-critical unless it is proven safe in-headset.
6. Do not ship a build where the watch lands on the floor, at the table center, or floats in the lobby.
7. Do not ship without locomotion fallback.
8. Do not ship without visible chair glow, sit, stand, and teleport paths intact.
