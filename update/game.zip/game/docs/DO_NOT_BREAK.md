# SVR Poker — Do Not Break Notes

1. Do not replace the direct scene-mount boot path with a fragile custom init gate.
2. Do not remove local texture assets from the zip.
3. Do not attach the watch to world-space coordinates.
4. Do not use the left controller as the primary watch fallback; the fallback is the right controller.
5. Do not make any FBX/GLTF path boot-critical unless it is proven safe in-headset.
6. Do not ship a build where the watch lands on the floor, at the table center, or floats in the lobby.
7. Do not let right-hand teleport targeting depend on mere object visibility; require a valid tracked pose.
8. Do not ship without locomotion fallback.
9. Do not ship without visible chair glow, sit, stand, and teleport paths intact.
10. Do not remove the demo-state board unless another equally clear table-state cue replaces it.

11. Do not make CAM 3 the primary gameplay camera; it is a spectator mirror only.
12. Do not tie CAM 3 startup to a fragile gate that can block the main scene from loading.
