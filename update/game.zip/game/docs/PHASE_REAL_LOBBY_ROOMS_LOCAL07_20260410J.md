# Phase — real lobby + rooms + local 07

Build: 20260410J-REAL-LOBBY-ROOMS-LOCAL07

Source of truth:
- Main lobby visuals/runtime came from the user-uploaded `game.zip`.
- Room routes were merged from the audited room-source package.
- Local `07.mp3` was added as the only lobby music track.

What changed:
- Restored the user's real lobby baseline.
- Preserved Reiki, Scorpion, and PGA room routes.
- Added room buttons back to the HUD.
- Added local `07.mp3` only and removed the other bundled music tracks.
- Added a Music button wired to the local track.
- Extended `asset_base.js` so both the lobby code and room-route code can resolve assets.

Notes:
- Website untouched.
- Game-only package.
- Intended as the correct branch to continue future room upgrades from.
