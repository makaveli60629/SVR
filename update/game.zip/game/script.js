/*
  SVR Game Demo Script
  This demo uses a simple 2D canvas to illustrate chip gravity and teleport routing.
  Use the buttons at the top to simulate teleporting to different scenes.
  Click on the canvas to throw chips (red circles) with gravity enabled.
*/
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let width, height;
function resize() {
  width = canvas.width = window.innerWidth;
  height = canvas.height = window.innerHeight - document.getElementById('controls').offsetHeight;
}
window.addEventListener('resize', resize);
resize();

// Audio management
const lobbyMusic = new Audio('assets/audio/lobby_ambience.mp3');
lobbyMusic.loop = true;
// Play music after user interaction due to browser policies
let musicStarted = false;
document.body.addEventListener('click', () => {
  if (!musicStarted) {
    lobbyMusic.play().catch(() => {});
    musicStarted = true;
  }
});

// Chips physics
class Chip {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 10;
    this.vx = (Math.random() - 0.5) * 2;
    this.vy = -Math.random() * 5;
    this.color = '#e55';
  }
  update() {
    // gravity
    this.vy += 0.3;
    this.x += this.vx;
    this.y += this.vy;
    // bounce on table bottom (80% of canvas)
    const tableY = height * 0.8;
    if (this.y + this.radius > tableY) {
      this.y = tableY - this.radius;
      this.vy *= -0.5;
      // friction
      this.vx *= 0.7;
    }
    // damp velocity to simulate rolling friction
    this.vx *= 0.99;
  }
  draw(ctx) {
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 1;
    ctx.stroke();
  }
}
const chips = [];

// Golf ball physics (similar but bigger and heavier)
class GolfBall extends Chip {
  constructor(x, y) {
    super(x, y);
    this.radius = 12;
    this.color = '#eee';
  }
  update() {
    // stronger gravity for golf ball
    this.vy += 0.4;
    this.x += this.vx;
    this.y += this.vy;
    const tableY = height * 0.8;
    if (this.y + this.radius > tableY) {
      this.y = tableY - this.radius;
      this.vy *= -0.4;
      this.vx *= 0.8;
    }
    this.vx *= 0.98;
  }
}
const balls = [];

// Current scene state
let currentScene = 'Lobby';

// Planet objects for moon and mars animations
const moon = { angle: 0, radius: 40 };
const mars = { angle: Math.PI / 4, radius: 30 };

// Rising particle system for ambiance
const particles = [];
function initParticles(count = 50) {
  particles.length = 0;
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 2 + 1,
      speed: Math.random() * 0.5 + 0.2,
    });
  }
}
initParticles();

// Teleport simulation
function teleport(scene) {
  currentScene = scene;
  // Exit teleport mode when teleporting via buttons
  teleportMode = false;
  teleportBtn.textContent = 'Teleport Mode: OFF';
  // Optionally alert the user; comment out to avoid pop-ups
  // alert('Teleported to ' + scene + '! (simulated)');
}

// Button handlers
const teleportBtn = document.getElementById('teleportBtn');
let teleportMode = false;
teleportBtn.addEventListener('click', () => {
  teleportMode = !teleportMode;
  teleportBtn.textContent = teleportMode ? 'Teleport Mode: ON' : 'Teleport Mode: OFF';
});
document.getElementById('pgaBtn').addEventListener('click', () => teleport('Driving Range'));
document.getElementById('chipBtn').addEventListener('click', () => teleport('Chip/Putt'));
document.getElementById('reikiBtn').addEventListener('click', () => teleport('Reiki Escape'));
document.getElementById('missionBtn').addEventListener('click', () => teleport('Mission'));
document.getElementById('scorpionBtn').addEventListener('click', () => teleport('Scorpion'));

// Canvas interaction
canvas.addEventListener('click', (e) => {
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  if (teleportMode) {
    // In teleport mode, clicking does not spawn chips; we simulate teleport by spawning a chip marker
    chips.push(new Chip(x, y));
    // You could change scenes based on click position if desired.
  } else {
    // spawn chip
    chips.push(new Chip(x, y));
  }
});
// Right click to spawn golf ball
canvas.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  balls.push(new GolfBall(x, y));
});

// Track pointer position for teleport aiming
let pointerX = 0;
let pointerY = 0;
canvas.addEventListener('mousemove', (e) => {
  const rect = canvas.getBoundingClientRect();
  pointerX = e.clientX - rect.left;
  pointerY = e.clientY - rect.top;
});

function drawTable(ctx) {
  const tableTop = height * 0.8;
  // Draw table or ground differently based on scene
  if (currentScene === 'Driving Range') {
    ctx.fillStyle = '#283618'; // dark green turf
  } else if (currentScene === 'Chip/Putt') {
    ctx.fillStyle = '#2a9d8f'; // mint green for short game
  } else if (currentScene === 'Reiki Escape') {
    ctx.fillStyle = '#4b2e5c'; // deep purple for relaxing atmosphere
  } else if (currentScene === 'Mission') {
    ctx.fillStyle = '#403d39'; // muted dark for mission wall area
  } else if (currentScene === 'Scorpion') {
    ctx.fillStyle = '#5a1a1a'; // reddish hue for scorpion room
  } else {
    ctx.fillStyle = '#070'; // default poker table
  }
  ctx.fillRect(0, tableTop, width, height - tableTop);
  ctx.strokeStyle = '#090';
  ctx.lineWidth = 2;
  ctx.strokeRect(0, tableTop, width, height - tableTop);
}

// Draw environment background based on current scene
function drawEnvironment(ctx) {
  // Clear background first
  ctx.fillStyle = '#111';
  ctx.fillRect(0, 0, width, height);
  // Scene-specific backdrop colors or elements
  switch (currentScene) {
    case 'Driving Range':
      ctx.fillStyle = '#86ba90';
      ctx.fillRect(0, 0, width, height * 0.8);
      // Draw target rings for driving range
      for (let r = 50; r <= 200; r += 50) {
        ctx.strokeStyle = 'rgba(255,255,255,0.2)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(width * 0.5, height * 0.6, r, 0, Math.PI * 2);
        ctx.stroke();
      }
      break;
    case 'Chip/Putt':
      ctx.fillStyle = '#88c399';
      ctx.fillRect(0, 0, width, height * 0.8);
      // Draw putting holes
      for (let i = 0; i < 3; i++) {
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.arc(width * (0.3 + i * 0.2), height * 0.6, 8, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    case 'Reiki Escape':
      ctx.fillStyle = '#3d2352';
      ctx.fillRect(0, 0, width, height);
      // Draw a soft halo ring in the center
      ctx.strokeStyle = 'rgba(200, 160, 255, 0.3)';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(width * 0.5, height * 0.4, 80 + Math.sin(Date.now() * 0.001) * 10, 0, Math.PI * 2);
      ctx.stroke();
      break;
    case 'Mission':
      ctx.fillStyle = '#312f2f';
      ctx.fillRect(0, 0, width, height);
      // Draw mission board
      const boardX = width * 0.1;
      const boardY = height * 0.3;
      const boardW = width * 0.8;
      const boardH = height * 0.4;
      ctx.fillStyle = '#222';
      ctx.fillRect(boardX, boardY, boardW, boardH);
      ctx.strokeStyle = '#555';
      ctx.lineWidth = 4;
      ctx.strokeRect(boardX, boardY, boardW, boardH);
      ctx.fillStyle = '#ddd';
      ctx.font = '28px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('SVR Community Impact', width * 0.5, boardY + 40);
      ctx.font = '18px Arial';
      const lines = [
        'We give back to shelter pets, homeless, and families in need.',
        'Our tournaments are sponsor-funded, and proceeds support charities.',
        'Play, win, and make a difference!'
      ];
      for (let i = 0; i < lines.length; i++) {
        ctx.fillText(lines[i], width * 0.5, boardY + 80 + i * 30);
      }
      break;
    case 'Scorpion':
      ctx.fillStyle = '#4a1a1a';
      ctx.fillRect(0, 0, width, height);
      // Draw simple scorpion silhouette (circle body + tail)
      ctx.fillStyle = '#700';
      ctx.beginPath();
      ctx.arc(width * 0.5, height * 0.4, 30, 0, Math.PI * 2);
      ctx.fill();
      // Tail segments
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.arc(width * 0.5 + (i + 1) * 20, height * 0.4 - (i + 1) * 10, 10, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    default:
      // Lobby default: dark sky
      ctx.fillStyle = '#101028';
      ctx.fillRect(0, 0, width, height);
      break;
  }
}

// Draw rising particles for ambiance
function drawParticles(ctx) {
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  particles.forEach(p => {
    p.y -= p.speed;
    if (p.y < 0) {
      p.y = height;
      p.x = Math.random() * width;
    }
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  });
}

// Draw moon and mars orbiting above the skyline
function drawPlanets(ctx) {
  // Only show planets in the lobby scene
  if (currentScene !== 'Lobby') return;
  // Moon orbit
  moon.angle += 0.001;
  const moonX = width * 0.5 + Math.cos(moon.angle) * (width * 0.3);
  const moonY = height * 0.2 + Math.sin(moon.angle) * (height * 0.1);
  ctx.fillStyle = 'rgba(240, 240, 255, 0.9)';
  ctx.beginPath();
  ctx.arc(moonX, moonY, moon.radius, 0, Math.PI * 2);
  ctx.fill();
  // Glow
  ctx.fillStyle = 'rgba(240, 240, 255, 0.2)';
  ctx.beginPath();
  ctx.arc(moonX, moonY, moon.radius * 1.8, 0, Math.PI * 2);
  ctx.fill();
  // Mars orbit
  mars.angle += 0.0006;
  const marsX = width * 0.5 + Math.cos(mars.angle) * (width * 0.4);
  const marsY = height * 0.15 + Math.sin(mars.angle) * (height * 0.15);
  ctx.fillStyle = 'rgba(255, 120, 80, 0.9)';
  ctx.beginPath();
  ctx.arc(marsX, marsY, mars.radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255, 120, 80, 0.2)';
  ctx.beginPath();
  ctx.arc(marsX, marsY, mars.radius * 1.8, 0, Math.PI * 2);
  ctx.fill();
}

// Draw teleport pointer
function drawPointer(ctx) {
  if (!teleportMode) return;
  ctx.strokeStyle = 'rgba(180, 0, 255, 0.6)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(pointerX, pointerY, 12, 0, Math.PI * 2);
  ctx.stroke();
  // crosshair
  ctx.beginPath();
  ctx.moveTo(pointerX - 15, pointerY);
  ctx.lineTo(pointerX + 15, pointerY);
  ctx.moveTo(pointerX, pointerY - 15);
  ctx.lineTo(pointerX, pointerY + 15);
  ctx.stroke();
}

function animate() {
  // Draw environment and ambiance
  drawEnvironment(ctx);
  drawParticles(ctx);
  drawPlanets(ctx);
  // Draw table/ground on top
  drawTable(ctx);
  // Update and draw chips and golf balls
  for (const chip of chips) {
    chip.update();
    chip.draw(ctx);
  }
  for (const ball of balls) {
    ball.update();
    ball.draw(ctx);
  }
  // Draw teleport pointer if in teleport mode
  drawPointer(ctx);
  requestAnimationFrame(animate);
}
animate();
