import { evaluateBestHand } from "./handEvaluator.js";
import { buildSidePots, splitPotAmount } from "./sidePots.js";

export function rankContenders(state) {
  const contenders = state.players.filter((player) => !player.folded);

  if (contenders.length === 0) {
    throw new Error("No contenders in showdown");
  }

  return contenders
    .map((player) => ({
      playerId: player.id,
      name: player.name,
      result: evaluateBestHand([...player.cards, ...state.board])
    }))
    .sort((a, b) => b.result.score - a.result.score);
}

export function resolveShowdown(state) {
  const ranked = rankContenders(state);
  const topScore = ranked[0].result.score;
  const winners = ranked.filter((entry) => entry.result.score === topScore);

  return { winners, ranked };
}

export function resolveSidePotShowdown(state) {
  const ranked = rankContenders(state);
  const sidePots = state.sidePots?.length ? state.sidePots : buildSidePots(state.players);
  const payouts = [];

  for (const pot of sidePots) {
    const eligibleRanked = ranked.filter((entry) => pot.eligible.includes(entry.playerId));
    if (!eligibleRanked.length) continue;

    const bestScore = eligibleRanked[0].result.score;
    const winners = eligibleRanked.filter((entry) => entry.result.score === bestScore);
    payouts.push({
      potAmount: pot.amount,
      winners,
      shares: splitPotAmount(pot.amount, winners.map((entry) => entry.playerId))
    });
  }

  return { ranked, sidePots, payouts };
}
