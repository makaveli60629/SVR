import { evaluateBestHand } from "./handEvaluator.js";

export function resolveShowdown(state) {
  const contenders = state.players.filter((p) => !p.folded);

  if (contenders.length === 0) {
    throw new Error("No contenders in showdown");
  }

  const ranked = contenders.map((player) => {
    const result = evaluateBestHand([...player.cards, ...state.board]);
    return {
      playerId: player.id,
      name: player.name,
      result
    };
  });

  ranked.sort((a, b) => b.result.score - a.result.score);

  const topScore = ranked[0].result.score;
  const winners = ranked.filter((r) => r.result.score === topScore);

  return {
    winners,
    ranked
  };
}
