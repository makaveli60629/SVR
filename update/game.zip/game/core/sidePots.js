export function buildSidePots(players) {
  const committedPlayers = players
    .filter((player) => player.totalCommitted > 0)
    .map((player) => ({ ...player }))
    .sort((a, b) => a.totalCommitted - b.totalCommitted);

  const sidePots = [];
  let previousLevel = 0;

  for (const player of committedPlayers) {
    const level = player.totalCommitted;
    const contribution = level - previousLevel;
    if (contribution <= 0) continue;

    const contributors = committedPlayers.filter((p) => p.totalCommitted >= level);
    const eligible = contributors.filter((p) => !p.folded).map((p) => p.id);
    const amount = contribution * contributors.length;

    if (amount > 0) {
      sidePots.push({ amount, eligible });
    }

    previousLevel = level;
  }

  return sidePots;
}

export function splitPotAmount(amount, winnerIds) {
  if (!winnerIds.length) throw new Error("splitPotAmount requires at least one winner");
  const baseShare = Math.floor(amount / winnerIds.length);
  let remainder = amount % winnerIds.length;

  return winnerIds.map((playerId) => {
    const extra = remainder > 0 ? 1 : 0;
    remainder -= extra;
    return { playerId, amount: baseShare + extra };
  });
}
