import { createDeck, shuffleDeck, drawCards } from "./deck.js";

export function createPlayer(id, name, chips = 1000) {
  return {
    id,
    name,
    chips,
    cards: [],
    folded: false,
    allIn: false,
    currentBet: 0,
    totalCommitted: 0,
    hasActed: false
  };
}

export function createTableState(players = [], config = {}) {
  return {
    players,
    dealerIndex: 0,
    smallBlind: config.smallBlind ?? 10,
    bigBlind: config.bigBlind ?? 20,
    pot: 0,
    sidePots: [],
    board: [],
    burn: [],
    deck: [],
    phase: "waiting",
    currentPlayerIndex: 0,
    currentBetToMatch: 0,
    handNumber: 0,
    actionLog: []
  };
}

export function startHand(state) {
  let deck = shuffleDeck(createDeck());

  const players = state.players.map((player) => ({
    ...player,
    cards: [],
    folded: false,
    allIn: false,
    currentBet: 0,
    totalCommitted: 0,
    hasActed: false
  }));

  for (let round = 0; round < 2; round += 1) {
    for (let i = 0; i < players.length; i += 1) {
      const result = drawCards(deck, 1);
      players[i].cards.push(result.drawn[0]);
      deck = result.deck;
    }
  }

  return {
    ...state,
    players,
    deck,
    pot: 0,
    sidePots: [],
    board: [],
    burn: [],
    phase: "preflop",
    currentBetToMatch: 0,
    handNumber: state.handNumber + 1,
    actionLog: [...state.actionLog, { type: "START_HAND", handNumber: state.handNumber + 1 }]
  };
}

export function dealBoardCards(state, street) {
  let deck = [...state.deck];

  const burnResult = drawCards(deck, 1);
  const burnCard = burnResult.drawn[0];
  deck = burnResult.deck;

  const count = street === "flop" ? 3 : 1;
  const boardResult = drawCards(deck, count);

  return {
    ...state,
    deck: boardResult.deck,
    burn: [...state.burn, burnCard],
    board: [...state.board, ...boardResult.drawn],
    phase: street,
    actionLog: [...state.actionLog, { type: "DEAL_BOARD", street, cards: boardResult.drawn }]
  };
}
