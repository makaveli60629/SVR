export const SUITS=["hearts","diamonds","clubs","spades"];
export const RANKS=["2","3","4","5","6","7","8","9","10","J","Q","K","A"];
export function createDeck(){return SUITS.flatMap(suit=>RANKS.map(rank=>({rank,suit,code:`${rank}${suit[0].toUpperCase()}`})));}
export function shuffleDeck(inputDeck,rng=Math.random){const deck=[...inputDeck];for(let i=deck.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}return deck;}
export function drawCards(deck,count=1){if(!Array.isArray(deck))throw new Error("drawCards expected deck array");if(deck.length<count)throw new Error("Not enough cards in deck");return{drawn:deck.slice(0,count),deck:deck.slice(count)};}
