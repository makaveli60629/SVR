const RANK_VALUE = {
  "2": 2,
  "3": 3,
  "4": 4,
  "5": 5,
  "6": 6,
  "7": 7,
  "8": 8,
  "9": 9,
  "10": 10,
  J: 11,
  Q: 12,
  K: 13,
  A: 14
};

export function scoreFiveCardHand(cards) {
  if (!Array.isArray(cards) || cards.length !== 5) {
    throw new Error("scoreFiveCardHand expects exactly 5 cards");
  }

  const ranks = cards
    .map((c) => RANK_VALUE[c.rank])
    .sort((a, b) => b - a);

  return {
    category: "high-card",
    score: ranks.reduce((acc, value, index) => acc + value * Math.pow(15, 4 - index), 0),
    ranks
  };
}

export function evaluateBestHand(sevenCards) {
  if (!Array.isArray(sevenCards) || sevenCards.length < 5) {
    throw new Error("evaluateBestHand expects at least 5 cards");
  }

  let best = null;

  for (let a = 0; a < sevenCards.length - 4; a += 1) {
    for (let b = a + 1; b < sevenCards.length - 3; b += 1) {
      for (let c = b + 1; c < sevenCards.length - 2; c += 1) {
        for (let d = c + 1; d < sevenCards.length - 1; d += 1) {
          for (let e = d + 1; e < sevenCards.length; e += 1) {
            const hand = [
              sevenCards[a],
              sevenCards[b],
              sevenCards[c],
              sevenCards[d],
              sevenCards[e]
            ];

            const scored = scoreFiveCardHand(hand);

            if (!best || scored.score > best.score) {
              best = { ...scored, cards: hand };
            }
          }
        }
      }
    }
  }

  return best;
}
