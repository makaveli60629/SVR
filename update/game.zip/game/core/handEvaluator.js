const RANK_VALUE = {
  "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8,
  "9": 9, "10": 10, J: 11, Q: 12, K: 13, A: 14
};

const CATEGORY = {
  HIGH_CARD: 1,
  PAIR: 2,
  TWO_PAIR: 3,
  THREE_OF_A_KIND: 4,
  STRAIGHT: 5,
  FLUSH: 6,
  FULL_HOUSE: 7,
  FOUR_OF_A_KIND: 8,
  STRAIGHT_FLUSH: 9
};

const CATEGORY_NAME = {
  [CATEGORY.HIGH_CARD]: "high-card",
  [CATEGORY.PAIR]: "pair",
  [CATEGORY.TWO_PAIR]: "two-pair",
  [CATEGORY.THREE_OF_A_KIND]: "three-of-a-kind",
  [CATEGORY.STRAIGHT]: "straight",
  [CATEGORY.FLUSH]: "flush",
  [CATEGORY.FULL_HOUSE]: "full-house",
  [CATEGORY.FOUR_OF_A_KIND]: "four-of-a-kind",
  [CATEGORY.STRAIGHT_FLUSH]: "straight-flush"
};

function rankValue(card) {
  const value = RANK_VALUE[card.rank];
  if (!value) throw new Error(`Unknown card rank: ${card.rank}`);
  return value;
}

function groupByRank(cards) {
  const groups = new Map();
  for (const card of cards) {
    const value = rankValue(card);
    if (!groups.has(value)) groups.set(value, []);
    groups.get(value).push(card);
  }
  return [...groups.entries()]
    .map(([rank, rankCards]) => ({ rank, cards: rankCards, count: rankCards.length }))
    .sort((a, b) => b.count - a.count || b.rank - a.rank);
}

function findStraightHigh(values) {
  const unique = [...new Set(values)].sort((a, b) => b - a);
  if (unique.includes(14)) unique.push(1); // wheel: A-5

  let run = 1;
  for (let i = 0; i < unique.length - 1; i += 1) {
    if (unique[i] - 1 === unique[i + 1]) {
      run += 1;
      if (run >= 5) return unique[i - 3];
    } else if (unique[i] !== unique[i + 1]) {
      run = 1;
    }
  }
  return null;
}

function makeScore(category, kickers) {
  return kickers.reduce(
    (score, value, index) => score + value * Math.pow(15, 5 - index),
    category * Math.pow(15, 6)
  );
}

function topCardsByRanks(cards, ranks, count = 5) {
  const selected = [];
  for (const rank of ranks) {
    const match = cards.find((card) => rankValue(card) === rank && !selected.includes(card));
    if (match) selected.push(match);
    if (selected.length === count) break;
  }
  return selected;
}

export function scoreFiveCardHand(cards) {
  if (!Array.isArray(cards) || cards.length !== 5) {
    throw new Error("scoreFiveCardHand expects exactly 5 cards");
  }

  const sorted = [...cards].sort((a, b) => rankValue(b) - rankValue(a));
  const ranks = sorted.map(rankValue);
  const groups = groupByRank(sorted);
  const isFlush = sorted.every((card) => card.suit === sorted[0].suit);
  const straightHigh = findStraightHigh(ranks);

  if (isFlush && straightHigh) {
    return {
      category: CATEGORY_NAME[CATEGORY.STRAIGHT_FLUSH],
      categoryRank: CATEGORY.STRAIGHT_FLUSH,
      score: makeScore(CATEGORY.STRAIGHT_FLUSH, [straightHigh]),
      ranks: [straightHigh],
      cards: sorted
    };
  }

  const four = groups.find((group) => group.count === 4);
  if (four) {
    const kicker = groups.find((group) => group.rank !== four.rank).rank;
    return {
      category: CATEGORY_NAME[CATEGORY.FOUR_OF_A_KIND],
      categoryRank: CATEGORY.FOUR_OF_A_KIND,
      score: makeScore(CATEGORY.FOUR_OF_A_KIND, [four.rank, kicker]),
      ranks: [four.rank, kicker],
      cards: sorted
    };
  }

  const trips = groups.filter((group) => group.count === 3);
  const pairs = groups.filter((group) => group.count === 2);
  if (trips.length && (pairs.length || trips.length > 1)) {
    const tripRank = trips[0].rank;
    const pairRank = trips.length > 1 ? trips[1].rank : pairs[0].rank;
    return {
      category: CATEGORY_NAME[CATEGORY.FULL_HOUSE],
      categoryRank: CATEGORY.FULL_HOUSE,
      score: makeScore(CATEGORY.FULL_HOUSE, [tripRank, pairRank]),
      ranks: [tripRank, pairRank],
      cards: sorted
    };
  }

  if (isFlush) {
    return {
      category: CATEGORY_NAME[CATEGORY.FLUSH],
      categoryRank: CATEGORY.FLUSH,
      score: makeScore(CATEGORY.FLUSH, ranks),
      ranks,
      cards: sorted
    };
  }

  if (straightHigh) {
    return {
      category: CATEGORY_NAME[CATEGORY.STRAIGHT],
      categoryRank: CATEGORY.STRAIGHT,
      score: makeScore(CATEGORY.STRAIGHT, [straightHigh]),
      ranks: [straightHigh],
      cards: sorted
    };
  }

  if (trips.length) {
    const kickers = groups.filter((group) => group.rank !== trips[0].rank).map((group) => group.rank).slice(0, 2);
    return {
      category: CATEGORY_NAME[CATEGORY.THREE_OF_A_KIND],
      categoryRank: CATEGORY.THREE_OF_A_KIND,
      score: makeScore(CATEGORY.THREE_OF_A_KIND, [trips[0].rank, ...kickers]),
      ranks: [trips[0].rank, ...kickers],
      cards: sorted
    };
  }

  if (pairs.length >= 2) {
    const pairRanks = pairs.slice(0, 2).map((group) => group.rank);
    const kicker = groups.find((group) => !pairRanks.includes(group.rank)).rank;
    return {
      category: CATEGORY_NAME[CATEGORY.TWO_PAIR],
      categoryRank: CATEGORY.TWO_PAIR,
      score: makeScore(CATEGORY.TWO_PAIR, [...pairRanks, kicker]),
      ranks: [...pairRanks, kicker],
      cards: sorted
    };
  }

  if (pairs.length === 1) {
    const kickers = groups.filter((group) => group.rank !== pairs[0].rank).map((group) => group.rank).slice(0, 3);
    return {
      category: CATEGORY_NAME[CATEGORY.PAIR],
      categoryRank: CATEGORY.PAIR,
      score: makeScore(CATEGORY.PAIR, [pairs[0].rank, ...kickers]),
      ranks: [pairs[0].rank, ...kickers],
      cards: sorted
    };
  }

  return {
    category: CATEGORY_NAME[CATEGORY.HIGH_CARD],
    categoryRank: CATEGORY.HIGH_CARD,
    score: makeScore(CATEGORY.HIGH_CARD, ranks),
    ranks,
    cards: sorted
  };
}

export function evaluateBestHand(sevenCards) {
  if (!Array.isArray(sevenCards) || sevenCards.length < 5) {
    throw new Error("evaluateBestHand expects at least 5 cards");
  }

  let best = null;

  for (let a = 0; a < sevenCards.length - 4; a += 1) {
    for (let b = a + 1; b < sevenCards.length - 3; b += 1) {
      for (let c = b + 1; c < sevenCards.length - 2; c += 1) {
        for (let d = c + 1; d < sevenCards.length - 1; d += 1) {
          for (let e = d + 1; e < sevenCards.length; e += 1) {
            const hand = [sevenCards[a], sevenCards[b], sevenCards[c], sevenCards[d], sevenCards[e]];
            const scored = scoreFiveCardHand(hand);
            if (!best || scored.score > best.score) best = scored;
          }
        }
      }
    }
  }

  return best;
}

export function compareHands(a, b) {
  if (a.score > b.score) return 1;
  if (a.score < b.score) return -1;
  return 0;
}
