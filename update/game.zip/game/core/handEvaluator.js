const RANK_VALUE={"2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"10":10,J:11,Q:12,K:13,A:14};
const CATEGORY={HIGH_CARD:1,PAIR:2,TWO_PAIR:3,THREE_KIND:4,STRAIGHT:5,FLUSH:6,FULL_HOUSE:7,FOUR_KIND:8,STRAIGHT_FLUSH:9};
const CATEGORY_NAME={1:"High Card",2:"Pair",3:"Two Pair",4:"Three of a Kind",5:"Straight",6:"Flush",7:"Full House",8:"Four of a Kind",9:"Straight Flush"};
function byDesc(a,b){return b-a;}
function score(category,ranks){return ranks.reduce((acc,value,index)=>acc+value*Math.pow(15,5-index),category*Math.pow(15,6));}
function rankCounts(cards){const m=new Map();for(const c of cards){const v=RANK_VALUE[c.rank];m.set(v,(m.get(v)||0)+1);}return [...m.entries()].sort((a,b)=>b[1]-a[1]||b[0]-a[0]);}
function straightHigh(values){const unique=[...new Set(values)].sort(byDesc);if(unique.includes(14))unique.push(1);for(let i=0;i<=unique.length-5;i++){const run=unique.slice(i,i+5);if(run[0]-run[4]===4)return run[0]===1?5:run[0];}return null;}
export function scoreFiveCardHand(cards){if(!Array.isArray(cards)||cards.length!==5)throw new Error("scoreFiveCardHand expects exactly 5 cards");const values=cards.map(c=>RANK_VALUE[c.rank]).sort(byDesc);const flush=cards.every(c=>c.suit===cards[0].suit);const sHigh=straightHigh(values);const counts=rankCounts(cards);
 if(flush&&sHigh)return{category:CATEGORY.STRAIGHT_FLUSH,name:"Straight Flush",score:score(CATEGORY.STRAIGHT_FLUSH,[sHigh]),ranks:[sHigh]};
 if(counts[0][1]===4){const quad=counts[0][0],kicker=counts.find(c=>c[1]===1)[0];return{category:CATEGORY.FOUR_KIND,name:"Four of a Kind",score:score(CATEGORY.FOUR_KIND,[quad,kicker]),ranks:[quad,kicker]};}
 if(counts[0][1]===3&&counts[1]?.[1]===2)return{category:CATEGORY.FULL_HOUSE,name:"Full House",score:score(CATEGORY.FULL_HOUSE,[counts[0][0],counts[1][0]]),ranks:[counts[0][0],counts[1][0]]};
 if(flush)return{category:CATEGORY.FLUSH,name:"Flush",score:score(CATEGORY.FLUSH,values),ranks:values};
 if(sHigh)return{category:CATEGORY.STRAIGHT,name:"Straight",score:score(CATEGORY.STRAIGHT,[sHigh]),ranks:[sHigh]};
 if(counts[0][1]===3){const trips=counts[0][0],k=counts.filter(c=>c[1]===1).map(c=>c[0]).sort(byDesc);return{category:CATEGORY.THREE_KIND,name:"Three of a Kind",score:score(CATEGORY.THREE_KIND,[trips,...k]),ranks:[trips,...k]};}
 if(counts[0][1]===2&&counts[1]?.[1]===2){const pairs=counts.filter(c=>c[1]===2).map(c=>c[0]).sort(byDesc);const kicker=counts.find(c=>c[1]===1)[0];return{category:CATEGORY.TWO_PAIR,name:"Two Pair",score:score(CATEGORY.TWO_PAIR,[...pairs,kicker]),ranks:[...pairs,kicker]};}
 if(counts[0][1]===2){const pair=counts[0][0],k=counts.filter(c=>c[1]===1).map(c=>c[0]).sort(byDesc);return{category:CATEGORY.PAIR,name:"Pair",score:score(CATEGORY.PAIR,[pair,...k]),ranks:[pair,...k]};}
 return{category:CATEGORY.HIGH_CARD,name:CATEGORY_NAME[CATEGORY.HIGH_CARD],score:score(CATEGORY.HIGH_CARD,values),ranks:values};}
export function evaluateBestHand(cards){if(!Array.isArray(cards)||cards.length<5)throw new Error("evaluateBestHand expects at least 5 cards");let best=null;for(let a=0;a<cards.length-4;a++)for(let b=a+1;b<cards.length-3;b++)for(let c=b+1;c<cards.length-2;c++)for(let d=c+1;d<cards.length-1;d++)for(let e=d+1;e<cards.length;e++){const hand=[cards[a],cards[b],cards[c],cards[d],cards[e]];const scored=scoreFiveCardHand(hand);if(!best||scored.score>best.score)best={...scored,cards:hand};}return best;}
export function compareHands(a,b){return Math.sign(a.score-b.score);}
