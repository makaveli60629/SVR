export function getActivePlayers(players){return players.filter(p=>!p.folded&&p.chips>=0);}
export function getLegalActions(player,state){if(player.folded||player.allIn)return[];const toCall=Math.max(0,state.currentBetToMatch-player.currentBet);if(toCall===0)return["check","bet","all-in","fold"];if(player.chips<=toCall)return["fold","all-in"];return["fold","call","raise","all-in"];}
export function getMinimumRaiseAmount(state,player){const toCall=Math.max(0,state.currentBetToMatch-player.currentBet);return toCall+(state.lastRaiseSize||state.bigBlind||20);}
