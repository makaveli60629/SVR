SVR refined next phase build

Changes in this package:
- camera 3 preview now auto-runs when the game is loaded inside an iframe/site preview
- wrist watch rotated to a 45 degree inner-forearm fit and pushed farther up the arm
- watch now shows NOW PLAYING text and track name more clearly
- audio playback priming improved so music can start more reliably after interaction
- moon raised higher, Earth refined, denser small far stars and atmosphere haze added
- stronger table and room lighting with shadows enabled
- floor, wall, chair, and table topper textures made reliable with packaged assets and procedural fallback
- dealer Eric reoriented toward the table and textured from bundled repo assets
- detailed chairs added with active seat positions and seated player height offset
