SVR Poker — Next Phase Module (2026-03-17)

Changes in this phase:
- room radius doubled for a larger skyline chamber
- wall and floor textures applied
- denser long-range stars and atmosphere sprites added
- Earth + Moon added high in the skyline and rotating continuously
- smoother teleport ring/arc/logo marker pass
- real table only, fallback table removed from normal path
- Eric dealer reoriented toward the table and textured from repo assets
- inner forearm watch extended with:
  - cash display set to $50,000
  - music on/off + next track
  - join table / leave table buttons
- generated ambient playlist added because no shipping audio files were found in the repo
- embed/autocam mode added for the public site live preview window
