# SVR Poker Quest-Safe Game Overlay

This game zip is designed to replace the current `update/game.zip` with a safer, self-contained overlay.

## Included
- modern Three.js/WebXR game shell
- hand mesh loading
- fist-near-face teleport toggle
- pinch-release teleport
- circular room + skyline + moon
- table + dealer loading from existing repo assets
- local fallback geometry if table/dealer models fail

## Expected repo assumptions
These files already exist in the base repo copy:
- `game/assets/models/table.glb` or `table.fbx`
- `game/assets/models/eric/eric.fbx`
- `game/assets/texture/tablefelt.png`
- `game/assets/texture/moon_diffuse.png`

## Goal
Avoid the current mixed-generation deploy where `update/game.zip` only overrides `game/index.html` but leaves older game JS underneath.
