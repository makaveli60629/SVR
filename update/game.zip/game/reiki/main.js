import * as THREE from "three";
import { OBJLoader } from "three/addons/loaders/OBJLoader.js";
import { createCore } from "../modules/core_scene.js";
import { createDesktopControls } from "../modules/desktop_controls.js";
import { createHands } from "../modules/hands.js";
import { createTeleportRig } from "../modules/teleport.js";
import { createDebugStats } from "../modules/debug_stats.js";
import { createJointDebug } from "../modules/hand_debug.js";
import { urlsFor } from "../modules/asset_base.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $stats = document.getElementById("stats");
const $err = document.getElementById("err");

function log(...args){
  const line = args.map(a => (typeof a === "string" ? a : JSON.stringify(a, null, 2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}
document.getElementById("toggleLog").addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

const { scene, camera, renderer } = createCore({ containerId: "app" });
camera.position.set(0, 1.6, 4.8);
const desktop = createDesktopControls({ camera, domElement: renderer.domElement });

window.addEventListener("error", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});

function makeCircleTexture(color){
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext("2d");
  const grad = ctx.createRadialGradient(64,64,8,64,64,60);
  grad.addColorStop(0, "rgba(255,255,255,1)");
  grad.addColorStop(0.3, color);
  grad.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0,0,128,128);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function loadTexture(rel){
  const loader = new THREE.TextureLoader();
  const tex = loader.load(new URL(rel, import.meta.url).toString());
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

function addPlanetSky(){
  scene.background = new THREE.Color(0x04050a);
  scene.fog = new THREE.FogExp2(0x05070c, 0.012);

  scene.add(new THREE.HemisphereLight(0xe9f4ff, 0x091014, 1.4));
  const moonGlow = new THREE.PointLight(0xdfe8ff, 16, 220, 1.7);
  moonGlow.position.set(-40, 42, -90);
  scene.add(moonGlow);
  const aura = new THREE.PointLight(0x6cffc7, 9, 90, 1.9);
  aura.position.set(0, 4, -6);
  scene.add(aura);

  const starGeo = new THREE.BufferGeometry();
  const positions = [];
  const colors = [];
  const palette = [new THREE.Color(0xcffff5), new THREE.Color(0xffa8ff), new THREE.Color(0xb497ff), new THREE.Color(0xffffff)];
  for (let i = 0; i < 420; i++){
    const angle = Math.random() * Math.PI * 2;
    const radius = 50 + Math.random() * 90;
    const y = 12 + Math.random() * 65;
    positions.push(Math.cos(angle) * radius, y, Math.sin(angle) * radius - 60);
    const c = palette[i % palette.length];
    colors.push(c.r, c.g, c.b);
  }
  starGeo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  starGeo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ size: 0.22, transparent: true, opacity: 0.9, vertexColors: true }));
  scene.add(stars);

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(7.8, 64, 64),
    new THREE.MeshStandardMaterial({
      map: loadTexture("../assets/texture/moon_diffuse.png"),
      bumpMap: loadTexture("../assets/texture/moon_bump.png"),
      bumpScale: 0.18,
      color: 0xf7f7ff,
      roughness: 0.98,
      emissive: 0x1f2940,
      emissiveIntensity: 0.22,
    })
  );
  const mars = new THREE.Mesh(
    new THREE.SphereGeometry(3.8, 48, 48),
    new THREE.MeshStandardMaterial({
      map: loadTexture("../assets/texture/mars/diffuse_1k.jpg"),
      bumpMap: loadTexture("../assets/texture/mars/bump_1k.jpg"),
      bumpScale: 0.08,
      color: 0xffddcf,
      roughness: 0.96,
      emissive: 0x25120d,
      emissiveIntensity: 0.14,
    })
  );
  scene.add(moon, mars);
  scene.userData._planets = { moon, mars };
}

function addTerrain(){
  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(22, 120),
    new THREE.MeshStandardMaterial({ color: 0x0b1511, roughness: 1.0, metalness: 0.0 })
  );
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  const moss = new THREE.Mesh(
    new THREE.CircleGeometry(12.5, 80),
    new THREE.MeshStandardMaterial({ color: 0x133124, roughness: 1.0, metalness: 0.0, emissive: 0x07170f, emissiveIntensity: 0.08 })
  );
  moss.rotation.x = -Math.PI / 2;
  moss.position.y = 0.01;
  scene.add(moss);

  const meditationPad = new THREE.Mesh(
    new THREE.RingGeometry(1.25, 1.85, 48),
    new THREE.MeshStandardMaterial({ color: 0x6effc6, roughness: 0.24, metalness: 0.15, emissive: 0x1c7f59, emissiveIntensity: 1.0, side: THREE.DoubleSide })
  );
  meditationPad.rotation.x = -Math.PI / 2;
  meditationPad.position.set(0, 0.02, 1.8);
  scene.add(meditationPad);

  const logoFloor = new THREE.Mesh(
    new THREE.CircleGeometry(0.82, 48),
    new THREE.MeshBasicMaterial({ map: loadTexture("../assets/ui/logo.png"), transparent: true, opacity: 0.95, side: THREE.DoubleSide })
  );
  logoFloor.rotation.x = -Math.PI / 2;
  logoFloor.position.set(0, 0.021, 1.8);
  scene.add(logoFloor);

  for (const [x,z,s] of [[-7,-4,4.2],[7,-5,3.8],[-9,5,4.6],[9,6,4.2],[-12,0,5.4],[12,0,5.2]]){
    const mound = new THREE.Mesh(
      new THREE.SphereGeometry(s, 26, 22),
      new THREE.MeshStandardMaterial({ color: 0x102018, roughness: 1.0, metalness: 0.0 })
    );
    mound.scale.y = 0.28;
    mound.position.set(x, -0.85, z);
    scene.add(mound);
  }

  for (let i = 0; i < 22; i++){
    const angle = (i / 22) * Math.PI * 2;
    const r = 16 + Math.sin(i * 1.5) * 0.7;
    const rock = new THREE.Mesh(
      new THREE.DodecahedronGeometry(0.55 + (i % 3) * 0.18, 0),
      new THREE.MeshStandardMaterial({ color: 0x1b2227, roughness: 0.94, metalness: 0.02 })
    );
    rock.position.set(Math.cos(angle) * r, 0.22, Math.sin(angle) * r - 0.6);
    rock.rotation.set(Math.random(), Math.random(), Math.random());
    scene.add(rock);
  }

  const pathMat = new THREE.MeshStandardMaterial({ color: 0x293129, roughness: 1.0, metalness: 0.0 });
  for (let i = 0; i < 8; i++){
    const stone = new THREE.Mesh(new THREE.CircleGeometry(0.55 - i * 0.03, 24), pathMat);
    stone.rotation.x = -Math.PI / 2;
    stone.position.set(Math.sin(i * 0.32) * 0.24, 0.025, 6.5 - i * 1.05);
    scene.add(stone);
  }
}

function createStylizedTree(scale = 1){
  const group = new THREE.Group();
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12 * scale, 0.18 * scale, 1.6 * scale, 10),
    new THREE.MeshStandardMaterial({ color: 0x4b3524, roughness: 1.0, metalness: 0.0 })
  );
  trunk.position.y = 0.8 * scale;
  group.add(trunk);
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x1a5f41, roughness: 0.95, metalness: 0.0, emissive: 0x0b2a1c, emissiveIntensity: 0.12 });
  for (const [y,s] of [[1.6,1.0],[2.15,0.82],[2.65,0.6]]){
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.72 * scale * s, 1.18 * scale * s, 12), leafMat);
    cone.position.y = y * scale;
    group.add(cone);
  }
  return group;
}

async function addVegetation(){
  const treeSpots = [
    [-5.6, -1.5, 1.2], [-7.5, 2.8, 1.35], [6.8, -2.2, 1.28], [8.4, 2.6, 1.18],
    [-10.2, -6.4, 1.55], [10.6, -5.8, 1.46], [-11.2, 6.3, 1.52], [11.5, 6.6, 1.44]
  ];
  for (const [x,z,s] of treeSpots){
    const tree = createStylizedTree(s);
    tree.position.set(x, 0, z);
    scene.add(tree);
  }

  try{
    const obj = await new OBJLoader().loadAsync(new URL("../assets/models/riki/plant/indoor_plant.obj", import.meta.url).toString());
    const colorTex = loadTexture("../assets/models/riki/plant/plant_col.jpg");
    obj.traverse((child)=>{
      if (child.isMesh){
        child.material = new THREE.MeshStandardMaterial({ map: colorTex, roughness: 0.96, metalness: 0.0 });
      }
    });
    const placements = [[-2.6,4.6,0.45],[2.8,4.9,0.48],[-4.8,5.3,0.44],[4.9,5.5,0.46],[-6.4,3.8,0.42],[6.5,3.9,0.42]];
    for (const [x,z,s] of placements){
      const plant = obj.clone(true);
      plant.scale.setScalar(s);
      plant.position.set(x, 0, z);
      plant.rotation.y = Math.random() * Math.PI * 2;
      scene.add(plant);
    }
  }catch(err){
    log("Plant OBJ fallback:", err?.message || String(err));
  }
}

function addSpiritSprites(){
  const texture = makeCircleTexture("rgba(165,255,212,0.95)");
  const textureB = makeCircleTexture("rgba(255,124,227,0.95)");
  const textureC = makeCircleTexture("rgba(180,132,255,0.95)");
  const texes = [texture, textureB, textureC];
  const sprites = [];
  for (let i = 0; i < 180; i++){
    const mat = new THREE.SpriteMaterial({ map: texes[i % texes.length], transparent:true, opacity:0.5 + Math.random() * 0.28, depthWrite:false });
    const sprite = new THREE.Sprite(mat);
    const angle = Math.random() * Math.PI * 2;
    const radius = 2 + Math.random() * 13;
    sprite.position.set(Math.cos(angle) * radius, 0.2 + Math.random() * 3.6, Math.sin(angle) * radius - 0.4);
    const scale = 0.11 + Math.random() * 0.08;
    sprite.scale.setScalar(scale);
    scene.add(sprite);
    sprites.push({ sprite, speed:0.08 + Math.random() * 0.16, drift:(Math.random() - 0.5) * 0.06 });
  }
  scene.userData._sprites = sprites;
}

function buildReikiRoom(){
  addPlanetSky();
  addTerrain();
  addSpiritSprites();
  scene.userData._tickWorld = (dt)=>{
    scene.userData._t = (scene.userData._t || 0) + dt;
    const t = scene.userData._t;
    const planets = scene.userData._planets;
    if (planets){
      planets.moon.position.set(Math.sin(t * 0.017) * 24, 40 + Math.sin(t * 0.011) * 2.4, -88 + Math.cos(t * 0.017) * 7);
      planets.mars.position.set(Math.sin(t * 0.024 + 1.4) * 16, 30 + Math.sin(t * 0.015 + 0.8) * 1.8, -98 + Math.cos(t * 0.024 + 1.4) * 5);
      planets.moon.rotation.y += dt * 0.03;
      planets.mars.rotation.y += dt * 0.045;
    }
    const sprites = scene.userData._sprites || [];
    for (let i = 0; i < sprites.length; i++){
      const s = sprites[i];
      s.sprite.position.y += dt * s.speed;
      s.sprite.position.x += Math.sin(t * 0.35 + i) * s.drift * dt;
      if (s.sprite.position.y > 5.8) s.sprite.position.y = 0.15;
    }
  };
  return { roomClamp: 18.5 };
}

async function loadLogoTexture(){
  const loader = new THREE.TextureLoader();
  for (const url of urlsFor("ui/logo.png")){
    const tex = await new Promise((resolve)=> loader.load(url, (t)=> resolve(t), undefined, ()=> resolve(null)));
    if (tex){
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      return tex;
    }
  }
  return await new Promise((resolve)=> loader.load(new URL("../logo_fallback.png", import.meta.url).toString(), resolve, undefined, ()=> resolve(null)));
}

const { roomClamp } = buildReikiRoom();
await addVegetation();
const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
const stats = createDebugStats({ renderer, scene, camera, el: $stats, label: "REIKI SANCTUARY" });
const joints = createJointDebug({ scene });

document.getElementById("toggleJoints").addEventListener("click", ()=> joints.toggle());
document.getElementById("toggleStats").addEventListener("click", ()=> stats.toggle());
window.addEventListener("keydown", (e)=>{
  if (e.code === "Digit1") joints.toggle();
  if (e.code === "Digit2") stats.toggle();
});

$status.textContent = "Loading Reiki sanctuary assets…";
const logo = await loadLogoTexture();
tp.setLogoTexture(logo);
$status.textContent = "Reiki sanctuary ready. Enter VR or use desktop controls.";
$mode.textContent = "Hands: waiting…";

function setHudVisible(visible){
  document.getElementById("hud").style.display = visible ? "flex" : "none";
  $err.style.display = "none";
  if (!visible){
    $log.style.display = "none";
    $stats.style.display = "none";
  }
}
renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});
renderer.xr.addEventListener("sessionend", ()=> setHudVisible(true));

let prev = performance.now();
renderer.setAnimationLoop(()=>{
  const now = performance.now();
  const dt = Math.min((now - prev) / 1000, 0.05);
  prev = now;

  if (!renderer.xr.isPresenting) desktop.update(dt);
  if (scene.userData._tickWorld) scene.userData._tickWorld(dt);

  const left = hands.getLeft();
  const right = hands.getRight();
  joints.update(left, right);
  stats.update(dt, left, right);

  tp.update({
    leftHand: left,
    rightHand: right,
    statusCb: (t)=>{ $status.textContent = t; },
    modeCb: (t)=>{ $mode.textContent = t; },
  });

  renderer.render(scene, camera);
});
