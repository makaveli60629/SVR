import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { createCore } from "../modules/core_scene.js";
import { createDesktopControls } from "../modules/desktop_controls.js";
import { createHands } from "../modules/hands.js";
import { createTeleportRig } from "../modules/teleport.js";
import { createDebugStats } from "../modules/debug_stats.js";
import { createJointDebug } from "../modules/hand_debug.js";
import { urlsFor } from "../modules/asset_base.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $stats = document.getElementById("stats");
const $err = document.getElementById("err");

function log(...args){
  const line = args.map(a => (typeof a === "string" ? a : JSON.stringify(a, null, 2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}
document.getElementById("toggleLog").addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

const { scene, camera, renderer } = createCore({ containerId: "app" });
camera.position.set(0, 1.6, 4.2);
const desktop = createDesktopControls({ camera, domElement: renderer.domElement });

window.addEventListener("error", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});

function roundRect(ctx, x, y, w, h, r){
  const rr = Math.min(r, w * 0.5, h * 0.5);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function makeCanvasTexture(draw, width = 1024, height = 1024){
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  draw(ctx, width, height);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

function createPortalMark(){
  const tex = makeCanvasTexture((ctx, w, h)=>{
    ctx.clearRect(0, 0, w, h);
    ctx.translate(w / 2, h / 2);
    const grad = ctx.createRadialGradient(0, 0, 30, 0, 0, 320);
    grad.addColorStop(0, "rgba(93,255,187,0.92)");
    grad.addColorStop(0.45, "rgba(55,168,255,0.44)");
    grad.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, 310, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "rgba(124,255,196,0.95)";
    ctx.lineWidth = 18;
    ctx.beginPath();
    ctx.arc(0, 0, 250, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = "rgba(255,120,235,0.7)";
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(0, 0, 190, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = "rgba(220,255,236,0.96)";
    ctx.font = "700 84px Arial";
    ctx.textAlign = "center";
    ctx.fillText("ENTER REIKI ROOM", 0, -20);
    ctx.fillStyle = "rgba(184,255,214,0.92)";
    ctx.font = "600 42px Arial";
    ctx.fillText("Meditation sanctuary portal", 0, 46);
  }, 1400, 1400);
  const mark = new THREE.Mesh(
    new THREE.CircleGeometry(1.45, 56),
    new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.DoubleSide })
  );
  mark.rotation.x = -Math.PI / 2;
  mark.position.y = 0.02;
  mark.renderOrder = 900;
  return mark;
}

function buildProceduralTree({ trunkHeight = 2.4, crown = 1.5, hue = 0x6fd28c }){
  const group = new THREE.Group();
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.18, trunkHeight, 10),
    new THREE.MeshStandardMaterial({ color: 0x5f4330, roughness: 0.95, metalness: 0.02 })
  );
  trunk.position.y = trunkHeight * 0.5;
  group.add(trunk);

  const leafMat = new THREE.MeshStandardMaterial({
    color: hue,
    roughness: 0.9,
    metalness: 0.02,
    emissive: new THREE.Color(hue).multiplyScalar(0.1),
    emissiveIntensity: 0.28,
  });
  const cone = new THREE.Mesh(new THREE.ConeGeometry(crown, trunkHeight * 0.95, 10), leafMat);
  cone.position.y = trunkHeight + trunkHeight * 0.4;
  group.add(cone);
  const cone2 = new THREE.Mesh(new THREE.ConeGeometry(crown * 0.72, trunkHeight * 0.78, 10), leafMat.clone());
  cone2.position.y = trunkHeight + trunkHeight * 0.85;
  group.add(cone2);
  return group;
}

function buildSanctuary(){
  scene.background = new THREE.Color(0x03040a);
  scene.fog = new THREE.FogExp2(0x04050a, 0.015);

  scene.add(new THREE.HemisphereLight(0xdde8ff, 0x091011, 1.55));
  const moonLight = new THREE.DirectionalLight(0xf3f6ff, 1.35);
  moonLight.position.set(-14, 18, -24);
  scene.add(moonLight);
  const fillA = new THREE.PointLight(0x9b9cff, 10, 100, 2.0);
  fillA.position.set(0, 7, -6);
  scene.add(fillA);
  const fillB = new THREE.PointLight(0x4cffae, 8, 70, 2.0);
  fillB.position.set(-3, 2.4, 5);
  scene.add(fillB);

  const roomRadius = 24;
  const wallHeight = 16;

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius, 160),
    new THREE.MeshStandardMaterial({ color: 0x0b0f12, roughness: 0.98, metalness: 0.01 })
  );
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  const outerWall = new THREE.Mesh(
    new THREE.CylinderGeometry(roomRadius, roomRadius, wallHeight, 120, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x07080f, roughness: 0.92, metalness: 0.04, side: THREE.BackSide, transparent: true, opacity: 0.82 })
  );
  outerWall.position.y = wallHeight * 0.5;
  scene.add(outerWall);

  const terrainMat = new THREE.MeshStandardMaterial({ color: 0x10181a, roughness: 1.0, metalness: 0.0, emissive: 0x0e1716, emissiveIntensity: 0.15 });
  const centerRise = new THREE.Mesh(new THREE.CylinderGeometry(5.8, 7.8, 0.65, 40), terrainMat);
  centerRise.position.y = 0.22;
  scene.add(centerRise);

  const meditationRing = new THREE.Mesh(
    new THREE.TorusGeometry(2.1, 0.08, 18, 80),
    new THREE.MeshStandardMaterial({ color: 0x79ffc4, roughness: 0.18, metalness: 0.18, emissive: 0x2ab576, emissiveIntensity: 0.85 })
  );
  meditationRing.rotation.x = Math.PI / 2;
  meditationRing.position.y = 0.48;
  scene.add(meditationRing);
  const portalMark = createPortalMark();
  portalMark.position.y = 0.03;
  scene.add(portalMark);

  // Low mountain silhouettes / terrain mounds.
  for (let i = 0; i < 14; i++){
    const angle = (i / 14) * Math.PI * 2;
    const mound = new THREE.Mesh(
      new THREE.SphereGeometry(2.2 + Math.random() * 2.6, 18, 18),
      new THREE.MeshStandardMaterial({ color: 0x11171f, roughness: 0.98, metalness: 0.0, emissive: 0x0a0d14, emissiveIntensity: 0.08 })
    );
    const dist = 13.8 + Math.random() * 4.0;
    mound.scale.y = 0.36 + Math.random() * 0.18;
    mound.position.set(Math.cos(angle) * dist, 0.4, Math.sin(angle) * dist);
    scene.add(mound);
  }

  // Imported plants around the sanctuary edge.
  const importedPlantSpots = [
    [-5.2, 0, -7.8, 1.0], [5.1, 0, -7.6, 1.05], [-7.6, 0, -1.8, 0.95], [7.5, 0, -1.6, 0.95],
    [-8.8, 0, 5.6, 1.15], [8.5, 0, 5.4, 1.15], [-2.8, 0, 9.1, 1.0], [3.1, 0, 9.1, 1.0],
  ];
  scene.userData._importedPlantSpots = importedPlantSpots;

  // Procedural trees along the perimeter.
  const treeGroup = new THREE.Group();
  for (let i = 0; i < 12; i++){
    const angle = (i / 12) * Math.PI * 2 + 0.12;
    const tree = buildProceduralTree({ trunkHeight: 2.1 + Math.random() * 1.1, crown: 1.1 + Math.random() * 0.55, hue: i % 2 ? 0x74c96b : 0x4db987 });
    const dist = 15.6 + Math.random() * 2.5;
    tree.position.set(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
    tree.rotation.y = Math.random() * Math.PI * 2;
    treeGroup.add(tree);
  }
  scene.add(treeGroup);

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(3.3, 40, 40),
    new THREE.MeshStandardMaterial({ color: 0xe6ebff, roughness: 0.98, metalness: 0.0, emissive: 0x263450, emissiveIntensity: 0.28 })
  );
  moon.position.set(-10.5, 11.4, -20.5);
  scene.add(moon);

  const mars = new THREE.Mesh(
    new THREE.SphereGeometry(1.65, 30, 30),
    new THREE.MeshStandardMaterial({ color: 0xd0825d, roughness: 0.98, metalness: 0.0, emissive: 0x4c1b0d, emissiveIntensity: 0.12 })
  );
  mars.position.set(7.8, 9.8, -19.8);
  scene.add(mars);

  const starGeo = new THREE.BufferGeometry();
  const starPositions = [];
  for (let i = 0; i < 540; i++){
    const a = Math.random() * Math.PI * 2;
    const r = 16 + Math.random() * 48;
    const y = 8 + Math.random() * 20;
    starPositions.push(Math.cos(a) * r, y, Math.sin(a) * r - 10);
  }
  starGeo.setAttribute("position", new THREE.Float32BufferAttribute(starPositions, 3));
  scene.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xf7f3ff, size: 0.16, transparent: true, opacity: 0.72 })));

  const spriteCount = 220;
  const spritePositions = new Float32Array(spriteCount * 3);
  const spriteColors = new Float32Array(spriteCount * 3);
  const palette = [new THREE.Color(0x66ffb3), new THREE.Color(0xff87f3), new THREE.Color(0xc38dff)];
  for (let i = 0; i < spriteCount; i++){
    const ring = 1.8 + Math.random() * 12;
    const a = Math.random() * Math.PI * 2;
    spritePositions[i * 3 + 0] = Math.cos(a) * ring;
    spritePositions[i * 3 + 1] = Math.random() * 6.5;
    spritePositions[i * 3 + 2] = Math.sin(a) * ring;
    const c = palette[i % palette.length];
    spriteColors[i * 3 + 0] = c.r;
    spriteColors[i * 3 + 1] = c.g;
    spriteColors[i * 3 + 2] = c.b;
  }
  const spriteGeo = new THREE.BufferGeometry();
  spriteGeo.setAttribute("position", new THREE.BufferAttribute(spritePositions, 3));
  spriteGeo.setAttribute("color", new THREE.BufferAttribute(spriteColors, 3));
  const spriteMat = new THREE.PointsMaterial({ size: 0.11, vertexColors: true, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
  const spritePoints = new THREE.Points(spriteGeo, spriteMat);
  scene.add(spritePoints);

  scene.userData._spritePoints = spritePoints;
  scene.userData._moon = moon;
  scene.userData._mars = mars;
  scene.userData._portalMark = portalMark;
  scene.userData._meditationRing = meditationRing;

  scene.userData._tickWorld = (dt)=>{
    scene.userData._t = (scene.userData._t || 0) + dt;
    const t = scene.userData._t;
    meditationRing.material.emissiveIntensity = 0.78 + Math.sin(t * 1.2) * 0.12;
    portalMark.material.opacity = 0.88 + Math.sin(t * 1.4) * 0.08;

    moon.position.x = -10.5 + Math.cos(t * 0.032) * 2.4;
    moon.position.y = 11.4 + Math.sin(t * 0.028) * 0.9;
    mars.position.x = 7.8 + Math.cos(t * 0.043 + 1.2) * 2.9;
    mars.position.y = 9.8 + Math.sin(t * 0.037 + 0.4) * 0.8;

    const pos = spritePoints.geometry.attributes.position;
    for (let i = 0; i < pos.count; i++){
      const ix = i * 3;
      pos.array[ix + 1] += dt * (0.32 + (i % 5) * 0.04);
      if (pos.array[ix + 1] > 7.2){
        const a = Math.random() * Math.PI * 2;
        const ring = 1.5 + Math.random() * 12;
        pos.array[ix + 0] = Math.cos(a) * ring;
        pos.array[ix + 1] = 0.1;
        pos.array[ix + 2] = Math.sin(a) * ring;
      }
    }
    pos.needsUpdate = true;
  };

  return { roomClamp: roomRadius - 2.2 };
}

async function tryLoadFBX(urls){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const obj = await loader.loadAsync(url);
      log("Loaded FBX:", url);
      return obj;
    }catch(err){
      log("Missing FBX:", url);
    }
  }
  return null;
}

function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const ctr = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(ctr);
  return { size, ctr };
}
function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}
function dropToGround(obj){
  const { size, ctr } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - ctr.y;
}

const { roomClamp } = buildSanctuary();
const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
const stats = createDebugStats({ renderer, scene, camera, el: $stats, label: "REIKI MEDITATION ROOM" });
const joints = createJointDebug({ scene });

document.getElementById("toggleJoints").addEventListener("click", ()=> joints.toggle());
document.getElementById("toggleStats").addEventListener("click", ()=> stats.toggle());
window.addEventListener("keydown", (e)=>{
  if (e.code === "Digit1") joints.toggle();
  if (e.code === "Digit2") stats.toggle();
});

async function loadLogoTexture(){
  const loader = new THREE.TextureLoader();
  for (const url of urlsFor("ui/logo.png")){
    const tex = await new Promise((resolve)=> loader.load(url, (t)=> resolve(t), undefined, ()=> resolve(null)));
    if (tex){
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      return tex;
    }
  }
  return await new Promise((resolve)=> loader.load(new URL("../logo_fallback.png", import.meta.url).toString(), resolve, undefined, ()=> resolve(null)));
}

function stylizePlant(obj){
  obj.traverse((child)=>{
    if (child.isMesh){
      child.castShadow = false;
      child.receiveShadow = false;
      const c = new THREE.Color(0x69b97a);
      child.material = new THREE.MeshStandardMaterial({
        color: c,
        roughness: 0.96,
        metalness: 0.0,
        emissive: c.clone().multiplyScalar(0.08),
        emissiveIntensity: 0.22,
      });
    }
  });
}

$status.textContent = "Loading Reiki meditation assets…";
const logo = await loadLogoTexture();
tp.setLogoTexture(logo);

(async()=>{
  const plantUrls = [
    new URL("../assets/reiki/plant01.fbx", import.meta.url).toString(),
    new URL("../assets/reiki/plant03.fbx", import.meta.url).toString(),
  ];
  const loader = new FBXLoader();
  const spots = scene.userData._importedPlantSpots || [];
  for (let i = 0; i < spots.length; i++){
    const [x, y, z, scale] = spots[i];
    const url = plantUrls[i % plantUrls.length];
    try{
      const plant = await loader.loadAsync(url);
      stylizePlant(plant);
      scaleToHeight(plant, 1.05 * scale + (i % 2) * 0.25);
      dropToGround(plant);
      plant.position.set(x, y, z);
      plant.rotation.y = Math.random() * Math.PI * 2;
      scene.add(plant);
    }catch(err){
      log('Plant missing:', url);
    }
  }
})();

$status.textContent = "Reiki room ready. Enter VR or use desktop controls.";
$mode.textContent = "Hands: waiting…";

function setHudVisible(visible){
  document.getElementById("hud").style.display = visible ? "flex" : "none";
  $err.style.display = "none";
  if (!visible){
    $log.style.display = "none";
    $stats.style.display = "none";
  }
}
renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});
renderer.xr.addEventListener("sessionend", ()=> setHudVisible(true));

let prev = performance.now();
renderer.setAnimationLoop(()=>{
  const now = performance.now();
  const dt = Math.min((now - prev) / 1000, 0.05);
  prev = now;

  if (!renderer.xr.isPresenting) desktop.update(dt);
  if (scene.userData._tickWorld) scene.userData._tickWorld(dt);

  const left = hands.getLeft();
  const right = hands.getRight();
  joints.update(left, right);
  stats.update(dt, left, right);

  tp.update({
    leftHand: left,
    rightHand: right,
    statusCb: (t)=>{ $status.textContent = t; },
    modeCb: (t)=>{ $mode.textContent = t; },
  });

  renderer.render(scene, camera);
});
