import * as THREE from "three";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { createCore } from "../modules/core_scene.js";
import { createDesktopControls } from "../modules/desktop_controls.js";
import { createHands } from "../modules/hands.js";
import { createTeleportRig } from "../modules/teleport.js";
import { createDebugStats } from "../modules/debug_stats.js";
import { createJointDebug } from "../modules/hand_debug.js";
import { urlsFor } from "../modules/asset_base.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $stats = document.getElementById("stats");
const $err = document.getElementById("err");

function log(...args){
  const line = args.map(a => (typeof a === "string" ? a : JSON.stringify(a, null, 2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}
document.getElementById("toggleLog").addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

const { scene, camera, renderer } = createCore({ containerId: "app" });
camera.position.set(0, 1.6, 3.2);
const desktop = createDesktopControls({ camera, domElement: renderer.domElement });

window.addEventListener("error", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});

function buildReikiRoom(){
  scene.background = new THREE.Color(0x05050a);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x0d1022, 1.45));
  const overhead = new THREE.PointLight(0xe6e8ff, 42, 120, 2.0);
  overhead.position.set(0, 6.5, 0);
  scene.add(overhead);
  const fill = new THREE.PointLight(0xb48cff, 18, 46, 2.0);
  fill.position.set(0, 2.8, -2.8);
  scene.add(fill);

  const roomRadius = 16;
  const wallHeight = 8;

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(roomRadius, 120),
    new THREE.MeshStandardMaterial({ color: 0x07070d, roughness: 0.96, metalness: 0.02 })
  );
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(roomRadius, roomRadius, wallHeight, 120, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x090913, roughness: 0.9, metalness: 0.08, emissive: 0x25113c, emissiveIntensity: 0.28, side: THREE.BackSide })
  );
  wall.position.y = wallHeight / 2;
  scene.add(wall);

  const halo = new THREE.Mesh(
    new THREE.TorusGeometry(4.2, 0.08, 16, 96),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.18, metalness: 0.25, emissive: 0x2a0d3a, emissiveIntensity: 1.2 })
  );
  halo.rotation.x = Math.PI / 2;
  halo.position.y = 0.02;
  scene.add(halo);

  const dais = new THREE.Mesh(
    new THREE.CylinderGeometry(1.35, 1.6, 0.32, 40),
    new THREE.MeshStandardMaterial({ color: 0x191522, roughness: 0.75, metalness: 0.18, emissive: 0x170d22, emissiveIntensity: 0.25 })
  );
  dais.position.y = 0.16;
  scene.add(dais);

  for (let i = 0; i < 8; i++){
    const angle = (i / 8) * Math.PI * 2;
    const pillar = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.18, 2.6, 18),
      new THREE.MeshStandardMaterial({ color: 0x161926, roughness: 0.7, metalness: 0.18, emissive: 0x111425, emissiveIntensity: 0.2 })
    );
    pillar.position.set(Math.cos(angle) * 6.6, 1.3, Math.sin(angle) * 6.6);
    scene.add(pillar);

    const crown = new THREE.Mesh(
      new THREE.SphereGeometry(0.11, 12, 12),
      new THREE.MeshBasicMaterial({ color: 0xb48cff })
    );
    crown.position.copy(pillar.position).add(new THREE.Vector3(0, 1.45, 0));
    scene.add(crown);
  }

  const starGeo = new THREE.BufferGeometry();
  const starPositions = [];
  for (let i = 0; i < 260; i++){
    const a = Math.random() * Math.PI * 2;
    const r = 10 + Math.random() * 40;
    const y = 5 + Math.random() * 18;
    starPositions.push(Math.cos(a) * r, y, Math.sin(a) * r - 15);
  }
  starGeo.setAttribute("position", new THREE.Float32BufferAttribute(starPositions, 3));
  scene.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xf7f3ff, size: 0.15, transparent: true, opacity: 0.75 })));

  scene.userData._tickWorld = (dt)=>{
    scene.userData._t = (scene.userData._t || 0) + dt;
    halo.material.emissiveIntensity = 1.0 + Math.sin(scene.userData._t * 1.2) * 0.22;
  };

  return { roomClamp: roomRadius - 1.5 };
}

async function tryLoadFBX(urls){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const obj = await loader.loadAsync(url);
      log("Loaded FBX:", url);
      return obj;
    }catch(err){
      log("Missing FBX:", url);
    }
  }
  return null;
}

function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const ctr = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(ctr);
  return { size, ctr };
}
function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}
function dropToGround(obj){
  const { size, ctr } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - ctr.y;
}

const { roomClamp } = buildReikiRoom();
const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
const stats = createDebugStats({ renderer, scene, camera, el: $stats, label: "REIKI TEST ROOM" });
const joints = createJointDebug({ scene });

document.getElementById("toggleJoints").addEventListener("click", ()=> joints.toggle());
document.getElementById("toggleStats").addEventListener("click", ()=> stats.toggle());
window.addEventListener("keydown", (e)=>{
  if (e.code === "Digit1") joints.toggle();
  if (e.code === "Digit2") stats.toggle();
});

async function loadLogoTexture(){
  const loader = new THREE.TextureLoader();
  for (const url of urlsFor("ui/logo.png")){
    const tex = await new Promise((resolve)=> loader.load(url, (t)=> resolve(t), undefined, ()=> resolve(null)));
    if (tex){
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      return tex;
    }
  }
  return await new Promise((resolve)=> loader.load(new URL("../logo_fallback.png", import.meta.url).toString(), resolve, undefined, ()=> resolve(null)));
}

$status.textContent = "Loading Reiki room assets…";
const logo = await loadLogoTexture();
tp.setLogoTexture(logo);

(async()=>{
  const table = await tryLoadFBX(urlsFor("table/table.fbx"));
  if (table){
    scaleToHeight(table, 0.9);
    dropToGround(table);
    table.position.set(0, 0, 0);
    scene.add(table);
  }

  const eric = await tryLoadFBX(urlsFor("npc/eric/eric.fbx"));
  if (eric){
    scaleToHeight(eric, 1.76);
    dropToGround(eric);
    eric.position.set(0, 0, -2.1);
    eric.rotation.y = Math.PI;
    scene.add(eric);
  }
})();

$status.textContent = "Reiki room ready. Enter VR or use desktop controls.";
$mode.textContent = "Hands: waiting…";

function setHudVisible(visible){
  document.getElementById("hud").style.display = visible ? "flex" : "none";
  $err.style.display = "none";
  if (!visible){
    $log.style.display = "none";
    $stats.style.display = "none";
  }
}
renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});
renderer.xr.addEventListener("sessionend", ()=> setHudVisible(true));

let prev = performance.now();
renderer.setAnimationLoop(()=>{
  const now = performance.now();
  const dt = Math.min((now - prev) / 1000, 0.05);
  prev = now;

  if (!renderer.xr.isPresenting) desktop.update(dt);
  if (scene.userData._tickWorld) scene.userData._tickWorld(dt);

  const left = hands.getLeft();
  const right = hands.getRight();
  joints.update(left, right);
  stats.update(dt, left, right);

  tp.update({
    leftHand: left,
    rightHand: right,
    statusCb: (t)=>{ $status.textContent = t; },
    modeCb: (t)=>{ $mode.textContent = t; },
  });

  renderer.render(scene, camera);
});
