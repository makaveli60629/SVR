
import {PokerEngine} from "../systems/pokerEngine.js"

export class PokerTable{

constructor(scene){

this.scene=scene
this.engine=new PokerEngine()

this.createTable()
this.createSeats()
this.createChipStacks()

}

createTable(){

const table=document.createElement("a-cylinder")

table.setAttribute("radius","1.6")
table.setAttribute("height","0.15")
table.setAttribute("color","green")
table.setAttribute("position","0 1 -4")

this.scene.appendChild(table)

}

createSeats(){

const seatRadius=2

for(let i=0;i<6;i++){

let angle=(i/6)*Math.PI*2

let x=Math.cos(angle)*seatRadius
let z=-4+Math.sin(angle)*seatRadius

const seat=document.createElement("a-box")

seat.setAttribute("width","0.4")
seat.setAttribute("height","0.1")
seat.setAttribute("depth","0.4")
seat.setAttribute("color","green")
seat.setAttribute("position",`${x} 0.5 ${z}`)

seat.addEventListener("click",()=>{

seat.setAttribute("color","red")
document.querySelector("#player").setAttribute("position",`${x} 1.6 ${z+0.6}`)

})

this.scene.appendChild(seat)

}

}

createChipStacks(){

for(let i=0;i<6;i++){

let chip=document.createElement("a-cylinder")

chip.setAttribute("radius","0.08")
chip.setAttribute("height","0.02")
chip.setAttribute("color","red")

let angle=(i/6)*Math.PI*2
let x=Math.cos(angle)*1.3
let z=-4+Math.sin(angle)*1.3

chip.setAttribute("position",`${x} 1.1 ${z}`)

this.scene.appendChild(chip)

}

}

}
