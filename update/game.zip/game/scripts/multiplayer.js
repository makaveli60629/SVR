
console.log("SVR Multiplayer Placeholder Loaded");

function connectServer(){
    console.log("Connecting to multiplayer server...");
}
