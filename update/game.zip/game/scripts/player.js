
export function initPlayer(){
 console.log("Player system initialized");
}
