
AFRAME.registerSystem('seat-system', {
  init: function() {
    console.log('Seat system initialized');
  }
});
