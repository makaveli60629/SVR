/*
  Seat system module.

  In A‑Frame, systems register global state and services.  This module
  exports a function that, when invoked, registers a simple seat
  system which logs to the console when initialised.  Registering
  systems via a function allows them to be imported as ES modules.
*/

export function registerSeatSystem() {
  if (typeof AFRAME === 'undefined') {
    console.warn('AFRAME is not loaded; seat system will not be registered');
    return;
  }
  AFRAME.registerSystem('seat-system', {
    init: function () {
      console.log('Seat system initialised');
    },
  });
}