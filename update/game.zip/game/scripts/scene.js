document.addEventListener('DOMContentLoaded', () => {
  const skyline = document.getElementById('skyline');
  const particles = document.getElementById('particles');
  const state = document.getElementById('teleportState');
  const marker = document.getElementById('teleportMarker');
  const rig = document.getElementById('rig');

  const buildings = [
    {x:-14,h:12,w:6,d:6,z:-34,c:'#15161e'},
    {x:-9,h:18,w:5,d:5,z:-36,c:'#11131a'},
    {x:-8.2,h:22,w:2,d:2,z:-36,c:'#0e1017'},
    {x:-2,h:14,w:5,d:5,z:-33,c:'#14151d'},
    {x:4,h:20,w:6,d:6,z:-38,c:'#101118'},
    {x:11,h:16,w:5,d:5,z:-35,c:'#15161e'},
    {x:16,h:10,w:4,d:4,z:-31,c:'#171821'},
    {x:-18,h:9,w:4,d:4,z:-29,c:'#181922'}
  ];
  buildings.forEach(b=>{
    const box=document.createElement('a-box');
    box.setAttribute('position', `${b.x} ${b.h/2} ${b.z}`);
    box.setAttribute('width', b.w);
    box.setAttribute('height', b.h);
    box.setAttribute('depth', b.d);
    box.setAttribute('color', b.c);
    skyline.appendChild(box);
    for(let i=0;i<Math.max(3,Math.floor(b.h/3));i++){
      const line=document.createElement('a-box');
      line.setAttribute('position', `${b.x} ${0.7+i*2.5} ${b.z + b.d/2 + 0.03}`);
      line.setAttribute('width', Math.max(0.4,b.w-0.8));
      line.setAttribute('height', 0.08);
      line.setAttribute('depth', 0.02);
      line.setAttribute('color', i%2? '#38cfff':'#9f54ff');
      skyline.appendChild(line);
    }
  });

  for (let i = 0; i < 50; i++) {
    const p = document.createElement('a-sphere');
    const x = (Math.random() * 10) - 5;
    const z = -3 - (Math.random() * 8);
    const y = 0.5 + Math.random() * 2.5;
    const cyan = Math.random() > 0.5;
    p.setAttribute('radius', 0.035 + Math.random() * 0.02);
    p.setAttribute('color', cyan ? '#38cfff' : '#b66cff');
    p.setAttribute('position', `${x} ${y} ${z}`);
    p.setAttribute('material', 'emissive:' + (cyan ? '#38cfff' : '#b66cff') + '; emissiveIntensity: 1.2');
    p.setAttribute('animation', `property: position; to: ${x} ${y + 3.2} ${z}; dir: alternate; dur: ${3500 + Math.floor(Math.random()*1800)}; loop: true`);
    particles.appendChild(p);
  }

  let teleportOn = false;
  function setTeleport(v){
    teleportOn = v;
    if(state){
      state.textContent = v ? 'ON' : 'OFF';
      state.style.color = v ? '#38cfff' : '#b66cff';
    }
    if(marker) marker.setAttribute('visible', v);
  }

  window.addEventListener('keydown', (e) => {
    if (e.key && e.key.toLowerCase() === 't') setTeleport(!teleportOn);
  });

  const scene = document.querySelector('a-scene');
  if(scene){
    scene.addEventListener('click', () => {
      if (!teleportOn) return;
      if(rig) rig.setAttribute('position', '0 1.6 1.5');
    });
  }
});