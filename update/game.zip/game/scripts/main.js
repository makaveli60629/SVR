/*
  Entry point for the SVR game.

  This module initialises a simple Three.js scene with a rotating cube
  and registers a handful of A‑Frame components and systems to make
  the VR portion modular.  All third‑party dependencies are imported
  via ECMAScript modules, enabling bundlers to optimize the code and
  making the structure easier to reason about.
*/

// Import the Three.js library from a CDN.  Using a versioned URL
// ensures deterministic builds.
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

// Import our own modules for A‑Frame systems and components.  These
// functions register themselves with A‑Frame when invoked.
import { registerSeatSystem } from './seat-system.js';
import { registerVrHands } from '../systems/hands.js';
import { registerPokerTable } from '../systems/poker.js';
import { registerTeleportSystem } from '../systems/teleport.js';

function initThreeScene() {
  // Create a basic scene, camera and renderer.
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(
    70,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  );
  camera.position.z = 3;
  const renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);
  // Responsive resize support.
  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
  // Create a green cube.
  const geometry = new THREE.BoxGeometry();
  const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
  const cube = new THREE.Mesh(geometry, material);
  scene.add(cube);
  function animate() {
    requestAnimationFrame(animate);
    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;
    renderer.render(scene, camera);
  }
  animate();
}

// Register A‑Frame components and systems if the library is present.  This
// check allows the Three.js demo to run even when A‑Frame is not loaded.
function initAFrameSystems() {
  registerSeatSystem();
  registerVrHands();
  registerPokerTable();
  registerTeleportSystem();
}

// Kick off the game once the DOM has loaded.  We register A‑Frame
// systems first so they are available before any `a-scene` elements
// initialise.  Then we initialise our Three.js scene.
document.addEventListener('DOMContentLoaded', () => {
  initAFrameSystems();
  initThreeScene();
});