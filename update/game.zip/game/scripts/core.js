
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.1/build/three.module.js';
import { FBXLoader } from 'https://cdn.jsdelivr.net/npm/three@0.160.1/examples/jsm/loaders/FBXLoader.js';

function init() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x000000);

  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 1.6, 3);

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const ambient = new THREE.AmbientLight(0x404040, 2);
  scene.add(ambient);
  const dirLight = new THREE.DirectionalLight(0xffffff, 1);
  dirLight.position.set(5, 10, 7.5);
  scene.add(dirLight);

  const loader = new FBXLoader();
  loader.load('assets/models/poker_table.fbx', (object) => {
    scene.add(object);
  }, undefined, (error) => {
    // fallback to cylinder if model fails
    const geometry = new THREE.CylinderGeometry(1.5, 1.5, 0.1, 32);
    const material = new THREE.MeshStandardMaterial({ color: 0x654321 });
    const cylinder = new THREE.Mesh(geometry, material);
    cylinder.position.y = 0.05;
    scene.add(cylinder);
  });

  // floor
  const floorGeo = new THREE.PlaneGeometry(10, 10);
  const floorMat = new THREE.MeshStandardMaterial({ color: 0x303030 });
  const floor = new THREE.Mesh(floorGeo, floorMat);
  floor.rotation.x = -Math.PI / 2;
  scene.add(floor);

  let atOrigin = true
  window.addEventListener('keydown', (e) => {
    if (e.code === 'KeyT') {
      if (atOrigin) {
        camera.position.set(0, 1.6, -3);
      } else {
        camera.position.set(0, 1.6, 3);
      }
      atOrigin = !atOrigin;
    }
  });

  function animate() {
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
  }
  animate();
}

window.addEventListener('load', init);
