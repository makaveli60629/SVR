
window.SVR = {};

SVR.init = function(){

SVR.scene = new THREE.Scene();
SVR.scene.background = new THREE.Color(0x000000);

SVR.camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,0.1,1000);
SVR.camera.position.set(0,1.7,8);

SVR.renderer = new THREE.WebGLRenderer({antialias:true});
SVR.renderer.setSize(window.innerWidth,window.innerHeight);
SVR.renderer.xr.enabled = true;

document.body.appendChild(SVR.renderer.domElement);
document.body.appendChild(VRButton.createButton(SVR.renderer));

window.addEventListener("resize",()=>{
SVR.camera.aspect = window.innerWidth/window.innerHeight;
SVR.camera.updateProjectionMatrix();
SVR.renderer.setSize(window.innerWidth,window.innerHeight);
});

};
