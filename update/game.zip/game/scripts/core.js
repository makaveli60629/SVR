
import {PokerTable} from "./table.js"

const scene = document.querySelector("a-scene")

scene.addEventListener("loaded", ()=>{

new PokerTable(scene)

console.log("SVR Poker Loaded")

})
