# Phase L grab system note

Implemented inline in index.html for this deploy-safe phase:
- controller ray grab
- selectstart grab
- selectend drop
- desktop click pickup/drop

Next phase should split this into runtime JS modules once the visual behavior is confirmed.
