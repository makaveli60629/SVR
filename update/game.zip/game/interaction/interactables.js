Phase L interactables: cards and chips are flagged with `userData.interactable = true`.
