Phase L raycaster: controller and desktop ray picking are enabled in index.html.
