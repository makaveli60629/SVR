import { createPlayer, createTableState, startHand, dealBoardCards } from "../core/tableState.js";
import { applyAction, resetBetsForNextStreet } from "../core/bettingRound.js";
import { resolveShowdown } from "../core/showdown.js";

export function simulateRound() {
  let state = createTableState([
    createPlayer("p1", "Alice", 1000),
    createPlayer("p2", "Bob", 1000),
    createPlayer("p3", "Cara", 1000)
  ]);

  state = startHand(state);

  state = applyAction(state, "p1", "bet", 20);
  state = applyAction(state, "p2", "call");
  state = applyAction(state, "p3", "call");

  state = resetBetsForNextStreet(state);
  state = dealBoardCards(state, "flop");

  state = applyAction(state, "p1", "check");
  state = applyAction(state, "p2", "bet", 40);
  state = applyAction(state, "p3", "fold");
  state = applyAction(state, "p1", "call");

  state = resetBetsForNextStreet(state);
  state = dealBoardCards(state, "turn");

  state = applyAction(state, "p1", "check");
  state = applyAction(state, "p2", "check");

  state = resetBetsForNextStreet(state);
  state = dealBoardCards(state, "river");

  state = applyAction(state, "p1", "check");
  state = applyAction(state, "p2", "check");

  const result = resolveShowdown(state);

  return {
    state,
    result
  };
}
