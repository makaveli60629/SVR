import { evaluateBestHand } from "../core/handEvaluator.js";

function card(rank, suit) {
  return { rank, suit, code: `${rank}${suit[0].toUpperCase()}` };
}

export function runBasicHandTests() {
  const sample = [
    card("A", "spades"),
    card("K", "spades"),
    card("Q", "hearts"),
    card("10", "clubs"),
    card("7", "diamonds"),
    card("3", "spades"),
    card("2", "hearts")
  ];

  const result = evaluateBestHand(sample);

  return {
    ok: !!result,
    result
  };
}
