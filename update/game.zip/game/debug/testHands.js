import { evaluateBestHand } from "../core/handEvaluator.js";
import { resolveSidePotShowdown } from "../core/showdown.js";

function card(rank, suit) {
  return { rank, suit, code: `${rank}${suit[0].toUpperCase()}` };
}

export function runBasicHandTests() {
  const tests = [
    {
      name: "straight flush beats four of a kind",
      cards: [card("9", "spades"), card("8", "spades"), card("7", "spades"), card("6", "spades"), card("5", "spades"), card("A", "hearts"), card("A", "clubs")],
      expect: "straight-flush"
    },
    {
      name: "full house detected",
      cards: [card("K", "spades"), card("K", "hearts"), card("K", "clubs"), card("3", "spades"), card("3", "hearts"), card("8", "diamonds"), card("2", "clubs")],
      expect: "full-house"
    },
    {
      name: "wheel straight detected",
      cards: [card("A", "spades"), card("5", "hearts"), card("4", "clubs"), card("3", "diamonds"), card("2", "spades"), card("9", "clubs"), card("K", "hearts")],
      expect: "straight"
    },
    {
      name: "flush detected",
      cards: [card("A", "clubs"), card("10", "clubs"), card("8", "clubs"), card("5", "clubs"), card("2", "clubs"), card("K", "hearts"), card("4", "spades")],
      expect: "flush"
    }
  ];

  const results = tests.map((test) => {
    const result = evaluateBestHand(test.cards);
    return { ...test, category: result.category, ok: result.category === test.expect, result };
  });

  return { ok: results.every((test) => test.ok), results };
}

export function runSidePotTest() {
  const state = {
    board: [card("A", "spades"), card("K", "spades"), card("Q", "spades"), card("2", "clubs"), card("3", "diamonds")],
    players: [
      { id: "p1", name: "Short", folded: false, totalCommitted: 100, cards: [card("J", "spades"), card("10", "spades")] },
      { id: "p2", name: "Mid", folded: false, totalCommitted: 300, cards: [card("A", "clubs"), card("A", "diamonds")] },
      { id: "p3", name: "Big", folded: false, totalCommitted: 500, cards: [card("9", "hearts"), card("9", "diamonds")] }
    ]
  };

  return resolveSidePotShowdown(state);
}
