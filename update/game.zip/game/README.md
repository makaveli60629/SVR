# SVR Poker Phase X

Lobby scale and visual cleanup restore.
