# SVR Poker Phase V

Boot-first control fix. Removes controller model dependency.
