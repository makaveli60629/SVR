# SVR Poker Phase T

Lobby camera clean. Camera 3 used only for optional live preview.
