# SVR Poker Phase Y

Center Spawn and Clean Play View.
