# SVR Poker Phase AB

Label sync and VR notice cleanup.
