# Game Module - Next Phase

This folder contains the modular poker core for the web game only.

## Goals
- Keep all game logic inside `game/`
- Do not depend on website/root files
- Separate poker rules from UI
- Prepare for WebXR now and Unity later

## Modules
- `core/deck.js` - deck creation and shuffling
- `core/tableState.js` - players, blinds, board, pots, phase
- `core/bettingRound.js` - legal actions and turn progression
- `core/handEvaluator.js` - placeholder hand scoring interface
- `core/showdown.js` - determine winners using evaluator
- `debug/simulateRound.js` - quick round simulation
- `debug/testHands.js` - simple evaluator test cases

## Notes
This phase is framework-light on purpose so it can be reused later.

This is a foundation phase, not a complete production poker engine yet. The evaluator currently scores high-card combinations and provides the interface for the next full Texas Hold'em evaluator phase.
