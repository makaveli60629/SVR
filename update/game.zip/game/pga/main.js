import * as THREE from "three";
import { createCore } from "../modules/core_scene.js";
import { createDesktopControls } from "../modules/desktop_controls.js";
import { createHands } from "../modules/hands.js";
import { createTeleportRig } from "../modules/teleport.js";
import { createDebugStats } from "../modules/debug_stats.js";
import { createJointDebug } from "../modules/hand_debug.js";
import { urlsFor } from "../modules/asset_base.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $log = document.getElementById("log");
const $stats = document.getElementById("stats");
const $err = document.getElementById("err");

function log(...args){
  const line = args.map(a => (typeof a === "string" ? a : JSON.stringify(a, null, 2))).join(" ");
  $log.textContent += line + "\n";
  $log.scrollTop = $log.scrollHeight;
}
document.getElementById("toggleLog").addEventListener("click", ()=>{
  $log.style.display = ($log.style.display === "none" || !$log.style.display) ? "block" : "none";
});

const { scene, camera, renderer } = createCore({ containerId: "app" });
camera.position.set(0, 1.6, 4.8);
const desktop = createDesktopControls({ camera, domElement: renderer.domElement });

window.addEventListener("error", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "RUNTIME ERROR:\n" + (e?.error?.stack || e?.message || String(e));
});
window.addEventListener("unhandledrejection", (e)=>{
  if (!renderer.xr.isPresenting) $err.style.display = "block";
  $err.textContent = "UNHANDLED PROMISE REJECTION:\n" + (e?.reason?.stack || e?.reason || String(e));
});

function canvasTexture(w, h, paint){
  const canvas = document.createElement("canvas");
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext("2d");
  paint(ctx, w, h);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

function addWorld(){
  scene.background = new THREE.Color(0x061018);
  scene.fog = new THREE.FogExp2(0x061018, 0.008);
  scene.add(new THREE.HemisphereLight(0xf1fbff, 0x0a140e, 1.3));
  const sun = new THREE.DirectionalLight(0xfff0cf, 1.3);
  sun.position.set(12, 18, 8);
  scene.add(sun);
  const fill = new THREE.PointLight(0x8fd6ff, 2.0, 50, 2.0);
  fill.position.set(0, 8, -14);
  scene.add(fill);

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(140, 220),
    new THREE.MeshStandardMaterial({ color: 0x174a20, roughness: 0.97, metalness: 0.0 })
  );
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  const fairway = new THREE.Mesh(
    new THREE.PlaneGeometry(20, 150),
    new THREE.MeshStandardMaterial({ color: 0x2c8c3f, roughness: 0.94, metalness: 0.0, emissive: 0x102611, emissiveIntensity: 0.08 })
  );
  fairway.rotation.x = -Math.PI / 2;
  fairway.position.z = -40;
  fairway.position.y = 0.02;
  scene.add(fairway);

  for (let i = 0; i < 11; i++){
    const stripe = new THREE.Mesh(
      new THREE.PlaneGeometry(20, 7),
      new THREE.MeshStandardMaterial({ color: i % 2 ? 0x338a42 : 0x2b7f3c, roughness: 0.94, metalness: 0.0 })
    );
    stripe.rotation.x = -Math.PI / 2;
    stripe.position.set(0, 0.021, -5 - i * 12);
    scene.add(stripe);
  }

  const tee = new THREE.Mesh(
    new THREE.BoxGeometry(4.6, 0.18, 3.4),
    new THREE.MeshStandardMaterial({ color: 0x11161b, roughness: 0.82, metalness: 0.18, emissive: 0x1c2a3a, emissiveIntensity: 0.16 })
  );
  tee.position.set(0, 0.09, 8.2);
  scene.add(tee);
  const teeMat = new THREE.Mesh(
    new THREE.PlaneGeometry(3.7, 2.4),
    new THREE.MeshStandardMaterial({ color: 0x1d7e35, roughness: 0.95, metalness: 0.0 })
  );
  teeMat.rotation.x = -Math.PI / 2;
  teeMat.position.set(0, 0.19, 8.2);
  scene.add(teeMat);

  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(7.6, 2.2),
    new THREE.MeshBasicMaterial({ map: canvasTexture(1400, 380, (ctx, w, h)=>{
      const g = ctx.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#0b0f16'); g.addColorStop(1, '#2e0b11');
      ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
      ctx.strokeStyle = 'rgba(255,203,210,0.92)'; ctx.lineWidth = 10; ctx.strokeRect(16,16,w-32,h-32);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ffffff'; ctx.font = '700 94px Arial'; ctx.fillText('PGA DRIVING RANGE', w/2, 130);
      ctx.fillStyle = '#ffd5cc'; ctx.font = '700 42px Arial'; ctx.fillText('layout lock • tee box • target range • return portal', w/2, 246);
    }), transparent: true, side: THREE.DoubleSide, depthWrite: false })
  );
  sign.position.set(0, 4.2, 1.0);
  scene.add(sign);

  const targetDefs = [
    { x: -5, z: -32, color: 0xff6277, size: 2.1 },
    { x: 3, z: -58, color: 0x7dffef, size: 2.6 },
    { x: -2, z: -96, color: 0xf2d269, size: 3.0 }
  ];
  targetDefs.forEach((d, idx)=>{
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,4.8,12), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4, metalness: 0.18 }));
    pole.position.set(d.x, 2.4, d.z);
    scene.add(pole);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(d.size, 0.12, 16, 48), new THREE.MeshStandardMaterial({ color: d.color, roughness: 0.2, metalness: 0.16, emissive: d.color, emissiveIntensity: 0.9 }));
    ring.position.set(d.x, 2.6, d.z);
    scene.add(ring);
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.48), new THREE.MeshBasicMaterial({ map: canvasTexture(800, 200, (ctx,w,h)=>{
      ctx.fillStyle = 'rgba(0,0,0,0.88)'; ctx.fillRect(0,0,w,h); ctx.strokeStyle = new THREE.Color(d.color).getStyle(); ctx.lineWidth = 8; ctx.strokeRect(10,10,w-20,h-20);
      ctx.fillStyle = '#fff'; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.font='700 62px Arial'; ctx.fillText(`TARGET ${idx+1}`, w/2, h/2);
    }), transparent:true, side:THREE.DoubleSide, depthWrite:false }));
    plate.position.set(d.x, 5.5, d.z);
    scene.add(plate);
  });

  const stars = new THREE.BufferGeometry();
  const pts = [];
  for (let i = 0; i < 260; i++){
    const a = Math.random() * Math.PI * 2;
    const r = 60 + Math.random() * 120;
    const y = 16 + Math.random() * 60;
    pts.push(Math.cos(a) * r, y, Math.sin(a) * r - 40);
  }
  stars.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
  scene.add(new THREE.Points(stars, new THREE.PointsMaterial({ color: 0xeefcff, size: 0.22, transparent: true, opacity: 0.88 })));

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(7.8, 48, 48),
    new THREE.MeshStandardMaterial({ color: 0xf0f1f6, roughness: 0.94, metalness: 0.0, emissive: 0x1f2940, emissiveIntensity: 0.18 })
  );
  moon.position.set(28, 30, -86);
  scene.add(moon);

  const lobbyPortal = { center: new THREE.Vector3(0, 0, 4.0), radius: 1.12 };
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.7, 0.98, 56), new THREE.MeshStandardMaterial({ color: 0xff6277, roughness: 0.2, metalness: 0.16, emissive: 0xff6277, emissiveIntensity: 0.92, side: THREE.DoubleSide }));
  ring.rotation.x = -Math.PI / 2; ring.position.copy(lobbyPortal.center).setY(0.03); scene.add(ring);
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(2.8,0.74), new THREE.MeshBasicMaterial({ map: canvasTexture(900,220,(ctx,w,h)=>{
    const g=ctx.createLinearGradient(0,0,w,h); g.addColorStop(0,'rgba(24,7,12,0.96)'); g.addColorStop(1,'rgba(0,0,0,0.90)');
    ctx.fillStyle=g; ctx.fillRect(0,0,w,h); ctx.strokeStyle='rgba(255,120,140,0.96)'; ctx.lineWidth=8; ctx.strokeRect(12,12,w-24,h-24);
    ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillStyle='#fff'; ctx.font='700 66px Arial'; ctx.fillText('RETURN TO LOBBY', w/2, h/2);
  }), transparent:true, side:THREE.DoubleSide, depthWrite:false }));
  plate.position.set(0,0.82,3.74); scene.add(plate);

  scene.userData._roomPortal = lobbyPortal;
  scene.userData._tickWorld = (dt)=>{
    sign.position.y = 4.2 + Math.sin((scene.userData._t || 0) * 0.7) * 0.04;
    moon.rotation.y += dt * 0.03;
    scene.userData._t = (scene.userData._t || 0) + dt;
  };
  return { roomClamp: 36 };
}

async function loadLogoTexture(){
  const loader = new THREE.TextureLoader();
  for (const url of urlsFor("ui/logo.png")){
    const tex = await new Promise((resolve)=> loader.load(url, (t)=> resolve(t), undefined, ()=> resolve(null)));
    if (tex){
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      return tex;
    }
  }
  return await new Promise((resolve)=> loader.load(new URL("../logo_fallback.png", import.meta.url).toString(), resolve, undefined, ()=> resolve(null)));
}

const { roomClamp } = addWorld();
const hands = createHands({ scene, renderer, log });
const tp = createTeleportRig({ scene, renderer, camera, roomClamp, log });
const stats = createDebugStats({ renderer, scene, camera, el: $stats, label: "PGA RANGE" });
const joints = createJointDebug({ scene });

document.getElementById("toggleJoints").addEventListener("click", ()=> joints.toggle());
document.getElementById("toggleStats").addEventListener("click", ()=> stats.toggle());
window.addEventListener("keydown", (e)=>{
  if (e.code === "Digit1") joints.toggle();
  if (e.code === "Digit2") stats.toggle();
});

$status.textContent = "Loading PGA range assets…";
const logo = await loadLogoTexture();
tp.setLogoTexture(logo);
$status.textContent = "PGA range ready. Enter VR or use desktop controls.";
$mode.textContent = "Hands: waiting…";

function setHudVisible(visible){
  document.getElementById("hud").style.display = visible ? "flex" : "none";
  $err.style.display = "none";
  if (!visible){
    $log.style.display = "none";
    $stats.style.display = "none";
  }
}
renderer.xr.addEventListener("sessionstart", async ()=>{
  setHudVisible(false);
  await tp.onSessionStart();
});
renderer.xr.addEventListener("sessionend", ()=> setHudVisible(true));

let prev = performance.now();
let roomPortalCooldown = 0;
renderer.setAnimationLoop(()=>{
  const now = performance.now();
  const dt = Math.min((now - prev) / 1000, 0.05);
  prev = now;

  if (!renderer.xr.isPresenting) desktop.update(dt);
  if (scene.userData._tickWorld) scene.userData._tickWorld(dt);

  const left = hands.getLeft();
  const right = hands.getRight();
  joints.update(left, right);
  stats.update(dt, left, right);

  tp.update({
    leftHand: left,
    rightHand: right,
    statusCb: (t)=>{ $status.textContent = t; },
    modeCb: (t)=>{ $mode.textContent = t; },
  });

  const activeCam = renderer.xr.isPresenting ? renderer.xr.getCamera(camera) : camera;
  const head = new THREE.Vector3();
  activeCam.getWorldPosition(head);
  if (performance.now() > roomPortalCooldown && head.distanceTo(scene.userData._roomPortal.center) <= scene.userData._roomPortal.radius){
    roomPortalCooldown = performance.now() + 2000;
    $status.textContent = 'Returning to lobby…';
    setTimeout(()=>{ window.location.href = '../'; }, 160);
  }

  renderer.render(scene, camera);
});
