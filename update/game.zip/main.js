import { createPlayer, createTableState, startHand, dealBoardCards } from './core/tableState.js';
import { applyAction, resetBetsForNextStreet } from './core/bettingRound.js';
import { resolveShowdown } from './core/showdown.js';

/**
 * Simulate a simple round of Texas Hold’em with three players.
 * Returns an object containing the final table state and showdown result.
 */
function simulateRound() {
  // Initialize a table state with three players
  let state = createTableState([
    createPlayer('p1', 'Alice', 1000),
    createPlayer('p2', 'Bob', 1000),
    createPlayer('p3', 'Cara', 1000),
  ]);

  // Start a new hand (deal two cards to each player)
  state = startHand(state);

  // Pre-flop betting: Alice bets 20, Bob calls, Cara calls
  state = applyAction(state, 'p1', 'bet', 20);
  state = applyAction(state, 'p2', 'call');
  state = applyAction(state, 'p3', 'call');

  // Move to the flop and reset bets
  state = resetBetsForNextStreet(state);
  state = dealBoardCards(state, 'flop');

  // Flop betting: Alice checks, Bob bets 40, Cara folds, Alice calls
  state = applyAction(state, 'p1', 'check');
  state = applyAction(state, 'p2', 'bet', 40);
  state = applyAction(state, 'p3', 'fold');
  state = applyAction(state, 'p1', 'call');

  // Turn: deal 1 card and reset bets; both players check
  state = resetBetsForNextStreet(state);
  state = dealBoardCards(state, 'turn');
  state = applyAction(state, 'p1', 'check');
  state = applyAction(state, 'p2', 'check');

  // River: deal 1 card and reset bets; both players check
  state = resetBetsForNextStreet(state);
  state = dealBoardCards(state, 'river');
  state = applyAction(state, 'p1', 'check');
  state = applyAction(state, 'p2', 'check');

  // Determine the winners
  const result = resolveShowdown(state);

  return { state, result };
}

/**
 * Convert a card object to a readable string (e.g. “A♠”).
 */
function cardToString(card) {
  const suitSymbols = {
    hearts: '♥',
    diamonds: '♦',
    clubs: '♣',
    spades: '♠',
  };
  return `${card.rank}${suitSymbols[card.suit]}`;
}

function logStateAndResult({ state, result }) {
  const lines = [];
  lines.push(`Board cards: ${state.board.map(cardToString).join(' ')}`);
  lines.push('Players:');
  state.players.forEach((p) => {
    const status = p.folded ? ' (folded)' : '';
    lines.push(`  ${p.name}: ${p.cards.map(cardToString).join(' ')}${status}`);
  });
  lines.push(`\nPot: ${state.pot}`);
  lines.push('\nShowdown results:');
  result.ranked.forEach(({ name, result: hand }) => {
    lines.push(`  ${name}: ${hand.category} (score: ${hand.score}) -> ${hand.cards.map(cardToString).join(' ')}`);
  });
  const winnerNames = result.winners.map((w) => w.name).join(', ');
  lines.push(`\nWinner(s): ${winnerNames}`);
  return lines.join('\n');
}

// Attach event listener to button
document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('playButton');
  const logDiv = document.getElementById('log');
  button.addEventListener('click', () => {
    const result = simulateRound();
    logDiv.textContent = logStateAndResult(result);
  });
});