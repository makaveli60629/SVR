import * as THREE from "three";
import { createCore } from "./modules/core_scene.js";
import { createDesktopControls } from "./modules/desktop_controls.js";
import { createXRInput } from "./modules/xr_input.js";
import { createPlayerRig } from "./modules/player_rig.js";
import { buildWorld } from "./modules/world.js";
import { createWatch } from "./modules/watch.js";
import { createTeleportSystem } from "./modules/teleport.js";
import { createInteractionSystem } from "./modules/interaction.js";
import { createPokerDemo } from "./modules/poker_demo.js";
import { CONFIG } from "./modules/config.js";

const $status = document.getElementById("status");
const $mode = document.getElementById("mode");
const $handState = document.getElementById("handState");
const $log = document.getElementById("log");
const QUERY = new URLSearchParams(window.location.search);
const PREVIEW_ONLY = QUERY.get("preview") === "1";
const SHOW_SPECTATOR = PREVIEW_ONLY;
const CAM_MODE = QUERY.get("cam") || (PREVIEW_ONLY ? "director" : "orbit");
const faultCounts = new Map();
if (PREVIEW_ONLY) document.body.classList.add("preview-only");

function log(...args) {
  const line = args.map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" ");
  $log.textContent += `${line}
`;
  $log.scrollTop = $log.scrollHeight;
  console.log(...args);
}


function safeStep(name, fn) {
  try {
    fn();
  } catch (err) {
    const count = (faultCounts.get(name) || 0) + 1;
    faultCounts.set(name, count);
    if (count <= 3) {
      log(`${name} recovered`, err?.stack || err?.message || String(err));
    }
    $status.textContent = `${name} recovered • lobby still running`;
  }
}

const { scene, camera, renderer, spectatorCamera, spectatorRenderer } = createCore({ containerId: "app", spectatorCanvasId: "spectatorCanvas", enableSpectator: SHOW_SPECTATOR });
const desktop = createDesktopControls({ camera, domElement: renderer.domElement });
const xrInput = createXRInput({ scene, renderer, log });
$status.textContent = PREVIEW_ONLY ? "CAM 3 live" : "Building phase 66 restored lobby…";
const world = await buildWorld(scene, { log });
desktop.setRoomClamp(world.roomClamp);
const playerRig = createPlayerRig({ renderer, camera, desktopControls: desktop, roomClamp: world.roomClamp, log });
playerRig.resetToSpawn();
const watch = createWatch({ scene, camera, renderer });
const teleport = createTeleportSystem({ scene, renderer, camera, playerRig, roomClamp: world.roomClamp });
const interaction = createInteractionSystem({ scene, camera, renderer, playerRig, seats: world.seats, watch, teleport, tableProps: world.tableProps, log });
const poker = createPokerDemo({ scene, chairRings: world.chairRings, statusCb: (text) => { if ($handState) $handState.textContent = text; }, log });
watch.setState({ teleportEnabled: false, seated: false, mode: "DESKTOP" });

renderer.xr.addEventListener("sessionstart", async () => {
  await playerRig.onSessionStart();
  teleport.setEnabled(false);
  interaction.releaseHeldProp();
  playerRig.resetToSpawn();
  watch.setState({ teleportEnabled: false, mode: "XR" });
  $mode.textContent = "Mode: XR";
  $status.textContent = PREVIEW_ONLY ? "CAM 3 preview live" : "XR ready • restored lobby + phase 66 stable";
});
renderer.xr.addEventListener("sessionend", () => {
  teleport.setEnabled(false);
  interaction.releaseHeldProp();
  watch.setState({ teleportEnabled: false, mode: "DESKTOP" });
  playerRig.resetToSpawn();
  $mode.textContent = "Mode: desktop";
  $status.textContent = PREVIEW_ONLY ? "CAM 3 preview live" : "Desktop ready • restored lobby + phase 66 stable";
});

let spectatorAngle = 0;
let last = performance.now();

renderer.setAnimationLoop(() => {
  const now = performance.now();
  const dt = Math.min((now - last) / 1000, 0.05);
  last = now;

  const xrPresenting = renderer.xr.isPresenting;
  const xrState = xrInput.getState();

  if (!xrPresenting && !PREVIEW_ONLY) {
    desktop.update(dt);
    watch.setState({ mode: "DESKTOP" });
  } else if (!xrPresenting && PREVIEW_ONLY) {
    watch.setState({ mode: "DESKTOP" });
  } else {
    watch.setState({ mode: xrState.leftHand?.joints?.wrist ? "HAND" : "CTRL" });
  }

  const gp = xrState.rightController?.userData?.gamepad;
  if (xrPresenting && gp?.axes?.length >= 4) {
    const axisX = gp.axes[2] ?? gp.axes[0] ?? 0;
    if (Math.abs(axisX) > CONFIG.SNAP_DEADZONE && !xrState.rightController.userData.snapLatch) {
      xrState.rightController.userData.snapLatch = true;
      playerRig.snapTurn(THREE.MathUtils.degToRad(axisX > 0 ? -CONFIG.SNAP_TURN_DEG : CONFIG.SNAP_TURN_DEG));
    }
    if (Math.abs(axisX) < 0.2) xrState.rightController.userData.snapLatch = false;
  }

  safeStep("interaction", () => interaction.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand }));
  safeStep("watch", () => watch.updatePose({ leftHand: xrState.leftHand, leftController: xrState.leftController, rightController: xrState.rightController, xrPresenting }));
  safeStep("teleport", () => teleport.update({ xrPresenting, rightController: xrState.rightController, rightHand: xrState.rightHand, statusCb: (t) => { $status.textContent = t; } }));
  safeStep("world", () => scene.userData._tickWorld?.(now * 0.001));
  safeStep("poker", () => poker.update(now * 0.001, dt));
  safeStep("safety", () => { if (!playerRig.isSeated()) playerRig.ensureSafePosition(); });

  const seated = playerRig.isSeated();
  watch.setState({ seated, teleportEnabled: teleport.isEnabled() });
  if (!PREVIEW_ONLY) {
    $mode.textContent = xrPresenting ? `Mode: XR • ${teleport.isEnabled() ? "TP ON" : "TP OFF"}` : `Mode: desktop • ${seated ? "seated" : "standing"}`;
  }

  renderer.render(scene, camera);

  if (SHOW_SPECTATOR && spectatorCamera && spectatorRenderer) {
    spectatorAngle += dt;
    if (CAM_MODE === "director") {
      const shots = [
        {
          pos: new THREE.Vector3(0, CONFIG.SPECTATOR_HEIGHT - 1.0, CONFIG.SPECTATOR_RADIUS + 3.2),
          look: new THREE.Vector3(world.tableCenter.x, 1.24, world.tableCenter.z - 0.42),
          fov: 40,
          dur: 6.4,
        },
        {
          pos: new THREE.Vector3(-CONFIG.SPECTATOR_RADIUS + 1.7, CONFIG.SPECTATOR_HEIGHT - 0.4, 5.0),
          look: new THREE.Vector3(world.tableCenter.x - 0.18, 1.2, world.tableCenter.z + 0.04),
          fov: 52,
          dur: 5.9,
        },
        {
          pos: new THREE.Vector3(-4.2, CONFIG.SPECTATOR_HEIGHT + 1.8, -CONFIG.SPECTATOR_RADIUS + 1.8),
          look: new THREE.Vector3(world.tableCenter.x - 0.12, 1.54, world.tableCenter.z + 0.1),
          fov: 46,
          dur: 5.4,
        },
        {
          pos: new THREE.Vector3(0.24, CONFIG.SPECTATOR_HEIGHT + 3.2, 0.65),
          look: new THREE.Vector3(world.tableCenter.x, 1.1, world.tableCenter.z),
          fov: 34,
          dur: 4.8,
        },
        {
          pos: new THREE.Vector3(CONFIG.SPECTATOR_RADIUS - 2.4, CONFIG.SPECTATOR_HEIGHT - 0.65, 2.4),
          look: new THREE.Vector3(world.tableCenter.x + 0.2, 1.18, world.tableCenter.z - 0.05),
          fov: 54,
          dur: 5.7,
        },
        {
          pos: new THREE.Vector3(3.4, CONFIG.SPECTATOR_HEIGHT + 0.6, CONFIG.SPECTATOR_RADIUS - 2.5),
          look: new THREE.Vector3(world.tableCenter.x + 0.08, 1.32, world.tableCenter.z - 0.2),
          fov: 44,
          dur: 5.5,
        }
      ];
      const totalDur = shots.reduce((sum, shot) => sum + shot.dur, 0);
      let cycle = spectatorAngle % totalDur;
      let shotIndex = 0;
      while (cycle > shots[shotIndex].dur && shotIndex < shots.length - 1) {
        cycle -= shots[shotIndex].dur;
        shotIndex += 1;
      }
      const currentShot = shots[shotIndex];
      const nextShot = shots[(shotIndex + 1) % shots.length];
      const blendStart = Math.max(0, currentShot.dur - 1.35);
      const blendT = THREE.MathUtils.clamp((cycle - blendStart) / 1.35, 0, 1);
      const ease = blendT * blendT * (3 - 2 * blendT);
      const camPos = currentShot.pos.clone().lerp(nextShot.pos, ease);
      const camLook = currentShot.look.clone().lerp(nextShot.look, ease);
      camPos.x += Math.sin(spectatorAngle * 0.42 + shotIndex) * 0.08;
      camPos.y += Math.sin(spectatorAngle * 0.33 + shotIndex * 0.7) * 0.04;
      camPos.z += Math.cos(spectatorAngle * 0.37 + shotIndex * 0.5) * 0.08;
      camLook.x += Math.sin(spectatorAngle * 0.24 + shotIndex * 0.8) * 0.06;
      camLook.y += Math.sin(spectatorAngle * 0.31 + shotIndex * 0.3) * 0.03;
      camLook.z += Math.cos(spectatorAngle * 0.26 + shotIndex * 0.5) * 0.05;
      spectatorCamera.position.copy(camPos);
      spectatorCamera.fov = THREE.MathUtils.lerp(currentShot.fov, nextShot.fov, ease);
      spectatorCamera.updateProjectionMatrix();
      spectatorCamera.lookAt(camLook);
    } else if (CAM_MODE === "broadcast") {
      spectatorCamera.position.set(Math.sin(spectatorAngle * 0.3) * 2.1, CONFIG.SPECTATOR_HEIGHT - 0.7 + Math.sin(spectatorAngle * 0.22) * 0.08, CONFIG.SPECTATOR_RADIUS - 1.6);
      spectatorCamera.fov = 50;
      spectatorCamera.updateProjectionMatrix();
      spectatorCamera.lookAt(world.tableCenter.x, 1.3, world.tableCenter.z - 0.1);
    } else {
      const specR = CONFIG.SPECTATOR_RADIUS;
      spectatorCamera.position.set(Math.cos(spectatorAngle * 0.14) * specR, CONFIG.SPECTATOR_HEIGHT, Math.sin(spectatorAngle * 0.14) * specR);
      spectatorCamera.fov = 58;
      spectatorCamera.updateProjectionMatrix();
      spectatorCamera.lookAt(world.tableCenter.x, 1.2, world.tableCenter.z);
    }
    spectatorRenderer.render(scene, spectatorCamera);
  }
});

window.addEventListener("error", (e) => {
  log("RUNTIME ERROR", e?.error?.stack || e?.message || String(e));
  $status.textContent = "Runtime error • open Logs";
});
window.addEventListener("unhandledrejection", (e) => {
  log("PROMISE ERROR", e?.reason?.stack || e?.reason || String(e));
  $status.textContent = "Promise rejection • open Logs";
});

$status.textContent = PREVIEW_ONLY ? `CAM 3 preview live • ${CAM_MODE}` : "Phase 66 ready • restored lobby + fuller poker demo";
if ($handState) $handState.textContent = "HAND 1 • shuffling real deck in restored phase 66 lobby";
window.addEventListener("keydown", (e) => { if (e.code === "KeyN") poker.forceNextHand(); });
log("SVR Poker phase 66 ready", { build: CONFIG.BUILD, camMode: CAM_MODE, showSpectator: SHOW_SPECTATOR });
