(function () {
  if (!window.AFRAME) return;

  AFRAME.registerComponent('phase96-vr-cleanup', {
    init: function () {
      const scene = this.el;
      const enterVr = () => {
        document.body.classList.add('vr-mode');
        document.querySelectorAll('.debug-note').forEach((el) => el.remove());
      };
      const exitVr = () => {
        document.body.classList.remove('vr-mode');
      };
      scene.addEventListener('enter-vr', enterVr);
      scene.addEventListener('exit-vr', exitVr);
    }
  });

  AFRAME.registerComponent('phase96-rig', {
    init: function () {
      this.turnValue = 0;
      this.moveVec = { x: 0, y: 0 };
      this.left = document.getElementById('leftHand');
      this.right = document.getElementById('rightHand');
      this.camera = document.getElementById('camera');
      this.snapCooldown = 0;
      this.onLeft = (e) => {
        if (!e.detail) return;
        this.moveVec.x = e.detail.x || 0;
        this.moveVec.y = e.detail.y || 0;
      };
      this.onRight = (e) => {
        if (!e.detail) return;
        this.turnValue = e.detail.x || 0;
      };
      this.onLeftEnd = () => { this.moveVec.x = 0; this.moveVec.y = 0; };
      this.onRightEnd = () => { this.turnValue = 0; };
      if (this.left) {
        this.left.addEventListener('thumbstickmoved', this.onLeft);
        this.left.addEventListener('thumbsticktouchend', this.onLeftEnd);
      }
      if (this.right) {
        this.right.addEventListener('thumbstickmoved', this.onRight);
        this.right.addEventListener('thumbsticktouchend', this.onRightEnd);
      }
    },
    tick: function (time, delta) {
      const dt = Math.min((delta || 16) / 1000, 0.05);
      if (Math.abs(this.turnValue) > 0.72) {
        this.snapCooldown -= delta || 16;
        if (this.snapCooldown <= 0) {
          this.el.object3D.rotation.y -= Math.sign(this.turnValue) * (Math.PI / 8);
          this.snapCooldown = 180;
        }
      } else {
        this.snapCooldown = 0;
      }

      const mag = Math.hypot(this.moveVec.x, this.moveVec.y);
      if (mag < 0.12) return;

      const yaw = (this.camera && this.camera.object3D) ? this.camera.object3D.rotation.y : 0;
      const forward = { x: -Math.sin(yaw), z: -Math.cos(yaw) };
      const right = { x: Math.cos(yaw), z: -Math.sin(yaw) };
      const speed = 1.8;
      const moveX = (right.x * this.moveVec.x + forward.x * this.moveVec.y) * speed * dt;
      const moveZ = (right.z * this.moveVec.x + forward.z * this.moveVec.y) * speed * dt;
      this.el.object3D.position.x += moveX;
      this.el.object3D.position.z += moveZ;

      this.el.object3D.position.x = Math.max(-7, Math.min(7, this.el.object3D.position.x));
      this.el.object3D.position.z = Math.max(-7, Math.min(7, this.el.object3D.position.z));
    }
  });

  AFRAME.registerComponent('phase96-table-fit', {
    init: function () {
      this.el.addEventListener('model-loaded', () => {
        const model = this.el.getObject3D('mesh');
        if (!model || !window.THREE) return;
        const THREE = window.THREE;

        model.traverse((obj) => {
          if (!obj.isMesh) return;
          obj.frustumCulled = false;
          obj.castShadow = false;
          obj.receiveShadow = false;
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          mats.forEach((mat) => {
            if (!mat) return;
            mat.transparent = false;
            mat.opacity = 1;
            mat.depthWrite = true;
            mat.side = THREE.DoubleSide;
            if (mat.metalness !== undefined) mat.metalness = Math.min(mat.metalness, 0.25);
            if (mat.roughness !== undefined) mat.roughness = Math.max(mat.roughness, 0.7);
            mat.needsUpdate = true;
          });
        });

        const bbox = new THREE.Box3().setFromObject(model);
        const size = new THREE.Vector3();
        const center = new THREE.Vector3();
        bbox.getSize(size);
        bbox.getCenter(center);

        const targetWidth = 2.55;
        const sourceWidth = Math.max(size.x, size.z) || 1;
        const scale = targetWidth / sourceWidth;
        model.scale.setScalar(scale);
        model.updateMatrixWorld(true);

        const bbox2 = new THREE.Box3().setFromObject(model);
        const size2 = new THREE.Vector3();
        const center2 = new THREE.Vector3();
        bbox2.getSize(size2);
        bbox2.getCenter(center2);
        model.position.x -= center2.x;
        model.position.z -= center2.z;
        model.position.y -= bbox2.min.y;
        model.updateMatrixWorld(true);

        const bbox3 = new THREE.Box3().setFromObject(model);
        const size3 = new THREE.Vector3();
        bbox3.getSize(size3);
        const topY = bbox3.max.y + 0.006;

        const felt = document.getElementById('feltTop');
        if (felt) {
          felt.setAttribute('visible', true);
          felt.setAttribute('width', Math.max(1.85, size3.x * 0.78));
          felt.setAttribute('height', Math.max(0.95, size3.z * 0.76));
          felt.setAttribute('position', { x: 0, y: topY, z: 0 });
        }
      });
    }
  });

  AFRAME.registerComponent('phase96-input', {
    init: function () {
      const scene = this.el;
      scene.addEventListener('loaded', () => {
        const status = document.getElementById('statusText');
        if (status) {
          status.setAttribute('text', 'value', 'Phase 96 Exact Table • Enter VR and verify movement + exact assets-folder table');
        }
      });
    }
  });
})();
