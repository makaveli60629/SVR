(function () {
  if (!window.AFRAME) return;

  AFRAME.registerComponent('phase94-vr-cleanup', {
    init: function () {
      const scene = this.el;
      const enterVr = () => {
        document.body.classList.add('vr-mode');
        document.querySelectorAll('.debug-note').forEach((el) => el.remove());
      };
      const exitVr = () => {
        document.body.classList.remove('vr-mode');
      };
      scene.addEventListener('enter-vr', enterVr);
      scene.addEventListener('exit-vr', exitVr);
    }
  });

  AFRAME.registerComponent('phase94-rig', {
    init: function () {
      this.turnValue = 0;
      this.moveVec = { x: 0, y: 0 };
      this.left = document.getElementById('leftHand');
      this.right = document.getElementById('rightHand');
      this.camera = document.getElementById('camera');
      this.snapCooldown = 0;
      this.onLeft = (e) => {
        if (!e.detail) return;
        this.moveVec.x = e.detail.x || 0;
        this.moveVec.y = e.detail.y || 0;
      };
      this.onRight = (e) => {
        if (!e.detail) return;
        this.turnValue = e.detail.x || 0;
      };
      this.onLeftEnd = () => { this.moveVec.x = 0; this.moveVec.y = 0; };
      this.onRightEnd = () => { this.turnValue = 0; };
      if (this.left) {
        this.left.addEventListener('thumbstickmoved', this.onLeft);
        this.left.addEventListener('thumbsticktouchend', this.onLeftEnd);
      }
      if (this.right) {
        this.right.addEventListener('thumbstickmoved', this.onRight);
        this.right.addEventListener('thumbsticktouchend', this.onRightEnd);
      }
    },
    tick: function (time, delta) {
      const dt = Math.min((delta || 16) / 1000, 0.05);
      if (Math.abs(this.turnValue) > 0.72) {
        this.snapCooldown -= delta || 16;
        if (this.snapCooldown <= 0) {
          this.el.object3D.rotation.y -= Math.sign(this.turnValue) * (Math.PI / 8);
          this.snapCooldown = 180;
        }
      } else {
        this.snapCooldown = 0;
      }

      const mag = Math.hypot(this.moveVec.x, this.moveVec.y);
      if (mag < 0.12) return;

      const yaw = (this.camera && this.camera.object3D) ? this.camera.object3D.rotation.y : 0;
      const forward = { x: -Math.sin(yaw), z: -Math.cos(yaw) };
      const right = { x: Math.cos(yaw), z: -Math.sin(yaw) };
      const speed = 1.8;
      const moveX = (right.x * this.moveVec.x + forward.x * this.moveVec.y) * speed * dt;
      const moveZ = (right.z * this.moveVec.x + forward.z * this.moveVec.y) * speed * dt;
      this.el.object3D.position.x += moveX;
      this.el.object3D.position.z += moveZ;

      this.el.object3D.position.x = Math.max(-7, Math.min(7, this.el.object3D.position.x));
      this.el.object3D.position.z = Math.max(-7, Math.min(7, this.el.object3D.position.z));
    }
  });

  AFRAME.registerComponent('phase94-input', {
    init: function () {
      const scene = this.el;
      scene.addEventListener('loaded', () => {
        const status = document.getElementById('statusText');
        if (status) {
          status.setAttribute('text', 'value', 'Phase 94 OBJ Table Step • Enter VR and verify movement + OBJ table');
        }
      });
    }
  });
})();
