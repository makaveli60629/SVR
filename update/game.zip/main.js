(function () {
  if (!window.AFRAME || !window.THREE) return;

  AFRAME.registerComponent('phase115-vr-cleanup', {
    init: function () {
      const scene = this.el;
      scene.addEventListener('enter-vr', () => document.body.classList.add('vr-mode'));
      scene.addEventListener('exit-vr', () => document.body.classList.remove('vr-mode'));
    }
  });

  AFRAME.registerComponent('phase115-rig', {
    init: function () {
      this.turnValue = 0;
      this.moveVec = { x: 0, y: 0 };
      this.left = document.getElementById('leftController');
      this.right = document.getElementById('rightController');
      this.camera = document.getElementById('camera');
      this.snapCooldown = 0;
      this.onLeft = (e) => {
        if (!e.detail) return;
        this.moveVec.x = e.detail.x || 0;
        this.moveVec.y = e.detail.y || 0;
      };
      this.onRight = (e) => {
        if (!e.detail) return;
        this.turnValue = e.detail.x || 0;
      };
      this.onLeftEnd = () => { this.moveVec.x = 0; this.moveVec.y = 0; };
      this.onRightEnd = () => { this.turnValue = 0; };
      if (this.left) {
        this.left.addEventListener('thumbstickmoved', this.onLeft);
        this.left.addEventListener('thumbsticktouchend', this.onLeftEnd);
      }
      if (this.right) {
        this.right.addEventListener('thumbstickmoved', this.onRight);
        this.right.addEventListener('thumbsticktouchend', this.onRightEnd);
      }
    },
    tick: function (time, delta) {
      const dt = Math.min((delta || 16) / 1000, 0.05);
      if (Math.abs(this.turnValue) > 0.72) {
        this.snapCooldown -= delta || 16;
        if (this.snapCooldown <= 0) {
          this.el.object3D.rotation.y -= Math.sign(this.turnValue) * (Math.PI / 8);
          this.snapCooldown = 180;
        }
      } else {
        this.snapCooldown = 0;
      }

      const mag = Math.hypot(this.moveVec.x, this.moveVec.y);
      if (mag < 0.12) return;

      const yaw = (this.camera && this.camera.object3D) ? this.camera.object3D.rotation.y : 0;
      const forward = { x: -Math.sin(yaw), z: -Math.cos(yaw) };
      const right = { x: Math.cos(yaw), z: -Math.sin(yaw) };
      const speed = 2.25;
      const moveX = (right.x * this.moveVec.x + forward.x * this.moveVec.y) * speed * dt;
      const moveZ = (right.z * this.moveVec.x + forward.z * this.moveVec.y) * speed * dt;
      this.el.object3D.position.x += moveX;
      this.el.object3D.position.z += moveZ;
      this.el.object3D.position.x = Math.max(-8.5, Math.min(8.5, this.el.object3D.position.x));
      this.el.object3D.position.z = Math.max(-8.5, Math.min(8.5, this.el.object3D.position.z));
      this.el.object3D.position.y = 0.0;
    }
  });

  AFRAME.registerComponent('phase115-floor-material', {
    init: function () {
      const el = this.el;
      const THREE = window.THREE;
      const loader = new THREE.TextureLoader();
      const base = loader.load('./assets/texture/slate_floor_basecolor.jpg');
      const normal = loader.load('./assets/texture/slate_floor_normal.png');
      const rough = loader.load('./assets/texture/slate_floor_roughness.jpg');
      [base, normal, rough].forEach((t) => {
        t.wrapS = t.wrapT = THREE.RepeatWrapping;
        t.repeat.set(6, 6);
      });
      if (THREE.SRGBColorSpace) base.colorSpace = THREE.SRGBColorSpace;
      const apply = () => {
        const mesh = el.getObject3D('mesh');
        if (!mesh) return;
        mesh.material = new THREE.MeshStandardMaterial({
          map: base,
          normalMap: normal,
          roughnessMap: rough,
          roughness: 1.0,
          metalness: 0.02,
          color: new THREE.Color('#ffffff')
        });
        mesh.receiveShadow = false;
      };
      if (el.getObject3D('mesh')) apply();
      else el.addEventListener('loaded', apply, { once: true });
    }
  });

  AFRAME.registerComponent('phase115-room-shell', {
    init: function () {
      const root = this.el;
      const wall = document.createElement('a-cylinder');
      wall.setAttribute('position', '0 1.72 0');
      wall.setAttribute('radius', '9');
      wall.setAttribute('height', '3.44');
      wall.setAttribute('open-ended', 'true');
      wall.setAttribute('side', 'back');
      wall.setAttribute('color', '#0a0c18');
      wall.setAttribute('phase114-wall-material', '');
      root.appendChild(wall);

      const baseRing = document.createElement('a-ring');
      baseRing.setAttribute('position', '0 0.02 0');
      baseRing.setAttribute('rotation', '-90 0 0');
      baseRing.setAttribute('radius-inner', '7.95');
      baseRing.setAttribute('radius-outer', '8.35');
      baseRing.setAttribute('color', '#1a1f33');
      baseRing.setAttribute('material', 'metalness: 0.02; roughness: 0.95; emissive: #121935; emissiveIntensity: 0.12');
      root.appendChild(baseRing);

      const topRing = document.createElement('a-ring');
      topRing.setAttribute('position', '0 3.39 0');
      topRing.setAttribute('rotation', '-90 0 0');
      topRing.setAttribute('radius-inner', '8.68');
      topRing.setAttribute('radius-outer', '8.98');
      topRing.setAttribute('color', '#8746ff');
      root.appendChild(topRing);
    }
  });

  AFRAME.registerComponent('phase115-city-ring', {
    init: function () {
      const root = this.el;
      const count = 18;
      for (let i = 0; i < count; i++) {
        const angle = (i / count) * Math.PI * 2;
        const radius = 7.1 + (i % 3) * 0.15;
        const height = 1.3 + (i % 5) * 0.42;
        const width = 0.45 + (i % 4) * 0.12;
        const box = document.createElement('a-box');
        box.setAttribute('position', { x: Math.cos(angle) * radius, y: height / 2, z: Math.sin(angle) * radius });
        box.setAttribute('rotation', { x: 0, y: THREE.MathUtils.radToDeg(-angle) + 90, z: 0 });
        box.setAttribute('depth', 0.45 + (i % 2) * 0.2);
        box.setAttribute('height', height);
        box.setAttribute('width', width);
        box.setAttribute('color', '#12172b');
        box.setAttribute('material', 'metalness: 0.05; roughness: 0.88; emissive: #101833; emissiveIntensity: 0.16');
        root.appendChild(box);
      }
    }
  });

  AFRAME.registerComponent('phase115-table-fit', {
    init: function () {
      this.el.addEventListener('model-loaded', () => {
        const model = this.el.getObject3D('mesh');
        if (!model) return;
        const THREE = window.THREE;
        const loader = new THREE.TextureLoader();
        const leather = loader.load('./assets/texture/leather_dark.jpg');
        leather.wrapS = leather.wrapT = THREE.RepeatWrapping;
        leather.repeat.set(3.2, 2.25);
        if (THREE.SRGBColorSpace) leather.colorSpace = THREE.SRGBColorSpace;
        const leatherBump = loader.load('./assets/texture/leather_dark_bump.jpg');
        leatherBump.wrapS = leatherBump.wrapT = THREE.RepeatWrapping;
        leatherBump.repeat.copy(leather.repeat);

        const modelBox = new THREE.Box3().setFromObject(model);
        const modelSize = new THREE.Vector3();
        modelBox.getSize(modelSize);
        model.traverse((obj) => {
          if (!obj.isMesh) return;
          obj.frustumCulled = false;
          const meshBox = new THREE.Box3().setFromObject(obj);
          const meshSize = new THREE.Vector3();
          const meshCenter = new THREE.Vector3();
          meshBox.getSize(meshSize);
          meshBox.getCenter(meshCenter);
          const thinTopCap = meshSize.y < modelSize.y * 0.08 && meshCenter.y > modelBox.max.y - modelSize.y * 0.10;
          if (thinTopCap) { obj.visible = false; return; }
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          mats.forEach((mat) => {
            if (!mat) return;
            mat.transparent = false;
            mat.opacity = 1;
            mat.depthWrite = true;
            mat.side = THREE.DoubleSide;
            mat.map = leather;
            if ('normalMap' in mat) {
              mat.normalMap = leatherBump;
              if (mat.normalScale) mat.normalScale.set(0.7, 0.7);
            } else if ('bumpMap' in mat) {
              mat.bumpMap = leatherBump;
              mat.bumpScale = 0.05;
            }
            if (mat.metalness !== undefined) mat.metalness = 0.04;
            if (mat.roughness !== undefined) mat.roughness = 0.97;
            mat.color = new THREE.Color('#c7c9cf');
            mat.needsUpdate = true;
          });
        });

        const bbox = new THREE.Box3().setFromObject(model);
        const size = new THREE.Vector3();
        bbox.getSize(size);
        const sourceWidth = Math.max(size.x, size.z) || 1;
        const targetWidth = 6.35;
        const scale = targetWidth / sourceWidth;
        model.scale.setScalar(scale);
        model.updateMatrixWorld(true);

        const bbox2 = new THREE.Box3().setFromObject(model);
        const center2 = new THREE.Vector3();
        bbox2.getCenter(center2);
        model.position.x -= center2.x;
        model.position.z -= center2.z;
        model.position.y -= bbox2.min.y + 0.258;
        model.updateMatrixWorld(true);

        const bbox3 = new THREE.Box3().setFromObject(model);
        const size3 = new THREE.Vector3();
        bbox3.getSize(size3);
        const feltY = bbox3.max.y - 0.342;
        const felt = document.getElementById('feltTop');
        if (felt) {
          felt.setAttribute('visible', true);
          felt.setAttribute('width', Math.max(3.85, size3.x * 0.79));
          felt.setAttribute('height', Math.max(2.10, size3.z * 0.44));
          felt.setAttribute('position', { x: 0, y: feltY, z: 0 });
          const applyFeltMaterial = () => {
            const mesh = felt.getObject3D('mesh');
            if (!mesh) return;
            const feltMap = loader.load('./assets/texture/tablefelt.png');
            if (THREE.SRGBColorSpace) feltMap.colorSpace = THREE.SRGBColorSpace;
            mesh.material = new THREE.MeshStandardMaterial({
              map: feltMap,
              roughness: 0.98,
              metalness: 0.0,
              side: THREE.DoubleSide,
              color: new THREE.Color('#ffffff')
            });
            mesh.renderOrder = 4;
          };
          if (felt.getObject3D('mesh')) applyFeltMaterial();
          else felt.addEventListener('loaded', applyFeltMaterial, { once: true });
        }

        const rig = document.getElementById('rig');
        if (rig) rig.object3D.position.set(0, 0, bbox3.max.z + 1.75);
        const camera = document.getElementById('camera');
        if (camera) camera.setAttribute('position', { x: 0, y: 0.78, z: 0 });
        const dealerAnchor = document.getElementById('dealerAnchor');
        if (dealerAnchor) dealerAnchor.setAttribute('position', { x: 0, y: 0, z: bbox3.max.z + 0.58 });
      });
    }
  });

  AFRAME.registerComponent('phase115-dealer-loader', {
    init: function () {
      const THREE = window.THREE;
      if (!THREE || !THREE.FBXLoader) return;
      const el = this.el;
      const texLoader = new THREE.TextureLoader();
      const diffuse = texLoader.load('./assets/eric-diffuse.webp');
      if (THREE.SRGBColorSpace) diffuse.colorSpace = THREE.SRGBColorSpace;
      const loader = new THREE.FBXLoader();
      loader.load('./assets/eric.fbx', (fbx) => {
        fbx.traverse((obj) => {
          if (!obj.isMesh) return;
          obj.frustumCulled = false;
          obj.material = new THREE.MeshStandardMaterial({
            map: diffuse,
            roughness: 0.85,
            metalness: 0.02,
            side: THREE.DoubleSide,
            color: new THREE.Color('#ffffff')
          });
        });
        const bbox = new THREE.Box3().setFromObject(fbx);
        const size = new THREE.Vector3();
        bbox.getSize(size);
        const targetHeight = 1.78;
        const scale = targetHeight / Math.max(size.y, 0.001);
        fbx.scale.setScalar(scale);
        fbx.updateMatrixWorld(true);
        const bbox2 = new THREE.Box3().setFromObject(fbx);
        const center = new THREE.Vector3();
        bbox2.getCenter(center);
        fbx.position.x -= center.x;
        fbx.position.z -= center.z;
        fbx.position.y -= bbox2.min.y;
        fbx.rotation.y = Math.PI;
        el.setObject3D('mesh', fbx);
      });
    }
  });

  AFRAME.registerComponent('phase115-seat-markers', {
    init: function () {
      const root = this.el;
      const seats = [
        { x: 0.00, z: 3.14, r: '0 180 0' },
        { x: -3.28, z: 0.42, r: '0 90 0' },
        { x: 3.28, z: 0.42, r: '0 -90 0' },
        { x: -2.36, z: -2.42, r: '0 42 0' },
        { x: 2.36, z: -2.42, r: '0 -42 0' },
        { x: 0.00, z: -3.18, r: '0 0 0' }
      ];
      seats.forEach((s) => {
        const marker = document.createElement('a-cylinder');
        marker.setAttribute('position', { x: s.x, y: 0.02, z: s.z });
        marker.setAttribute('radius', 0.20);
        marker.setAttribute('height', 0.045);
        marker.setAttribute('rotation', s.r);
        marker.setAttribute('color', '#5e4aa8');
        marker.setAttribute('material', 'metalness: 0.02; roughness: 0.95; emissive: #26164a; emissiveIntensity: 0.25');
        root.appendChild(marker);
      });
    }
  });

  AFRAME.registerComponent('phase115-wall-material', {
    init: function () {
      const el = this.el;
      const THREE = window.THREE;
      const loader = new THREE.TextureLoader();
      const col = loader.load('./assets/texture/wall_stone_col.jpg');
      col.wrapS = col.wrapT = THREE.RepeatWrapping;
      col.repeat.set(8, 2);
      if (THREE.SRGBColorSpace) col.colorSpace = THREE.SRGBColorSpace;
      const apply = () => {
        const mesh = el.getObject3D('mesh');
        if (!mesh) return;
        mesh.material = new THREE.MeshStandardMaterial({
          map: col,
          roughness: 0.96,
          metalness: 0.02,
          side: THREE.BackSide,
          color: new THREE.Color('#d0d3db')
        });
      };
      if (el.getObject3D('mesh')) apply(); else el.addEventListener('loaded', apply, { once: true });
    }
  });

  AFRAME.registerComponent('phase115-teleport', {
    schema: { hand: { default: 'right' } },
    init: function () {
      this.rig = document.getElementById('rig');
      this.floor = document.getElementById('floorPlane');
      this.onTrigger = () => {
        const ray = this.el.components.raycaster;
        if (!ray || !this.rig || !this.floor) return;
        const hit = ray.getIntersection(this.floor);
        if (!hit || !hit.point) return;
        this.rig.object3D.position.x = hit.point.x;
        this.rig.object3D.position.z = hit.point.z;
      };
      this.el.addEventListener('triggerdown', this.onTrigger);
      this.el.addEventListener('abuttondown', this.onTrigger);
      this.el.addEventListener('xbuttondown', this.onTrigger);
    }
  });

  AFRAME.registerComponent('phase115-hand-teleport', {
    init: function () {
      this.rig = document.getElementById('rig');
      this.floor = document.getElementById('floorPlane');
      this.onPinch = () => {
        const ray = this.el.components.raycaster;
        if (!ray || !this.rig || !this.floor) return;
        const hit = ray.getIntersection(this.floor);
        if (!hit || !hit.point) return;
        this.rig.object3D.position.x = hit.point.x;
        this.rig.object3D.position.z = hit.point.z;
      };
      this.el.addEventListener('pinchstarted', this.onPinch);
      this.el.addEventListener('pinchended', this.onPinch);
    }
  });

})();
