(function () {
  if (!window.AFRAME || !window.THREE) return;

  AFRAME.registerComponent('phase106-vr-cleanup', {
    init: function () {
      const scene = this.el;
      scene.addEventListener('enter-vr', () => document.body.classList.add('vr-mode'));
      scene.addEventListener('exit-vr', () => document.body.classList.remove('vr-mode'));
    }
  });

  AFRAME.registerComponent('phase106-rig', {
    init: function () {
      this.turnValue = 0;
      this.moveVec = { x: 0, y: 0 };
      this.left = document.getElementById('leftController');
      this.right = document.getElementById('rightController');
      this.camera = document.getElementById('camera');
      this.snapCooldown = 0;
      this.onLeft = (e) => {
        if (!e.detail) return;
        this.moveVec.x = e.detail.x || 0;
        this.moveVec.y = e.detail.y || 0;
      };
      this.onRight = (e) => {
        if (!e.detail) return;
        this.turnValue = e.detail.x || 0;
      };
      this.onLeftEnd = () => { this.moveVec.x = 0; this.moveVec.y = 0; };
      this.onRightEnd = () => { this.turnValue = 0; };
      if (this.left) {
        this.left.addEventListener('thumbstickmoved', this.onLeft);
        this.left.addEventListener('thumbsticktouchend', this.onLeftEnd);
      }
      if (this.right) {
        this.right.addEventListener('thumbstickmoved', this.onRight);
        this.right.addEventListener('thumbsticktouchend', this.onRightEnd);
      }
    },
    tick: function (time, delta) {
      const dt = Math.min((delta || 16) / 1000, 0.05);
      if (Math.abs(this.turnValue) > 0.72) {
        this.snapCooldown -= delta || 16;
        if (this.snapCooldown <= 0) {
          this.el.object3D.rotation.y -= Math.sign(this.turnValue) * (Math.PI / 8);
          this.snapCooldown = 180;
        }
      } else {
        this.snapCooldown = 0;
      }

      const mag = Math.hypot(this.moveVec.x, this.moveVec.y);
      if (mag < 0.12) return;

      const yaw = (this.camera && this.camera.object3D) ? this.camera.object3D.rotation.y : 0;
      const forward = { x: -Math.sin(yaw), z: -Math.cos(yaw) };
      const right = { x: Math.cos(yaw), z: -Math.sin(yaw) };
      const speed = 1.9;
      const moveX = (right.x * this.moveVec.x + forward.x * this.moveVec.y) * speed * dt;
      const moveZ = (right.z * this.moveVec.x + forward.z * this.moveVec.y) * speed * dt;
      this.el.object3D.position.x += moveX;
      this.el.object3D.position.z += moveZ;
      this.el.object3D.position.x = Math.max(-7, Math.min(7, this.el.object3D.position.x));
      this.el.object3D.position.z = Math.max(-7, Math.min(7, this.el.object3D.position.z));
      this.el.object3D.position.y = 0.0;
    }
  });

  AFRAME.registerComponent('phase106-city-ring', {
    init: function () {
      const root = this.el;
      const count = 18;
      for (let i = 0; i < count; i++) {
        const angle = (i / count) * Math.PI * 2;
        const radius = 7.1 + (i % 3) * 0.15;
        const height = 1.3 + (i % 5) * 0.42;
        const width = 0.45 + (i % 4) * 0.12;
        const box = document.createElement('a-box');
        box.setAttribute('position', { x: Math.cos(angle) * radius, y: height / 2, z: Math.sin(angle) * radius });
        box.setAttribute('rotation', { x: 0, y: THREE.MathUtils.radToDeg(-angle) + 90, z: 0 });
        box.setAttribute('depth', 0.45 + (i % 2) * 0.2);
        box.setAttribute('height', height);
        box.setAttribute('width', width);
        box.setAttribute('color', '#12172b');
        box.setAttribute('material', 'metalness: 0.05; roughness: 0.88; emissive: #101833; emissiveIntensity: 0.16');
        root.appendChild(box);
      }
    }
  });

  AFRAME.registerComponent('phase106-table-fit', {
    init: function () {
      this.el.addEventListener('model-loaded', () => {
        const model = this.el.getObject3D('mesh');
        if (!model) return;
        const THREE = window.THREE;
        const loader = new THREE.TextureLoader();
        const leather = loader.load('./assets/texture/leather_dark.jpg');
        leather.wrapS = leather.wrapT = THREE.RepeatWrapping;
        leather.repeat.set(3.2, 2.25);
        if (THREE.SRGBColorSpace) leather.colorSpace = THREE.SRGBColorSpace;

        const leatherBump = loader.load('./assets/texture/leather_dark_bump.jpg');
        leatherBump.wrapS = leatherBump.wrapT = THREE.RepeatWrapping;
        leatherBump.repeat.copy(leather.repeat);

        const modelBox = new THREE.Box3().setFromObject(model);
        const modelSize = new THREE.Vector3();
        modelBox.getSize(modelSize);
        model.traverse((obj) => {
          if (!obj.isMesh) return;
          obj.frustumCulled = false;
          obj.castShadow = false;
          obj.receiveShadow = false;
          const meshBox = new THREE.Box3().setFromObject(obj);
          const meshSize = new THREE.Vector3();
          const meshCenter = new THREE.Vector3();
          meshBox.getSize(meshSize);
          meshBox.getCenter(meshCenter);
          const thinTopCap = meshSize.y < modelSize.y * 0.08 && meshCenter.y > modelBox.max.y - modelSize.y * 0.10;
          if (thinTopCap) {
            obj.visible = false;
            return;
          }
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          mats.forEach((mat) => {
            if (!mat) return;
            mat.transparent = false;
            mat.opacity = 1;
            mat.depthWrite = true;
            mat.side = THREE.DoubleSide;
            mat.map = leather;
            if ('normalMap' in mat) {
              mat.normalMap = leatherBump;
              if (mat.normalScale) mat.normalScale.set(0.7, 0.7);
            } else if ('bumpMap' in mat) {
              mat.bumpMap = leatherBump;
              mat.bumpScale = 0.05;
            }
            if (mat.metalness !== undefined) mat.metalness = 0.04;
            if (mat.roughness !== undefined) mat.roughness = 0.97;
            mat.color = new THREE.Color('#c7c9cf');
            mat.needsUpdate = true;
          });
        });

        const bbox = new THREE.Box3().setFromObject(model);
        const size = new THREE.Vector3();
        bbox.getSize(size);
        const sourceWidth = Math.max(size.x, size.z) || 1;
        const targetWidth = 1.72;
        const scale = targetWidth / sourceWidth;
        model.scale.setScalar(scale);
        model.updateMatrixWorld(true);

        const bbox2 = new THREE.Box3().setFromObject(model);
        const center2 = new THREE.Vector3();
        bbox2.getCenter(center2);
        model.position.x -= center2.x;
        model.position.z -= center2.z;
        model.position.y -= bbox2.min.y + 0.055;
        model.updateMatrixWorld(true);

        const bbox3 = new THREE.Box3().setFromObject(model);
        const size3 = new THREE.Vector3();
        bbox3.getSize(size3);
        const feltY = bbox3.max.y - 0.105;

        const felt = document.getElementById('feltTop');
        if (felt) {
          felt.setAttribute('visible', true);
          felt.setAttribute('width', Math.max(0.88, size3.x * 0.60));
          felt.setAttribute('height', Math.max(0.42, size3.z * 0.34));
          felt.setAttribute('position', { x: 0, y: feltY, z: 0 });
          const applyFeltMaterial = () => {
            const mesh = felt.getObject3D('mesh');
            if (!mesh) return;
            const feltMap = loader.load('./assets/texture/tablefelt.png');
            if (THREE.SRGBColorSpace) feltMap.colorSpace = THREE.SRGBColorSpace;
            mesh.material = new THREE.MeshStandardMaterial({
              map: feltMap,
              roughness: 0.99,
              metalness: 0.0,
              side: THREE.DoubleSide,
              color: new THREE.Color('#ffffff')
            });
            mesh.renderOrder = 4;
          };
          if (felt.getObject3D('mesh')) applyFeltMaterial();
          else felt.addEventListener('loaded', applyFeltMaterial, { once: true });
        }

        const rig = document.getElementById('rig');
        if (rig) rig.object3D.position.set(0, 0, bbox3.max.z + 1.12);
        const camera = document.getElementById('camera');
        if (camera) camera.setAttribute('position', { x: 0, y: 1.14, z: 0 });
        const dealerAnchor = document.getElementById('dealerAnchor');
        if (dealerAnchor) dealerAnchor.setAttribute('position', { x: 0, y: 0, z: bbox3.min.z - 0.12 });
      });
    }
  });

  AFRAME.registerComponent('phase106-dealer-loader', {
    init: function () {
      const THREE = window.THREE;
      if (!THREE || !THREE.FBXLoader) return;
      const el = this.el;
      const texLoader = new THREE.TextureLoader();
      const diffuse = texLoader.load('./assets/eric-diffuse.webp');
      if (THREE.SRGBColorSpace) diffuse.colorSpace = THREE.SRGBColorSpace;
      const loader = new THREE.FBXLoader();
      loader.load('./assets/eric.fbx', (fbx) => {
        fbx.traverse((obj) => {
          if (!obj.isMesh) return;
          obj.frustumCulled = false;
          obj.castShadow = false;
          obj.receiveShadow = false;
          obj.material = new THREE.MeshStandardMaterial({
            map: diffuse,
            roughness: 0.85,
            metalness: 0.02,
            side: THREE.DoubleSide,
            color: new THREE.Color('#ffffff')
          });
        });
        const bbox = new THREE.Box3().setFromObject(fbx);
        const size = new THREE.Vector3();
        bbox.getSize(size);
        const targetHeight = 1.78;
        const scale = targetHeight / Math.max(size.y, 0.001);
        fbx.scale.setScalar(scale);
        fbx.updateMatrixWorld(true);
        const bbox2 = new THREE.Box3().setFromObject(fbx);
        const center = new THREE.Vector3();
        bbox2.getCenter(center);
        fbx.position.x -= center.x;
        fbx.position.z -= center.z;
        fbx.position.y -= bbox2.min.y;
        fbx.rotation.y = Math.PI;
        el.setObject3D('mesh', fbx);
      });
    }
  });

  AFRAME.registerComponent('phase108-seat-markers', {
    init: function () {
      const root = this.el;
      const seats = [
        { x: 0, z: 1.28, r: '0 180 0' },
        { x: -1.28, z: 0, r: '0 90 0' },
        { x: 1.28, z: 0, r: '0 -90 0' },
        { x: -0.92, z: -1.02, r: '0 35 0' },
        { x: 0.92, z: -1.02, r: '0 -35 0' }
      ];
      seats.forEach((s) => {
        const marker = document.createElement('a-cylinder');
        marker.setAttribute('position', { x: s.x, y: 0.02, z: s.z });
        marker.setAttribute('radius', 0.18);
        marker.setAttribute('height', 0.04);
        marker.setAttribute('rotation', s.r);
        marker.setAttribute('color', '#5e4aa8');
        marker.setAttribute('material', 'metalness: 0.02; roughness: 0.95; emissive: #26164a; emissiveIntensity: 0.25');
        root.appendChild(marker);
      });
    }
  });

})();
