AFRAME.registerComponent('watch-ui', {
  init: function () {
    const watch = document.createElement('a-plane');
    watch.setAttribute('width', 0.2);
    watch.setAttribute('height', 0.1);
    watch.setAttribute('material', 'color: #222; opacity: 0.8');
    watch.setAttribute('position', '0 0 -0.15');
    watch.setAttribute('rotation', '-90 0 0');

    const text = document.createElement('a-text');
    text.setAttribute('value', 'SVR Watch\\nTeleport: OFF');
    text.setAttribute('color', '#fff');
    text.setAttribute('align', 'center');
    text.setAttribute('position', '0 0 0.01');
    text.setAttribute('scale', '0.1 0.1 0.1');

    watch.appendChild(text);
    this.el.appendChild(watch);

    this.teleportEnabled = false;
    window.addEventListener('keypress', (e) => {
      if (e.key === 't' || e.key === 'T') {
        this.teleportEnabled = !this.teleportEnabled;
        text.setAttribute('value', 'SVR Watch\\nTeleport: ' + (this.teleportEnabled ? 'ON' : 'OFF'));
      }
    });
  }
});
