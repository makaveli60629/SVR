AFRAME.registerComponent('teleport-controls', {
  init: function () {
    const player = document.getElementById('player');
    this.teleportEnabled = false;
    // Toggle teleport mode with 'T'
    window.addEventListener('keypress', (e) => {
      if (e.key === 't' || e.key === 'T') {
        this.teleportEnabled = !this.teleportEnabled;
      }
      // If teleport mode enabled and space pressed, move forward 1 meter
      if (this.teleportEnabled && (e.key === ' ' || e.code === 'Space')) {
        const pos = player.getAttribute('position');
        pos.z -= 1;
        player.setAttribute('position', pos);
      }
    });
  }
});
