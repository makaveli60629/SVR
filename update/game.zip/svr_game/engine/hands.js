AFRAME.registerComponent('hand-controller', {
  init: function () {
    console.log('Hand controller initialized');
  }
});
