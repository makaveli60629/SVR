Flat-root game zip for update/game.zip. Root contains index.html and assets/ so the GitHub Pages flatten step copies directly into build/game. Visible build marker: 20260314-P46-FLAT.
