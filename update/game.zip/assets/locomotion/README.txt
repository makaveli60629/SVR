Put FBX/GLB + textures here. Paths should match world_skyline.js candidates.
