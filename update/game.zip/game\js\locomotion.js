console.log("locomotion active"); 
