/**
 * Determine which players are still active (have not folded and still have chips).
 */
export function getActivePlayers(players) {
  return players.filter((p) => !p.folded && p.chips >= 0);
}

/**
 * Determine the legal actions for a player given the current bet to match.
 */
export function getLegalActions(player, state) {
  if (player.folded || player.allIn) {
    return [];
  }
  const toCall = Math.max(0, state.currentBetToMatch - player.currentBet);
  if (toCall === 0) {
    return ['check', 'bet', 'all-in', 'fold'];
  }
  if (player.chips <= toCall) {
    return ['fold', 'all-in'];
  }
  return ['fold', 'call', 'raise', 'all-in'];
}

/**
 * Apply a player action to the game state. This function performs basic checks and updates
 * the player's chips, current bet, total committed, and the state's current bet to match.
 */
export function applyAction(state, playerId, action, amount = 0) {
  const players = state.players.map((p) => ({ ...p }));
  const playerIndex = players.findIndex((p) => p.id === playerId);
  if (playerIndex === -1) {
    throw new Error('Player not found');
  }
  const player = players[playerIndex];
  const toCall = Math.max(0, state.currentBetToMatch - player.currentBet);
  switch (action) {
    case 'fold':
      player.folded = true;
      player.hasActed = true;
      break;
    case 'check':
      if (toCall !== 0) {
        throw new Error('Cannot check when facing a bet');
      }
      player.hasActed = true;
      break;
    case 'call': {
      if (toCall <= 0) {
        throw new Error('Nothing to call');
      }
      if (player.chips < toCall) {
        throw new Error('Not enough chips to call');
      }
      player.chips -= toCall;
      player.currentBet += toCall;
      player.totalCommitted += toCall;
      player.hasActed = true;
      break;
    }
    case 'bet':
    case 'raise': {
      if (amount <= toCall) {
        throw new Error('Raise amount must exceed call amount');
      }
      if (player.chips < amount) {
        throw new Error('Not enough chips to bet/raise');
      }
      player.chips -= amount;
      player.currentBet += amount;
      player.totalCommitted += amount;
      player.hasActed = true;
      // Raise the current bet to match for everyone
      state.currentBetToMatch = player.currentBet;
      break;
    }
    case 'all-in': {
      const shove = player.chips;
      player.currentBet += shove;
      player.totalCommitted += shove;
      player.chips = 0;
      player.allIn = true;
      player.hasActed = true;
      if (player.currentBet > state.currentBetToMatch) {
        state.currentBetToMatch = player.currentBet;
      }
      break;
    }
    default:
      throw new Error(`Unknown action: ${action}`);
  }
  // Update pot (sum of all committed chips)
  const pot = players.reduce((sum, p) => sum + p.totalCommitted, 0);
  return {
    ...state,
    players,
    pot,
    actionLog: [...state.actionLog, { type: 'PLAYERACTION', playerId, action, amount }],
  };
}

/**
 * Reset all players' currentBet values and hasActed flags for the next betting street.
 */
export function resetBetsForNextStreet(state) {
  return {
    ...state,
    currentBetToMatch: 0,
    players: state.players.map((p) => ({
      ...p,
      currentBet: 0,
      hasActed: false,
    })),
  };
}