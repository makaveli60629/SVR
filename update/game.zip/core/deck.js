export const SUITS = ['hearts', 'diamonds', 'clubs', 'spades'];
export const RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

/**
 * Create a fresh deck of 52 cards. Each card is an object with rank, suit and a code.
 */
export function createDeck() {
  const deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({
        rank,
        suit,
        // Use the first letter of the suit (uppercase) as a code suffix
        code: `${rank}${suit[0].toUpperCase()}`,
      });
    }
  }
  return deck;
}

/**
 * Shuffle a deck using Fisher–Yates algorithm. Accepts an optional random function.
 * Returns a new array so the input deck is not mutated.
 */
export function shuffleDeck(inputDeck, rng = Math.random) {
  const deck = [...inputDeck];
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

/**
 * Draw `count` cards from the top of the deck. Returns an object with the drawn cards
 * and the remaining deck. Does not mutate the input deck.
 */
export function drawCards(deck, count = 1) {
  if (!Array.isArray(deck)) {
    throw new Error('drawCards expected an array');
  }
  if (count < 1) {
    return { drawn: [], deck: [...deck] };
  }
  if (deck.length < count) {
    throw new Error('Not enough cards in deck');
  }
  const drawn = deck.slice(0, count);
  const rest = deck.slice(count);
  return { drawn, deck: rest };
}