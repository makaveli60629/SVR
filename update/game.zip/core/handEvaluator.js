// Assign numeric values to each rank for scoring hands. Higher ranks get higher values.
const RANK_VALUE = {
  '2': 2,
  '3': 3,
  '4': 4,
  '5': 5,
  '6': 6,
  '7': 7,
  '8': 8,
  '9': 9,
  '10': 10,
  J: 11,
  Q: 12,
  K: 13,
  A: 14,
};

/**
 * Score a five‑card hand. This implementation only distinguishes high card hands and
 * uses a base‑15 positional system to encode the ranks. Hands with higher ranks
 * produce higher scores. For a complete game you would expand this to include
 * pairs, two pairs, straights, flushes, etc.
 */
export function scoreFiveCardHand(cards) {
  if (!Array.isArray(cards) || cards.length !== 5) {
    throw new Error('scoreFiveCardHand expects exactly 5 cards');
  }
  // Convert ranks to numeric values and sort descending
  const values = cards.map((c) => RANK_VALUE[c.rank]).sort((a, b) => b - a);
  // Compute a base-15 score to order high‑card hands. Each card contributes
  // value * 15^(4-index). The base (15) is > highest rank (14) to ensure
  // lexicographic ordering.
  const score = values.reduce((acc, val, idx) => acc + val * Math.pow(15, 4 - idx), 0);
  return {
    category: 'high-card',
    score,
    ranks: values,
  };
}

/**
 * Evaluate the best five‑card hand from seven cards. Returns the best scoring hand
 * along with its score and the cards making up that hand.
 */
export function evaluateBestHand(sevenCards) {
  if (!Array.isArray(sevenCards) || sevenCards.length < 5) {
    throw new Error('evaluateBestHand expects at least 5 cards');
  }
  let best = null;
  // Iterate over all 5‑card combinations out of the seven cards
  for (let a = 0; a < sevenCards.length - 4; a++) {
    for (let b = a + 1; b < sevenCards.length - 3; b++) {
      for (let c = b + 1; c < sevenCards.length - 2; c++) {
        for (let d = c + 1; d < sevenCards.length - 1; d++) {
          for (let e = d + 1; e < sevenCards.length; e++) {
            const hand = [sevenCards[a], sevenCards[b], sevenCards[c], sevenCards[d], sevenCards[e]];
            const scored = scoreFiveCardHand(hand);
            if (!best || scored.score > best.score) {
              best = { ...scored, cards: hand };
            }
          }
        }
      }
    }
  }
  return best;
}