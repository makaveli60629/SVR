import { createDeck, shuffleDeck, drawCards } from './deck.js';

/**
 * Create a new player object.
 * @param {string} id Unique player identifier
 * @param {string} name Player display name
 * @param {number} chips Starting chip count
 */
export function createPlayer(id, name, chips = 1000) {
  return {
    id,
    name,
    chips,
    cards: [],
    folded: false,
    allIn: false,
    currentBet: 0,
    totalCommitted: 0,
    hasActed: false,
  };
}

/**
 * Initialize an empty table state with players and config options.
 */
export function createTableState(players = [], config = {}) {
  return {
    players,
    dealerIndex: 0,
    smallBlind: config.smallBlind ?? 10,
    bigBlind: config.bigBlind ?? 20,
    pot: 0,
    sidePots: [],
    board: [],
    burn: [],
    deck: [],
    phase: 'waiting',
    currentPlayerIndex: 0,
    currentBetToMatch: 0,
    handNumber: 0,
    actionLog: [],
  };
}

/**
 * Start a new hand: shuffle a fresh deck, deal two cards to each player and reset bets.
 */
export function startHand(state) {
  // Create and shuffle a new deck
  let deck = shuffleDeck(createDeck());
  // Reset players for a new hand
  const players = state.players.map((p) => ({
    ...p,
    cards: [],
    folded: false,
    allIn: false,
    currentBet: 0,
    totalCommitted: 0,
    hasActed: false,
  }));
  // Deal two cards to each player
  for (let round = 0; round < 2; round++) {
    for (let i = 0; i < players.length; i++) {
      const draw = drawCards(deck, 1);
      players[i].cards.push(draw.drawn[0]);
      deck = draw.deck;
    }
  }
  return {
    ...state,
    players,
    deck,
    pot: 0,
    sidePots: [],
    board: [],
    burn: [],
    phase: 'preflop',
    currentBetToMatch: 0,
    handNumber: state.handNumber + 1,
    actionLog: [...state.actionLog, { type: 'STARTHAND', handNumber: state.handNumber + 1 }],
  };
}

/**
 * Deal community cards for a specific street (flop, turn, or river).
 * Burn one card before dealing. For the flop, deal three cards; otherwise one card.
 */
export function dealBoardCards(state, street) {
  if (!state.deck || state.deck.length === 0) {
    throw new Error('No deck in state');
  }
  let deck = [...state.deck];
  // Burn one card
  const burnResult = drawCards(deck, 1);
  const burnCard = burnResult.drawn[0];
  deck = burnResult.deck;
  // Determine how many cards to deal this street
  const count = street === 'flop' ? 3 : 1;
  const boardResult = drawCards(deck, count);
  return {
    ...state,
    deck: boardResult.deck,
    burn: [...state.burn, burnCard],
    board: [...state.board, ...boardResult.drawn],
    phase: street,
    actionLog: [...state.actionLog, { type: 'DEALBOARD', street, cards: boardResult.drawn }],
  };
}