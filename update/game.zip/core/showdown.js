import { evaluateBestHand } from './handEvaluator.js';

/**
 * Resolve a showdown: evaluate the best hand for each contender and determine
 * the winner(s). Returns an object with an array of winners and the ranked
 * list of all contenders in descending order of hand strength.
 */
export function resolveShowdown(state) {
  // Only players who have not folded participate in the showdown
  const contenders = state.players.filter((p) => !p.folded);
  if (contenders.length === 0) {
    throw new Error('No contenders in showdown');
  }
  // Evaluate each player's best hand
  const ranked = contenders.map((player) => {
    const best = evaluateBestHand([...player.cards, ...state.board]);
    return {
      id: player.id,
      name: player.name,
      result: best,
    };
  });
  // Sort by descending score
  ranked.sort((a, b) => b.result.score - a.result.score);
  const topScore = ranked[0].result.score;
  const winners = ranked.filter((r) => r.result.score === topScore);
  return {
    winners,
    ranked,
  };
}