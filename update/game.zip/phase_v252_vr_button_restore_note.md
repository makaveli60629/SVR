SVR v2.5.2 stable restore
- kept the working lobby-aligned scene from v243
- restored a real on-page VR button using WebXR session requests
- kept lobby music toggle on M key
- slightly improved scene visibility while preserving the darker mood
