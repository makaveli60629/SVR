SVR Poker Game Phase 47

Flat-root deploy package.
Drop this zip in update/game.zip.
This phase keeps the stable rescue boot path and restores a richer training room with seat-snap movement, skyline window, chips/cards, and cleaner lighting.
