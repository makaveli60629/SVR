Fixed VR button creation for classic three.js build by using THREE.VRButton instead of window.VRButton. Updated build label to 20260319-v263.
