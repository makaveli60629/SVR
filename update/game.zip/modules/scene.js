
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160/build/three.module.js";

export function createScene(){

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const light = new THREE.HemisphereLight(0xffffff,0x444444,1);
scene.add(light);

return scene;

}
