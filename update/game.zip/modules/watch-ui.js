AFRAME.registerComponent('watch-ui',{
  schema:{side:{default:'right'}},
  init:function(){
    const y=this.data.side==='left'?12:-12,w=document.createElement('a-entity');
    w.setAttribute('position',this.data.side==='left'?'-.055 -.035 -.03':'.055 -.035 -.03'); w.setAttribute('rotation',`-8 ${y} 0`);
    w.innerHTML='<a-box width=".25" height=".035" depth=".17" material="color:#09040f; roughness:.35; metalness:.25"></a-box><a-plane width=".22" height=".105" position="0 .021 -.001" rotation="-90 0 0" material="src:#watchCanvas; transparent:false; emissive:#7a33ff; emissiveIntensity:.22"></a-plane><a-torus radius=".14" radius-tubular=".007" rotation="90 0 0" material="color:#7d33ff; emissive:#7d33ff; emissiveIntensity:.45"></a-torus>';
    this.el.appendChild(w);
  }
});