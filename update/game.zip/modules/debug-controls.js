AFRAME.registerComponent('debug-controls',{
  init:function(){
    window.SVR_DEBUG={version:'PHASE_3_MODULAR_RECOVERY',scene:this.el,rig:()=>document.getElementById('rig')};
    console.log('[SVR] Phase 3 modular recovery loaded.');
  }
});