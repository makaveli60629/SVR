AFRAME.registerComponent('performance-core',{
  init:function(){
    const scene=this.el;
    scene.addEventListener('render-target-loaded',()=>{
      const r=scene.renderer;
      if(!r)return;
      r.setClearColor(new THREE.Color('#080012'),1);
      r.setPixelRatio(Math.min(window.devicePixelRatio||1,1.15));
      r.shadowMap.enabled=false;
      r.sortObjects=true;
      r.autoClear=true;
      if(r.info) r.info.autoReset=true;
    });
    let pending=false;
    window.addEventListener('resize',()=>{
      if(pending)return;
      pending=true;
      requestAnimationFrame(()=>{
        pending=false;
        const r=scene.renderer,c=scene.camera;
        if(r&&c){r.setSize(window.innerWidth,window.innerHeight,false);c.aspect=window.innerWidth/window.innerHeight;c.updateProjectionMatrix();}
      });
    },{passive:true});
  }
});