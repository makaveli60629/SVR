AFRAME.registerComponent('texture-factory',{
  init:function(){
    this.felt(); this.moon(); this.mars(); this.logo(); this.watch(); this.wall();
  },
  felt:function(){
    const c=document.getElementById('feltCanvas'); if(!c)return; const x=c.getContext('2d');
    const g=x.createRadialGradient(512,512,70,512,512,650);
    g.addColorStop(0,'#241044'); g.addColorStop(.55,'#130823'); g.addColorStop(1,'#07020e');
    x.fillStyle=g; x.fillRect(0,0,1024,1024);
    x.strokeStyle='rgba(190,120,255,.38)'; x.lineWidth=18; x.beginPath(); x.ellipse(512,512,410,255,0,0,Math.PI*2); x.stroke();
    x.strokeStyle='rgba(100,215,255,.18)'; x.lineWidth=8; x.beginPath(); x.ellipse(512,512,330,190,0,0,Math.PI*2); x.stroke();
    x.fillStyle='rgba(255,255,255,.08)'; x.font='bold 82px Arial'; x.textAlign='center'; x.fillText('SVR POKER',512,545);
    for(let i=0;i<9000;i++){x.fillStyle=Math.random()>.5?'rgba(255,255,255,.018)':'rgba(0,0,0,.035)';x.fillRect(Math.random()*1024,Math.random()*1024,1,1);}
  },
  moon:function(){
    const c=document.getElementById('moonCanvas'); if(!c)return; const x=c.getContext('2d'),g=x.createRadialGradient(210,170,20,256,256,290);
    g.addColorStop(0,'#f4ecff'); g.addColorStop(.55,'#b7a6d8'); g.addColorStop(1,'#51466d'); x.fillStyle=g; x.fillRect(0,0,512,512);
    for(let i=0;i<95;i++){x.beginPath();x.fillStyle=`rgba(40,30,60,${.05+Math.random()*.18})`;x.arc(Math.random()*512,Math.random()*512,5+Math.random()*34,0,Math.PI*2);x.fill();}
  },
  mars:function(){
    const c=document.getElementById('marsCanvas'); if(!c)return; const x=c.getContext('2d'),g=x.createRadialGradient(210,160,20,256,256,290);
    g.addColorStop(0,'#ffb27a'); g.addColorStop(.55,'#9b321e'); g.addColorStop(1,'#35100c'); x.fillStyle=g; x.fillRect(0,0,512,512);
    for(let i=0;i<60;i++){x.beginPath();x.fillStyle=`rgba(80,20,10,${.08+Math.random()*.20})`;x.ellipse(Math.random()*512,Math.random()*512,20+Math.random()*55,4+Math.random()*18,Math.random()*Math.PI,0,Math.PI*2);x.fill();}
  },
  logo:function(){
    const c=document.getElementById('logoFloorCanvas'); if(!c)return; const x=c.getContext('2d'); x.clearRect(0,0,512,512);
    const g=x.createRadialGradient(256,256,10,256,256,240); g.addColorStop(0,'rgba(210,150,255,.72)'); g.addColorStop(.55,'rgba(110,35,210,.42)'); g.addColorStop(1,'rgba(30,0,60,0)');
    x.fillStyle=g; x.fillRect(0,0,512,512); x.beginPath(); x.arc(256,256,212,0,Math.PI*2); x.fillStyle='rgba(98,26,180,.28)'; x.fill();
    x.lineWidth=20; x.strokeStyle='rgba(220,160,255,.95)'; x.stroke(); x.lineWidth=8; x.strokeStyle='rgba(100,230,255,.70)'; x.beginPath(); x.arc(256,256,164,0,Math.PI*2); x.stroke();
    x.font='bold 92px Arial'; x.textAlign='center'; x.textBaseline='middle'; x.fillStyle='rgba(245,235,255,.98)'; x.fillText('SVR',256,224); x.font='bold 54px Arial'; x.fillText('POKER',256,304);
  },
  watch:function(){
    const c=document.getElementById('watchCanvas'); if(!c)return; const x=c.getContext('2d');
    x.fillStyle='#080010'; x.fillRect(0,0,512,256); x.strokeStyle='#bc75ff'; x.lineWidth=8; x.strokeRect(10,10,492,236);
    x.fillStyle='#e8dcff'; x.font='bold 34px Arial'; x.fillText('SVR WATCH',34,62); x.fillStyle='#caa6ff'; x.font='24px Arial';
    x.fillText('GRIP/FIST: TELEPORT ON/OFF',34,114); x.fillText('TRIGGER RELEASE: JUMP',34,154); x.fillStyle='#7fffdc'; x.fillText('STATUS: READY',34,205);
  },
  wall:function(){
    const c=document.getElementById('wallCanvas'); if(!c)return; const x=c.getContext('2d');
    const g=x.createLinearGradient(0,0,1024,512); g.addColorStop(0,'#0d031a'); g.addColorStop(.5,'#1c0832'); g.addColorStop(1,'#07020e'); x.fillStyle=g; x.fillRect(0,0,1024,512);
    for(let i=0;i<60;i++){x.strokeStyle=i%2?'rgba(160,80,255,.18)':'rgba(90,220,255,.12)';x.beginPath();x.moveTo(Math.random()*1024,Math.random()*512);x.lineTo(Math.random()*1024,Math.random()*512);x.stroke();}
  }
});