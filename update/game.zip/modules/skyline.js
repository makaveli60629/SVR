AFRAME.registerComponent('skyline',{init:function(){
for(let i=0;i<120;i++){
let b=document.createElement('a-box');
let x=(Math.random()*200)-100;
let z=(Math.random()*-200)-20;
let h=(Math.random()*60)+10;
b.setAttribute('position',x+" "+(h/2)+" "+z);
b.setAttribute('height',h);
b.setAttribute('width',Math.random()*6+4);
b.setAttribute('depth',Math.random()*6+4);
b.setAttribute('color','#1a1a1a');
this.el.appendChild(b);}}});