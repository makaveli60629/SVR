
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160/build/three.module.js";

export function createSky(scene){

const geometry = new THREE.SphereGeometry(100,32,32);
const material = new THREE.MeshBasicMaterial({
color:0x000011,
side:THREE.BackSide
});

const sky = new THREE.Mesh(geometry,material);

scene.add(sky);

}
