AFRAME.registerComponent('scene-health',{
  init:function(){
    const overlay=document.getElementById('bootOverlay');
    const done=()=>{if(!overlay)return;overlay.querySelector('span').textContent='Loaded. Test /game/ only. Phase 3 lobby recovery is active.';setTimeout(()=>{overlay.style.opacity='0';overlay.style.transition='opacity .6s ease';},2200);setTimeout(()=>{overlay.style.display='none';},3000);};
    this.el.addEventListener('loaded',done);
    this.el.addEventListener('enter-vr',()=>{const h=document.getElementById('desktopHelp'); if(h)h.style.display='none';});
    this.el.addEventListener('exit-vr',()=>{const h=document.getElementById('desktopHelp'); if(h)h.style.display='';});
    window.addEventListener('error',e=>{if(!overlay)return; overlay.style.display='block'; overlay.style.opacity='1'; overlay.querySelector('span').textContent='Recovered from script error: '+(e.message||'unknown');});
  }
});