/* SVR Phase 2 hand/controller visual refinement.
   Goal: hands/controllers stay usable but no longer look like odd pills.
*/
AFRAME.registerComponent('hand-controller-rig',{
  init:function(){
    ['leftHand','rightHand'].forEach((id)=>{
      const h=document.getElementById(id);
      if(!h)return;

      const glove=document.createElement('a-entity');
      glove.setAttribute('id', id + '_svrGlove');
      glove.setAttribute('position','0 0 0');
      glove.innerHTML = `
        <a-box width=".095" height=".045" depth=".13" position="0 0 -.018"
          material="color:#1a0b2c; emissive:#50158a; emissiveIntensity:.32; roughness:.45"></a-box>
        <a-sphere radius=".045" position="0 .002 -.09"
          material="color:#d4b3ff; emissive:#7a29d8; emissiveIntensity:.26; roughness:.38"></a-sphere>
        <a-cylinder radius=".010" height=".115" position="-.045 .012 -.155" rotation="72 0 0"
          material="color:#d7b8ff; emissive:#6f25c8; emissiveIntensity:.22"></a-cylinder>
        <a-cylinder radius=".010" height=".125" position="-.018 .018 -.165" rotation="72 0 0"
          material="color:#d7b8ff; emissive:#6f25c8; emissiveIntensity:.22"></a-cylinder>
        <a-cylinder radius=".010" height=".125" position=".018 .018 -.165" rotation="72 0 0"
          material="color:#d7b8ff; emissive:#6f25c8; emissiveIntensity:.22"></a-cylinder>
        <a-cylinder radius=".010" height=".110" position=".045 .012 -.155" rotation="72 0 0"
          material="color:#d7b8ff; emissive:#6f25c8; emissiveIntensity:.22"></a-cylinder>
        <a-torus radius=".092" radius-tubular=".004" position="0 -.002 .038" rotation="90 0 0"
          material="color:#8d3cff; emissive:#8d3cff; emissiveIntensity:.55; transparent:true; opacity:.72"></a-torus>
      `;
      h.appendChild(glove);

      h.addEventListener('controllerconnected',()=>h.setAttribute('visible',true));
      h.addEventListener('hand-tracking-controls-ready',()=>h.setAttribute('visible',true));
    });
  }
});
