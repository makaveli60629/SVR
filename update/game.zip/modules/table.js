
import { GLTFLoader } from "https://cdn.jsdelivr.net/npm/three@0.160/examples/jsm/loaders/GLTFLoader.js";

export function loadTable(scene){

const loader = new GLTFLoader();

loader.load("./assets/models/table.glb",(gltf)=>{

const table = gltf.scene;

table.scale.set(0.8,0.8,0.8);
table.position.set(0,0,-3);

scene.add(table);

});

}
