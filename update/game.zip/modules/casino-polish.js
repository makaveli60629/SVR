/* SVR Phase 2 casino polish: chips + dealer label. */
AFRAME.registerComponent('casino-polish',{
  init:function(){
    setTimeout(()=>{
      const root=document.getElementById('pokerTable');
      if(!root)return;
      const colors=['#d44','#44d','#ddd','#151515','#d7a7ff'];
      for(let i=0;i<18;i++){
        const chip=document.createElement('a-cylinder');
        chip.setAttribute('radius','.055');
        chip.setAttribute('height','.025');
        chip.setAttribute('segments-radial','24');
        chip.setAttribute('position',`${-1.1+(i%6)*.12} ${.98+Math.floor(i/6)*.028} ${.38+Math.floor(i/6)*.09}`);
        chip.setAttribute('rotation','90 0 0');
        chip.setAttribute('material',`color:${colors[i%colors.length]}; roughness:.42; metalness:.08`);
        root.appendChild(chip);
      }
      const dealer=document.createElement('a-text');
      dealer.setAttribute('value','DEALER');
      dealer.setAttribute('align','center');
      dealer.setAttribute('width','1.6');
      dealer.setAttribute('position','0 .99 -.68');
      dealer.setAttribute('rotation','-90 0 0');
      dealer.setAttribute('material','color:#e8dcff; emissive:#7d33ff; emissiveIntensity:.35');
      root.appendChild(dealer);
    },600);
  }
});
