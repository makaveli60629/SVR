import * as THREE from "three";
import { XRHandModelFactory } from "three/addons/webxr/XRHandModelFactory.js";

function makeProxyJoint(name){
  const obj = new THREE.Object3D();
  obj.name = name;
  return obj;
}

function makeFingerSegment(radius, length, color){
  const mat = new THREE.MeshStandardMaterial({
    color,
    roughness: 0.6,
    metalness: 0.05,
    emissive: 0x0d1020,
    emissiveIntensity: 0.08
  });
  const seg = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 4, 8), mat);
  seg.castShadow = true;
  seg.receiveShadow = true;
  return seg;
}

function makeControllerHandVisual(color = 0xd3deff){
  const root = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({
    color,
    roughness: 0.68,
    metalness: 0.04,
    emissive: 0x10182a,
    emissiveIntensity: 0.08
  });
  const palm = new THREE.Mesh(new THREE.SphereGeometry(0.032, 14, 14), skin);
  palm.scale.set(1.0, 0.62, 1.22);
  palm.position.set(0, -0.004, 0.02);
  palm.castShadow = true;
  palm.receiveShadow = true;
  root.add(palm);

  const heel = new THREE.Mesh(new THREE.SphereGeometry(0.022, 12, 12), skin);
  heel.scale.set(1.1, 0.7, 0.95);
  heel.position.set(0, -0.01, -0.002);
  heel.castShadow = true;
  heel.receiveShadow = true;
  root.add(heel);

  const fingerXs = [-0.018, -0.006, 0.006, 0.018];
  fingerXs.forEach((x, i)=>{
    const len = 0.022 + i * 0.002;
    const seg1 = makeFingerSegment(0.0055, len, color);
    seg1.rotation.x = Math.PI * 0.5;
    seg1.position.set(x, 0.002, 0.056 + i * 0.002);
    root.add(seg1);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.0062, 10, 10), skin);
    tip.position.set(x, 0.002, 0.072 + i * 0.004);
    tip.castShadow = true;
    tip.receiveShadow = true;
    root.add(tip);
  });

  const thumb = makeFingerSegment(0.0065, 0.026, color);
  thumb.rotation.set(Math.PI * 0.12, 0, -Math.PI * 0.72);
  thumb.position.set(0.026, -0.008, 0.016);
  root.add(thumb);

  const thumbTip = new THREE.Mesh(new THREE.SphereGeometry(0.0068, 10, 10), skin);
  thumbTip.position.set(0.035, -0.01, 0.034);
  thumbTip.castShadow = true;
  thumbTip.receiveShadow = true;
  root.add(thumbTip);

  return root;
}

function makeControllerProxy(controller, handed = "right"){
  const proxy = new THREE.Group();
  proxy.userData.controller = controller;
  proxy.userData.handedness = handed;
  proxy.joints = {
    wrist: makeProxyJoint("wrist"),
    "thumb-tip": makeProxyJoint("thumb-tip"),
    "index-finger-tip": makeProxyJoint("index-finger-tip"),
    "middle-finger-tip": makeProxyJoint("middle-finger-tip"),
    "ring-finger-tip": makeProxyJoint("ring-finger-tip"),
    "pinky-finger-tip": makeProxyJoint("pinky-finger-tip")
  };
  Object.values(proxy.joints).forEach(j=>proxy.add(j));
  return proxy;
}

function updateControllerProxy(proxy){
  const controller = proxy?.userData?.controller;
  if (!controller) return;
  controller.updateWorldMatrix(true, false);
  controller.getWorldPosition(proxy.position);
  controller.getWorldQuaternion(proxy.quaternion);

  const gp = controller.inputSource?.gamepad;
  const trigger = gp?.buttons?.[0]?.value || 0;
  const squeeze = gp?.buttons?.[1]?.value || 0;
  const side = proxy.userData.handedness === "left" ? -1 : 1;
  const curl = THREE.MathUtils.lerp(0, 1, Math.max(trigger, squeeze));
  const fist = squeeze > 0.35;

  proxy.userData.trigger = trigger;
  proxy.userData.squeeze = squeeze;

  const wrist = proxy.joints.wrist;
  wrist.position.set(0, 0, 0);

  const thumb = proxy.joints["thumb-tip"];
  const index = proxy.joints["index-finger-tip"];
  const middle = proxy.joints["middle-finger-tip"];
  const ring = proxy.joints["ring-finger-tip"];
  const pinky = proxy.joints["pinky-finger-tip"];

  if (fist){
    thumb.position.set(0.016 * side, -0.005, 0.012);
    index.position.set(0.011 * side, -0.001, 0.018);
    middle.position.set(0.003 * side, -0.002, 0.017);
    ring.position.set(-0.006 * side, -0.002, 0.015);
    pinky.position.set(-0.014 * side, -0.002, 0.013);
  } else {
    thumb.position.set(0.026 * side, -0.012, 0.031 - trigger * 0.014);
    index.position.set(0.012 * side, 0.001, 0.074 - curl * 0.034);
    middle.position.set(0.003 * side, 0.001, 0.082 - curl * 0.030);
    ring.position.set(-0.008 * side, 0.0, 0.076 - curl * 0.024);
    pinky.position.set(-0.018 * side, -0.002, 0.068 - curl * 0.02);
  }

  if (trigger > 0.18){
    const pinchZ = 0.038 - trigger * 0.01;
    thumb.position.set(0.015 * side, -0.006, pinchZ);
    index.position.set(0.011 * side, -0.001, pinchZ + 0.004);
  }

  const visual = proxy.userData.visual;
  if (visual){
    visual.rotation.x = -0.18 - squeeze * 0.18;
    visual.rotation.z = side * (0.08 + trigger * 0.05);
    visual.position.set(0, -0.01, 0.04);
  }
}

export function createHands({ scene, renderer, log = console.log }){
  const factory = new XRHandModelFactory();
  const rawHands = [];
  const handDebugGroups = [];
  const controllers = [];
  const controllerProxies = [];
  let leftHand = null;
  let rightHand = null;
  let leftControllerProxy = null;
  let rightControllerProxy = null;
  let debugOn = false;

  function makeDebugGroup(parent){
    const group = new THREE.Group();
    group.visible = false;
    const keys = [
      "wrist", "thumb-tip", "index-finger-tip", "middle-finger-tip",
      "ring-finger-tip", "pinky-finger-tip"
    ];
    for (const key of keys){
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.009, 10, 10),
        new THREE.MeshBasicMaterial({ color: 0xb48cff })
      );
      mesh.userData.jointKey = key;
      group.add(mesh);
    }
    parent.add(group);
    return group;
  }

  for (let i = 0; i < 2; i++){
    const hand = renderer.xr.getHand(i);
    hand.add(factory.createHandModel(hand, "mesh"));
    scene.add(hand);
    rawHands.push(hand);
    handDebugGroups.push(makeDebugGroup(hand));

    hand.addEventListener("connected", (evt)=>{
      const handed = evt?.data?.handedness || "unknown";
      log("Hand connected", i, handed);
      if (handed === "left") leftHand = hand;
      if (handed === "right") rightHand = hand;
    });

    hand.addEventListener("disconnected", ()=>{
      if (leftHand === hand) leftHand = null;
      if (rightHand === hand) rightHand = null;
    });

    const controller = renderer.xr.getController(i);
    scene.add(controller);
    controllers.push(controller);

    controller.addEventListener("connected", (evt)=>{
      const handed = evt?.data?.handedness || evt?.data?.gamepad?.hand || (i === 0 ? "left" : "right");
      const proxy = makeControllerProxy(controller, handed);
      proxy.userData.inputSource = evt?.data || null;
      proxy.userData.visual = null;
      scene.add(proxy);
      const debug = makeDebugGroup(proxy);
      controllerProxies.push({ controller, proxy, debug });
      if (handed === "left") leftControllerProxy = proxy;
      if (handed === "right") rightControllerProxy = proxy;
      log("Controller connected", i, handed);
    });

    controller.addEventListener("disconnected", ()=>{
      const idx = controllerProxies.findIndex(x=>x.controller === controller);
      if (idx >= 0){
        const rec = controllerProxies[idx];
        if (rec.proxy === leftControllerProxy) leftControllerProxy = null;
        if (rec.proxy === rightControllerProxy) rightControllerProxy = null;
        rec.proxy.parent?.remove(rec.proxy);
        if (rec.proxy.userData.visual) controller.remove(rec.proxy.userData.visual);
        controllerProxies.splice(idx, 1);
      }
    });
  }

  function update(dt = 0.016){
    controllerProxies.forEach(({ proxy })=> updateControllerProxy(proxy, dt));
  }

  function updateDebug(){
    const sources = [...rawHands, ...controllerProxies.map(x=>x.proxy)];
    const groups = [...handDebugGroups, ...controllerProxies.map(x=>x.debug)];
    for (let i = 0; i < sources.length; i++){
      const hand = sources[i];
      const group = groups[i];
      if (!group) continue;
      group.visible = debugOn;
      if (!debugOn) continue;
      for (const child of group.children){
        const joint = hand.joints?.[child.userData.jointKey];
        child.visible = !!joint;
        if (joint) joint.getWorldPosition(child.position);
      }
    }
  }

  function toggleDebug(){
    debugOn = !debugOn;
    [...handDebugGroups, ...controllerProxies.map(x=>x.debug)].forEach(group=>{ if (group) group.visible = debugOn; });
    return debugOn;
  }

  return {
    getLeft: ()=> leftHand?.joints ? leftHand : (leftControllerProxy?.joints ? leftControllerProxy : rawHands[0] || null),
    getRight: ()=> rightHand?.joints ? rightHand : (rightControllerProxy?.joints ? rightControllerProxy : rawHands[1] || rawHands[0] || null),
    toggleDebug,
    updateDebug,
    update
  };
}
