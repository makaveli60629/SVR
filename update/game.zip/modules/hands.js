import * as THREE from "three";
import { XRHandModelFactory } from "three/addons/webxr/XRHandModelFactory.js";

export function createHands({ scene, renderer, log = console.log }){
  const factory = new XRHandModelFactory();
  const raw = [];
  const debugGroups = [];
  let left = null;
  let right = null;
  let debugOn = false;

  function makeDebugGroup(hand){
    const group = new THREE.Group();
    group.visible = false;
    const keys = [
      "wrist", "thumb-tip", "index-finger-tip", "middle-finger-tip",
      "ring-finger-tip", "pinky-finger-tip"
    ];
    for (const key of keys){
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.009, 10, 10),
        new THREE.MeshBasicMaterial({ color: 0xb48cff })
      );
      mesh.userData.jointKey = key;
      group.add(mesh);
    }
    hand.add(group);
    return group;
  }

  for (let i = 0; i < 2; i++){
    const hand = renderer.xr.getHand(i);
    hand.add(factory.createHandModel(hand, "mesh"));
    scene.add(hand);
    raw.push(hand);
    debugGroups.push(makeDebugGroup(hand));

    hand.addEventListener("connected", (evt)=>{
      const handed = evt?.data?.handedness || "unknown";
      log("Hand connected", i, handed);
      if (handed === "left") left = hand;
      if (handed === "right") right = hand;
    });

    hand.addEventListener("disconnected", ()=>{
      if (left === hand) left = null;
      if (right === hand) right = null;
    });
  }

  function updateDebug(){
    if (!debugOn) return;
    for (let i = 0; i < raw.length; i++){
      const hand = raw[i];
      const group = debugGroups[i];
      group.visible = true;
      for (const child of group.children){
        const joint = hand.joints?.[child.userData.jointKey];
        child.visible = !!joint;
        if (joint) joint.getWorldPosition(child.position);
      }
    }
  }

  function toggleDebug(){
    debugOn = !debugOn;
    for (const group of debugGroups) group.visible = debugOn;
    return debugOn;
  }

  return {
    getLeft: ()=> left || raw[0] || null,
    getRight: ()=> right || raw[1] || raw[0] || null,
    toggleDebug,
    updateDebug
  };
}
