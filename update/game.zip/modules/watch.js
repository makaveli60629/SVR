import * as THREE from "three";
import { isPinching } from "./gestures.js";

function rr(c, x, y, w, h, r){
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}

export function createWristWatch({ scene, getState = ()=>({}), actions = {} }){
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const group = new THREE.Group();
  group.visible = false;
  scene.add(group);

  const plateW = 0.215;
  const plateH = 0.105;

  const back = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 1.02, plateH * 1.04, 0.004),
    new THREE.MeshStandardMaterial({
      color: 0x0b0f16,
      roughness: 0.52,
      metalness: 0.18,
      emissive: 0x06060a,
      emissiveIntensity: 0.04
    })
  );
  back.position.z = -0.010;
  back.renderOrder = 5;
  group.add(back);

  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW, plateH),
    new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
      depthTest: false
    })
  );
  screen.renderOrder = 30;
  screen.position.z = 0.002;
  group.add(screen);

  const frame = new THREE.Mesh(
    new THREE.RingGeometry(0.042, 0.053, 28, 1, 0, Math.PI * 2),
    new THREE.MeshStandardMaterial({
      color: 0x151a26,
      roughness: 0.48,
      metalness: 0.20,
      emissive: 0x08080c,
      emissiveIntensity: 0.03,
      side: THREE.DoubleSide
    })
  );
  frame.scale.set(plateW / 0.106, plateH / 0.106, 1);
  frame.position.z = -0.004;
  frame.renderOrder = 10;
  group.add(frame);

  const hitPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW * 1.04, plateH * 1.04),
    new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false, depthTest: false })
  );
  hitPlane.position.z = 0.008;
  group.add(hitPlane);

  function drawButton(btn, hovered){
    ctx.save();
    ctx.fillStyle = hovered ? "rgba(180,140,255,0.28)" : "rgba(255,255,255,0.08)";
    ctx.strokeStyle = hovered ? "rgba(180,140,255,0.95)" : "rgba(180,140,255,0.35)";
    ctx.lineWidth = hovered ? 5 : 3;
    rr(ctx, btn.x, btn.y, btn.w, btn.h, 18);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = hovered ? "#ffffff" : "#e8e8ff";
    ctx.font = `bold ${btn.font || 28}px system-ui, Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2 + 1);
    ctx.restore();
  }

  function buildButtons(state){
    const buttons = [
      { id: "audio", label: state.audioEnabled ? "MUSIC ON" : "MUSIC OFF", x: 30, y: 345, w: 210, h: 58 },
      { id: "next", label: "NEXT TRACK", x: 258, y: 345, w: 190, h: 58 },
    ];
    if (state.seated){
      buttons.push({ id: "leave", label: "LEAVE TABLE", x: 466, y: 345, w: 240, h: 58, font: 26 });
    } else if (state.inTableZone){
      buttons.push({ id: "join", label: "QUICK SIT", x: 466, y: 345, w: 240, h: 58, font: 28 });
    }
    return buttons;
  }

  let hoveredId = null;
  let pressed = false;
  let lastSig = "";

  function draw(force = false){
    const state = getState();
    const sig = JSON.stringify({
      h: hoveredId,
      t: state.trackTitle,
      ae: state.audioEnabled,
      c: state.cash,
      s: state.seated,
      z: state.inTableZone,
      seat: state.seatLabel,
      p: !!state.audioPrimed,
      sec: new Date().getSeconds()
    });
    if (!force && sig === lastSig) return;
    lastSig = sig;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, "rgba(5,8,16,0.90)");
    grad.addColorStop(1, "rgba(18,10,32,0.94)");
    ctx.fillStyle = grad;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.fill();

    ctx.strokeStyle = "rgba(180,140,255,0.6)";
    ctx.lineWidth = 6;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.stroke();

    const band = ctx.createLinearGradient(0, 0, canvas.width, 0);
    band.addColorStop(0, "rgba(120,70,200,0.35)");
    band.addColorStop(1, "rgba(50,16,92,0.15)");
    ctx.fillStyle = band;
    rr(ctx, 24, 24, 976, 86, 26);
    ctx.fill();

    const now = new Date();
    const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 60px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(timeText, 42, 68);

    ctx.textAlign = "right";
    ctx.fillStyle = "#7ff5c7";
    ctx.font = "bold 40px system-ui, Arial";
    ctx.fillText(`$${Number(state.cash || 0).toLocaleString()}`, 972, 68);

    ctx.textAlign = "left";
    ctx.fillStyle = "rgba(233,233,255,0.95)";
    ctx.font = "bold 30px system-ui, Arial";
    ctx.fillText("SVR WRIST CONSOLE", 34, 150);

    ctx.fillStyle = "rgba(233,233,255,0.78)";
    ctx.font = "25px system-ui, Arial";
    ctx.fillText(`Seat: ${state.seated ? state.seatLabel : "Standing"}`, 36, 205);
    ctx.fillText(`Track: ${state.audioEnabled ? state.trackTitle : "Paused"}`, 36, 243);
    ctx.fillText(`Zone: ${state.inTableZone ? "Ready" : "Walk closer"}`, 36, 281);

    ctx.textAlign = "right";
    ctx.fillStyle = state.seated ? "#7ff5c7" : state.inTableZone ? "#f6e27f" : "rgba(233,233,255,0.72)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText(state.seated ? "AT TABLE" : (state.inTableZone ? "JOIN READY" : "LOBBY"), 970, 148);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 22px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.fillText("Tap with your other hand while pinching", 36, 315);

    for (const btn of buildButtons(state)) drawButton(btn, hoveredId === btn.id);
    tex.needsUpdate = true;
  }

  function localHit(local){
    const state = getState();
    const x = ((local.x / plateW) + 0.5) * canvas.width;
    const y = ((-local.y / plateH) + 0.5) * canvas.height;
    for (const btn of buildButtons(state)){
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return btn.id;
    }
    return null;
  }

  function activate(id){
    if (!id) return;
    if (id === "audio") actions.toggleAudio?.();
    if (id === "next") actions.nextTrack?.();
    if (id === "join") actions.joinTable?.();
    if (id === "leave") actions.leaveTable?.();
  }

  function update(_dt, leftHand, rightHand){
    const anchor = leftHand?.joints?.wrist ? leftHand : rightHand?.joints?.wrist ? rightHand : null;
    if (!anchor?.joints?.wrist){
      group.visible = false;
      hoveredId = null;
      draw(true);
      return;
    }

    const watchOnLeft = anchor === leftHand;
    const otherHand = watchOnLeft ? rightHand : leftHand;
    const wrist = anchor.joints.wrist;

    group.visible = true;
    wrist.updateWorldMatrix(true, false);
    wrist.getWorldPosition(group.position);
    wrist.getWorldQuaternion(group.quaternion);

    const side = watchOnLeft ? 1 : -1;
    group.translateX(0.030 * side);
    group.translateY(-0.004);
    group.translateZ(0.020);
    group.rotateZ(side * -Math.PI * 0.52);
    group.rotateX(-Math.PI * 0.12);

    let nextHovered = null;
    const tip = otherHand?.joints?.["index-finger-tip"];
    if (tip){
      const tipPos = new THREE.Vector3();
      tip.getWorldPosition(tipPos);
      const local = group.worldToLocal(tipPos.clone());
      if (Math.abs(local.z) < 0.04 && Math.abs(local.x) < plateW * 0.54 && Math.abs(local.y) < plateH * 0.54){
        nextHovered = localHit(local);
      }
    }
    hoveredId = nextHovered;

    const pinching = !!otherHand && isPinching(otherHand);
    if (hoveredId && pinching && !pressed){
      pressed = true;
      activate(hoveredId);
    }
    if (!pinching) pressed = false;

    draw();
  }

  draw(true);
  return { update, object: group };
}
