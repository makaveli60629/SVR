import * as THREE from "three";
import { CONFIG } from "./config.js";
import { makeCanvasLabel, roundRect, makeTextPlane } from "./utils.js";

export function createWatch({ scene, camera, renderer }) {
  const root = new THREE.Group();
  root.visible = false;
  root.renderOrder = 30;
  root.scale.setScalar(0.98);
  scene.add(root);

  const { canvas, ctx, texture } = makeCanvasLabel({
    width: 1024,
    height: 512,
    draw(drawCtx, w, h) {
      drawCtx.clearRect(0, 0, w, h);
      drawCtx.fillStyle = "rgba(4,6,12,0.9)";
      roundRect(drawCtx, 18, 18, w - 36, h - 36, 48);
      drawCtx.fill();
      drawCtx.strokeStyle = "rgba(180,140,255,0.72)";
      drawCtx.lineWidth = 10;
      roundRect(drawCtx, 18, 18, w - 36, h - 36, 48);
      drawCtx.stroke();
    }
  });

  const screenMat = new THREE.MeshStandardMaterial({
    map: texture,
    transparent: true,
    emissive: 0x451363,
    emissiveIntensity: 0.82,
    metalness: 0.18,
    roughness: 0.34,
    depthWrite: false,
    depthTest: false
  });
  const frame = new THREE.Mesh(new THREE.PlaneGeometry(0.204, 0.114), screenMat);
  root.add(frame);

  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(0.21, 0.12),
    new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.06, transmission: 0.16, roughness: 0.08, metalness: 0.1, depthWrite: false, depthTest: false })
  );
  glass.position.z = 0.001;
  root.add(glass);

  const strapMat = new THREE.MeshStandardMaterial({ color: 0x14111b, roughness: 0.7, metalness: 0.14, emissive: 0x190f22, emissiveIntensity: 0.14, depthWrite: false, depthTest: false });
  const strapTop = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.02, 0.01), strapMat);
  strapTop.position.set(0, 0.064, -0.004);
  root.add(strapTop);
  const strapBottom = strapTop.clone();
  strapBottom.position.y = -0.064;
  root.add(strapBottom);

  const bodyShell = new THREE.Mesh(
    new THREE.BoxGeometry(0.21, 0.118, 0.012),
    new THREE.MeshStandardMaterial({ color: 0x090a0f, roughness: 0.6, metalness: 0.22, emissive: 0x15102a, emissiveIntensity: 0.18, depthWrite: false, depthTest: false })
  );
  bodyShell.position.z = -0.008;
  root.add(bodyShell);

  const buttons = [];
  const buttonDefs = [
    { id: "teleport", label: "TP", x: -0.064, w: 0.058 },
    { id: "seat", label: "SEAT", x: 0, w: 0.084 },
    { id: "reset", label: "RST", x: 0.064, w: 0.058 },
  ];

  for (const def of buttonDefs) {
    const tex = makeTextPlane(def.label, { width: 256, height: 128, font: "bold 52px system-ui" });
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(def.w, 0.03),
      new THREE.MeshStandardMaterial({ map: tex, transparent: true, emissive: 0x2f1144, emissiveIntensity: 0.9, roughness: 0.28, metalness: 0.12, depthWrite: false, depthTest: false })
    );
    mesh.position.set(def.x, -0.036, 0.003);
    mesh.userData.action = def.id;
    buttons.push(mesh);
    root.add(mesh);
  }

  const led = new THREE.Mesh(
    new THREE.CircleGeometry(0.006, 20),
    new THREE.MeshBasicMaterial({ color: 0x36ff9d, depthWrite: false, depthTest: false })
  );
  led.position.set(0.082, 0.04, 0.003);
  root.add(led);

  let lastRefresh = 0;
  let state = {
    teleportEnabled: false,
    seated: false,
    mode: "HAND",
  };

  const worldWrist = new THREE.Vector3();
  const worldCamera = new THREE.Vector3();
  const offset = new THREE.Vector3();
  const desiredPosition = new THREE.Vector3();
  const desiredQuaternion = new THREE.Quaternion();
  const wristQuaternion = new THREE.Quaternion();
  const wristUp = new THREE.Vector3();
  const cameraNudge = new THREE.Vector3();
  const poseHelper = new THREE.Object3D();
  const screenTilt = new THREE.Quaternion().setFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(-7), 0, 0));
  let poseInitialized = false;

  function redraw(force = false) {
    const now = performance.now() * 0.001;
    if (!force && now - lastRefresh < CONFIG.WATCH_REFRESH_S) return;
    lastRefresh = now;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(4,6,12,0.9)";
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 48);
    ctx.fill();
    ctx.strokeStyle = "rgba(180,140,255,0.72)";
    ctx.lineWidth = 10;
    roundRect(ctx, 18, 18, canvas.width - 36, canvas.height - 36, 48);
    ctx.stroke();

    const nowDate = new Date();
    const time = nowDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });

    ctx.fillStyle = "#f5f0ff";
    ctx.font = "bold 112px system-ui";
    ctx.fillText(time, 42, 145);

    ctx.font = "36px system-ui";
    ctx.fillStyle = "rgba(240,236,255,0.92)";
    ctx.fillText(`MODE ${state.mode}`, 48, 212);
    ctx.fillText(`TP ${state.teleportEnabled ? "ARMED" : "OFF"}`, 48, 254);
    ctx.fillText(`SEAT ${state.seated ? "LOCKED" : "FREE"}`, 48, 296);

    ctx.fillStyle = state.teleportEnabled ? "rgba(95,255,164,0.95)" : "rgba(255,92,122,0.95)";
    ctx.font = "bold 38px system-ui";
    ctx.fillText(state.teleportEnabled ? "HOLD TRIGGER TO AIM" : "WATCH READY", 48, 380);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 42px system-ui";
    ctx.fillText("SVR POKER", 736, 72);

    ctx.font = "28px system-ui";
    ctx.fillStyle = "rgba(232,230,255,0.78)";
    ctx.fillText("TP    SEAT    RST", 644, 446);

    texture.needsUpdate = true;
    led.material.color.set(state.teleportEnabled ? 0x36ff9d : 0xff627b);
  }

  function setState(next) {
    const merged = { ...state, ...next };
    const changed = merged.teleportEnabled !== state.teleportEnabled || merged.seated !== state.seated || merged.mode !== state.mode;
    state = merged;
    if (changed) redraw(true);
  }

  function updatePose({ leftHand, leftController, rightController, xrPresenting }) {
    const wrist = leftHand?.joints?.wrist || leftController || rightController;
    if (!xrPresenting || !wrist) {
      root.visible = false;
      poseInitialized = false;
      return;
    }

    root.visible = true;
    redraw(false);

    wrist.updateWorldMatrix?.(true, false);
    wrist.getWorldPosition(worldWrist);
    wrist.getWorldQuaternion(wristQuaternion);
    renderer.xr.getCamera(camera).getWorldPosition(worldCamera);

    const isLeft = wrist.userData?.handedness === "left" || wrist === leftController || leftHand?.joints?.wrist === wrist;
    offset.set(isLeft ? -0.034 : 0.034, 0.014, 0.02).applyQuaternion(wristQuaternion);
    desiredPosition.copy(worldWrist).add(offset);
    cameraNudge.copy(worldCamera).sub(desiredPosition).normalize().multiplyScalar(0.004);
    desiredPosition.add(cameraNudge);

    wristUp.set(0, 1, 0).applyQuaternion(wristQuaternion).normalize();
    poseHelper.position.copy(desiredPosition);
    poseHelper.up.copy(wristUp);
    poseHelper.lookAt(worldCamera);
    desiredQuaternion.copy(poseHelper.quaternion).multiply(screenTilt);

    if (!poseInitialized) {
      root.position.copy(desiredPosition);
      root.quaternion.copy(desiredQuaternion);
      poseInitialized = true;
    } else {
      root.position.lerp(desiredPosition, CONFIG.WATCH_POSE_LERP);
      root.quaternion.slerp(desiredQuaternion, CONFIG.WATCH_ROTATION_SLERP);
    }
  }

  redraw(true);

  return {
    root,
    buttons,
    setState,
    updatePose,
  };
}
