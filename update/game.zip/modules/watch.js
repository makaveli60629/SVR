import * as THREE from "three";
import { isPinching } from "./gestures.js";

export function createWristWatch({ scene, getState = ()=>({}), actions = {} }){
  const canvas = document.createElement("canvas");
  canvas.width = 768;
  canvas.height = 1024;
  const ctx = canvas.getContext("2d");

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const mat = new THREE.MeshStandardMaterial({
    map: tex,
    transparent: true,
    side: THREE.DoubleSide,
    emissive: new THREE.Color(0xb48cff),
    emissiveIntensity: 1.05,
    roughness: 0.36,
    metalness: 0.18
  });

  const plateW = 0.135;
  const plateH = 0.255;
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(plateW, plateH), mat);
  plate.renderOrder = 20;
  plate.visible = false;

  const shell = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 1.12, plateH * 1.1, 0.013),
    new THREE.MeshStandardMaterial({
      color: 0x090c14,
      roughness: 0.52,
      metalness: 0.42,
      emissive: 0x110d18,
      emissiveIntensity: 0.26,
      side: THREE.DoubleSide
    })
  );
  shell.position.z = -0.006;
  plate.add(shell);

  const bezel = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 1.03, plateH * 1.03, 0.005),
    new THREE.MeshStandardMaterial({
      color: 0x271f32,
      roughness: 0.34,
      metalness: 0.62,
      emissive: 0x1a1230,
      emissiveIntensity: 0.22,
      side: THREE.DoubleSide
    })
  );
  bezel.position.z = -0.0022;
  plate.add(bezel);

  const strap = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 0.44, plateH * 2.35, 0.005),
    new THREE.MeshStandardMaterial({
      color: 0x10121a,
      roughness: 0.84,
      metalness: 0.05,
      emissive: 0x0d0d16,
      emissiveIntensity: 0.1,
      side: THREE.DoubleSide
    })
  );
  strap.position.z = -0.01;
  plate.add(strap);

  scene.add(plate);

  function rr(c, x, y, w, h, r){
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }

  function drawButton(btn, hovered){
    ctx.save();
    ctx.fillStyle = hovered ? "rgba(120,176,255,0.34)" : "rgba(255,255,255,0.08)";
    ctx.strokeStyle = hovered ? "rgba(130,200,255,0.98)" : "rgba(130,170,255,0.42)";
    ctx.lineWidth = hovered ? 5 : 3;
    rr(ctx, btn.x, btn.y, btn.w, btn.h, 22);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#eef4ff";
    ctx.font = `bold ${btn.font || 34}px system-ui, Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2 + 1);
    ctx.restore();
  }

  let hoveredId = null;
  let pressed = false;
  let lastSig = "";

  function buildButtons(state){
    const buttons = [
      { id: "audio", label: state.audioEnabled ? "MUSIC ON" : "MUSIC OFF", x: 42, y: 742, w: 684, h: 74, font: 34 },
      { id: "next", label: "NEXT TRACK", x: 42, y: 832, w: 684, h: 74, font: 34 },
    ];
    if (state.seated){
      buttons.push({ id: "leave", label: "LEAVE TABLE", x: 42, y: 922, w: 684, h: 60, font: 32 });
    } else if (state.inTableZone){
      buttons.push({ id: "join", label: "JOIN TABLE", x: 42, y: 922, w: 684, h: 60, font: 32 });
    }
    return buttons;
  }

  function draw(force = false){
    const state = getState();
    const sig = JSON.stringify({
      h: hoveredId,
      t: state.trackTitle,
      ae: state.audioEnabled,
      c: state.cash,
      s: state.seated,
      z: state.inTableZone,
      seat: state.seatLabel,
      p: state.audioPrimed,
      err: state.audioError || "",
      sec: Math.floor(performance.now() / 1000)
    });
    if (!force && sig === lastSig) return;
    lastSig = sig;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    grad.addColorStop(0, "rgba(4,8,18,0.97)");
    grad.addColorStop(1, "rgba(18,10,36,0.98)");
    ctx.fillStyle = grad;
    rr(ctx, 14, 14, canvas.width - 28, canvas.height - 28, 38);
    ctx.fill();

    ctx.strokeStyle = "rgba(123,188,255,0.65)";
    ctx.lineWidth = 6;
    rr(ctx, 14, 14, canvas.width - 28, canvas.height - 28, 38);
    ctx.stroke();

    const band = ctx.createLinearGradient(0, 0, canvas.width, 0);
    band.addColorStop(0, "rgba(60,120,220,0.28)");
    band.addColorStop(1, "rgba(26,12,62,0.18)");
    ctx.fillStyle = band;
    rr(ctx, 28, 28, canvas.width - 56, 124, 28);
    ctx.fill();

    const now = new Date();
    const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 72px system-ui, Arial";
    ctx.fillText(timeText, 50, 88);

    ctx.fillStyle = "#8dffcf";
    ctx.font = "bold 40px system-ui, Arial";
    ctx.fillText(`$${Number(state.cash || 0).toLocaleString()}`, 52, 156);

    ctx.fillStyle = "rgba(226,236,255,0.98)";
    ctx.font = "bold 34px system-ui, Arial";
    ctx.fillText("SVR FOREARM CONSOLE", 46, 228);

    ctx.fillStyle = "rgba(226,236,255,0.80)";
    ctx.font = "28px system-ui, Arial";
    ctx.fillText(`Seat: ${state.seated ? state.seatLabel : "Standing"}`, 48, 286);
    ctx.fillText(`Zone: ${state.inTableZone ? "Ready to join" : "Move closer to table"}`, 48, 324);

    ctx.fillStyle = "rgba(131,190,255,0.98)";
    ctx.font = "bold 24px system-ui, Arial";
    ctx.fillText("NOW PLAYING", 48, 392);

    ctx.fillStyle = state.audioEnabled ? "#ffffff" : "rgba(226,236,255,0.75)";
    ctx.font = "bold 36px system-ui, Arial";
    const line2 = state.audioEnabled ? state.trackTitle : (state.audioPrimed ? `Paused • ${state.trackTitle}` : `Tap Music On • ${state.trackTitle}`);
    wrapText(line2, 48, 430, 660, 42);

    ctx.fillStyle = state.seated ? "#8dffcf" : state.inTableZone ? "#ffe083" : "rgba(226,236,255,0.75)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText(state.seated ? "AT TABLE" : (state.inTableZone ? "JOIN READY" : "LOBBY"), 48, 612);

    if (state.audioError){
      ctx.fillStyle = "#ffe083";
      ctx.font = "bold 22px system-ui, Arial";
      wrapText(state.audioError, 48, 664, 660, 28);
    } else {
      ctx.fillStyle = "rgba(180,190,255,0.84)";
      ctx.font = "bold 22px system-ui, Arial";
      wrapText("Pinch with the free hand to press a control", 48, 664, 660, 28);
    }

    for (const btn of buildButtons(state)) drawButton(btn, hoveredId === btn.id);
    tex.needsUpdate = true;
  }

  function wrapText(text, x, y, maxWidth, lineHeight){
    const words = String(text || "").split(/\s+/);
    let line = "";
    let yy = y;
    for (const word of words){
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line){
        ctx.fillText(line, x, yy);
        line = word;
        yy += lineHeight;
      } else {
        line = test;
      }
    }
    if (line) ctx.fillText(line, x, yy);
  }

  function localHit(local){
    const state = getState();
    const x = ((local.x / plateW) + 0.5) * canvas.width;
    const y = ((-local.y / plateH) + 0.5) * canvas.height;
    for (const btn of buildButtons(state)){
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return btn.id;
    }
    return null;
  }

  function activate(id){
    if (!id) return;
    if (id === "audio") actions.toggleAudio?.();
    if (id === "next") actions.nextTrack?.();
    if (id === "join") actions.joinTable?.();
    if (id === "leave") actions.leaveTable?.();
  }

  let accum = 0;

  function update(dt, leftHand, rightHand){
    accum += dt;
    const anchor = leftHand?.joints?.wrist ? leftHand : rightHand?.joints?.wrist ? rightHand : null;
    if (!anchor?.joints?.wrist){
      plate.visible = false;
      hoveredId = null;
      draw(true);
      return;
    }

    const watchOnLeft = anchor === leftHand;
    const otherHand = watchOnLeft ? rightHand : leftHand;
    const wrist = anchor.joints.wrist;

    plate.visible = true;
    wrist.updateWorldMatrix(true, false);
    wrist.getWorldPosition(plate.position);
    wrist.getWorldQuaternion(plate.quaternion);

    const side = watchOnLeft ? 1 : -1;
    plate.translateX(0.024 * side);
    plate.translateY(-0.096);
    plate.translateZ(0.048);
    plate.rotateX(-Math.PI * 0.48);
    plate.rotateZ(side * -Math.PI * 0.06);
    plate.rotateY(side * Math.PI * 0.04);

    let nextHovered = null;
    const tip = otherHand?.joints?.["index-finger-tip"];
    if (tip){
      const tipPos = new THREE.Vector3();
      tip.getWorldPosition(tipPos);
      const local = plate.worldToLocal(tipPos.clone());
      if (Math.abs(local.z) < 0.06 && Math.abs(local.x) < plateW * 0.52 && Math.abs(local.y) < plateH * 0.52){
        nextHovered = localHit(local);
      }
    }

    const hoverChanged = hoveredId !== nextHovered;
    hoveredId = nextHovered;
    const pinching = !!otherHand && isPinching(otherHand);
    if (hoveredId && pinching && !pressed){
      pressed = true;
      activate(hoveredId);
    }
    if (!pinching) pressed = false;

    if (accum > 0.12 || hoverChanged) {
      draw(true);
      accum = 0;
    } else {
      draw();
    }
  }

  draw(true);
  return { update, redraw: ()=>draw(true) };
}
