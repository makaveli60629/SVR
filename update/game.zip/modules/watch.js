import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";
import { isPinching } from "./gestures.js";

function rr(c, x, y, w, h, r){
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}

function bendPlaneGeometry(width, height, radius, segmentsX = 28, segmentsY = 40){
  const geo = new THREE.PlaneGeometry(width, height, segmentsX, segmentsY);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++){
    const x = pos.getX(i);
    const theta = (x / width) * 1.18;
    const px = Math.sin(theta) * radius;
    const pz = radius - Math.cos(theta) * radius;
    pos.setXYZ(i, px, pos.getY(i), pz);
  }
  pos.needsUpdate = true;
  geo.computeVertexNormals();
  return geo;
}

export function createWristWatch({ scene, camera, renderer, getState = ()=>({}), actions = {} }){
  const canvas = document.createElement("canvas");
  canvas.width = 768;
  canvas.height = 1024;
  const ctx = canvas.getContext("2d");
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const group = new THREE.Group();
  group.visible = false;
  scene.add(group);

  const watchWidth = 0.072;
  const watchLength = 0.126;
  const curveRadius = 0.046;

  const forearmShell = new THREE.Mesh(
    new THREE.CylinderGeometry(0.029, 0.027, 0.16, 28, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0x0b1018,
      roughness: 0.86,
      metalness: 0.06,
      emissive: 0x080d16,
      emissiveIntensity: 0.04,
      side: THREE.DoubleSide
    })
  );
  forearmShell.position.set(0, 0, -0.012);
  forearmShell.rotation.set(0, 0, 0);
  group.add(forearmShell);

  const cuff = new THREE.Mesh(
    bendPlaneGeometry(watchWidth * 1.34, watchLength * 1.12, curveRadius + 0.012, 28, 30),
    new THREE.MeshStandardMaterial({
      color: 0x090c14,
      roughness: 0.82,
      metalness: 0.08,
      emissive: 0x090f1a,
      emissiveIntensity: 0.07,
      side: THREE.DoubleSide
    })
  );
  cuff.position.set(0, 0, -0.004);
  group.add(cuff);

  const bezel = new THREE.Mesh(
    bendPlaneGeometry(watchWidth * 1.1, watchLength * 1.04, curveRadius + 0.006, 28, 34),
    new THREE.MeshStandardMaterial({
      color: 0x111523,
      roughness: 0.55,
      metalness: 0.28,
      emissive: 0x12192b,
      emissiveIntensity: 0.16,
      side: THREE.DoubleSide
    })
  );
  bezel.position.set(0, 0, 0.003);
  group.add(bezel);

  const uiGroup = new THREE.Group();
  group.add(uiGroup);

  const screen = new THREE.Mesh(
    bendPlaneGeometry(watchWidth, watchLength, curveRadius, 28, 34),
    new THREE.MeshStandardMaterial({
      map: tex,
      color: 0xffffff,
      emissive: new THREE.Color(0xa78cff),
      emissiveIntensity: 1.0,
      roughness: 0.2,
      metalness: 0.12,
      transparent: true,
      side: THREE.DoubleSide
    })
  );
  screen.position.set(0, 0, 0.01);
  screen.renderOrder = 20;
  uiGroup.add(screen);


  const hitW = 0.092;
  const hitH = 0.126;
  const hitPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(hitW, hitH),
    new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.0, side: THREE.DoubleSide })
  );
  hitPlane.position.set(0, 0, 0.03);
  uiGroup.add(hitPlane);

  function drawButton(btn, hovered){
    ctx.save();
    ctx.fillStyle = hovered ? "rgba(120,176,255,0.34)" : "rgba(255,255,255,0.08)";
    ctx.strokeStyle = hovered ? "rgba(130,200,255,0.98)" : "rgba(130,170,255,0.42)";
    ctx.lineWidth = hovered ? 5 : 3;
    rr(ctx, btn.x, btn.y, btn.w, btn.h, 22);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#eef4ff";
    ctx.font = `bold ${btn.font || 34}px system-ui, Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2 + 1);
    ctx.restore();
  }

  function buildButtons(state){
    const buttons = [
      { id: "audio", label: state.audioEnabled ? "MUSIC ON" : "MUSIC OFF", x: 42, y: 742, w: 684, h: 74, font: 34 },
      { id: "next", label: "NEXT TRACK", x: 42, y: 832, w: 684, h: 74, font: 34 },
    ];
    if (state.seated){
      buttons.push({ id: "leave", label: "LEAVE TABLE", x: 42, y: 922, w: 684, h: 60, font: 32 });
    } else if (state.inTableZone){
      buttons.push({ id: "join", label: "QUICK SIT", x: 42, y: 922, w: 684, h: 60, font: 32 });
    }
    return buttons;
  }

  function wrapText(text, x, y, maxWidth, lineHeight){
    const words = String(text || "").split(/\s+/);
    let line = "";
    let yy = y;
    for (const word of words){
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line){
        ctx.fillText(line, x, yy);
        line = word;
        yy += lineHeight;
      } else {
        line = test;
      }
    }
    if (line) ctx.fillText(line, x, yy);
  }

  let hoveredId = null;
  let pressed = false;
  let lastSig = "";

  function draw(force = false){
    const state = getState();
    const sig = JSON.stringify({
      h: hoveredId,
      t: state.trackTitle,
      ae: state.audioEnabled,
      c: state.cash,
      s: state.seated,
      z: state.inTableZone,
      seat: state.seatLabel,
      p: state.audioPrimed,
      err: state.audioError || "",
      sec: Math.floor(performance.now() / 1000)
    });
    if (!force && sig === lastSig) return;
    lastSig = sig;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    grad.addColorStop(0, "rgba(5,8,18,0.98)");
    grad.addColorStop(1, "rgba(20,10,36,0.98)");
    ctx.fillStyle = grad;
    rr(ctx, 14, 14, canvas.width - 28, canvas.height - 28, 38);
    ctx.fill();
    ctx.strokeStyle = "rgba(123,188,255,0.65)";
    ctx.lineWidth = 6;
    rr(ctx, 14, 14, canvas.width - 28, canvas.height - 28, 38);
    ctx.stroke();

    const band = ctx.createLinearGradient(0, 0, canvas.width, 0);
    band.addColorStop(0, "rgba(60,120,220,0.28)");
    band.addColorStop(1, "rgba(70,12,84,0.22)");
    ctx.fillStyle = band;
    rr(ctx, 28, 28, canvas.width - 56, 124, 28);
    ctx.fill();

    const now = new Date();
    const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 72px system-ui, Arial";
    ctx.fillText(timeText, 50, 88);
    ctx.fillStyle = "#8dffcf";
    ctx.font = "bold 40px system-ui, Arial";
    ctx.fillText(`$${Number(state.cash || 0).toLocaleString()}`, 52, 156);
    ctx.fillStyle = "rgba(226,236,255,0.98)";
    ctx.font = "bold 34px system-ui, Arial";
    ctx.fillText("SVR WRIST CONSOLE", 46, 228);
    ctx.fillStyle = "rgba(226,236,255,0.80)";
    ctx.font = "28px system-ui, Arial";
    ctx.fillText(`Seat: ${state.seated ? state.seatLabel : "Standing"}`, 48, 286);
    ctx.fillText(`Zone: ${state.inTableZone ? "Ready to join" : "Move closer to table"}`, 48, 324);
    ctx.fillStyle = "rgba(131,190,255,0.98)";
    ctx.font = "bold 24px system-ui, Arial";
    ctx.fillText("NOW PLAYING", 48, 392);
    ctx.fillStyle = state.audioEnabled ? "#ffffff" : "rgba(226,236,255,0.75)";
    ctx.font = "bold 36px system-ui, Arial";
    const line2 = state.audioEnabled ? state.trackTitle : (state.audioPrimed ? `Paused • ${state.trackTitle}` : `Tap Music On • ${state.trackTitle}`);
    wrapText(line2, 48, 430, 660, 42);
    ctx.fillStyle = state.seated ? "#8dffcf" : state.inTableZone ? "#ffe083" : "rgba(226,236,255,0.75)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText(state.seated ? "AT TABLE" : (state.inTableZone ? "QUICK SIT READY" : "LOBBY"), 48, 612);

    if (state.audioError){
      ctx.fillStyle = "#ffe083";
      ctx.font = "bold 22px system-ui, Arial";
      wrapText(state.audioError, 48, 664, 660, 28);
    } else {
      ctx.fillStyle = "rgba(180,190,255,0.84)";
      ctx.font = "bold 22px system-ui, Arial";
      wrapText("Pinch with the free hand to press a control", 48, 664, 660, 28);
    }
    for (const btn of buildButtons(state)) drawButton(btn, hoveredId === btn.id);
    tex.needsUpdate = true;
  }

  function localHit(local){
    const state = getState();
    const x = ((local.x / hitW) + 0.5) * canvas.width;
    const y = ((-local.y / hitH) + 0.5) * canvas.height;
    for (const btn of buildButtons(state)){
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return btn.id;
    }
    return null;
  }

  function activate(id){
    if (!id) return;
    if (id === "audio") actions.toggleAudio?.();
    if (id === "next") actions.nextTrack?.();
    if (id === "join") actions.joinTable?.();
    if (id === "leave") actions.leaveTable?.();
  }

  function getViewerPosition(){
    const p = new THREE.Vector3();
    if (renderer?.xr?.isPresenting){
      renderer.xr.getCamera(camera).getWorldPosition(p);
    } else {
      camera.getWorldPosition(p);
    }
    return p;
  }

  const tmp = {
    wrist: new THREE.Vector3(),
    thumb: new THREE.Vector3(),
    pinky: new THREE.Vector3(),
    index: new THREE.Vector3(),
    middle: new THREE.Vector3(),
    ring: new THREE.Vector3(),
    viewer: new THREE.Vector3(),
    handForward: new THREE.Vector3(),
    forearm: new THREE.Vector3(),
    screenNormal: new THREE.Vector3(),
    widthAxis: new THREE.Vector3(),
    projected: new THREE.Vector3(),
    up: new THREE.Vector3(0, 1, 0),
    q: new THREE.Quaternion(),
    m: new THREE.Matrix4()
  };

  function deriveBasis(hand, watchOnLeft){
    const wrist = hand.joints.wrist;
    const thumb = hand.joints["thumb-tip"];
    const index = hand.joints["index-finger-tip"];
    const middle = hand.joints["middle-finger-tip"] || index;
    const ring = hand.joints["ring-finger-tip"] || middle;
    const pinky = hand.joints["pinky-finger-tip"] || ring;
    wrist.getWorldPosition(tmp.wrist);
    thumb?.getWorldPosition(tmp.thumb);
    index?.getWorldPosition(tmp.index);
    middle?.getWorldPosition(tmp.middle);
    ring?.getWorldPosition(tmp.ring);
    pinky?.getWorldPosition(tmp.pinky);

    tmp.handForward.copy(tmp.index).add(tmp.middle).add(tmp.ring).multiplyScalar(1 / 3).sub(tmp.wrist).normalize();
    if (!Number.isFinite(tmp.handForward.x) || tmp.handForward.lengthSq() < 0.0001) tmp.handForward.set(0, 0, -1);
    tmp.forearm.copy(tmp.handForward).multiplyScalar(-1).normalize();

    const thumbPos = thumb ? tmp.thumb : null;
    const pinkyPos = pinky ? tmp.pinky : null;
    if (thumbPos && pinkyPos){
      tmp.widthAxis.copy(thumbPos).sub(pinkyPos).normalize();
    } else {
      tmp.widthAxis.set(watchOnLeft ? -1 : 1, 0, 0);
    }
    if (!Number.isFinite(tmp.widthAxis.x) || tmp.widthAxis.lengthSq() < 0.0001) tmp.widthAxis.set(watchOnLeft ? -1 : 1, 0, 0);

    tmp.screenNormal.crossVectors(tmp.widthAxis, tmp.forearm).normalize();
    if (tmp.screenNormal.lengthSq() < 0.0001) tmp.screenNormal.set(0, 1, 0);
    if (tmp.screenNormal.y < 0) tmp.screenNormal.multiplyScalar(-1);

    tmp.viewer.copy(getViewerPosition()).sub(tmp.wrist).normalize();
    if (tmp.screenNormal.dot(tmp.viewer) < -0.15){
      tmp.screenNormal.multiplyScalar(-1);
      tmp.widthAxis.multiplyScalar(-1);
    }

    tmp.m.makeBasis(tmp.widthAxis, tmp.forearm, tmp.screenNormal);
    tmp.q.setFromRotationMatrix(tmp.m);
    return { wp: tmp.wrist.clone(), forearm: tmp.forearm.clone(), normal: tmp.screenNormal.clone(), right: tmp.widthAxis.clone(), quat: tmp.q.clone() };
  }

  let accum = 0;
  const tipPos = new THREE.Vector3();

  function update(dt, leftHand, rightHand){
    accum += dt;
    const anchor = leftHand?.joints?.wrist ? leftHand : (rightHand?.joints?.wrist ? rightHand : null);
    if (!anchor?.joints?.wrist){
      group.visible = false;
      hoveredId = null;
      draw(true);
      return;
    }

    const watchOnLeft = anchor === leftHand;
    const otherHand = watchOnLeft ? rightHand : leftHand;
    group.visible = true;

    const basis = deriveBasis(anchor, watchOnLeft);
    const topNormal = basis.normal.clone();
    group.position.copy(basis.wp)
      .addScaledVector(basis.forearm, 0.090)
      .addScaledVector(topNormal, 0.024)
      .addScaledVector(basis.right, watchOnLeft ? -0.004 : 0.004);
    group.quaternion.copy(basis.quat);

    uiGroup.quaternion.identity();

    let nextHovered = null;
    const tip = otherHand?.joints?.["index-finger-tip"];
    if (tip){
      tip.getWorldPosition(tipPos);
      const local = hitPlane.worldToLocal(tipPos.clone());
      if (Math.abs(local.z) < 0.07 && Math.abs(local.x) < hitW * 0.54 && Math.abs(local.y) < hitH * 0.54){
        nextHovered = localHit(local);
      }
    }

    const hoverChanged = hoveredId !== nextHovered;
    hoveredId = nextHovered;
    if (hoverChanged) draw(true);

    const pinchHand = otherHand;
    const pinch = !!pinchHand?.joints && isPinching(pinchHand);
    if (pinch && hoveredId && !pressed){
      pressed = true;
      activate(hoveredId);
      draw(true);
    } else if (!pinch){
      pressed = false;
    }

    if (accum >= 0.16){
      accum = 0;
      draw();
    }
  }

  draw(true);
  return { group, update };
}
