import * as THREE from "three";
import { isPinching } from "./gestures.js";

function rr(c, x, y, w, h, r){
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}


const WATCH_LAYOUT = {
  left: {
    forearmOffset: 0.094,
    liftOffset: 0.030,
    lateralOffset: -0.004
  },
  right: {
    forearmOffset: 0.094,
    liftOffset: 0.030,
    lateralOffset: 0.004
  }
};

const V0 = new THREE.Vector3();
const V1 = new THREE.Vector3();
const V2 = new THREE.Vector3();
const V3 = new THREE.Vector3();
const V4 = new THREE.Vector3();
const M0 = new THREE.Matrix4();

function getJointWorld(hand, names){
  if (!hand?.joints) return null;
  for (const name of names){
    const joint = hand.joints[name];
    if (!joint) continue;
    joint.updateWorldMatrix?.(true, false);
    return joint.getWorldPosition(new THREE.Vector3());
  }
  return null;
}

function getActiveCamera(camera, renderer){
  if (renderer?.xr?.isPresenting){
    return renderer.xr.getCamera(camera);
  }
  return camera || null;
}

function computeForearmPose(hand, camera, renderer, side = "left"){
  const wrist = getJointWorld(hand, ["wrist"]);
  const index = getJointWorld(hand, ["index-finger-metacarpal", "index-finger-phalanx-proximal", "index-finger-tip"]);
  const pinky = getJointWorld(hand, ["pinky-finger-metacarpal", "pinky-finger-phalanx-proximal", "pinky-finger-tip"]);
  if (!wrist || !index || !pinky) return null;

  const layout = WATCH_LAYOUT[side] || WATCH_LAYOUT.left;
  const midpoint = V3.copy(index).add(pinky).multiplyScalar(0.5);
  const forearmDir = V4.copy(wrist).sub(midpoint).normalize();
  let acrossPalm = V1.copy(index).sub(pinky).normalize();
  let faceNormal = V2.crossVectors(acrossPalm, forearmDir).normalize();

  const activeCamera = getActiveCamera(camera, renderer);
  if (activeCamera){
    activeCamera.getWorldPosition(V0);
    if (faceNormal.dot(V0.sub(wrist)) < 0) faceNormal.multiplyScalar(-1);
  }

  acrossPalm = new THREE.Vector3().crossVectors(faceNormal, forearmDir).normalize();
  if (side === "right") acrossPalm.multiplyScalar(-1);

  M0.makeBasis(forearmDir, acrossPalm, faceNormal);
  const quaternion = new THREE.Quaternion().setFromRotationMatrix(M0);

  const position = wrist.clone()
    .add(forearmDir.clone().multiplyScalar(layout.forearmOffset))
    .add(faceNormal.clone().multiplyScalar(layout.liftOffset))
    .add(acrossPalm.clone().multiplyScalar(layout.lateralOffset));

  return { position, quaternion };
}

export function createWristWatch({ scene, camera = null, renderer = null, getState = ()=>({}), actions = {} }){
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const group = new THREE.Group();
  group.visible = false;
  scene.add(group);

  const plateW = 0.248;
  const plateH = 0.132;

  const back = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 1.01, plateH * 1.01, 0.008),
    new THREE.MeshStandardMaterial({
      color: 0x0b0f16,
      roughness: 0.52,
      metalness: 0.18,
      emissive: 0x06060a,
      emissiveIntensity: 0.04
    })
  );
  back.position.z = -0.010;
  back.renderOrder = 5;
  group.add(back);

  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW, plateH),
    new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
      depthTest: false
    })
  );
  screen.renderOrder = 30;
  screen.position.z = 0.002;
  screen.scale.x = -1;
  group.add(screen);

  const bezel = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW * 1.015, plateH * 1.015),
    new THREE.MeshStandardMaterial({
      color: 0x151a26,
      roughness: 0.42,
      metalness: 0.24,
      emissive: 0x090a10,
      emissiveIntensity: 0.04,
      side: THREE.DoubleSide
    })
  );
  bezel.position.z = -0.003;
  bezel.renderOrder = 10;
  group.add(bezel);

  const sideBtnGeo = new THREE.BoxGeometry(0.008, 0.024, 0.012);
  const sideBtnMat = new THREE.MeshStandardMaterial({ color: 0x293244, roughness: 0.34, metalness: 0.42, emissive: 0x10182b, emissiveIntensity: 0.08 });
  [-0.032, 0.0, 0.032].forEach((yy)=>{
    const btn = new THREE.Mesh(sideBtnGeo, sideBtnMat);
    btn.position.set(-plateW * 0.515, yy, -0.001);
    group.add(btn);
  });

  const hitPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW * 1.04, plateH * 1.04),
    new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false, depthTest: false })
  );
  hitPlane.position.z = 0.008;
  group.add(hitPlane);

  function drawButton(btn, hovered){
    ctx.save();
    ctx.fillStyle = hovered ? "rgba(180,140,255,0.28)" : "rgba(255,255,255,0.08)";
    ctx.strokeStyle = hovered ? "rgba(180,140,255,0.95)" : "rgba(180,140,255,0.35)";
    ctx.lineWidth = hovered ? 5 : 3;
    rr(ctx, btn.x, btn.y, btn.w, btn.h, 18);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = hovered ? "#ffffff" : "#e8e8ff";
    ctx.font = `bold ${btn.font || 28}px system-ui, Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2 + 1);
    ctx.restore();
  }

  function drawLogoMark(){
    ctx.save();
    ctx.strokeStyle = "rgba(225,120,255,0.95)";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(730, 72);
    ctx.lineTo(782, 126);
    ctx.lineTo(744, 126);
    ctx.lineTo(792, 182);
    ctx.stroke();
    ctx.fillStyle = "rgba(245,245,255,0.96)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.fillText("SVR", 812, 132);
    ctx.restore();
  }

  
function buildButtons(state){
    return [
      { id: "audio", label: state.audioEnabled ? "MUSIC ON" : "MUSIC OFF", x: 34, y: 362, w: 228, h: 64, font: 27 },
      { id: "next", label: "NEXT TRACK", x: 274, y: 362, w: 212, h: 64, font: 27 },
      { id: "seat", label: state.seated ? "STAND UP" : "QUICK SIT", x: 500, y: 362, w: 244, h: 64, font: 28 },
      { id: "reset", label: "RESET VIEW", x: 760, y: 362, w: 232, h: 64, font: 27 }
    ];
  }

  let hoveredId = null;
  let pressed = false;
  let lastSig = "";

  function draw(force = false){
    const state = getState();
    const sig = JSON.stringify({
      h: hoveredId,
      t: state.trackTitle,
      ae: state.audioEnabled,
      c: state.cash,
      s: state.seated,
      z: state.inTableZone,
      seat: state.seatLabel,
      p: !!state.audioPrimed,
      sec: new Date().getSeconds()
    });
    if (!force && sig === lastSig) return;
    lastSig = sig;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, "rgba(5,8,16,0.90)");
    grad.addColorStop(1, "rgba(18,10,32,0.94)");
    ctx.fillStyle = grad;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.fill();

    ctx.strokeStyle = "rgba(180,140,255,0.6)";
    ctx.lineWidth = 6;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.stroke();

    const band = ctx.createLinearGradient(0, 0, canvas.width, 0);
    band.addColorStop(0, "rgba(120,70,200,0.35)");
    band.addColorStop(1, "rgba(50,16,92,0.15)");
    ctx.fillStyle = band;
    rr(ctx, 24, 24, 976, 86, 26);
    ctx.fill();

    const panel = ctx.createLinearGradient(0, 126, 0, 316);
    panel.addColorStop(0, "rgba(17,20,33,0.94)");
    panel.addColorStop(1, "rgba(8,10,18,0.92)");
    ctx.fillStyle = panel;
    rr(ctx, 30, 122, 964, 194, 24);
    ctx.fill();
    ctx.strokeStyle = "rgba(156,132,255,0.25)";
    ctx.lineWidth = 3;
    rr(ctx, 30, 122, 964, 194, 24);
    ctx.stroke();

    const now = new Date();
    const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 60px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(timeText, 42, 68);

    ctx.textAlign = "right";
    ctx.fillStyle = "#7ff5c7";
    ctx.font = "bold 40px system-ui, Arial";
    ctx.fillText(`$${Number(state.cash || 0).toLocaleString()}`, 972, 68);
    drawLogoMark();

    ctx.textAlign = "left";
    ctx.fillStyle = "rgba(233,233,255,0.96)";
    ctx.font = "bold 30px system-ui, Arial";
    ctx.fillText("SVR FOREARM HUD", 54, 158);

    ctx.fillStyle = "rgba(233,233,255,0.78)";
    ctx.font = "25px system-ui, Arial";
    ctx.fillText(`Seat: ${state.seated ? state.seatLabel : "Standing"}`, 54, 206);
    ctx.fillText(`Track: ${state.audioEnabled ? state.trackTitle : "Paused"}`, 54, 250);
    ctx.fillText(`Zone: ${state.inTableZone ? "Ready" : "Walk closer"}`, 54, 294);

    ctx.textAlign = "left";
    ctx.fillStyle = "#f1c9ff";
    ctx.font = "bold 24px system-ui, Arial";
    ctx.fillText("POT", 562, 172);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 36px system-ui, Arial";
    ctx.fillText("$24,500", 562, 210);

    ctx.fillStyle = "#9be8ff";
    ctx.font = "bold 24px system-ui, Arial";
    ctx.fillText("BOARD", 562, 256);
    ctx.fillStyle = "rgba(244,244,255,0.96)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText("A♠  K♥  9♣  9♦  2♠", 562, 292);

    ctx.textAlign = "right";
    ctx.fillStyle = state.seated ? "#7ff5c7" : state.inTableZone ? "#f6e27f" : "rgba(233,233,255,0.72)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText(state.seated ? "AT TABLE" : (state.inTableZone ? "JOIN READY" : "LOBBY"), 962, 156);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 22px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.fillText("Tap with your other hand while pinching", 54, 328);

    for (const btn of buildButtons(state)) drawButton(btn, hoveredId === btn.id);
    tex.needsUpdate = true;
  }

  function localHit(local){
    const state = getState();
    const x = ((local.x / plateW) + 0.5) * canvas.width;
    const y = ((-local.y / plateH) + 0.5) * canvas.height;
    for (const btn of buildButtons(state)){
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return btn.id;
    }
    return null;
  }

  function activate(id){
    if (!id) return;
    if (id === "audio") actions.toggleAudio?.();
    if (id === "next") actions.nextTrack?.();
    if (id === "seat") actions.toggleSeat?.();
    if (id === "reset") actions.resetView?.();
  }

  function update(_dt, leftHand, rightHand){
    const pose = computeForearmPose(leftHand, camera, renderer, "left");
    if (!pose){
      group.visible = false;
      hoveredId = null;
      draw(true);
      return;
    }

    group.visible = true;
    group.position.copy(pose.position);
    group.quaternion.copy(pose.quaternion);
    group.updateMatrixWorld(true);

    const interactionHand = rightHand?.joints?.["index-finger-tip"] ? rightHand : leftHand;
    let nextHovered = null;
    const tip = interactionHand?.joints?.["index-finger-tip"];
    if (tip){
      const tipPos = new THREE.Vector3();
      tip.getWorldPosition(tipPos);
      const local = group.worldToLocal(tipPos.clone());
      if (Math.abs(local.z) < 0.04 && Math.abs(local.x) < plateW * 0.54 && Math.abs(local.y) < plateH * 0.54){
        nextHovered = localHit(local);
      }
    }
    hoveredId = nextHovered;

    const pinching = !!interactionHand && isPinching(interactionHand);
    if (hoveredId && pinching && !pressed){
      pressed = true;
      activate(hoveredId);
    }
    if (!pinching) pressed = false;

    draw();
  }

  draw(true);
  return { update, object: group };
}
