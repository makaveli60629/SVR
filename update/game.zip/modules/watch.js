import * as THREE from "three";
import { isPinching } from "./gestures.js";

function rr(c, x, y, w, h, r){
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}

export function createWristWatch({ scene, getState = ()=>({}), actions = {} }){
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const group = new THREE.Group();
  group.visible = false;
  scene.add(group);

  const plateW = 0.245;
  const plateH = 0.118;

  const frame = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW * 1.08, plateH * 1.08),
    new THREE.MeshBasicMaterial({ color: 0x100f16, transparent: true, opacity: 0.92, side: THREE.DoubleSide, depthWrite: false, depthTest: false })
  );
  frame.position.z = -0.0015;
  frame.renderOrder = 20;
  group.add(frame);

  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW, plateH),
    new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
      depthTest: false
    })
  );
  screen.renderOrder = 30;
  screen.position.z = 0.0018;
  group.add(screen);

  const hitPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW * 1.05, plateH * 1.05),
    new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false, depthTest: false })
  );
  hitPlane.position.z = 0.0045;
  group.add(hitPlane);

  function buildButtons(state){
    const buttons = [
      { id: "audio", label: state.audioEnabled ? "RADIO ON" : "RADIO OFF", x: 34, y: 330, w: 225, h: 64, font: 26 },
      { id: "next", label: "NEXT", x: 276, y: 330, w: 176, h: 64, font: 26 },
      { id: "teleport", label: state.teleportEnabled ? "TP ON" : "TP OFF", x: 468, y: 330, w: 176, h: 64, font: 26 }
    ];
    if (state.seated){
      buttons.push({ id: "leave", label: "LEAVE", x: 660, y: 330, w: 330, h: 64, font: 26 });
    } else if (state.inTableZone){
      buttons.push({ id: "join", label: "QUICK SIT", x: 660, y: 330, w: 330, h: 64, font: 26 });
    }
    return buttons;
  }

  let hoveredId = null;
  let pressed = false;
  let lastSig = "";

  function drawButton(btn, hovered){
    ctx.save();
    ctx.fillStyle = hovered ? "rgba(180,140,255,0.30)" : "rgba(255,255,255,0.08)";
    ctx.strokeStyle = hovered ? "rgba(180,140,255,0.95)" : "rgba(180,140,255,0.35)";
    ctx.lineWidth = hovered ? 5 : 3;
    rr(ctx, btn.x, btn.y, btn.w, btn.h, 22);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = hovered ? "#ffffff" : "#ececff";
    ctx.font = `bold ${btn.font || 32}px system-ui, Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2 + 1);
    ctx.restore();
  }

  function draw(force = false){
    const state = getState();
    const sig = JSON.stringify({
      h: hoveredId,
      t: state.trackTitle,
      ae: state.audioEnabled,
      c: state.cash,
      s: state.seated,
      z: state.inTableZone,
      seat: state.seatLabel,
      p: !!state.audioPrimed,
      sec: new Date().getSeconds()
    });
    if (!force && sig === lastSig) return;
    lastSig = sig;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, "rgba(6,8,14,0.94)");
    grad.addColorStop(1, "rgba(16,10,28,0.96)");
    ctx.fillStyle = grad;
    rr(ctx, 12, 12, 1000, 488, 30);
    ctx.fill();

    ctx.strokeStyle = "rgba(180,140,255,0.65)";
    ctx.lineWidth = 6;
    rr(ctx, 12, 12, 1000, 488, 30);
    ctx.stroke();

    ctx.fillStyle = "rgba(255,255,255,0.98)";
    ctx.font = "bold 54px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText("SVR FOREARM", 34, 58);

    const now = new Date();
    const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    ctx.font = "bold 58px system-ui, Arial";
    ctx.fillText(timeText, 34, 132);

    ctx.textAlign = "right";
    ctx.fillStyle = "#7ff5c7";
    ctx.font = "bold 44px system-ui, Arial";
    ctx.fillText(`$${Number(state.cash || 0).toLocaleString()}`, 988, 58);

    ctx.textAlign = "left";
    ctx.fillStyle = "rgba(233,233,255,0.86)";
    ctx.font = "30px system-ui, Arial";
    ctx.fillText(`Seat: ${state.seated ? state.seatLabel : "Standing"}`, 34, 206);
    ctx.fillText(`Zone: ${state.inTableZone ? "Ready" : "Walk closer"}`, 34, 246);
    ctx.fillText(`Teleport: ${state.teleportEnabled ? "Enabled" : "Disabled"}`, 34, 286);

    ctx.fillStyle = "rgba(233,233,255,0.76)";
    ctx.font = "28px system-ui, Arial";
    const track = state.audioEnabled ? (state.trackTitle || "Radio playing") : "Paused";
    wrapText(track, 34, 138, 520, 30);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 24px system-ui, Arial";
    wrapText("Use other hand + pinch or trigger", 560, 138, 430, 28);

    for (const btn of buildButtons(state)) drawButton(btn, hoveredId === btn.id);
    tex.needsUpdate = true;
  }

  function wrapText(text, x, y, maxW, lineH){
    const words = String(text).split(/\s+/);
    let line = "";
    let yy = y;
    for (const word of words){
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxW && line){
        ctx.fillText(line, x, yy);
        line = word;
        yy += lineH;
      } else {
        line = test;
      }
    }
    if (line) ctx.fillText(line, x, yy);
  }

  function localHit(local){
    const state = getState();
    const x = ((local.x / plateW) + 0.5) * canvas.width;
    const y = ((-local.y / plateH) + 0.5) * canvas.height;
    for (const btn of buildButtons(state)){
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return btn.id;
    }
    return null;
  }

  function activate(id){
    if (!id) return;
    if (id === "audio") actions.toggleAudio?.();
    if (id === "next") actions.nextTrack?.();
    if (id === "teleport") actions.toggleTeleport?.();
    if (id === "join") actions.joinTable?.();
    if (id === "leave") actions.leaveTable?.();
  }

  function update(_dt, leftHand, rightHand){
    const anchor = leftHand?.joints?.wrist ? leftHand : rightHand?.joints?.wrist ? rightHand : null;
    if (!anchor?.joints?.wrist){
      group.visible = false;
      hoveredId = null;
      draw(true);
      return;
    }

    const watchOnLeft = anchor === leftHand;
    const otherHand = watchOnLeft ? rightHand : leftHand;
    const wrist = anchor.joints.wrist;

    group.visible = true;
    wrist.updateWorldMatrix(true, false);
    wrist.getWorldPosition(group.position);
    wrist.getWorldQuaternion(group.quaternion);

    const side = watchOnLeft ? 1 : -1;
    group.translateX(0.030 * side);
    group.translateY(0.006);
    group.translateZ(0.042);
    group.rotateZ(side * -Math.PI * 0.52);
    group.rotateY(side * Math.PI * 0.14);
    group.rotateX(Math.PI * 0.02);

    let nextHovered = null;
    const tip = otherHand?.joints?.["index-finger-tip"];
    if (tip){
      const tipPos = new THREE.Vector3();
      tip.getWorldPosition(tipPos);
      const local = group.worldToLocal(tipPos.clone());
      if (Math.abs(local.z) < 0.05 && Math.abs(local.x) < plateW * 0.56 && Math.abs(local.y) < plateH * 0.56){
        nextHovered = localHit(local);
      }
    }
    hoveredId = nextHovered;

    const triggerPress = (otherHand?.userData?.trigger || 0) > 0.72 || (otherHand?.userData?.squeeze || 0) > 0.72;
    const pinching = (!!otherHand && isPinching(otherHand)) || triggerPress;
    if (hoveredId && pinching && !pressed){
      pressed = true;
      activate(hoveredId);
    }
    if (!pinching) pressed = false;

    draw();
  }

  draw(true);
  return { update, object: group };
}
