import * as THREE from "three";
import { isPinching } from "./gestures.js";

function rr(c, x, y, w, h, r){
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}


const TMP_V0 = new THREE.Vector3();
const TMP_V1 = new THREE.Vector3();
const TMP_V2 = new THREE.Vector3();
const TMP_V3 = new THREE.Vector3();
const TMP_Q0 = new THREE.Quaternion();
const TMP_M0 = new THREE.Matrix4();

function getJoint(hand, names){
  if (!hand?.joints) return null;
  for (const name of names){
    if (hand.joints[name]) return hand.joints[name];
  }
  return null;
}

function hasValidTrackedPose(obj){
  if (!obj) return false;
  obj.updateWorldMatrix?.(true, false);
  obj.getWorldPosition(TMP_V0);
  return Number.isFinite(TMP_V0.x) && Number.isFinite(TMP_V0.y) && Number.isFinite(TMP_V0.z) && TMP_V0.lengthSq() > 1e-8;
}

function buildWatchPose(hand, side = "left"){
  const wristObj = getJoint(hand, ["wrist"]);
  const indexObj = getJoint(hand, ["index-finger-metacarpal", "index-finger-phalanx-proximal", "index-finger-tip"]);
  const pinkyObj = getJoint(hand, ["pinky-finger-metacarpal", "pinky-finger-phalanx-proximal", "pinky-finger-tip"]);
  if (!hasValidTrackedPose(wristObj) || !hasValidTrackedPose(indexObj) || !hasValidTrackedPose(pinkyObj)) return null;

  wristObj.getWorldPosition(TMP_V0);
  indexObj.getWorldPosition(TMP_V1);
  pinkyObj.getWorldPosition(TMP_V2);

  const acrossPalm = TMP_V1.clone().sub(TMP_V2);
  if (acrossPalm.lengthSq() < 1e-8) return null;
  acrossPalm.normalize();

  const wristToKnuckles = TMP_V1.clone().add(TMP_V2).multiplyScalar(0.5).sub(TMP_V0);
  if (wristToKnuckles.lengthSq() < 1e-8) return null;
  wristToKnuckles.normalize();

  const palmNormal = new THREE.Vector3().crossVectors(acrossPalm, wristToKnuckles).normalize();
  if (side === "left") acrossPalm.multiplyScalar(-1);

  const xAxis = acrossPalm;
  const yAxis = wristToKnuckles.clone().multiplyScalar(-1);
  const zAxis = palmNormal;
  TMP_M0.makeBasis(xAxis, yAxis, zAxis);
  const wristQ = TMP_Q0.setFromRotationMatrix(TMP_M0).clone();

  const sideSign = side === "left" ? 1 : -1;
  const adjust = new THREE.Quaternion().setFromEuler(new THREE.Euler(-1.55, 0.10 * sideSign, 1.64 * sideSign, "YXZ"));
  const worldQ = wristQ.multiply(adjust);

  // Forearm slab: keep it close to the wrist, push it down the forearm, and reduce side drift.
  const worldP = TMP_V0.clone().add(new THREE.Vector3(0.006 * sideSign, 0.074, -0.012).applyQuaternion(worldQ));
  return { position: worldP, quaternion: worldQ };
}

export function createWristWatch({ scene, getState = ()=>({}), actions = {} }){
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const group = new THREE.Group();
  group.visible = false;
  scene.add(group);

  const plateW = 0.248;
  const plateH = 0.132;

  const back = new THREE.Mesh(
    new THREE.BoxGeometry(plateW * 1.01, plateH * 1.01, 0.008),
    new THREE.MeshStandardMaterial({
      color: 0x0b0f16,
      roughness: 0.52,
      metalness: 0.18,
      emissive: 0x06060a,
      emissiveIntensity: 0.04
    })
  );
  back.position.z = -0.010;
  back.renderOrder = 5;
  group.add(back);

  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW, plateH),
    new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
      depthTest: false
    })
  );
  screen.renderOrder = 30;
  screen.position.z = 0.002;
  group.add(screen);

  const bezel = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW * 1.015, plateH * 1.015),
    new THREE.MeshStandardMaterial({
      color: 0x151a26,
      roughness: 0.42,
      metalness: 0.24,
      emissive: 0x090a10,
      emissiveIntensity: 0.04,
      side: THREE.DoubleSide
    })
  );
  bezel.position.z = -0.003;
  bezel.renderOrder = 10;
  group.add(bezel);

  const sideBtnGeo = new THREE.BoxGeometry(0.008, 0.024, 0.012);
  const sideBtnMat = new THREE.MeshStandardMaterial({ color: 0x293244, roughness: 0.34, metalness: 0.42, emissive: 0x10182b, emissiveIntensity: 0.08 });
  [-0.032, 0.0, 0.032].forEach((yy)=>{
    const btn = new THREE.Mesh(sideBtnGeo, sideBtnMat);
    btn.position.set(-plateW * 0.515, yy, -0.001);
    group.add(btn);
  });

  const strapMat = new THREE.MeshStandardMaterial({
    color: 0x06080d,
    roughness: 0.88,
    metalness: 0.08,
    emissive: 0x05070b,
    emissiveIntensity: 0.02
  });
  const strapOuter = new THREE.Mesh(new THREE.BoxGeometry(plateW * 0.78, 0.030, 0.010), strapMat);
  strapOuter.position.set(0, plateH * 0.60, -0.014);
  group.add(strapOuter);
  const strapInner = strapOuter.clone();
  strapInner.position.y = -plateH * 0.60;
  group.add(strapInner);

  const hitPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(plateW * 1.04, plateH * 1.04),
    new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false, depthTest: false })
  );
  hitPlane.position.z = 0.008;
  group.add(hitPlane);

  function drawButton(btn, hovered){
    ctx.save();
    ctx.fillStyle = hovered ? "rgba(180,140,255,0.28)" : "rgba(255,255,255,0.08)";
    ctx.strokeStyle = hovered ? "rgba(180,140,255,0.95)" : "rgba(180,140,255,0.35)";
    ctx.lineWidth = hovered ? 5 : 3;
    rr(ctx, btn.x, btn.y, btn.w, btn.h, 18);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = hovered ? "#ffffff" : "#e8e8ff";
    ctx.font = `bold ${btn.font || 28}px system-ui, Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(btn.label, btn.x + btn.w / 2, btn.y + btn.h / 2 + 1);
    ctx.restore();
  }

  function drawLogoMark(){
    ctx.save();
    ctx.strokeStyle = "rgba(225,120,255,0.95)";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(730, 72);
    ctx.lineTo(782, 126);
    ctx.lineTo(744, 126);
    ctx.lineTo(792, 182);
    ctx.stroke();
    ctx.fillStyle = "rgba(245,245,255,0.96)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.fillText("SVR", 812, 132);
    ctx.restore();
  }

  function buildButtons(state){
    const buttons = [
      { id: "audio", label: state.audioEnabled ? "MUSIC ON" : "MUSIC OFF", x: 36, y: 362, w: 220, h: 64 },
      { id: "next", label: "NEXT TRACK", x: 276, y: 362, w: 208, h: 64 },
    ];
    if (state.seated){
      buttons.push({ id: "leave", label: "LEAVE TABLE", x: 506, y: 362, w: 250, h: 64, font: 26 });
    } else if (state.inTableZone){
      buttons.push({ id: "join", label: "QUICK SIT", x: 506, y: 362, w: 250, h: 64, font: 28 });
    }
    buttons.push({ id: "menu", label: "MENU", x: 776, y: 362, w: 210, h: 64, font: 28 });
    return buttons;
  }

  let hoveredId = null;
  let pressed = false;
  let lastSig = "";
  if (group.parent !== scene) scene.add(group);
  group.scale.set(1, 1, 1);

  function draw(force = false){
    const state = getState();
    const sig = JSON.stringify({
      h: hoveredId,
      t: state.trackTitle,
      ae: state.audioEnabled,
      c: state.cash,
      s: state.seated,
      z: state.inTableZone,
      seat: state.seatLabel,
      p: !!state.audioPrimed,
      sec: new Date().getSeconds()
    });
    if (!force && sig === lastSig) return;
    lastSig = sig;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, "rgba(5,8,16,0.90)");
    grad.addColorStop(1, "rgba(18,10,32,0.94)");
    ctx.fillStyle = grad;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.fill();

    ctx.strokeStyle = "rgba(180,140,255,0.6)";
    ctx.lineWidth = 6;
    rr(ctx, 12, 12, 1000, 488, 34);
    ctx.stroke();

    const band = ctx.createLinearGradient(0, 0, canvas.width, 0);
    band.addColorStop(0, "rgba(120,70,200,0.35)");
    band.addColorStop(1, "rgba(50,16,92,0.15)");
    ctx.fillStyle = band;
    rr(ctx, 24, 24, 976, 86, 26);
    ctx.fill();

    const panel = ctx.createLinearGradient(0, 126, 0, 316);
    panel.addColorStop(0, "rgba(17,20,33,0.94)");
    panel.addColorStop(1, "rgba(8,10,18,0.92)");
    ctx.fillStyle = panel;
    rr(ctx, 30, 122, 964, 194, 24);
    ctx.fill();
    ctx.strokeStyle = "rgba(156,132,255,0.25)";
    ctx.lineWidth = 3;
    rr(ctx, 30, 122, 964, 194, 24);
    ctx.stroke();

    const now = new Date();
    const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 60px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(timeText, 42, 68);

    ctx.textAlign = "right";
    ctx.fillStyle = "#7ff5c7";
    ctx.font = "bold 40px system-ui, Arial";
    ctx.fillText(`$${Number(state.cash || 0).toLocaleString()}`, 972, 68);
    drawLogoMark();

    ctx.textAlign = "left";
    ctx.fillStyle = "rgba(233,233,255,0.96)";
    ctx.font = "bold 30px system-ui, Arial";
    ctx.fillText("SVR FOREARM HUD", 54, 158);

    ctx.fillStyle = "rgba(233,233,255,0.78)";
    ctx.font = "25px system-ui, Arial";
    ctx.fillText(`Seat: ${state.seated ? state.seatLabel : "Standing"}`, 54, 206);
    ctx.fillText(`Track: ${state.audioEnabled ? state.trackTitle : "Paused"}`, 54, 250);
    ctx.fillText(`Zone: ${state.inTableZone ? "Ready" : "Walk closer"}`, 54, 294);

    ctx.textAlign = "left";
    ctx.fillStyle = "#f1c9ff";
    ctx.font = "bold 24px system-ui, Arial";
    ctx.fillText("POT", 562, 172);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 36px system-ui, Arial";
    ctx.fillText("$24,500", 562, 210);

    ctx.fillStyle = "#9be8ff";
    ctx.font = "bold 24px system-ui, Arial";
    ctx.fillText("BOARD", 562, 256);
    ctx.fillStyle = "rgba(244,244,255,0.96)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText("A♠  K♥  9♣  9♦  2♠", 562, 292);

    ctx.textAlign = "right";
    ctx.fillStyle = state.seated ? "#7ff5c7" : state.inTableZone ? "#f6e27f" : "rgba(233,233,255,0.72)";
    ctx.font = "bold 28px system-ui, Arial";
    ctx.fillText(state.seated ? "AT TABLE" : (state.inTableZone ? "JOIN READY" : "LOBBY"), 962, 156);

    ctx.fillStyle = "rgba(180,140,255,0.92)";
    ctx.font = "bold 22px system-ui, Arial";
    ctx.textAlign = "left";
    ctx.fillText("Tap with your other hand while pinching", 54, 328);

    for (const btn of buildButtons(state)) drawButton(btn, hoveredId === btn.id);
    tex.needsUpdate = true;
  }

  function localHit(local){
    const state = getState();
    const x = ((local.x / plateW) + 0.5) * canvas.width;
    const y = ((-local.y / plateH) + 0.5) * canvas.height;
    for (const btn of buildButtons(state)){
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) return btn.id;
    }
    return null;
  }

  function activate(id){
    if (!id) return;
    if (id === "audio") actions.toggleAudio?.();
    if (id === "next") actions.nextTrack?.();
    if (id === "join") actions.joinTable?.();
    if (id === "leave") actions.leaveTable?.();
    if (id === "menu") actions.openMenu?.();
  }

  function update(_dt, leftHand, rightHand){
    const pose = buildWatchPose(leftHand, "left");
    if (!pose){
      group.visible = false;
      hoveredId = null;
      draw(true);
      return;
    }

    group.visible = true;
    group.position.copy(pose.position);
    group.quaternion.copy(pose.quaternion);
    group.updateMatrixWorld(true);

    const otherHand = rightHand;
    let nextHovered = null;
    const tip = otherHand?.joints?.["index-finger-tip"] || getJoint(otherHand, ["index-finger-tip"]);
    if (tip && hasValidTrackedPose(tip)){
      const tipPos = TMP_V3;
      tip.getWorldPosition(tipPos);
      const local = group.worldToLocal(tipPos.clone());
      if (Math.abs(local.z) < 0.04 && Math.abs(local.x) < plateW * 0.54 && Math.abs(local.y) < plateH * 0.54){
        nextHovered = localHit(local);
      }
    }
    hoveredId = nextHovered;

    const pinching = !!otherHand && isPinching(otherHand);
    if (hoveredId && pinching && !pressed){
      pressed = true;
      activate(hoveredId);
    }
    if (!pinching) pressed = false;

    draw();
  }

  draw(true);
  return { update, object: group };
}
