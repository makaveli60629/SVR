AFRAME.registerComponent('table-system',{
  init:function(){
    const root=document.createElement('a-entity'); root.setAttribute('id','pokerTable'); root.setAttribute('position','0 0 -1.2'); this.el.appendChild(root);

    const model=document.createElement('a-entity');
    model.setAttribute('id','optionalTableModel'); model.setAttribute('gltf-model','#tableGLB'); model.setAttribute('position','0 .78 0'); model.setAttribute('scale','1 1 1'); model.setAttribute('visible','false');
    root.appendChild(model);
    model.addEventListener('model-loaded',()=>{model.setAttribute('visible','true'); const fb=document.getElementById('fallbackTable'); if(fb)fb.setAttribute('visible','false');});

    const fb=document.createElement('a-entity'); fb.setAttribute('id','fallbackTable'); root.appendChild(fb);
    const top=document.createElement('a-cylinder'); top.setAttribute('class','clickable'); top.setAttribute('radius','2.05'); top.setAttribute('height','.18'); top.setAttribute('segments-radial','96'); top.setAttribute('position','0 .78 0'); top.setAttribute('scale','1.42 .12 .82'); top.setAttribute('material','src:#feltCanvas; roughness:.9; metalness:.03'); fb.appendChild(top);
    const rail=document.createElement('a-torus'); rail.setAttribute('position','0 .91 0'); rail.setAttribute('rotation','90 0 0'); rail.setAttribute('radius','2.05'); rail.setAttribute('radius-tubular','.09'); rail.setAttribute('scale','1.42 1 .82'); rail.setAttribute('material','color:#1d0c2b; roughness:.58; metalness:.15; emissive:#170727; emissiveIntensity:.2'); fb.appendChild(rail);

    for(let i=0;i<8;i++){
      const a=(i/8)*Math.PI*2,x=Math.cos(a)*2.25,z=Math.sin(a)*1.35,s=document.createElement('a-entity');
      s.setAttribute('position',`${x} .05 ${z}`); s.setAttribute('rotation',`0 ${-a*180/Math.PI+90} 0`);
      s.innerHTML='<a-box width=".75" height=".12" depth=".75" position="0 .36 0" material="color:#111; roughness:.75"></a-box><a-box width=".78" height=".75" depth=".10" position="0 .78 .34" material="color:#151020; roughness:.75"></a-box><a-torus radius=".42" radius-tubular=".018" position="0 .42 0" rotation="90 0 0" material="color:#8b42ff; emissive:#8b42ff; emissiveIntensity:.35"></a-torus>';
      root.appendChild(s);
    }

    for(let i=0;i<5;i++){const c=document.createElement('a-box');c.setAttribute('position',`${(i-2)*.42} .94 -.18`);c.setAttribute('width','.28');c.setAttribute('height','.01');c.setAttribute('depth','.40');c.setAttribute('material','color:#f4ecff; roughness:.35');root.appendChild(c);}
    const colors=['#d44','#44d','#ddd','#151515','#d7a7ff'];
    for(let i=0;i<20;i++){const chip=document.createElement('a-cylinder');chip.setAttribute('radius','.055');chip.setAttribute('height','.025');chip.setAttribute('segments-radial','24');chip.setAttribute('position',`${-1.1+(i%6)*.12} ${.98+Math.floor(i/6)*.028} ${.38+Math.floor(i/6)*.09}`);chip.setAttribute('rotation','90 0 0');chip.setAttribute('material',`color:${colors[i%colors.length]}; roughness:.42; metalness:.08`);root.appendChild(chip);}
  }
});