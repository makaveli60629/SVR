AFRAME.registerComponent('scene-portals',{
  init:function(){
    this.active='LOBBY';
    const pads=[['POKER',-4,0.04,4,'#7d33ff'],['REIKI',4,0.04,4,'#46e3c8'],['PGA',-6,0.04,-5,'#48a6ff'],['SCORPION',6,0.04,-5,'#ff4ab8']];
    pads.forEach(p=>this.makePad(...p));
    window.addEventListener('keydown',e=>{
      const map={'1':'LOBBY','2':'POKER','3':'REIKI','4':'PGA','5':'SCORPION'}; if(map[e.key])this.switchScene(map[e.key]);
    });
  },
  makePad:function(label,x,y,z,color){
    const p=document.createElement('a-entity'); p.setAttribute('position',`${x} ${y} ${z}`); p.setAttribute('class','portal clickable');
    p.innerHTML=`<a-cylinder radius=".72" height=".035" segments-radial="48" material="color:${color}; emissive:${color}; emissiveIntensity:.75; transparent:true; opacity:.55"></a-cylinder><a-text value="${label}" align="center" width="2.7" position="0 .18 0" rotation="-90 0 0" material="color:#fff; emissive:${color}; emissiveIntensity:.4"></a-text>`;
    p.addEventListener('click',()=>this.switchScene(label)); this.el.appendChild(p);
  },
  switchScene:function(name){
    this.active=name;
    const rig=document.getElementById('rig'); if(!rig)return;
    const pos={LOBBY:'0 1.6 3',POKER:'0 1.6 3',REIKI:'4 1.6 4',PGA:'-6 1.6 -5',SCORPION:'6 1.6 -5'}[name]||'0 1.6 3';
    rig.setAttribute('position',pos);
    const overlay=document.getElementById('bootOverlay'); if(overlay){overlay.style.display='block'; overlay.style.opacity='1'; overlay.querySelector('span').textContent='Scene selected: '+name+' (placeholder room is staged; assets can drop into modules later).'; setTimeout(()=>{overlay.style.opacity='0';},1700); setTimeout(()=>{overlay.style.display='none';},2300);}
  }
});