
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160/build/three.module.js";
import { createScene } from "./scene.js";
import { loadTable } from "./table.js";
import { initHands } from "./hands.js";
import { createSky } from "./skyline.js";

const scene = createScene();

createSky(scene);

const camera = new THREE.PerspectiveCamera(
70,
window.innerWidth/window.innerHeight,
0.1,
1000
);

camera.position.set(0,1.6,3);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.xr.enabled = true;

document.body.appendChild(renderer.domElement);

const light = new THREE.DirectionalLight(0xffffff,1);
light.position.set(0,5,5);
scene.add(light);

loadTable(scene);

initHands(renderer,scene);

function animate(){
renderer.setAnimationLoop(()=>{
renderer.render(scene,camera);
});
}

animate();
