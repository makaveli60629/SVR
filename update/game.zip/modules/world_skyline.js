import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { CONFIG } from "./config.js";
import { assetUrls, loadFirstTexture } from "./asset_base.js";

function delay(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }
async function withTimeout(promise, ms){
  return await Promise.race([
    promise,
    (async()=>{ await delay(ms); throw new Error("timeout"); })()
  ]);
}
function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  return { size, center, box };
}
function dropToGround(obj){
  const { size, center } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - center.y;
}
function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}
function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia = Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

function orientCharacterUpright(obj){
  const trials = [
    [0,0,0],
    [-Math.PI*0.5,0,0],
    [Math.PI*0.5,0,0],
    [0,0,Math.PI*0.5],
    [0,0,-Math.PI*0.5],
    [0,Math.PI,0],
    [-Math.PI*0.5,Math.PI,0],
    [Math.PI*0.5,Math.PI,0],
    [0,Math.PI,Math.PI*0.5],
    [0,Math.PI,-Math.PI*0.5]
  ];
  const original = obj.rotation.clone();
  let best = { score: -Infinity, rot: original.clone() };
  for (const [rx,ry,rz] of trials){
    obj.rotation.set(rx,ry,rz);
    obj.updateMatrixWorld(true);
    const { size } = boxSize(obj);
    const score = size.y - Math.max(size.x, size.z) * 0.25;
    if (Number.isFinite(score) && score > best.score){
      best = { score, rot: obj.rotation.clone() };
    }
  }
  obj.rotation.copy(best.rot);
  obj.updateMatrixWorld(true);
}
async function tryLoadGLTF(urls, log, timeoutMs = 12000){
  const loader = new GLTFLoader();
  for (const url of urls){
    try{
      const gltf = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded GLTF:", url);
      return gltf.scene;
    }catch(_err){ log("GLTF miss:", url); }
  }
  return null;
}
async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const fbx = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded FBX:", url);
      return fbx;
    }catch(_err){ log("FBX miss:", url); }
  }
  return null;
}
function canvasTexture(width, height, painter){
  const c = document.createElement("canvas");
  c.width = width; c.height = height;
  const x = c.getContext("2d");
  painter(x, width, height, c);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  return tex;
}
function makeSpriteTexture(){
  return canvasTexture(128, 128, (x,w,h)=>{
    const g = x.createRadialGradient(w/2,h/2,3,w/2,h/2,58);
    g.addColorStop(0,"rgba(255,255,255,1)");
    g.addColorStop(0.18,"rgba(220,230,255,0.95)");
    g.addColorStop(0.42,"rgba(180,140,255,0.26)");
    g.addColorStop(1,"rgba(180,140,255,0)");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
  });
}
function makeEarthTexture(){
  return canvasTexture(1024, 512, (x,w,h)=>{
    x.fillStyle = "#0a2c60";
    x.fillRect(0,0,w,h);
    for (let i = 0; i < 68; i++){
      x.fillStyle = `rgba(${20 + Math.random()*40|0}, ${90 + Math.random()*90|0}, ${60 + Math.random()*60|0}, ${0.55 + Math.random()*0.25})`;
      x.beginPath();
      x.ellipse(Math.random()*w, Math.random()*h, 40+Math.random()*130, 18+Math.random()*75, Math.random()*Math.PI, 0, Math.PI*2);
      x.fill();
    }
    x.fillStyle = "rgba(255,255,255,0.22)";
    for (let i = 0; i < 24; i++){
      x.beginPath();
      x.ellipse(Math.random()*w, Math.random()*h, 60+Math.random()*180, 15+Math.random()*40, Math.random()*Math.PI, 0, Math.PI*2);
      x.fill();
    }
  });
}
function makeWoodTexture(){
  return canvasTexture(1024, 256, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,0,h);
    g.addColorStop(0,"#5f381c");
    g.addColorStop(1,"#2a160d");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    for (let i=0;i<180;i++){
      x.strokeStyle = `rgba(${120+Math.random()*80|0},${70+Math.random()*35|0},${35+Math.random()*20|0},0.22)`;
      x.beginPath();
      const yy = Math.random()*h;
      x.moveTo(0,yy);
      x.bezierCurveTo(w*0.25, yy+Math.random()*18-9, w*0.75, yy+Math.random()*18-9, w, yy+Math.random()*12-6);
      x.stroke();
    }
  });
}
function makeChairTexture(){
  return canvasTexture(512, 512, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0,"#2c1a34");
    g.addColorStop(1,"#17111f");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(255,255,255,0.08)";
    x.lineWidth = 2;
    for (let i=0;i<24;i++){
      x.beginPath();
      x.moveTo(0, i*(h/24));
      x.lineTo(w, i*(h/24));
      x.stroke();
    }
  });
}
function buildStars(scene, R){
  const count = 8400;
  const pos = new Float32Array(count * 3);
  const col = new Float32Array(count * 3);
  for (let i = 0; i < count; i++){
    const rr = R + 95 + Math.random() * 220;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.48 + 0.02;
    pos[i*3+0] = Math.cos(theta) * Math.sin(phi) * rr;
    pos[i*3+1] = Math.cos(phi) * rr * 0.95 + 42;
    pos[i*3+2] = Math.sin(theta) * Math.sin(phi) * rr;
    const tint = 0.84 + Math.random() * 0.16;
    col[i*3+0] = tint;
    col[i*3+1] = 0.88 + Math.random() * 0.12;
    col[i*3+2] = 0.96 + Math.random() * 0.04;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({
    size: 0.082,
    sizeAttenuation: true,
    transparent: true,
    opacity: 0.96,
    map: makeSpriteTexture(),
    vertexColors: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  }));
  scene.add(pts);

  const spriteGroup = new THREE.Group();
  for (let i = 0; i < 360; i++){
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: makeSpriteTexture(),
      color: new THREE.Color(i % 7 === 0 ? 0xb48cff : 0xffffff),
      transparent: true,
      opacity: 0.20 + Math.random() * 0.12,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    }));
    spr.scale.setScalar(0.022 + Math.random() * 0.07);
    const rr = R + 110 + Math.random() * 180;
    const theta = Math.random() * Math.PI * 2;
    const y = 55 + Math.random() * 120;
    spr.position.set(Math.cos(theta) * rr, y, Math.sin(theta) * rr);
    spriteGroup.add(spr);
  }
  scene.add(spriteGroup);
  return { pts, spriteGroup };
}
function createOrbHaloSprite(color = 0xffffff, opacity = 0.5){
  return new THREE.Sprite(new THREE.SpriteMaterial({
    map: makeSpriteTexture(),
    color,
    transparent: true,
    opacity,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  }));
}
function createMatrixBillboardTexture(){
  const canvas = document.createElement("canvas");
  canvas.width = 768;
  canvas.height = 1152;
  const ctx = canvas.getContext("2d");
  const cols = Array.from({ length: 34 }, (_, i)=>({ x: 18 + i * 22, y: Math.random() * canvas.height, speed: 4 + (i % 4) }));
  const phrases = [
    "SVRPOKER.COM",
    "ALL IN",
    "PUBLIC LAUNCH",
    "COMING SOON",
    "SCARLETT VR POKER",
    "THE FUTURE OF PLAYING POKER",
    "WIN MONEY FROM SPONSOR WINS",
    "DONORNATION",
    "FUNDRAISING FOR HOMELESS",
    "ANIMAL RESCUE"
  ];
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  function redraw(t = 0){
    const time = t || 0;
    ctx.fillStyle = "#040109";
    ctx.fillRect(0,0,canvas.width,canvas.height);
    const bg = ctx.createLinearGradient(0,0,0,canvas.height);
    bg.addColorStop(0, "rgba(25, 5, 40, 0.26)");
    bg.addColorStop(1, "rgba(3, 0, 8, 0.88)");
    ctx.fillStyle = bg;
    ctx.fillRect(0,0,canvas.width,canvas.height);

    ctx.font = "bold 20px monospace";
    cols.forEach((c, i)=>{
      const head = (Math.floor(time * 18) + i * 7) % 2;
      for (let j = 0; j < 52; j++){
        const yy = (c.y + j * 22) % (canvas.height + 120) - 60;
        const char = ((j + head + i) % 2) ? "1" : "0";
        ctx.fillStyle = j < 2 ? "rgba(235,225,255,0.98)" : (i % 3 === 0 ? "rgba(202,126,255,0.82)" : "rgba(140,78,235,0.78)");
        ctx.fillText(char, c.x, yy);
      }
      c.y += c.speed;
      if (c.y > canvas.height + 30) c.y = -Math.random() * 140;
    });

    ctx.strokeStyle = "rgba(150,235,255,0.82)";
    ctx.lineWidth = 5;
    ctx.strokeRect(176, 404, 416, 272);
    const plate = ctx.createLinearGradient(132,376,636,706);
    plate.addColorStop(0, "rgba(10,22,40,0.78)");
    plate.addColorStop(1, "rgba(26,4,34,0.60)");
    ctx.fillStyle = plate;
    ctx.fillRect(176, 404, 416, 272);

    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#edf6ff";
    ctx.font = "bold 52px system-ui, Arial";
    ctx.fillText("ALL IN", 384, 486);
    ctx.font = "bold 24px monospace";
    for (let i = 0; i < phrases.length; i++){
      const yy = 566 + i * 30;
      ctx.fillStyle = i % 2 ? "rgba(152,220,255,0.92)" : "rgba(198,132,255,0.90)";
      ctx.fillText(phrases[i], 384, yy);
    }

    tex.needsUpdate = true;
  }
  redraw(0);
  return { texture: tex, update: redraw };
}
function createAdBillboardTexture(lines = ["SVRPOKER.COM", "ALL IN"]){
  return canvasTexture(512, 512, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0,"#04122c");
    g.addColorStop(1,"#25092a");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(127,212,255,0.92)";
    x.lineWidth = 8;
    x.strokeRect(18,18,w-36,h-36);
    x.fillStyle = "#f6fbff";
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.font = "bold 52px system-ui, Arial";
    x.fillText(lines[0], w/2, h/2 - 40);
    x.font = "bold 64px system-ui, Arial";
    x.fillText(lines[1], w/2, h/2 + 38);
  });
}
function buildOuterCity(scene, R){
  const group = new THREE.Group();
  const windowMats = [
    new THREE.MeshStandardMaterial({ color: 0x7fd4ff, roughness: 0.14, metalness: 0.22, emissive: 0x1d58a2, emissiveIntensity: 2.8 }),
    new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.16, metalness: 0.25, emissive: 0x411a78, emissiveIntensity: 2.2 }),
    new THREE.MeshStandardMaterial({ color: 0x9ce3ff, roughness: 0.12, metalness: 0.28, emissive: 0x2962b6, emissiveIntensity: 3.0 })
  ];
  const bodyMats = [
    new THREE.MeshStandardMaterial({ color: 0x08111d, roughness: 0.74, metalness: 0.18, emissive: 0x0a1428, emissiveIntensity: 0.9 }),
    new THREE.MeshStandardMaterial({ color: 0x0b1623, roughness: 0.68, metalness: 0.22, emissive: 0x0d1b34, emissiveIntensity: 1.0 }),
    new THREE.MeshStandardMaterial({ color: 0x09131f, roughness: 0.7, metalness: 0.2, emissive: 0x09192f, emissiveIntensity: 1.1 })
  ];
  const matrix = createMatrixBillboardTexture();
  const adTex = createAdBillboardTexture();
  const billboardUpdaters = [matrix.update];

  const count = 220;
  for (let i = 0; i < count; i++){
    const a = (i / count) * Math.PI * 2;
    const rr = (R + 8) + Math.random() * 22;
    const h = 12 + Math.random() * 46;
    const w = 1.8 + Math.random() * 4.8;
    const d = 1.8 + Math.random() * 4.8;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;
    const style = i % 5;
    const bodyMat = bodyMats[i % bodyMats.length];
    const winMat = windowMats[i % windowMats.length];
    let bodyGeo;
    if (style === 0) bodyGeo = new THREE.BoxGeometry(w, h, d);
    else if (style === 1) bodyGeo = new THREE.CylinderGeometry(w * 0.52, w * 0.66, h, 8);
    else if (style === 2) bodyGeo = new THREE.BoxGeometry(w, h, d * 0.72);
    else if (style === 3) bodyGeo = new THREE.CylinderGeometry(w * 0.54, w * 0.62, h, 6);
    else bodyGeo = new THREE.BoxGeometry(w * 0.88, h, d * 1.15);
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.set(x, h / 2, z);
    body.rotation.y = -a + Math.PI / 2;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    if (style !== 1){
      const cap = new THREE.Mesh(new THREE.BoxGeometry(w * 0.82, 0.9 + Math.random() * 1.3, d * 0.82), winMat);
      cap.position.set(x, h + cap.geometry.parameters.height * 0.5, z);
      cap.rotation.y = body.rotation.y;
      group.add(cap);
    }

    const stripCount = 2 + (Math.random() * 5 | 0);
    for (let s = 0; s < stripCount; s++){
      const strip = new THREE.Mesh(new THREE.BoxGeometry(Math.max(0.35, w * 0.86), 0.16, Math.max(0.18, d * 1.02)), winMat);
      strip.position.set(x, 2 + ((s + 1) / (stripCount + 1)) * (h - 3), z);
      strip.rotation.y = body.rotation.y;
      group.add(strip);
    }

    if (i % 16 === 0){
      const towerLine = new THREE.Mesh(new THREE.BoxGeometry(0.16, h * 0.9, 0.18), winMat);
      towerLine.position.set(x + Math.cos(a + Math.PI/2) * (w * 0.36), h * 0.48, z + Math.sin(a + Math.PI/2) * (w * 0.36));
      group.add(towerLine);
    }

    if (i === 8 || i === 44 || i === 118){
      const tex = i === 44 ? matrix.texture : adTex;
      tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
      const bill = new THREE.Mesh(
        new THREE.PlaneGeometry(2.8, 5.4),
        new THREE.MeshBasicMaterial({ map: tex, transparent: true, side: THREE.DoubleSide })
      );
      const outward = new THREE.Vector3(Math.cos(a), 0, Math.sin(a));
      bill.position.set(x - outward.x * (w * 0.52 + 0.35), Math.min(h * 0.68, 16), z - outward.z * (w * 0.52 + 0.35));
      bill.lookAt(bill.position.clone().sub(outward));
      group.add(bill);
    }
  }
  scene.add(group);
  return { group, billboardUpdaters };
}
function makeSeat(scene, x, z, angle, label, chairMat, metalMat){
  const group = new THREE.Group();
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.36, 0.54, 48),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.72, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.014;
  group.add(ring);
  const seatBase = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.11, 0.72, 18), metalMat);
  seatBase.position.y = 0.36;
  group.add(seatBase);
  const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 0.06, 28), metalMat);
  foot.position.y = 0.03;
  group.add(foot);
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.12, 0.68), chairMat);
  seat.position.y = 0.72;
  seat.castShadow = true;
  seat.receiveShadow = true;
  group.add(seat);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.72, 0.12), chairMat);
  back.position.set(0, 1.08, -0.28);
  back.rotation.x = -0.12;
  back.castShadow = true;
  back.receiveShadow = true;
  group.add(back);
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 0.56), chairMat);
  armL.position.set(-0.34, 0.88, 0.02);
  group.add(armL);
  const armR = armL.clone();
  armR.position.x = 0.34;
  group.add(armR);
  const headrest = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.18, 0.1), chairMat);
  headrest.position.set(0, 1.42, -0.24);
  group.add(headrest);
  const legs = [[-0.24,0.34,-0.24],[0.24,0.34,-0.24],[-0.24,0.34,0.24],[0.24,0.34,0.24]];
  for (const [lx,ly,lz] of legs){
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.035, 0.72, 12), metalMat);
    leg.position.set(lx, ly, lz);
    group.add(leg);
  }
  group.position.set(x, 0, z);
  group.rotation.y = angle;
  scene.add(group);
  return { group, ring, x, z, angle, label };
}
function addChipsAndCards(scene){
  const group = new THREE.Group();
  const chipMatA = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.35, metalness: 0.25, emissive: 0x230d30, emissiveIntensity: 0.35 });
  const chipMatB = new THREE.MeshStandardMaterial({ color: 0x00e2c7, roughness: 0.35, metalness: 0.25, emissive: 0x06261f, emissiveIntensity: 0.28 });
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf2f2ff, roughness: 0.85, metalness: 0.03 });
  const redPip = new THREE.MeshStandardMaterial({ color: 0xd6263d, roughness: 0.7 });
  const stacks = [[-0.92, 1.08, chipMatA],[-0.38, 1.18, chipMatB],[0.42, 1.14, chipMatA],[0.95, 1.0, chipMatB]];
  for (const [x, z, mat] of stacks){
    for (let i = 0; i < 6; i++){
      const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.018, 24), mat);
      chip.position.set(x, 0.846 + i * 0.02, z - 0.19);
      chip.rotation.x = Math.PI / 2;
      chip.castShadow = true;
      chip.receiveShadow = true;
      group.add(chip);
    }
  }
  for (let i = 0; i < 5; i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.004, 0.18), cardMat);
    card.position.set(-0.3 + i * 0.15, 0.844, -0.03 + (i % 2) * 0.01);
    card.rotation.y = -0.18 + i * 0.09;
    card.castShadow = true;
    card.receiveShadow = true;
    group.add(card);
    const pip = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.002, 0.018), redPip);
    pip.position.copy(card.position).add(new THREE.Vector3(0.034, 0.004, 0.055));
    group.add(pip);
  }
  scene.add(group);
}
function applyEricMaterial(obj, texture, normalTex){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    child.material = new THREE.MeshStandardMaterial({
      map: texture || null,
      normalMap: normalTex || null,
      color: texture ? 0xffffff : 0xd6d4e8,
      roughness: 0.68,
      metalness: 0.02,
      emissive: 0x0d0914,
      emissiveIntensity: 0.06,
      side: THREE.DoubleSide,
      skinning: !!child.isSkinnedMesh
    });
    child.frustumCulled = false;
  });
}
function applyClaudiaMaterial(obj, texture){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    child.material = new THREE.MeshStandardMaterial({
      map: texture || null,
      color: texture ? 0xffffff : 0xe6e6f2,
      roughness: 0.72,
      metalness: 0.02,
      emissive: 0x0b0d18,
      emissiveIntensity: 0.05,
      side: THREE.DoubleSide,
      skinning: !!child.isSkinnedMesh,
      alphaTest: 0.1
    });
    child.frustumCulled = false;
  });
}
function touchModelShadows(obj){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    if (!Array.isArray(child.material) && child.material) child.material.side = THREE.DoubleSide;
    child.frustumCulled = false;
  });
}
export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const R = CONFIG.ROOM_RADIUS;
  const H = CONFIG.WALL_HEIGHT;
  scene.fog = new THREE.FogExp2(0x010105, 0.0068);
  const hemi = new THREE.HemisphereLight(0xcfd8ff, 0x03060d, 1.05);
  scene.add(hemi);
  const key = new THREE.DirectionalLight(0xf8fbff, 3.7);
  key.position.set(16, 28, 12);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.left = -24;
  key.shadow.camera.right = 24;
  key.shadow.camera.top = 24;
  key.shadow.camera.bottom = -24;
  scene.add(key);
  const tableSpot = new THREE.SpotLight(0xf8fbff, 10.6, 120, Math.PI * 0.28, 0.28, 1.02);
  tableSpot.position.set(0, 15, 4);
  tableSpot.target.position.set(0, 0.8, 0);
  tableSpot.castShadow = true;
  scene.add(tableSpot);
  scene.add(tableSpot.target);
  const fill = new THREE.PointLight(0x6ea4ff, 4.2, 180, 1.8);
  fill.position.set(0, 10.2, 0);
  scene.add(fill);
  const rimLight = new THREE.PointLight(0x4d86ff, 3.8, 240, 1.9);
  rimLight.position.set(20, 18, -34);
  scene.add(rimLight);

  const floorTex = await loadFirstTexture(assetUrls("texture/slate_basecolor.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const floorNormal = await loadFirstTexture(assetUrls("texture/slate_normal.png"));
  const floorRough = await loadFirstTexture(assetUrls("texture/slate_roughness.jpg"));
  [floorTex, floorNormal, floorRough].forEach(tex=>{ if (tex){ tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(38,38); } });
  const wallTex = await loadFirstTexture(assetUrls("texture/stonebrick_wall_basecolor.png"), { colorSpace: THREE.SRGBColorSpace });
  const wallNormal = await loadFirstTexture(assetUrls("texture/stonebrick_wall_normal.png"));
  const wallRough = await loadFirstTexture(assetUrls("texture/stonebrick_wall_roughness.png"));
  [wallTex, wallNormal, wallRough].forEach(tex=>{ if (tex){ tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(18,4.2); } });

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(R + 34, 220),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.9,
      metalness: 0.03,
      map: floorTex || null,
      normalMap: floorNormal || null,
      normalScale: new THREE.Vector2(0.38, 0.38),
      roughnessMap: floorRough || null
    })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const wallHeight = H * 0.48;
  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, wallHeight, 220, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.84,
      metalness: 0.04,
      emissive: 0x143154,
      emissiveIntensity: 0.18,
      side: THREE.BackSide,
      map: wallTex || null,
      normalMap: wallNormal || null,
      normalScale: new THREE.Vector2(0.36, 0.36),
      roughnessMap: wallRough || null
    })
  );
  wall.position.set(0, wallHeight / 2, 0);
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(R - 1.2, 0.18, 16, 220),
    new THREE.MeshStandardMaterial({
      color: 0xb48cff,
      roughness: 0.2,
      metalness: 0.35,
      emissive: 0x2a0d3a,
      emissiveIntensity: 1.45
    })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.set(0, wallHeight - 0.18, 0);
  scene.add(rim);

  const innerPlatform = new THREE.Mesh(
    new THREE.CylinderGeometry(8.8, 9.2, 0.3, 96),
    new THREE.MeshStandardMaterial({
      color: 0x14121b,
      roughness: 0.78,
      metalness: 0.12,
      emissive: 0x12061c,
      emissiveIntensity: 0.12
    })
  );
  innerPlatform.position.y = 0.15;
  innerPlatform.receiveShadow = true;
  scene.add(innerPlatform);

  const city = buildOuterCity(scene, R);
  const stars = buildStars(scene, R);
  const spawnLogoTex = await loadFirstTexture(assetUrls("ui/logo.png", "logo.png"), { colorSpace: THREE.SRGBColorSpace });
  const wallPanels = [];
  const wallPanelUpdaters = [];
  [
    { angle: Math.PI, label: "NORTH SPAWN" },
    { angle: 0, label: "SOUTH SPAWN" },
    { angle: -Math.PI * 0.5, label: "EAST SPAWN" },
    { angle: Math.PI * 0.5, label: "WEST SPAWN" }
  ].forEach(({ angle, label })=>{
    const matrix = createMatrixBillboardTexture();
    wallPanelUpdaters.push(matrix.update);
    const panel = new THREE.Mesh(
      new THREE.PlaneGeometry(6.6, 9.4),
      new THREE.MeshBasicMaterial({ map: matrix.texture, transparent: true, side: THREE.DoubleSide })
    );
    const rr = R - 0.32;
    panel.position.set(Math.cos(angle) * rr, 8.1, Math.sin(angle) * rr);
    panel.lookAt(0, 8.1, 0);
    scene.add(panel);
    wallPanels.push(panel);
    if (spawnLogoTex){
      const logo = new THREE.Mesh(
        new THREE.PlaneGeometry(2.15, 2.15),
        new THREE.MeshBasicMaterial({ map: spawnLogoTex, transparent: true, side: THREE.DoubleSide })
      );
      logo.position.copy(panel.position).add(new THREE.Vector3(0, 1.2, 0));
      logo.lookAt(0, 8.1, 0);
      scene.add(logo);
      wallPanels.push(logo);
    }
  });

  const moonTex = await loadFirstTexture(assetUrls("texture/moon_diffuse.png"), { colorSpace: THREE.SRGBColorSpace });
  const moonBump = await loadFirstTexture(assetUrls("texture/moon_bump.png"));
  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(9.6, 48, 48),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.94,
      metalness: 0.0,
      map: makeEarthTexture(),
      emissive: 0x2c7cff,
      emissiveIntensity: 1.82
    })
  );
  earth.position.set(18, 236, -(R + 104));
  earth.rotation.z = 0.35;
  scene.add(earth);
  const earthHalo = createOrbHaloSprite(0x6bc4ff, 0.34);
  earthHalo.scale.set(38, 38, 1);
  scene.add(earthHalo);
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(6.2, 40, 40),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 1.0,
      metalness: 0.0,
      map: moonTex || null,
      bumpMap: moonBump || null,
      bumpScale: moonBump ? 0.2 : 0,
      emissive: 0x7089d6,
      emissiveIntensity: 1.46
    })
  );
  moon.position.set(42, 248, -(R + 96));
  scene.add(moon);
  const moonHalo = createOrbHaloSprite(0xf4f7ff, 0.28);
  moonHalo.scale.set(24, 24, 1);
  scene.add(moonHalo);
  const earthSpark = new THREE.Group();
  for (let i = 0; i < 14; i++){
    const spr = createOrbHaloSprite(i % 2 ? 0x79d8ff : 0xffffff, 0.34);
    spr.scale.setScalar(1.8 + (i % 3) * 0.7);
    earthSpark.add(spr);
  }
  scene.add(earthSpark);
  const moonSpark = new THREE.Group();
  for (let i = 0; i < 10; i++){
    const spr = createOrbHaloSprite(i % 2 ? 0xfefefe : 0xbcd3ff, 0.30);
    spr.scale.setScalar(1.2 + (i % 3) * 0.5);
    moonSpark.add(spr);
  }
  scene.add(moonSpark);
  const earthGlow = new THREE.PointLight(0x70c8ff, 34.0, 420, 1.45);
  scene.add(earthGlow);
  const moonGlow = new THREE.PointLight(0xfaf8ff, 29.0, 400, 1.45);
  scene.add(moonGlow);
  const skylineGlow = new THREE.PointLight(0x3b74ff, 8.4, 330, 1.8);
  skylineGlow.position.set(0, 26, -(R + 8));
  scene.add(skylineGlow);
  const accentGlow = new THREE.PointLight(0x92c2ff, 3.8, 110, 2.0);
  accentGlow.position.set(-9, 8, 7);
  scene.add(accentGlow);
  const atmosphereGlow = new THREE.Mesh(
    new THREE.SphereGeometry(R + 18, 42, 42),
    new THREE.MeshBasicMaterial({ color: 0x0a1f3f, transparent: true, opacity: 0.0, side: THREE.BackSide })
  );
  scene.add(atmosphereGlow);
  const haze = new THREE.Mesh(
    new THREE.CylinderGeometry(14, 22, 6, 64, 1, true),
    new THREE.MeshBasicMaterial({ color: 0x251138, transparent: true, opacity: 0.0, side: THREE.DoubleSide })
  );
  haze.position.y = 3.5;
  scene.add(haze);

  const chairTex = makeChairTexture();
  chairTex.repeat.set(2,2);
  const chairMat = new THREE.MeshStandardMaterial({ map: chairTex, color: 0xffffff, roughness: 0.62, metalness: 0.12, emissive: 0x12081a, emissiveIntensity: 0.10 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x272a31, roughness: 0.35, metalness: 0.55, emissive: 0x0e1016, emissiveIntensity: 0.08 });
  const seatRadius = 3.15;
  const seats = [
    makeSeat(scene, 0,  seatRadius, Math.PI, "Front Center", chairMat, metalMat),
    makeSeat(scene, -2.6, 1.68, Math.PI * 0.72, "Front Left", chairMat, metalMat),
    makeSeat(scene,  2.6, 1.68, -Math.PI * 0.72, "Front Right", chairMat, metalMat),
    makeSeat(scene, -2.6, -1.68, Math.PI * 0.28, "Back Left", chairMat, metalMat),
    makeSeat(scene,  2.6, -1.68, -Math.PI * 0.28, "Back Right", chairMat, metalMat),
    makeSeat(scene, 0, -seatRadius, 0, "Dealer Side", chairMat, metalMat)
  ];

  const table = await tryLoadGLTF(assetUrls("models/table.glb"), log, 10000) || await tryLoadFBX(assetUrls("models/table.fbx"), log, 10000);
  if (table){
    touchModelShadows(table);
    scaleToHeight(table, 0.96);
    dropToGround(table);
    fitDiameter(table, 3.25);
    dropToGround(table);
    table.position.set(0, 0, 0);
    scene.add(table);
  }
  const feltMap = await loadFirstTexture(assetUrls("texture/tablefelt.png"), { colorSpace: THREE.SRGBColorSpace });
  if (feltMap){
    feltMap.wrapS = feltMap.wrapT = THREE.ClampToEdgeWrapping;
    const feltTop = new THREE.Mesh(
      new THREE.CylinderGeometry(1.22, 1.27, 0.012, 80),
      new THREE.MeshStandardMaterial({ color: 0xffffff, map: feltMap, roughness: 0.84, metalness: 0.02 })
    );
    feltTop.position.y = 0.807;
    feltTop.receiveShadow = true;
    feltTop.castShadow = true;
    scene.add(feltTop);
  }
  addChipsAndCards(scene);

  const ericTex = await loadFirstTexture(assetUrls("models/eric/rp_eric_rigged_001_dif.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const ericNorm = await loadFirstTexture(assetUrls("models/eric/rp_eric_rigged_001_norm.jpg"));
  const eric = await tryLoadFBX(assetUrls("models/eric/eric.fbx"), log, 12000);
  if (eric){
    applyEricMaterial(eric, ericTex, ericNorm);
    scaleToHeight(eric, 1.78);
    dropToGround(eric);
    eric.position.set(0.0, 0, -2.42);
    eric.rotation.y = Math.PI;
    scene.add(eric);
  }

  let claudia = null;
  let claudiaAnchor = null;
  let claudiaMixer = null;
  const claudiaTex = await loadFirstTexture(assetUrls("models/claudia/rp_claudia_rigged_002_dif.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const claudiaWalkSrc = await tryLoadFBX(assetUrls("models/claudia/walking.fbx"), log, 14000);
  const claudiaBase = await tryLoadFBX(assetUrls("models/claudia/claudia.fbx"), log, 14000);
  if (claudiaWalkSrc || claudiaBase){
    claudia = claudiaWalkSrc || claudiaBase;
    applyClaudiaMaterial(claudia, claudiaTex);
    orientCharacterUpright(claudia);
    scaleToHeight(claudia, 1.18);
    dropToGround(claudia);
    const cb = boxSize(claudia).box;
    claudia.position.set(0, -cb.min.y + 0.02, 0);
    claudiaAnchor = new THREE.Group();
    claudiaAnchor.position.set(4.0, 0, 2.2);
    claudiaAnchor.rotation.y = Math.PI * 0.85;
    claudiaAnchor.add(claudia);
    scene.add(claudiaAnchor);
    const clips = [];
    if (claudiaWalkSrc?.animations?.length) clips.push(...claudiaWalkSrc.animations);
    else if (claudia.animations?.length) clips.push(...claudia.animations);
    if (clips.length){
      claudiaMixer = new THREE.AnimationMixer(claudia);
      const clip = clips[0];
      const action = claudiaMixer.clipAction(clip, claudia);
      action.enabled = true;
      action.setEffectiveWeight(1);
      action.play();
    }
  }

  scene.userData._tickWorld = (dt)=>{
    scene.userData._time = (scene.userData._time || 0) + dt;
    const t = scene.userData._time;
    earth.rotation.y += dt * 0.042;
    earth.rotation.z = 0.22 + Math.sin(t * 0.08) * 0.02;
    earth.position.x = 18 + Math.cos(t * 0.012) * 6.0;
    earth.position.z = -(R + 108) + Math.sin(t * 0.012) * 2.2;
    earth.position.y = 236 + Math.sin(t * 0.010) * 1.2;
    const orbitA = t * 0.062;
    const moonNear = 26 + Math.sin(t * 0.14) * 10.0;
    moon.position.set(
      earth.position.x + Math.cos(orbitA) * moonNear,
      earth.position.y + 12 + Math.sin(orbitA * 1.1) * 10.0,
      earth.position.z + Math.sin(orbitA) * (20 + Math.cos(t * 0.14) * 12.0)
    );
    moon.rotation.y += dt * 0.034;
    moonGlow.position.copy(moon.position).add(new THREE.Vector3(8, 0, 10));
    moonHalo.position.copy(moon.position);
    earthGlow.position.copy(earth.position).add(new THREE.Vector3(0, 0, 16));
    earthHalo.position.copy(earth.position);
    earthSpark.children.forEach((spr, i)=>{
      const a = t * 0.6 + i * 0.45;
      spr.position.set(
        earth.position.x + Math.cos(a) * (10.8 + (i % 3) * 0.8),
        earth.position.y + Math.sin(a * 1.2) * 2.4,
        earth.position.z + Math.sin(a) * (8.8 + (i % 4) * 0.7)
      );
    });
    moonSpark.children.forEach((spr, i)=>{
      const a = t * 0.75 + i * 0.6;
      spr.position.set(
        moon.position.x + Math.cos(a) * (6.2 + (i % 3) * 0.5),
        moon.position.y + Math.sin(a * 1.1) * 1.8,
        moon.position.z + Math.sin(a) * (5.4 + (i % 2) * 0.5)
      );
    });
    rim.material.emissiveIntensity = 1.25 + Math.sin(t * 1.2) * 0.22;
    seats.forEach((seat, i)=>{ seat.ring.material.opacity = 0.56 + Math.sin(t * 1.8 + i * 0.8) * 0.14; });
    stars.spriteGroup.rotation.y += dt * 0.0018;
    stars.pts.material.opacity = 0.86 + Math.sin(t * 0.5) * 0.04;
    city.billboardUpdaters.forEach(fn=>fn(t));
    wallPanelUpdaters.forEach(fn=>fn(t));
    if (claudiaMixer) claudiaMixer.update(dt);
    if (claudiaAnchor && claudia){
      const a = t * 0.24;
      const pathX = 4.4 + Math.sin(a) * 0.9;
      const pathZ = 2.4 + Math.cos(a * 0.92) * 0.7;
      claudiaAnchor.position.set(pathX, 0, pathZ);
      claudiaAnchor.rotation.y = Math.atan2(Math.cos(a * 0.92) * -1.0 * 0.92, Math.cos(a) * 0.9) - Math.PI * 0.5;
      claudia.position.y = Math.max(claudia.position.y, 0.02);
    }
  };

  return {
    roomClamp: R - 2.5,
    tableCenter: new THREE.Vector3(0, 0, 0),
    seats,
    joinRadius: 6.3,
    previewOrbitRadius: 15.5
  };
}
