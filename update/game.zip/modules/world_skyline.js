import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { OBJLoader } from "three/addons/loaders/OBJLoader.js";
import { CONFIG } from "./config.js";
import { assetUrls, loadFirstTexture } from "./asset_base.js";

function delay(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }
async function withTimeout(promise, ms){
  return await Promise.race([
    promise,
    (async()=>{ await delay(ms); throw new Error("timeout"); })()
  ]);
}
function boxSize(obj){
  const box = new THREE.Box3();
  const tempBox = new THREE.Box3();
  const tempPos = new THREE.Vector3();
  let foundMesh = false;
  obj.updateMatrixWorld(true);
  obj.traverse((child)=>{
    if (!child.isMesh || !child.geometry) return;
    const geom = child.geometry;
    if (!geom.boundingBox) geom.computeBoundingBox();
    if (!geom.boundingBox) return;
    tempBox.copy(geom.boundingBox).applyMatrix4(child.matrixWorld);
    if (!foundMesh){
      box.copy(tempBox);
      foundMesh = true;
    } else {
      box.union(tempBox);
    }
  });
  if (!foundMesh) box.setFromObject(obj);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  return { size, center, box };
}
function dropToGround(obj){
  const { size, center } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - center.y;
}
function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}
function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia = Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

function orientCharacterUpright(obj){
  const trials = [
    [0,0,0],
    [-Math.PI*0.5,0,0],
    [Math.PI*0.5,0,0],
    [0,0,Math.PI*0.5],
    [0,0,-Math.PI*0.5],
    [0,Math.PI,0],
    [-Math.PI*0.5,Math.PI,0],
    [Math.PI*0.5,Math.PI,0],
    [0,Math.PI,Math.PI*0.5],
    [0,Math.PI,-Math.PI*0.5]
  ];
  const original = obj.rotation.clone();
  let best = { score: -Infinity, rot: original.clone() };
  for (const [rx,ry,rz] of trials){
    obj.rotation.set(rx,ry,rz);
    obj.updateMatrixWorld(true);
    const { size } = boxSize(obj);
    const score = size.y - Math.max(size.x, size.z) * 0.25;
    if (Number.isFinite(score) && score > best.score){
      best = { score, rot: obj.rotation.clone() };
    }
  }
  obj.rotation.copy(best.rot);
  obj.updateMatrixWorld(true);
}
async function tryLoadGLTF(urls, log, timeoutMs = 12000){
  const loader = new GLTFLoader();
  for (const url of urls){
    try{
      const gltf = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded GLTF:", url);
      return gltf.scene;
    }catch(_err){ log("GLTF miss:", url); }
  }
  return null;
}
async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const fbx = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded FBX:", url);
      return fbx;
    }catch(_err){ log("FBX miss:", url); }
  }
  return null;
}

async function tryLoadOBJ(urls, log, timeoutMs = 12000){
  const loader = new OBJLoader();
  for (const url of urls){
    try{
      const obj = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded OBJ:", url);
      return obj;
    }catch(_err){ log("OBJ miss:", url); }
  }
  return null;
}
function canvasTexture(width, height, painter){
  const c = document.createElement("canvas");
  c.width = width; c.height = height;
  const x = c.getContext("2d");
  painter(x, width, height, c);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  return tex;
}
function makeSpriteTexture(){
  return canvasTexture(128, 128, (x,w,h)=>{
    const g = x.createRadialGradient(w/2,h/2,3,w/2,h/2,58);
    g.addColorStop(0,"rgba(255,255,255,1)");
    g.addColorStop(0.18,"rgba(220,230,255,0.95)");
    g.addColorStop(0.42,"rgba(180,140,255,0.26)");
    g.addColorStop(1,"rgba(180,140,255,0)");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
  });
}
function makeEarthTexture(){
  return canvasTexture(1024, 512, (x,w,h)=>{
    x.fillStyle = "#0a2c60";
    x.fillRect(0,0,w,h);
    for (let i = 0; i < 68; i++){
      x.fillStyle = `rgba(${20 + Math.random()*40|0}, ${90 + Math.random()*90|0}, ${60 + Math.random()*60|0}, ${0.55 + Math.random()*0.25})`;
      x.beginPath();
      x.ellipse(Math.random()*w, Math.random()*h, 40+Math.random()*130, 18+Math.random()*75, Math.random()*Math.PI, 0, Math.PI*2);
      x.fill();
    }
    x.fillStyle = "rgba(255,255,255,0.22)";
    for (let i = 0; i < 24; i++){
      x.beginPath();
      x.ellipse(Math.random()*w, Math.random()*h, 60+Math.random()*180, 15+Math.random()*40, Math.random()*Math.PI, 0, Math.PI*2);
      x.fill();
    }
  });
}
function makeWoodTexture(){
  return canvasTexture(1024, 256, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,0,h);
    g.addColorStop(0,"#5f381c");
    g.addColorStop(1,"#2a160d");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    for (let i=0;i<180;i++){
      x.strokeStyle = `rgba(${120+Math.random()*80|0},${70+Math.random()*35|0},${35+Math.random()*20|0},0.22)`;
      x.beginPath();
      const yy = Math.random()*h;
      x.moveTo(0,yy);
      x.bezierCurveTo(w*0.25, yy+Math.random()*18-9, w*0.75, yy+Math.random()*18-9, w, yy+Math.random()*12-6);
      x.stroke();
    }
  });
}
function makeChairTexture(){
  return canvasTexture(512, 512, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0,"#2c1a34");
    g.addColorStop(1,"#17111f");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(255,255,255,0.08)";
    x.lineWidth = 2;
    for (let i=0;i<24;i++){
      x.beginPath();
      x.moveTo(0, i*(h/24));
      x.lineTo(w, i*(h/24));
      x.stroke();
    }
  });
}

function makePillShape(w, h, r){
  const hw = w * 0.5;
  const hh = h * 0.5;
  const cr = Math.min(r, hw * 0.98, hh * 0.98);
  const shape = new THREE.Shape();
  shape.moveTo(-hw + cr, -hh);
  shape.lineTo(hw - cr, -hh);
  shape.absarc(hw - cr, -hh + cr, cr, -Math.PI * 0.5, 0, false);
  shape.lineTo(hw, hh - cr);
  shape.absarc(hw - cr, hh - cr, cr, 0, Math.PI * 0.5, false);
  shape.lineTo(-hw + cr, hh);
  shape.absarc(-hw + cr, hh - cr, cr, Math.PI * 0.5, Math.PI, false);
  shape.lineTo(-hw, -hh + cr);
  shape.absarc(-hw + cr, -hh + cr, cr, Math.PI, Math.PI * 1.5, false);
  return shape;
}

function createStablePokerTable(scene, tableTopY = 0.90, feltTex = null){
  const group = new THREE.Group();
  const topShape = makePillShape(4.18, 2.72, 0.92);
  const railShape = makePillShape(4.62, 3.10, 1.02);
  const hole = makePillShape(4.02, 2.56, 0.86);
  railShape.holes.push(hole);

  const railGeo = new THREE.ExtrudeGeometry(railShape, { depth: 0.18, bevelEnabled: false, curveSegments: 32 });
  railGeo.rotateX(-Math.PI * 0.5);
  railGeo.translate(0, tableTopY - 0.09, 0);
  const railMat = new THREE.MeshStandardMaterial({ color: 0x3a2518, roughness: 0.78, metalness: 0.06, emissive: 0x090607, emissiveIntensity: 0.06 });
  const rail = new THREE.Mesh(railGeo, railMat);
  group.add(rail);

  const feltGeo = new THREE.ShapeGeometry(topShape, 48);
  feltGeo.rotateX(-Math.PI * 0.5);
  feltGeo.translate(0, tableTopY, 0);
  const feltMat = new THREE.MeshStandardMaterial({
    map: feltTex || null,
    color: feltTex ? 0xffffff : 0x6a1d86,
    roughness: 0.92,
    metalness: 0.0,
    emissive: 0x16061c,
    emissiveIntensity: 0.04,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1
  });
  const felt = new THREE.Mesh(feltGeo, feltMat);
  felt.renderOrder = 6;
  group.add(felt);

  const lip = new THREE.Mesh(
    new THREE.TorusGeometry(1.95, 0.055, 14, 80),
    new THREE.MeshStandardMaterial({ color: 0x3a2518, roughness: 0.56, metalness: 0.08, emissive: 0x0c0810, emissiveIntensity: 0.02 })
  );
  lip.rotation.x = Math.PI * 0.5;
  lip.scale.set(1.0, 1.0, 0.70);
  lip.position.y = tableTopY + 0.005;
  group.add(lip);

  const pedestal = new THREE.Mesh(
    new THREE.CylinderGeometry(0.58, 0.76, tableTopY - 0.11, 28),
    new THREE.MeshStandardMaterial({ color: 0x1d1823, roughness: 0.88, metalness: 0.04, emissive: 0x08070c, emissiveIntensity: 0.02 })
  );
  pedestal.position.y = (tableTopY - 0.11) * 0.5;
  group.add(pedestal);

  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(1.22, 1.36, 0.11, 36),
    new THREE.MeshStandardMaterial({ color: 0x18131f, roughness: 0.82, metalness: 0.06, emissive: 0x06060b, emissiveIntensity: 0.02 })
  );
  base.position.y = 0.055;
  group.add(base);

  scene.add(group);
  return { group, topY: tableTopY };
}


function findPlayableFeltMesh(table){
  let best = null;
  table.updateMatrixWorld(true);
  const box = new THREE.Box3();
  const size = new THREE.Vector3();
  table.traverse((child)=>{
    if (!child.isMesh || child === keepMesh) return;
    const name = String(child.name || '').toLowerCase();
    let priority = 0;
    if (/circle005/.test(name)) priority = 3;
    else if (/object002/.test(name)) priority = 2;
    else if (/circle02/.test(name)) priority = 1;
    if (!priority) return;
    box.setFromObject(child);
    box.getSize(size);
    const area = size.x * size.z;
    if (!best || priority > best.priority || (priority === best.priority && area > best.area)) best = { mesh: child, priority, area };
  });
  return best?.mesh || null;
}

function findPlayableFeltSurface(table){
  const box = new THREE.Box3();
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  let best = null;
  table.updateMatrixWorld(true);
  table.traverse((child)=>{
    if (!child.isMesh || !child.visible) return;
    const name = String(child.name || '').toLowerCase();
    if (!(/circle005|object002|circle02/.test(name))) return;
    box.setFromObject(child); box.getSize(size); box.getCenter(center);
    const score = size.x * size.z;
    if (!best || score > best.score) best = { box: box.clone(), size: size.clone(), center: center.clone(), score };
  });
  return best;
}

function findTableTopSurface(table){
  const box = new THREE.Box3();
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  let best = null;
  table.updateMatrixWorld(true);
  table.traverse((child)=>{
    if (!child.isMesh || !child.visible) return;
    box.setFromObject(child); box.getSize(size); box.getCenter(center);
    const area = size.x * size.z;
    if (size.y > 0.22 || area < 0.8) return;
    if (!best || center.y > best.center.y || (Math.abs(center.y - best.center.y) < 0.05 && area > best.area)) best = { box: box.clone(), size: size.clone(), center: center.clone(), area };
  });
  return best;
}
async function createPreferredTable(scene, tableTopY = 0.90, feltTex = null, log = console.log){
  const realTable = await tryLoadGLTF(assetUrls("models/table.glb"), log, 12000) || await tryLoadFBX(assetUrls("models/table.fbx"), log, 12000);
  if (!realTable) return createStablePokerTable(scene, tableTopY, feltTex);

  const hideNames = /circle007|circle008|object002|object001|circle005|circle02/i;
  const railMat = new THREE.MeshStandardMaterial({ color: 0x3a2518, roughness: 0.78, metalness: 0.06, emissive: 0x090607, emissiveIntensity: 0.04, side: THREE.DoubleSide });
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x241c2d, roughness: 0.86, metalness: 0.04, emissive: 0x0f0a18, emissiveIntensity: 0.04, side: THREE.DoubleSide });
  realTable.traverse((child)=>{
    if (!child.isMesh) return;
    const name = String(child.name || "").toLowerCase();
    child.castShadow = false;
    child.receiveShadow = false;
    child.frustumCulled = false;
    if (hideNames.test(name)){
      child.visible = false;
      return;
    }
    child.material = (/circle006/.test(name) ? bodyMat : railMat).clone();
  });
  fitDiameter(realTable, 4.86);
  realTable.updateMatrixWorld(true);
  const bb = boxSize(realTable).box;
  realTable.position.set(-((bb.min.x + bb.max.x) * 0.5), tableTopY - bb.max.y, -((bb.min.z + bb.max.z) * 0.5));
  realTable.updateMatrixWorld(true);
  scene.add(realTable);

  const railShape = makePillShape(4.58, 3.04, 1.00);
  const railHole = makePillShape(4.02, 2.54, 0.84);
  railShape.holes.push(railHole);
  const railGeo = new THREE.ExtrudeGeometry(railShape, { depth: 0.16, bevelEnabled: false, curveSegments: 32 });
  railGeo.rotateX(-Math.PI * 0.5);
  railGeo.translate(0, tableTopY - 0.08, 0);
  const customRail = new THREE.Mesh(
    railGeo,
    new THREE.MeshStandardMaterial({ color: 0x3b2418, roughness: 0.78, metalness: 0.05, emissive: 0x0b0607, emissiveIntensity: 0.03 })
  );
  customRail.renderOrder = 6;
  scene.add(customRail);

  const innerW = 3.98;
  const innerH = 2.52;
  const feltShape = makePillShape(innerW, innerH, 0.84);
  const feltGeo = new THREE.ShapeGeometry(feltShape, 48);
  feltGeo.rotateX(-Math.PI * 0.5);
  feltGeo.translate(0, tableTopY + 0.012, 0);
  const feltMat = new THREE.MeshStandardMaterial({
    map: feltTex || null,
    color: feltTex ? 0xffffff : 0x6a1d86,
    roughness: 0.94,
    metalness: 0.0,
    emissive: 0x000000,
    emissiveIntensity: 0.0,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: -4,
    polygonOffsetUnits: -4
  });
  const felt = new THREE.Mesh(feltGeo, feltMat);
  felt.renderOrder = 10;
  scene.add(felt);
  return { group: realTable, topY: tableTopY, felt, customRail };
}

function buildStars(scene, R){
  const count = 5200;
  const pos = new Float32Array(count * 3);
  const col = new Float32Array(count * 3);
  for (let i = 0; i < count; i++){
    const rr = R + 95 + Math.random() * 220;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.48 + 0.02;
    pos[i*3+0] = Math.cos(theta) * Math.sin(phi) * rr;
    pos[i*3+1] = Math.cos(phi) * rr * 0.95 + 42;
    pos[i*3+2] = Math.sin(theta) * Math.sin(phi) * rr;
    const tint = 0.84 + Math.random() * 0.16;
    col[i*3+0] = tint;
    col[i*3+1] = 0.88 + Math.random() * 0.12;
    col[i*3+2] = 0.96 + Math.random() * 0.04;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({
    size: 0.10,
    sizeAttenuation: true,
    transparent: true,
    opacity: 1.0,
    map: makeSpriteTexture(),
    vertexColors: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  }));
  scene.add(pts);

  const spriteGroup = new THREE.Group();
  for (let i = 0; i < 180; i++){
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: makeSpriteTexture(),
      color: new THREE.Color(i % 7 === 0 ? 0xb48cff : 0xffffff),
      transparent: true,
      opacity: 0.28 + Math.random() * 0.18,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    }));
    spr.scale.setScalar(0.028 + Math.random() * 0.09);
    const rr = R + 110 + Math.random() * 180;
    const theta = Math.random() * Math.PI * 2;
    const y = 55 + Math.random() * 120;
    spr.position.set(Math.cos(theta) * rr, y, Math.sin(theta) * rr);
    spriteGroup.add(spr);
  }
  scene.add(spriteGroup);
  return { pts, spriteGroup };
}
function buildLobbySprites(scene, R, wallHeight){
  const group = new THREE.Group();
  const colors = [0xe67cff, 0xff77d7, 0x86e3ff, 0xc08dff];
  for (let i = 0; i < 16; i++){
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: makeSpriteTexture(),
      color: colors[i % colors.length],
      transparent: true,
      opacity: 0.34 + Math.random() * 0.18,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    }));
    const ang = (i / 26) * Math.PI * 2;
    const rad = R * (0.34 + Math.random() * 0.10);
    const s = 0.35 + Math.random() * 0.95;
    spr.scale.set(s, s, 1);
    spr.position.set(Math.cos(ang) * rad, wallHeight * 0.22 + Math.random() * 2.4, Math.sin(ang) * rad);
    spr.userData.baseY = spr.position.y;
    spr.userData.phase = Math.random() * Math.PI * 2;
    group.add(spr);
  }
  scene.add(group);
  return group;
}

async function addRikiArea(scene, R, wallHeight, spawnLogoTex, log = console.log){
  const angle = 0;
  const inward = new THREE.Vector3(-Math.cos(angle), 0, -Math.sin(angle));
  const right = new THREE.Vector3(Math.sin(angle), 0, -Math.cos(angle));
  const center = new THREE.Vector3(Math.cos(angle) * (R - 6.1), 0.01, Math.sin(angle) * (R - 6.1));
  const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xbdeeff, transparent: true, opacity: 0.17, roughness: 0.05, metalness: 0.0, transmission: 0.76, side: THREE.DoubleSide });
  const roomW = 6.6, roomD = 4.4, roomH = 3.2;
  const front = new THREE.Mesh(new THREE.PlaneGeometry(roomW, roomH), glassMat);
  front.position.copy(center).addScaledVector(inward, 2.05).add(new THREE.Vector3(0, roomH * 0.5, 0));
  front.lookAt(center.x, roomH * 0.5, center.z);
  scene.add(front);
  const back = new THREE.Mesh(new THREE.PlaneGeometry(roomW, roomH), glassMat);
  back.position.copy(center).addScaledVector(inward, -1.95).add(new THREE.Vector3(0, roomH * 0.5, 0));
  back.lookAt(0, roomH * 0.5, 0);
  scene.add(back);
  for (const s of [-1,1]){
    const side = new THREE.Mesh(new THREE.PlaneGeometry(roomD, roomH), glassMat);
    side.position.copy(center).addScaledVector(right, s * (roomW * 0.5)).addScaledVector(inward, 0.05).add(new THREE.Vector3(0, roomH * 0.5, 0));
    side.lookAt(side.position.clone().addScaledVector(right, s));
    scene.add(side);
  }
  const roof = new THREE.Mesh(new THREE.PlaneGeometry(roomW, roomD), glassMat);
  roof.rotation.x = -Math.PI * 0.5;
  roof.position.copy(center).add(new THREE.Vector3(0, roomH, 0.05));
  scene.add(roof);

  const carpet = new THREE.Mesh(new THREE.PlaneGeometry(5.2, 3.0), new THREE.MeshStandardMaterial({ color: 0x8d1024, roughness: 0.94, metalness: 0.02, emissive: 0x30060d, emissiveIntensity: 0.24, side: THREE.DoubleSide }));
  carpet.rotation.x = -Math.PI * 0.5;
  carpet.position.copy(center).addScaledVector(inward, 0.20).add(new THREE.Vector3(0, 0.002, 0));
  scene.add(carpet);
  const walk = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 2.6), new THREE.MeshStandardMaterial({ color: 0xa8132a, roughness: 0.92, metalness: 0.01, emissive: 0x450914, emissiveIntensity: 0.15, side: THREE.DoubleSide }));
  walk.rotation.x = -Math.PI * 0.5;
  walk.position.copy(center).addScaledVector(inward, 0.35).add(new THREE.Vector3(0, 0.004, 0));
  scene.add(walk);

  const ropeMat = new THREE.MeshStandardMaterial({ color: 0xb81c31, roughness: 0.8, metalness: 0.06 });
  const postMat = new THREE.MeshStandardMaterial({ color: 0xd0c3d3, roughness: 0.28, metalness: 0.76 });
  const ropeOffsets = [-2.2, -1.0, 1.0, 2.2];
  ropeOffsets.forEach((ox)=>{
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.045,0.05,0.9,14), postMat);
    post.position.copy(center).addScaledVector(right, ox).addScaledVector(inward, 1.15).add(new THREE.Vector3(0,0.45,0));
    scene.add(post);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.065, 12, 12), postMat);
    head.position.copy(post.position).add(new THREE.Vector3(0,0.46,0));
    scene.add(head);
  });
  [[-2.2,-1.0],[-1.0,1.0],[1.0,2.2]].forEach(([a,b])=>{
    const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.024,0.024,Math.abs(b-a),12), ropeMat);
    rope.rotation.z = Math.PI * 0.5;
    rope.position.copy(center).addScaledVector(right, (a+b)*0.5).addScaledVector(inward, 1.15).add(new THREE.Vector3(0,0.84,0));
    scene.add(rope);
  });

  const signTex = createSponsorPlateTexture('REIKI MASTER ROOM', 'RESERVED FOR S.R.');
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 1.15), new THREE.MeshBasicMaterial({ map: signTex, transparent: true, side: THREE.DoubleSide, depthWrite: false }));
  sign.position.copy(front.position).addScaledVector(inward, -0.03).add(new THREE.Vector3(0, 0.62, 0));
  sign.lookAt(center.x, sign.position.y, center.z);
  scene.add(sign);
  if (spawnLogoTex){
    const logo = new THREE.Mesh(new THREE.PlaneGeometry(1.22, 1.22), new THREE.MeshBasicMaterial({ map: spawnLogoTex, transparent: true, side: THREE.DoubleSide, depthWrite: false }));
    logo.position.copy(sign.position).add(new THREE.Vector3(0, 0.80, 0));
    logo.lookAt(center.x, logo.position.y, center.z);
    scene.add(logo);
  }

  const plantRoot = await tryLoadOBJ(assetUrls('models/riki/plant/indoor_plant.obj'), log, 12000);
  const plantCol = await loadFirstTexture(assetUrls('models/riki/plant/plant_col.jpg'), { colorSpace: THREE.SRGBColorSpace });
  const plantNor = await loadFirstTexture(assetUrls('models/riki/plant/plant_nor.jpg'));
  if (plantRoot){
    plantRoot.traverse((child)=>{
      if (!child.isMesh) return;
      child.castShadow = false;
      child.receiveShadow = false;
      child.frustumCulled = false;
      const nm = String(child.material?.name || child.name || '').toLowerCase();
      if (nm.includes('pot')) child.material = new THREE.MeshStandardMaterial({ color: 0x3c1620, roughness: 0.88, metalness: 0.02, emissive: 0x17060b, emissiveIntensity: 0.10 });
      else child.material = new THREE.MeshStandardMaterial({ map: plantCol || null, normalMap: plantNor || null, color: 0xffffff, roughness: 0.92, metalness: 0.0, side: THREE.DoubleSide });
    });
    const placements = [
      [-2.0,0.95],[-1.2,0.9],[1.2,0.9],[2.0,0.95],
      [-2.0,-0.8],[-1.2,-0.9],[1.2,-0.9],[2.0,-0.8],
      [-2.4,1.8],[2.4,1.8],[-2.4,-1.6],[2.4,-1.6]
    ];
    placements.forEach(([ox,oz], idx)=>{
      const plant = plantRoot.clone(true);
      scaleToHeight(plant, 1.45 + (idx % 3) * 0.12);
      dropToGround(plant);
      plant.position.copy(center).addScaledVector(right, ox).addScaledVector(inward, oz);
      plant.rotation.y = angle + Math.PI + (idx % 2 ? 0.12 : -0.08);
      scene.add(plant);
    });
  }
}
function createOrbHaloSprite(color = 0xffffff, opacity = 0.5){
  return new THREE.Sprite(new THREE.SpriteMaterial({
    map: makeSpriteTexture(),
    color,
    transparent: true,
    opacity,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  }));
}
function createMatrixBillboardTexture(variant = "main"){
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 1536;
  const ctx = canvas.getContext("2d");
  const glyphs = "0101SVRPOKERALLIN0101011010010110";
  const phrases = variant === "main"
    ? ["SCARLETT VR POKER", "ALL IN", "SPONSOR READY", "DONOR NATION", "WIN MONEY"]
    : ["RESERVED FOR SPONSOR", "BINARY RAIN ACTIVE", "SCARLETT VR POKER"];
  const cols = Array.from({ length: 60 }, (_, i)=>({ x: 12 + i * 17, y: Math.random() * canvas.height, speed: 9 + (i % 7) }));
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  let lastT = -999;
  function redraw(t = 0){
    if (t - lastT < 0.08) return;
    lastT = t;
    ctx.clearRect(0,0,canvas.width,canvas.height);
    const bg = ctx.createLinearGradient(0,0,0,canvas.height);
    bg.addColorStop(0, "rgba(5,0,12,0.98)");
    bg.addColorStop(1, "rgba(1,2,8,1.0)");
    ctx.fillStyle = bg;
    ctx.fillRect(0,0,canvas.width,canvas.height);

    ctx.font = "bold 22px monospace";
    cols.forEach((c, i)=>{
      const phase = Math.floor(t * 22 + i * 5);
      for (let j = 0; j < 96; j++){
        const yy = (c.y + j * 18) % (canvas.height + 160) - 80;
        const char = glyphs[(phase + j + i * 3) % glyphs.length];
        const hot = j < 4;
        ctx.fillStyle = hot ? "rgba(255,245,255,0.98)" : (i % 2 ? "rgba(238,114,255,0.80)" : "rgba(118,204,255,0.82)");
        ctx.fillText(char, c.x, yy);
      }
      c.y += c.speed;
      if (c.y > canvas.height + 40) c.y = -Math.random() * 180;
    });

    const panelTop = variant === "main" ? 200 : 320;
    const panelH = variant === "main" ? 1080 : 860;
    ctx.fillStyle = "rgba(7,10,18,0.40)";
    ctx.fillRect(70, panelTop, canvas.width - 140, panelH);
    ctx.strokeStyle = "rgba(148,226,255,0.40)";
    ctx.lineWidth = 4;
    ctx.strokeRect(70, panelTop, canvas.width - 140, panelH);

    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    phrases.forEach((line, idx)=>{
      ctx.fillStyle = idx % 2 ? "rgba(202,144,255,0.98)" : "rgba(230,245,255,0.98)";
      ctx.font = idx === 0 ? "bold 62px system-ui, Arial" : "bold 42px system-ui, Arial";
      ctx.fillText(line, canvas.width / 2, panelTop + 130 + idx * 96);
    });
    tex.needsUpdate = true;
  }
  redraw(0);
  return { texture: tex, update: redraw };
}

function createSponsorPlateTexture(title = "MAIN SPONSOR SCREEN", subtitle = "SCARLETT VR POKER"){
  return canvasTexture(1024, 256, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0, "rgba(5,16,30,0.94)");
    g.addColorStop(1, "rgba(25,4,34,0.94)");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(130,210,255,0.95)";
    x.lineWidth = 8;
    x.strokeRect(10,10,w-20,h-20);
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.fillStyle = "#f2f7ff";
    x.font = "bold 56px system-ui, Arial";
    x.fillText(title, w/2, 92);
    x.fillStyle = "rgba(198,136,255,0.96)";
    x.font = "bold 34px system-ui, Arial";
    x.fillText(subtitle, w/2, 172);
  });
}
function createAdBillboardTexture(lines = ["SVRPOKER.COM", "ALL IN"]){
  return canvasTexture(512, 512, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0,"#04122c");
    g.addColorStop(1,"#25092a");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(127,212,255,0.92)";
    x.lineWidth = 8;
    x.strokeRect(18,18,w-36,h-36);
    x.fillStyle = "#f6fbff";
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.font = "bold 52px system-ui, Arial";
    x.fillText(lines[0], w/2, h/2 - 40);
    x.font = "bold 64px system-ui, Arial";
    x.fillText(lines[1], w/2, h/2 + 38);
  });
}

function createStoreDisplayTexture(){
  return canvasTexture(1024, 1024, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0, "#081221");
    g.addColorStop(1, "#18081e");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(140,220,255,0.88)";
    x.lineWidth = 10;
    x.strokeRect(18,18,w-36,h-36);
    x.fillStyle = "rgba(20,28,40,0.72)";
    x.fillRect(74,94,w-148,h-188);
    x.strokeStyle = "rgba(190,120,255,0.72)";
    x.lineWidth = 5;
    x.strokeRect(74,94,w-148,h-188);
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.fillStyle = "#f3f8ff";
    x.font = "bold 78px system-ui, Arial";
    x.fillText("SVR STORE", w/2, 170);
    x.fillStyle = "rgba(188,214,255,0.98)";
    x.font = "bold 42px system-ui, Arial";
    x.fillText("north east wall", w/2, 236);
    const items = ["chips", "cards", "sponsor merch", "hall of fame soon"];
    items.forEach((item, i)=>{
      const yy = 420 + i*110;
      x.fillStyle = i % 2 ? "rgba(194,145,255,0.95)" : "rgba(127,214,255,0.95)";
      x.fillRect(190, yy-34, w-380, 68);
      x.fillStyle = "#08101a";
      x.font = "bold 34px system-ui, Arial";
      x.fillText(item.toUpperCase(), w/2, yy);
    });
  });
}

function createPlaqueTexture(title = "legend", subtitle = "hall of fame"){
  return canvasTexture(512, 256, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0, "rgba(8,14,24,0.98)");
    g.addColorStop(1, "rgba(34,10,44,0.98)");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(136,220,255,0.85)";
    x.lineWidth = 6;
    x.strokeRect(12,12,w-24,h-24);
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.fillStyle = "#f6fbff";
    x.font = "bold 40px system-ui, Arial";
    x.fillText(String(title || "").toUpperCase(), w/2, 92);
    x.fillStyle = "rgba(198,136,255,0.96)";
    x.font = "bold 26px system-ui, Arial";
    x.fillText(String(subtitle || "").toUpperCase(), w/2, 170);
  });
}
function createHologramSilhouette(kind = "legend"){
  const group = new THREE.Group();
  const mat = new THREE.MeshBasicMaterial({ color: 0x9fe1ff, transparent: true, opacity: 0.24, wireframe: true });
  let mesh;
  if (kind === "free ghost"){
    mesh = new THREE.Mesh(new THREE.ConeGeometry(0.55, 1.55, 10, 1, true), mat);
    mesh.position.y = 0.78;
  } else if (kind === "mutant2"){
    mesh = new THREE.Mesh(new THREE.OctahedronGeometry(0.82, 1), mat);
    mesh.position.y = 0.92;
  } else {
    mesh = new THREE.Mesh(new THREE.TorusKnotGeometry(0.42, 0.14, 84, 10), mat);
    mesh.position.y = 0.9;
  }
  group.add(mesh);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: makeSpriteTexture(), color: 0xb48cff, transparent: true, opacity: 0.42, depthWrite: false, blending: THREE.AdditiveBlending }));
  halo.scale.set(2.2, 2.2, 1);
  halo.position.y = 0.92;
  group.add(halo);
  group.userData.core = mesh;
  return group;
}
function buildLegendHall(scene, R, wallHeight, log = console.log){
  const group = new THREE.Group();
  const center = new THREE.Vector3(-R * 0.46, 0, -R * 0.36);
  group.position.copy(center);
  scene.add(group);

  const base = new THREE.Mesh(
    new THREE.BoxGeometry(11.0, 0.18, 6.4),
    new THREE.MeshStandardMaterial({ color: 0x10141d, roughness: 0.78, metalness: 0.12, emissive: 0x0a0f1a, emissiveIntensity: 0.12 })
  );
  base.position.y = 0.09;
  group.add(base);

  const trim = new THREE.Mesh(
    new THREE.BoxGeometry(11.2, 0.08, 6.6),
    new THREE.MeshStandardMaterial({ color: 0x7b57ff, roughness: 0.22, metalness: 0.34, emissive: 0x5521ff, emissiveIntensity: 0.95 })
  );
  trim.position.y = 0.22;
  group.add(trim);

  const backWall = new THREE.Mesh(
    new THREE.PlaneGeometry(10.2, 4.6),
    new THREE.MeshStandardMaterial({ color: 0x0b1018, roughness: 0.82, metalness: 0.08, emissive: 0x091120, emissiveIntensity: 0.12, side: THREE.DoubleSide })
  );
  backWall.position.set(0, 2.45, -3.16);
  group.add(backWall);

  const titleTex = createPlaqueTexture("game legends", "hall of fame");
  const title = new THREE.Mesh(
    new THREE.PlaneGeometry(5.0, 1.3),
    new THREE.MeshBasicMaterial({ map: titleTex, transparent: true, side: THREE.DoubleSide })
  );
  title.position.set(0, 4.02, -3.05);
  group.add(title);

  const pedX = [-2.9, 0, 2.9];
  const labels = ["character model", "scarlett vr", "animated model"];
  const holoGroups = [];
  pedX.forEach((xPos, idx)=>{
    const pedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(0.86, 0.98, 1.08, 24),
      new THREE.MeshStandardMaterial({ color: 0x171b22, roughness: 0.65, metalness: 0.24, emissive: 0x0c1018, emissiveIntensity: 0.16 })
    );
    pedestal.position.set(xPos, 0.62, -0.3);
    group.add(pedestal);

    const cap = new THREE.Mesh(
      new THREE.CylinderGeometry(0.94, 0.94, 0.06, 28),
      new THREE.MeshStandardMaterial({ color: 0x8bcfff, roughness: 0.18, metalness: 0.42, emissive: 0x4da9ff, emissiveIntensity: 0.65 })
    );
    cap.position.set(xPos, 1.18, -0.3);
    group.add(cap);

    const plaqueTex = createPlaqueTexture(labels[idx], "reserved display");
    const plaque = new THREE.Mesh(
      new THREE.PlaneGeometry(2.1, 0.72),
      new THREE.MeshBasicMaterial({ map: plaqueTex, transparent: true, side: THREE.DoubleSide })
    );
    plaque.position.set(xPos, 1.04, 0.70);
    plaque.rotation.x = -0.42;
    group.add(plaque);

    const holo = createHologramSilhouette(labels[idx]);
    holo.position.set(xPos, 1.2, -0.3);
    group.add(holo);
    holoGroups.push(holo);

    const spot = new THREE.SpotLight(0xe7f1ff, 13.5, 18, Math.PI * 0.16, 0.26, 1.4);
    spot.position.set(xPos, 6.2, 1.2);
    spot.target.position.set(xPos, 1.2, -0.3);
    spot.castShadow = false;
    group.add(spot);
    group.add(spot.target);
  });

  const postMat = new THREE.MeshStandardMaterial({ color: 0xaab5c8, roughness: 0.32, metalness: 0.55, emissive: 0x1b2432, emissiveIntensity: 0.22 });
  const ropeMat = new THREE.MeshStandardMaterial({ color: 0x6e4dff, roughness: 0.34, metalness: 0.14, emissive: 0x4522d0, emissiveIntensity: 0.88 });
  const railPts = [
    new THREE.Vector3(-4.75, 0, 1.7),
    new THREE.Vector3( 4.75, 0, 1.7),
    new THREE.Vector3( 5.2, 0, -2.15),
    new THREE.Vector3(-5.2, 0, -2.15)
  ];
  railPts.forEach((p)=>{
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.09, 1.08, 16), postMat);
    post.position.copy(p).add(new THREE.Vector3(0, 0.54, 0));
    group.add(post);
  });
  function addRope(a,b,y){
    const dir = new THREE.Vector3().subVectors(b,a);
    const len = dir.length();
    const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, len, 12), ropeMat);
    rope.position.copy(a).lerp(b, 0.5).add(new THREE.Vector3(0, y, 0));
    rope.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0), dir.clone().normalize());
    group.add(rope);
  }
  for (let i = 0; i < railPts.length; i++){
    const a = railPts[i];
    const b = railPts[(i + 1) % railPts.length];
    addRope(a,b,0.78);
    addRope(a,b,0.54);
  }

  const blocker = new THREE.Mesh(
    new THREE.BoxGeometry(10.8, 0.18, 0.52),
    new THREE.MeshStandardMaterial({ color: 0x111722, roughness: 0.76, metalness: 0.08, emissive: 0x0d1220, emissiveIntensity: 0.10 })
  );
  blocker.position.set(0, 0.09, 1.96);
  group.add(blocker);

  const fillA = new THREE.PointLight(0x9a7cff, 5.4, 30, 2.0);
  fillA.position.set(-2.8, 3.8, -1.0);
  group.add(fillA);
  const fillB = new THREE.PointLight(0x89d8ff, 5.0, 30, 2.0);
  fillB.position.set(2.8, 3.8, -1.0);
  group.add(fillB);

  return { group, holoGroups };
}

function buildAlignedLegendHall(scene, R, wallHeight, log = console.log){
  const hall = buildLegendHall(scene, R, wallHeight, log);
  const angle = -Math.PI * 0.75;
  const center = new THREE.Vector3(Math.cos(angle) * (R - 4.4), 0, Math.sin(angle) * (R - 4.4));
  hall.group.position.copy(center);
  hall.group.rotation.y = Math.atan2(-center.x, -center.z);
  return hall;
}


async function populateLegendPedestals(legendHall, spawnLogoTex, log = console.log){
  if (!legendHall?.group) return;
  legendHall.holoGroups?.forEach((holo)=>{ holo.visible = false; });
  legendHall.displayUpdaters = [];

  const prepare = (root)=>{
    root.traverse((obj)=>{
      if (!obj.isMesh) return;
      obj.castShadow = false;
      obj.receiveShadow = false;
      obj.frustumCulled = false;
    });
  };

  async function addModel(xPos, urls, opts={}){
    const root = await tryLoadGLTF(urls, log, 12000);
    if (!root) return;
    prepare(root);
    orientCharacterUpright(root);
    scaleToHeight(root, opts.targetHeight || 2.08);
    dropToGround(root);
    root.position.set(xPos, 1.21, -0.34);
    root.rotation.y = Math.PI;
    legendHall.group.add(root);
    legendHall.displayUpdaters.push((t, dt)=>{ root.rotation.y += dt * (opts.spin || 0.12); root.position.y = 1.21 + Math.sin(t * 1.15 + xPos) * 0.03; });
  }

  await addModel(-2.9, assetUrls("models/legend_character.glb"), { spin: 0.10, targetHeight: 2.12 });

  if (spawnLogoTex){
    const logo = new THREE.Mesh(
      new THREE.PlaneGeometry(2.0, 2.0),
      new THREE.MeshBasicMaterial({ map: spawnLogoTex, transparent: true, side: THREE.DoubleSide, depthWrite: false })
    );
    logo.position.set(0, 2.25, -0.28);
    legendHall.group.add(logo);
    legendHall.displayUpdaters.push((t, dt)=>{ logo.rotation.y += dt * 0.40; logo.position.y = 2.25 + Math.sin(t * 1.45) * 0.08; });
  }

  await addModel(2.9, assetUrls("models/legend_animated.glb"), { spin: -0.09, targetHeight: 2.12 });
}

function chooseBestWallFacingY(obj){
  const rotations = [0, Math.PI * 0.5, Math.PI, -Math.PI * 0.5];
  let bestRot = 0;
  let bestScore = -Infinity;
  for (const ry of rotations){
    obj.rotation.y = ry;
    obj.updateMatrixWorld(true);
    const { size } = boxSize(obj);
    const score = size.x * 1.2 - size.z * 0.9;
    if (score > bestScore){
      bestScore = score;
      bestRot = ry;
    }
  }
  obj.rotation.y = bestRot;
  obj.updateMatrixWorld(true);
  return bestRot;
}

function buildStoreWall(scene, R, wallHeight, spawnLogoTex){
  const group = new THREE.Group();
  const angle = -Math.PI * 0.25;
  const inward = new THREE.Vector3(-Math.cos(angle), 0, -Math.sin(angle));
  const center = new THREE.Vector3(Math.cos(angle) * (R - 0.54), wallHeight * 0.5, Math.sin(angle) * (R - 0.54));
  group.position.copy(center);
  group.rotation.y = Math.atan2(inward.x, inward.z);
  scene.add(group);

  const wallFrame = new THREE.Mesh(
    new THREE.BoxGeometry(8.6, wallHeight - 0.5, 0.22),
    new THREE.MeshStandardMaterial({ color: 0x0c1118, roughness: 0.72, metalness: 0.16, emissive: 0x101a2b, emissiveIntensity: 0.16 })
  );
  group.add(wallFrame);

  const signX = -2.28;
  const signZ = 0.12;
  const modelX = 2.18;

  const signPanel = new THREE.Mesh(
    new THREE.PlaneGeometry(4.25, wallHeight - 1.25),
    new THREE.MeshStandardMaterial({ color: 0x060a12, roughness: 0.72, metalness: 0.12, emissive: 0x0e1730, emissiveIntensity: 0.24, side: THREE.DoubleSide })
  );
  signPanel.position.set(signX, 0.0, 0.105);
  group.add(signPanel);

  const storeTex = createStoreDisplayTexture();
  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(4.0, wallHeight - 1.55),
    new THREE.MeshBasicMaterial({ map: storeTex, side: THREE.DoubleSide })
  );
  screen.position.set(signX, -0.02, signZ);
  group.add(screen);


  const plaqueTex = createPlaqueTexture("store wall", "north east");
  const plaque = new THREE.Mesh(
    new THREE.PlaneGeometry(2.8, 0.84),
    new THREE.MeshBasicMaterial({ map: plaqueTex, transparent: true, side: THREE.DoubleSide })
  );
  plaque.position.set(signX, wallHeight * 0.39, 0.14);
  group.add(plaque);

  if (spawnLogoTex){
    const logo = new THREE.Mesh(
      new THREE.PlaneGeometry(1.3, 1.3),
      new THREE.MeshBasicMaterial({ map: spawnLogoTex, transparent: true, side: THREE.DoubleSide, depthWrite: false })
    );
    logo.position.set(signX, wallHeight * 0.18, 0.16);
    group.add(logo);
  }

  const displayPanel = new THREE.Mesh(
    new THREE.PlaneGeometry(3.6, wallHeight - 1.32),
    new THREE.MeshStandardMaterial({ color: 0x070d14, roughness: 0.78, metalness: 0.08, emissive: 0x121c2f, emissiveIntensity: 0.22, side: THREE.DoubleSide })
  );
  displayPanel.position.set(modelX, 0.02, 0.085);
  group.add(displayPanel);

  const spotA = new THREE.SpotLight(0x9fdcff, 8.5, 24, Math.PI * 0.18, 0.28, 1.3);
  spotA.position.set(-1.7, wallHeight * 0.86, 3.2);
  spotA.target.position.set(signX, wallHeight * 0.20, 0.18);
  group.add(spotA);
  group.add(spotA.target);
  const spotB = new THREE.SpotLight(0xc191ff, 9.0, 26, Math.PI * 0.20, 0.24, 1.2);
  spotB.position.set(1.9, wallHeight * 0.86, 3.2);
  spotB.target.position.set(modelX, wallHeight * 0.12, 0.18);
  group.add(spotB);
  group.add(spotB.target);
  const modelFill = new THREE.PointLight(0x8fd6ff, 3.4, 16, 2.0);
  modelFill.position.set(modelX, wallHeight * 0.35, 1.2);
  group.add(modelFill);

  const modelMount = new THREE.Group();
  modelMount.position.set(modelX, -0.20, 0.22);
  group.add(modelMount);

  const kioskShell = new THREE.Group();
  const kioskBody = new THREE.Mesh(
    new THREE.BoxGeometry(1.34, 2.22, 0.54),
    new THREE.MeshStandardMaterial({ color: 0x121722, roughness: 0.46, metalness: 0.22, emissive: 0x18243d, emissiveIntensity: 0.26 })
  );
  kioskBody.position.y = 1.11;
  kioskShell.add(kioskBody);
  const kioskScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.92, 1.36),
    new THREE.MeshBasicMaterial({ map: storeTex, side: THREE.DoubleSide })
  );
  kioskScreen.position.set(0, 1.18, 0.275);
  kioskShell.add(kioskScreen);
  const kioskTrim = new THREE.Mesh(
    new THREE.BoxGeometry(1.02, 1.46, 0.05),
    new THREE.MeshStandardMaterial({ color: 0xa6dfff, roughness: 0.24, metalness: 0.42, emissive: 0x3d7fff, emissiveIntensity: 0.45 })
  );
  kioskTrim.position.set(0, 1.18, 0.26);
  kioskShell.add(kioskTrim);
  modelMount.add(kioskShell);

  (async ()=>{
    let storeModel = await tryLoadGLTF(assetUrls("models/store.glb", "store.glb"), ()=>{}, 9000);
    if (!storeModel) storeModel = await tryLoadFBX(assetUrls("models/store.fbx", "store.fbx"), ()=>{}, 10000);
    if (!storeModel) return;
    touchModelShadows(storeModel);
    orientCharacterUpright(storeModel);
    scaleToHeight(storeModel, 2.20);
    fitDiameter(storeModel, 1.42);
    chooseBestWallFacingY(storeModel);
    let info = boxSize(storeModel);
    storeModel.position.set(-info.center.x, -info.box.min.y, -info.center.z + 0.02);
    info = boxSize(storeModel);
    storeModel.position.x -= info.center.x * 0.02;
    storeModel.position.z += 0.04;
    storeModel.traverse((child)=>{ if (child.isMesh && child.material){ child.material.emissive = new THREE.Color(0x101828); child.material.emissiveIntensity = 0.06; } });
    kioskShell.visible = false;
    modelMount.add(storeModel);
  })().catch(()=>{});

  const activeBtn = new THREE.Mesh(
    new THREE.BoxGeometry(0.9, 0.22, 0.08),
    new THREE.MeshStandardMaterial({ color: 0x8b1e2f, roughness: 0.45, metalness: 0.18, emissive: 0x5a0b18, emissiveIntensity: 0.9 })
  );
  activeBtn.position.set(signX, 0.72, 0.20);
  group.add(activeBtn);

  const activePlaque = new THREE.Mesh(
    new THREE.PlaneGeometry(1.8, 0.5),
    new THREE.MeshBasicMaterial({ map: createPlaqueTexture("active", "store entry"), transparent: true, side: THREE.DoubleSide })
  );
  activePlaque.position.set(signX, 1.04, 0.18);
  group.add(activePlaque);

  return { group };
}

function buildOuterCity(scene, R){
  const group = new THREE.Group();
  const glassMats = [
    new THREE.MeshStandardMaterial({ color: 0x9fdfff, roughness: 0.16, metalness: 0.30, emissive: 0x15396a, emissiveIntensity: 1.2 }),
    new THREE.MeshStandardMaterial({ color: 0xb993ff, roughness: 0.18, metalness: 0.28, emissive: 0x31125f, emissiveIntensity: 1.1 }),
    new THREE.MeshStandardMaterial({ color: 0x8bd7ff, roughness: 0.14, metalness: 0.30, emissive: 0x1c4e84, emissiveIntensity: 1.25 })
  ];
  const bodyMats = [
    new THREE.MeshStandardMaterial({ color: 0x08111d, roughness: 0.68, metalness: 0.24, emissive: 0x091624, emissiveIntensity: 0.8 }),
    new THREE.MeshStandardMaterial({ color: 0x0b1623, roughness: 0.62, metalness: 0.28, emissive: 0x0c1b2d, emissiveIntensity: 0.9 }),
    new THREE.MeshStandardMaterial({ color: 0x0a131d, roughness: 0.64, metalness: 0.26, emissive: 0x0d1828, emissiveIntensity: 0.85 })
  ];
  const matrix = createMatrixBillboardTexture();
  const adTex = createAdBillboardTexture();
  const billboardUpdaters = [matrix.update];

  const count = 88;
  for (let i = 0; i < count; i++){
    const a = (i / count) * Math.PI * 2;
    const rr = (R + 8) + Math.random() * 22;
    const h = 12 + Math.random() * 46;
    const w = 1.8 + Math.random() * 4.8;
    const d = 1.8 + Math.random() * 4.8;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;
    const style = i % 6;
    const bodyMat = bodyMats[i % bodyMats.length];
    const glassMat = glassMats[i % glassMats.length];
    let bodyGeo;
    if (style === 0) bodyGeo = new THREE.BoxGeometry(w, h, d);
    else if (style === 1) bodyGeo = new THREE.CylinderGeometry(w * 0.52, w * 0.66, h, 10);
    else if (style === 2) bodyGeo = new THREE.BoxGeometry(w, h, d * 0.72);
    else if (style === 3) bodyGeo = new THREE.CylinderGeometry(w * 0.54, w * 0.62, h, 8);
    else if (style === 4) bodyGeo = new THREE.BoxGeometry(w * 0.88, h, d * 1.15);
    else bodyGeo = new THREE.BoxGeometry(w * 1.05, h, d * 0.84);
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.set(x, h / 2, z);
    body.rotation.y = -a + Math.PI / 2;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    const outward = new THREE.Vector3(Math.cos(a), 0, Math.sin(a));
    const frontGlass = new THREE.Mesh(new THREE.PlaneGeometry(Math.max(1.0, w * 0.76), Math.max(6, h * 0.86)), glassMat);
    frontGlass.position.set(x - outward.x * (d * 0.5 + 0.04), h * 0.5, z - outward.z * (d * 0.5 + 0.04));
    frontGlass.lookAt(frontGlass.position.clone().sub(outward));
    group.add(frontGlass);

    const stripCount = 2 + (Math.random() * 3 | 0);
    for (let s2 = 0; s2 < stripCount; s2++){
      const strip = new THREE.Mesh(new THREE.PlaneGeometry(Math.max(0.4, w * 0.84), 0.18), glassMat);
      strip.position.set(x - outward.x * (d * 0.5 + 0.03), 2 + ((s2 + 1) / (stripCount + 1)) * (h - 3), z - outward.z * (d * 0.5 + 0.03));
      strip.lookAt(strip.position.clone().sub(outward));
      group.add(strip);
    }


    if (i % 7 === 0){
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.6 + Math.random() * 3.4, 8), glassMat);
      pole.position.set(x, h + 1.2, z);
      group.add(pole);
      const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 10), glassMat);
      beacon.position.set(x, pole.position.y + pole.geometry.parameters.height * 0.5, z);
      group.add(beacon);
    }

    if (i === 8 || i === 44 || i === 118){
      const tex = i === 44 ? matrix.texture : adTex;
      tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
      const bill = new THREE.Mesh(
        new THREE.PlaneGeometry(2.8, 5.4),
        new THREE.MeshBasicMaterial({ map: tex, transparent: false, side: THREE.DoubleSide })
      );
      bill.position.set(x - outward.x * (w * 0.52 + 0.35), Math.min(h * 0.68, 16), z - outward.z * (w * 0.52 + 0.35));
      bill.lookAt(bill.position.clone().sub(outward));
      group.add(bill);
    }
  }
  scene.add(group);
  return { group, billboardUpdaters };
}

function makeSeat(scene, x, z, angle, label, chairMat, metalMat){
  const group = new THREE.Group();
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.36, 0.54, 48),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.64, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.014;
  group.add(ring);
  const seatBase = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.11, 0.72, 18), metalMat);
  seatBase.position.y = 0.36;
  group.add(seatBase);
  const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 0.06, 28), metalMat);
  foot.position.y = 0.03;
  group.add(foot);
  const seatShell = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.10, 0.72), chairMat);
  seatShell.position.y = 0.70;
  group.add(seatShell);
  const seatCushion = new THREE.Mesh(
    new THREE.BoxGeometry(0.62, 0.08, 0.58),
    new THREE.MeshStandardMaterial({ color: 0x2f2040, roughness: 0.72, metalness: 0.08, emissive: 0x140a1e, emissiveIntensity: 0.06 })
  );
  seatCushion.position.y = 0.77;
  group.add(seatCushion);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.76, 0.12), chairMat);
  back.position.set(0, 1.10, -0.30);
  back.rotation.x = -0.16;
  group.add(back);
  const lumbar = new THREE.Mesh(
    new THREE.BoxGeometry(0.54, 0.26, 0.07),
    new THREE.MeshStandardMaterial({ color: 0x2a1836, roughness: 0.72, metalness: 0.05, emissive: 0x120916, emissiveIntensity: 0.05 })
  );
  lumbar.position.set(0, 1.04, -0.23);
  lumbar.rotation.x = -0.10;
  group.add(lumbar);
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.18, 0.56), chairMat);
  armL.position.set(-0.35, 0.90, 0.02);
  group.add(armL);
  const armR = armL.clone();
  armR.position.x = 0.35;
  group.add(armR);
  const headrest = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.18, 0.10), chairMat);
  headrest.position.set(0, 1.45, -0.26);
  group.add(headrest);
  const sideL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.62, 0.10), metalMat);
  sideL.position.set(-0.32, 1.02, -0.18);
  sideL.rotation.z = 0.08;
  group.add(sideL);
  const sideR = sideL.clone();
  sideR.position.x = 0.32;
  sideR.rotation.z = -0.08;
  group.add(sideR);
  const legs = [[-0.24,0.34,-0.24],[0.24,0.34,-0.24],[-0.24,0.34,0.24],[0.24,0.34,0.24]];
  for (const [lx,ly,lz] of legs){
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.035, 0.72, 12), metalMat);
    leg.position.set(lx, ly, lz);
    group.add(leg);
  }
  const crossbar = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.04, 0.06), metalMat);
  crossbar.position.set(0, 0.22, 0);
  group.add(crossbar);
  group.position.set(x, 0, z);
  group.rotation.y = angle;
  scene.add(group);
  return { group, ring, x, z, angle, label };
}
function addChipsAndCards(scene, tableTopY = 0.86){
  const group = new THREE.Group();
  const chipMatA = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.35, metalness: 0.25, emissive: 0x230d30, emissiveIntensity: 0.35 });
  const chipMatB = new THREE.MeshStandardMaterial({ color: 0x00e2c7, roughness: 0.35, metalness: 0.25, emissive: 0x06261f, emissiveIntensity: 0.28 });
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf2f2ff, roughness: 0.85, metalness: 0.03 });
  const redPip = new THREE.MeshStandardMaterial({ color: 0xd6263d, roughness: 0.7 });
  const stacks = [[-1.08, 1.12, chipMatA],[-0.42, 1.26, chipMatB],[0.48, 1.18, chipMatA],[1.12, 1.04, chipMatB]];
  for (const [x, z, mat] of stacks){
    for (let i = 0; i < 6; i++){
      const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.018, 24), mat);
      chip.position.set(x, tableTopY + 0.015 + i * 0.02, z - 0.19);
      chip.rotation.x = Math.PI / 2;
      chip.castShadow = true;
      chip.receiveShadow = true;
      group.add(chip);
    }
  }
  for (let i = 0; i < 5; i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.004, 0.18), cardMat);
    card.position.set(-0.34 + i * 0.17, tableTopY + 0.008, -0.05 + (i % 2) * 0.01);
    card.rotation.y = -0.18 + i * 0.09;
    card.castShadow = true;
    card.receiveShadow = true;
    group.add(card);
    const pip = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.002, 0.018), redPip);
    pip.position.copy(card.position).add(new THREE.Vector3(0.034, 0.004, 0.055));
    group.add(pip);
  }
  scene.add(group);
  return group;
}

function addDealingDemo(scene, seats, tableTopY = 0.86, getDealerPos = null){
  const group = new THREE.Group();
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf8f8ff, roughness: 0.82, metalness: 0.04, emissive: 0x161622, emissiveIntensity: 0.12 });
  const redMat = new THREE.MeshStandardMaterial({ color: 0xcf2644, roughness: 0.7, metalness: 0.02 });
  const cards = [];
  const dealer = new THREE.Vector3(0, tableTopY + 0.14, 1.52);
  const targetSeats = seats.filter(s=>s.label !== "Dealer Side");
  for (let i = 0; i < 3; i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.004, 0.18), cardMat);
    card.castShadow = true; card.receiveShadow = true;
    const pip = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.0022, 0.018), redMat);
    group.add(card); group.add(pip);
    cards.push({ card, pip, offset: i * 0.92 });
  }
  scene.add(group);
  function update(t){
    cards.forEach((rec, idx)=>{
      const loop = (t * 0.75 + rec.offset) % targetSeats.length;
      const seatIndex = Math.floor(loop);
      const nextSeat = targetSeats[seatIndex];
      const f = loop - seatIndex;
      const lift = Math.sin(f * Math.PI) * 0.28;
      const source = getDealerPos ? getDealerPos() : dealer;
      const target = new THREE.Vector3(nextSeat.x * 0.48, tableTopY + 0.10 + lift, nextSeat.z * 0.48 - 0.05);
      rec.card.position.lerpVectors(source, target, f);
      rec.card.rotation.set(-0.35 - lift * 0.3, Math.atan2(target.x - source.x, target.z - source.z), 0.08 * Math.sin((t + idx) * 2.2));
      rec.pip.position.copy(rec.card.position).add(new THREE.Vector3(0.032, 0.004, 0.054));
      rec.pip.rotation.copy(rec.card.rotation);
    });
  }
  return { group, update, dealer };
}

function applyEricMaterial(obj, texture, normalTex){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = false;
    child.receiveShadow = false;
    child.material = new THREE.MeshStandardMaterial({
      map: texture || null,
      normalMap: normalTex || null,
      color: texture ? 0xffffff : 0xd6d4e8,
      roughness: 0.68,
      metalness: 0.02,
      emissive: 0x0d0914,
      emissiveIntensity: 0.06,
      side: THREE.DoubleSide,
      skinning: !!child.isSkinnedMesh
    });
    child.frustumCulled = false;
  });
}
function applyClaudiaMaterial(obj, texture){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    child.material = new THREE.MeshStandardMaterial({
      map: texture || null,
      color: texture ? 0xffffff : 0xe6e6f2,
      roughness: 0.72,
      metalness: 0.02,
      emissive: 0x0b0d18,
      emissiveIntensity: 0.05,
      side: THREE.DoubleSide,
      skinning: !!child.isSkinnedMesh,
      alphaTest: 0.1
    });
    child.frustumCulled = false;
  });
}
function touchModelShadows(obj){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = false;
    child.receiveShadow = false;
    if (!Array.isArray(child.material) && child.material) child.material.side = THREE.DoubleSide;
    child.frustumCulled = false;
  });
}
function sanitizeTableSurface(table, keepMesh = null){
  const box = new THREE.Box3();
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  const blinkNames = /object002_79f581|circle007|circle008/i;
  table.updateMatrixWorld(true);
  table.traverse((child)=>{
    if (!child.isMesh) return;
    box.setFromObject(child);
    box.getSize(size);
    box.getCenter(center);
    const flatSpan = Math.max(size.x, size.z);
    const isThinCap = size.y < 0.04 && flatSpan > 1.85 && center.y > 0.55;
    const isKnownBlink = blinkNames.test(child.name || "");
    if (isThinCap || isKnownBlink) child.visible = false;
  });
}
export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const R = CONFIG.ROOM_RADIUS;
  const H = CONFIG.WALL_HEIGHT;
  scene.fog = new THREE.FogExp2(0x010105, 0.00125);
  const hemi = new THREE.HemisphereLight(0xc7d6ec, 0x02040a, 0.50);
  scene.add(hemi);
  const key = new THREE.DirectionalLight(0xeaf1ff, 1.15);
  key.position.set(16, 28, 12);
  key.castShadow = false;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.left = -24;
  key.shadow.camera.right = 24;
  key.shadow.camera.top = 24;
  key.shadow.camera.bottom = -24;
  key.shadow.bias = -0.00002;
  key.shadow.normalBias = 0.035;
  scene.add(key);
  const tableSpot = new THREE.SpotLight(0xf0f4ff, 5.2, 120, Math.PI * 0.28, 0.22, 1.0);
  tableSpot.position.set(0, 15, 4);
  tableSpot.target.position.set(0, 0.8, 0);
  tableSpot.castShadow = false;
  scene.add(tableSpot);
  scene.add(tableSpot.target);
  const fill = new THREE.PointLight(0x7fafff, 1.2, 180, 1.9);
  fill.position.set(0, 10.2, 0);
  scene.add(fill);
  const rimLight = new THREE.PointLight(0x6d6cff, 1.8, 260, 1.8);
  rimLight.position.set(20, 18, -34);
  scene.add(rimLight);

  const floorTex = await loadFirstTexture(assetUrls("texture/slate_basecolor.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const floorNormal = await loadFirstTexture(assetUrls("texture/slate_normal.png"));
  const floorRough = await loadFirstTexture(assetUrls("texture/slate_roughness.jpg"));
  [floorTex, floorNormal, floorRough].forEach(tex=>{ if (tex){ tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(24,24); tex.anisotropy = 4; tex.minFilter = THREE.LinearMipmapLinearFilter; tex.magFilter = THREE.LinearFilter; } });
  const wallTex = await loadFirstTexture(assetUrls("texture/stonebrick_wall_basecolor.png"), { colorSpace: THREE.SRGBColorSpace });
  const wallNormal = await loadFirstTexture(assetUrls("texture/stonebrick_wall_normal.png"));
  const wallRough = await loadFirstTexture(assetUrls("texture/stonebrick_wall_roughness.png"));
  [wallTex, wallNormal, wallRough].forEach(tex=>{ if (tex){ tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(26,9); tex.anisotropy = 4; tex.minFilter = THREE.LinearMipmapLinearFilter; tex.magFilter = THREE.LinearFilter; } });

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(R + 34, 220),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.9,
      metalness: 0.03,
      map: floorTex || null,
      normalMap: null,
      roughnessMap: null,
      polygonOffset: false
    })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = false;
  floor.renderOrder = -10;
  scene.add(floor);

  const wallHeight = H * 0.56;
  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, wallHeight, 220, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.84,
      metalness: 0.04,
      emissive: 0x143154,
      emissiveIntensity: 0.10,
      side: THREE.BackSide,
      map: wallTex || null,
      normalMap: null,
      normalScale: new THREE.Vector2(0, 0),
      roughnessMap: null
    })
  );
  wall.position.set(0, wallHeight / 2, 0);
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(R - 1.2, 0.18, 16, 220),
    new THREE.MeshStandardMaterial({
      color: 0xb48cff,
      roughness: 0.2,
      metalness: 0.35,
      emissive: 0x2a0d3a,
      emissiveIntensity: 0.55
    })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.set(0, wallHeight - 0.18, 0);
  scene.add(rim);

  const innerPlatform = null;

  const city = buildOuterCity(scene, R);
  const stars = buildStars(scene, R);
  const lobbySprites = buildLobbySprites(scene, R, wallHeight);
  const spawnLogoTex = await loadFirstTexture(assetUrls("ui/logo.png", "logo.png"), { colorSpace: THREE.SRGBColorSpace });
  const wallPanels = [];
  const wallPanelUpdaters = [];
  [
    { angle: Math.PI, kind: "main", title: "MAIN SPONSOR SCREEN", subtitle: "SCARLETT VR POKER", size: [8.8, wallHeight - 0.36], logo: [2.3, 2.3], y: wallHeight * 0.5 },
    { angle: 0, kind: "reserve", title: "RESERVED FOR SPONSOR", subtitle: "SOUTH SPAWN", size: [6.8, wallHeight - 0.46], logo: [1.8, 1.8], y: wallHeight * 0.5 },
    { angle: -Math.PI * 0.5, kind: "reserve", title: "RESERVED FOR SPONSOR", subtitle: "EAST SPAWN", size: [6.8, wallHeight - 0.46], logo: [1.8, 1.8], y: wallHeight * 0.5 },
    { angle: Math.PI * 0.5, kind: "reserve", title: "RESERVED FOR SPONSOR", subtitle: "WEST SPAWN", size: [6.8, wallHeight - 0.46], logo: [1.8, 1.8], y: wallHeight * 0.5 }
  ].forEach(({ angle, kind, title, subtitle, size, logo, y })=>{
    const matrix = createMatrixBillboardTexture(kind === "main" ? "main" : "reserve");
    wallPanelUpdaters.push(matrix.update);
    const inward = new THREE.Vector3(-Math.cos(angle), 0, -Math.sin(angle));
    const rr = R - 0.38;
    const panelMat = new THREE.MeshBasicMaterial({
      map: matrix.texture,
      transparent: false,
      side: THREE.DoubleSide,
      depthWrite: true,
      depthTest: true
    });
    const panel = new THREE.Mesh(new THREE.PlaneGeometry(size[0], size[1]), panelMat);
    panel.position.set(Math.cos(angle) * rr, y, Math.sin(angle) * rr);
    panel.lookAt(0, y, 0);
    panel.renderOrder = 30;
    scene.add(panel);
    wallPanels.push(panel);
    if (spawnLogoTex){
      const logoMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(logo[0], logo[1]),
        new THREE.MeshBasicMaterial({
          map: spawnLogoTex,
          transparent: true,
          side: THREE.DoubleSide,
          depthWrite: false,
          depthTest: true
        })
      );
      logoMesh.position.copy(panel.position).addScaledVector(inward, 0.12).add(new THREE.Vector3(0, kind === "main" ? 1.85 : 1.25, 0));
      logoMesh.lookAt(0, y, 0);
      logoMesh.renderOrder = 31;
      scene.add(logoMesh);
      wallPanels.push(logoMesh);
    }
    const plateTex = createSponsorPlateTexture(title, subtitle);
    const plate = new THREE.Mesh(
      new THREE.PlaneGeometry(kind === "main" ? 5.4 : 4.5, 1.3),
      new THREE.MeshBasicMaterial({
        map: plateTex,
        transparent: true,
        side: THREE.DoubleSide,
        depthWrite: false,
        depthTest: true
      })
    );
    plate.position.copy(panel.position).addScaledVector(inward, 0.14).add(new THREE.Vector3(0, -(size[1] * 0.33), 0));
    plate.lookAt(0, y, 0);
    plate.renderOrder = 31;
    scene.add(plate);
    wallPanels.push(plate);
  });

  const legendHall = buildAlignedLegendHall(scene, R, wallHeight, log);
  await populateLegendPedestals(legendHall, spawnLogoTex, log);
  const storeWall = buildStoreWall(scene, R, wallHeight, spawnLogoTex);
  await addRikiArea(scene, R, wallHeight, spawnLogoTex, log);

  const moonTex = await loadFirstTexture(assetUrls("texture/moon_diffuse.png"), { colorSpace: THREE.SRGBColorSpace });
  const moonBump = await loadFirstTexture(assetUrls("texture/moon_bump.png"));
  const marsTex = await loadFirstTexture(assetUrls("texture/mars/diffuse_1k.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const marsBump = await loadFirstTexture(assetUrls("texture/mars/bump_1k.jpg"));
  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(9.4, 48, 48),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.88,
      metalness: 0.0,
      map: makeEarthTexture(),
      emissive: 0x000000,
      emissiveIntensity: 0.0
    })
  );
  earth.position.set(0, wallHeight + 54.0, -(R + 140));
  earth.visible = false;
  earth.frustumCulled = false;
  earth.rotation.z = 0.24;
  earth.visible = false; earth.frustumCulled = false; scene.add(earth);
  const earthHalo = createOrbHaloSprite(0x6bc4ff, 0.0);
  earthHalo.scale.set(92, 92, 1);
  earthHalo.material.depthTest = false;
  earthHalo.visible = false;
  scene.add(earthHalo);
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(18.0, 64, 64),
    new THREE.MeshStandardMaterial({
      color: 0xe9ebef,
      roughness: 0.96,
      metalness: 0.0,
      map: moonTex || null,
      bumpMap: moonBump || null,
      bumpScale: moonBump ? 0.68 : 0,
      emissive: 0x323844,
      emissiveIntensity: 0.12
    })
  );
  moon.position.set(-18, wallHeight + 226.0, -(R + 430));
  moon.frustumCulled = false;
  scene.add(moon);
  const moonHalo = createOrbHaloSprite(0xf4f7ff, 0.0);
  moonHalo.scale.set(64, 64, 1);
  moonHalo.material.depthTest = false;
  moonHalo.visible = true;
  scene.add(moonHalo);
  const mars = new THREE.Mesh(
    new THREE.SphereGeometry(4.8, 48, 48),
    new THREE.MeshStandardMaterial({
      color: 0xc56b45,
      roughness: 0.82,
      metalness: 0.0,
      map: marsTex || null,
      bumpMap: marsBump || null,
      bumpScale: marsBump ? 0.22 : 0,
      emissive: 0x000000,
      emissiveIntensity: 0.0
    })
  );
  mars.position.set(18, wallHeight + 144.0, -(R + 320));
  mars.visible = false;
  mars.frustumCulled = false;
  mars.visible = false; mars.frustumCulled = false; scene.add(mars);
  const marsHalo = createOrbHaloSprite(0xff9b6b, 0.0);
  marsHalo.scale.set(42, 42, 1);
  marsHalo.material.depthTest = false;
  marsHalo.visible = false;
  scene.add(marsHalo);
  const earthSpark = new THREE.Group();
  for (let i = 0; i < 8; i++){
    const spr = createOrbHaloSprite(i % 2 ? 0x79d8ff : 0xffffff, 0.40);
    spr.scale.setScalar(1.4 + (i % 3) * 0.5);
    spr.material.depthTest = false;
    earthSpark.add(spr);
  }
  earthSpark.visible = false;
  scene.add(earthSpark);
  const moonSpark = new THREE.Group();
  for (let i = 0; i < 6; i++){
    const spr = createOrbHaloSprite(i % 2 ? 0xfefefe : 0xbcd3ff, 0.34);
    spr.scale.setScalar(1.0 + (i % 3) * 0.45);
    spr.material.depthTest = false;
    moonSpark.add(spr);
  }
  moonSpark.visible = false;
  scene.add(moonSpark);
  const earthGlow = new THREE.PointLight(0x70c8ff, 0.0, 220, 1.8);
  scene.add(earthGlow);
  const moonGlow = new THREE.PointLight(0xeaf2ff, 2.4, 320, 1.8);
  scene.add(moonGlow);
  const marsGlow = new THREE.PointLight(0xff9a72, 1.0, 180, 2.0);
  scene.add(marsGlow);
  const skylineGlow = new THREE.PointLight(0x3b74ff, 9.6, 420, 1.7);
  skylineGlow.position.set(0, 26, -(R + 8));
  scene.add(skylineGlow);
  const accentGlow = new THREE.PointLight(0x92c2ff, 1.4, 110, 2.0);
  accentGlow.position.set(-9, 8, 7);
  scene.add(accentGlow);
  // Removed previous atmospheric overlay shells to keep the headset view clear.

  const chairTex = makeChairTexture();
  chairTex.repeat.set(2,2);
  const chairMat = new THREE.MeshStandardMaterial({ map: chairTex, color: 0xffffff, roughness: 0.62, metalness: 0.12, emissive: 0x12081a, emissiveIntensity: 0.10 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x272a31, roughness: 0.35, metalness: 0.55, emissive: 0x0e1016, emissiveIntensity: 0.08 });
  const seatRadius = 3.45;
  const seats = [
    makeSeat(scene, 0, -seatRadius, Math.PI, "Dealer Side", chairMat, metalMat),
    makeSeat(scene, -2.8, -1.76, -Math.PI * 0.28, "Front Left", chairMat, metalMat),
    makeSeat(scene,  2.8, -1.76,  Math.PI * 0.28, "Front Right", chairMat, metalMat),
    makeSeat(scene, -2.8, 1.76, -Math.PI * 0.72, "Back Left", chairMat, metalMat),
    makeSeat(scene,  2.8, 1.76,  Math.PI * 0.72, "Back Right", chairMat, metalMat),
    makeSeat(scene, 0, seatRadius, 0, "Back Center", chairMat, metalMat)
  ];

  const feltTex = await loadFirstTexture(assetUrls("texture/tablefelt.png"), { colorSpace: THREE.SRGBColorSpace });
  let tableTopY = 0.905;
  await createPreferredTable(scene, tableTopY, feltTex, log);
  const tableShadow = new THREE.Mesh(
    new THREE.CircleGeometry(2.55, 48),
    new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.16, depthWrite: false })
  );
  tableShadow.rotation.x = -Math.PI / 2;
  tableShadow.position.y = 0.002;
  tableShadow.renderOrder = -5;
  scene.add(tableShadow);
  const tableAccentA = new THREE.PointLight(0xb48cff, 1.8, 16, 2.0);
  tableAccentA.position.set(-1.2, tableTopY + 0.6, 0.4);
  scene.add(tableAccentA);
  const tableAccentB = new THREE.PointLight(0x7bd5ff, 1.6, 16, 2.0);
  tableAccentB.position.set(1.2, tableTopY + 0.6, -0.4);
  scene.add(tableAccentB);
  addChipsAndCards(scene, tableTopY);
  const dealerSource = new THREE.Vector3(0, tableTopY + 0.22, -1.22);
  const dealingDemo = addDealingDemo(scene, seats, tableTopY, ()=> dealerSource.clone());

  let claudia = null;
  let claudiaAnchor = null;
  let claudiaMixer = null;
  let claudiaPose = null;
  const claudiaUpper = [];
  const claudiaTex = await loadFirstTexture(assetUrls("models/claudia/rp_claudia_rigged_002_dif.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const claudiaBase = await tryLoadFBX(assetUrls("models/claudia/claudia.fbx"), log, 14000);
  const claudiaWalk = await tryLoadFBX(assetUrls("models/claudia/walking.fbx"), log, 14000);
  if (claudiaBase){
    claudia = claudiaBase;
    applyClaudiaMaterial(claudia, claudiaTex);
    orientCharacterUpright(claudia);
    claudia.rotation.x = 0;
    claudia.rotation.z = 0;
    scaleToHeight(claudia, 1.74);
    dropToGround(claudia);
    const cb = boxSize(claudia).box;
    claudia.position.set(0, -cb.min.y + 0.001, 0);
    dealerSource.set(0.26, tableTopY + 0.16, -1.24);
    claudia.traverse((obj)=>{ if (obj.isBone && /(arm|forearm|hand|spine|shoulder)/i.test(obj.name || "")) claudiaUpper.push(obj); });
    claudiaAnchor = new THREE.Group();
    claudiaAnchor.position.set(0.0, 0.02, -1.98);
    claudiaAnchor.add(claudia);
    claudiaAnchor.lookAt(new THREE.Vector3(0, 1.04, 0.10));
    scene.add(claudiaAnchor);
    claudiaPose = { leftArm: [], rightArm: [], leftFore: [], rightFore: [], leftHand: [], rightHand: [], spine: [], shoulder: [] };
    claudia.traverse((obj)=>{
      if (!obj.isBone) return;
      const n = String(obj.name || '').toLowerCase();
      const left = /(left|\bl\b|_l\b|\.l\b|arm_l|hand_l|forearm_l|larm|lhand|lforearm)/.test(n);
      const right = /(right|\br\b|_r\b|\.r\b|arm_r|hand_r|forearm_r|rarm|rhand|rforearm)/.test(n);
      if (/spine|chest|hips/.test(n)) claudiaPose.spine.push(obj);
      if (/shoulder|clavicle/.test(n)) claudiaPose.shoulder.push(obj);
      if (/forearm|lowerarm/.test(n)){ if (left) claudiaPose.leftFore.push(obj); if (right) claudiaPose.rightFore.push(obj); }
      else if (/hand/.test(n)){ if (left) claudiaPose.leftHand.push(obj); if (right) claudiaPose.rightHand.push(obj); }
      else if (/upperarm|arm/.test(n)){ if (left) claudiaPose.leftArm.push(obj); if (right) claudiaPose.rightArm.push(obj); }
    });
  }

  scene.userData._tickWorld = (dt)=>{
    scene.userData._time = (scene.userData._time || 0) + dt;
    const t = scene.userData._time;
    dealingDemo.update(t);
    earth.rotation.y += dt * 0.05;
    earth.rotation.z = 0.02;
    const cityOrbit = t * 0.012;
    const cityRadius = R + 112.0;
    earth.position.set(
      Math.cos(cityOrbit) * (cityRadius * 0.14),
      wallHeight + 72.0 + Math.sin(t * 0.018) * 0.22,
      -(cityRadius * 1.18) + Math.sin(cityOrbit) * 16.0
    );
    const moonOrbit = t * 0.008 + Math.PI * 0.72;
    const moonRadius = cityRadius + 150.0;
    moon.position.set(
      Math.cos(moonOrbit) * 22.0,
      wallHeight + 134.0 + Math.sin(t * 0.012) * 1.2,
      -(moonRadius * 1.06) + Math.sin(moonOrbit) * 24.0
    );
    moon.rotation.y += dt * 0.060;
    moon.rotation.z = 0.05;
    const marsOrbit = t * 0.006 + Math.PI * 0.32;
    const marsRadius = cityRadius + 204.0;
    mars.position.set(
      Math.cos(marsOrbit) * 30.0,
      wallHeight + 150.0 + Math.sin(t * 0.010) * 1.4,
      -(marsRadius * 1.08) + Math.sin(marsOrbit) * 32.0
    );
    mars.rotation.y += dt * 0.080;
    mars.rotation.z = 0.06;
    moonGlow.position.copy(moon.position);
    moonHalo.position.copy(moon.position);
    marsGlow.position.copy(mars.position).add(new THREE.Vector3(-2, 1, 2));
    marsHalo.position.copy(mars.position);
    earthGlow.position.copy(earth.position).add(new THREE.Vector3(0, 0, 10));
    earthHalo.position.copy(earth.position);
    if (lobbySprites){
      lobbySprites.children.forEach((spr, i)=>{
        spr.position.y = (spr.userData.baseY || spr.position.y) + Math.sin(t * 1.15 + (spr.userData.phase || 0)) * 0.18;
        if (spr.material && 'opacity' in spr.material) spr.material.opacity = 0.28 + 0.16 * (0.5 + 0.5 * Math.sin(t * 1.8 + i));
      });
      lobbySprites.rotation.y += dt * 0.016;
    }
    if (earthSpark.visible) earthSpark.children.forEach((spr, i)=>{
      const a = i * ((Math.PI * 2) / Math.max(1, earthSpark.children.length));
      spr.position.set(
        earth.position.x + Math.cos(a) * (12.0 + (i % 2) * 0.4),
        earth.position.y + Math.sin(a * 1.5) * 1.1,
        earth.position.z + Math.sin(a) * (10.5 + (i % 2) * 0.4)
      );
    });
    if (moonSpark.visible) moonSpark.children.forEach((spr, i)=>{
      const a = i * ((Math.PI * 2) / Math.max(1, moonSpark.children.length));
      spr.position.set(
        moon.position.x + Math.cos(a) * (5.7 + (i % 2) * 0.3),
        moon.position.y + Math.sin(a * 1.4) * 0.9,
        moon.position.z + Math.sin(a) * (5.0 + (i % 2) * 0.3)
      );
    });
    rim.material.emissiveIntensity = 0.18;
    seats.forEach((seat)=>{ seat.ring.material.opacity = 0.60; });
    stars.spriteGroup.rotation.y += dt * 0.0003;
    stars.pts.material.opacity = 0.92;
    city.billboardUpdaters.forEach(fn=>fn(t));
    wallPanelUpdaters.forEach(fn=>fn(t));
    legendHall.holoGroups.forEach((holo, i)=>{
      const core = holo.userData.core;
      if (core){
        core.rotation.y += dt * (0.35 + i * 0.08);
        core.rotation.x = Math.sin(t * 0.7 + i) * 0.08;
        holo.position.y = 1.2 + Math.sin(t * 1.2 + i * 0.8) * 0.05;
      }
    });
    legendHall.displayUpdaters?.forEach((fn)=>fn(t, dt));
    if (claudiaMixer) claudiaMixer.update(dt);
    if (claudiaAnchor && claudia){
      claudia.position.y = Math.max(claudia.position.y, 0.002);
      claudiaAnchor.position.set(0.0, 0.02, -1.98);
      claudiaAnchor.lookAt(new THREE.Vector3(0, 1.04, 0.10));
      claudiaAnchor.rotation.z = 0;
      claudiaAnchor.rotation.x = 0;
      claudia.rotation.x = 0;
      claudia.rotation.z = 0;
      claudia.position.y = Math.max(0.0, claudia.position.y);
      claudia.position.x = 0;
      claudia.position.z = 0;
      const dealerSwing = Math.sin(t * 2.0) * 0.16;
      dealerSource.set(0.24 + dealerSwing * 0.08, tableTopY + 0.16 + Math.abs(Math.sin(t * 2.0)) * 0.01, -1.08 + Math.cos(t * 2.0) * 0.02);
      if (claudiaPose){
        claudiaPose.spine.forEach((bone, i)=>{
          bone.rotation.x = 0.02 + Math.sin(t * 1.0 + i * 0.2) * 0.01;
          bone.rotation.y = Math.sin(t * 0.75 + i * 0.2) * 0.04;
          bone.rotation.z = 0.0;
        });
        claudiaPose.shoulder.forEach((bone, i)=>{
          bone.rotation.x = -0.02;
          bone.rotation.y = Math.sin(t * 1.4 + i) * 0.02;
          bone.rotation.z = 0.0;
        });
        claudiaPose.leftArm.forEach((bone)=>{ bone.rotation.x = -0.10; bone.rotation.y = 0.02; bone.rotation.z = 0.08; });
        claudiaPose.leftFore.forEach((bone)=>{ bone.rotation.x = -0.44; bone.rotation.y = 0.0; bone.rotation.z = 0.10; });
        claudiaPose.leftHand.forEach((bone)=>{ bone.rotation.x = 0.06; bone.rotation.y = 0.0; bone.rotation.z = 0.0; });
        claudiaPose.rightArm.forEach((bone)=>{ bone.rotation.x = -0.06; bone.rotation.y = -0.12; bone.rotation.z = -0.16 + dealerSwing * 0.03; });
        claudiaPose.rightFore.forEach((bone)=>{ bone.rotation.x = -0.70; bone.rotation.y = 0.0; bone.rotation.z = 0.08 - dealerSwing * 0.03; });
        claudiaPose.rightHand.forEach((bone)=>{ bone.rotation.x = 0.12; bone.rotation.y = 0.02; bone.rotation.z = 0.0; });
      } else {
        claudiaUpper.forEach((bone, i)=>{
          const n = (bone.name || '').toLowerCase();
          if (/right.*arm|arm.*right|_r|\.r/.test(n)){ bone.rotation.x = -0.08; bone.rotation.z = -0.12; }
          else if (/left.*arm|arm.*left|_l|\.l/.test(n)){ bone.rotation.x = -0.10; bone.rotation.z = 0.14; }
          else if (/forearm|lowerarm/.test(n)){ bone.rotation.x = -0.42; }
          else if (/hand/.test(n)){ bone.rotation.x = 0.08; }
          else if (/shoulder|spine/.test(n)){ bone.rotation.y = Math.sin(t * 0.45 + i * 0.2) * 0.02; }
        });
      }
    }
  };

  return {
    roomClamp: R - 2.5,
    tableCenter: new THREE.Vector3(0, 0, 0),
    seats,
    joinRadius: 6.3,
    previewOrbitRadius: 12.8
  };
}
