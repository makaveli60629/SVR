import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";
import { CONFIG } from "./config.js";
import { assetUrls, loadFirstTexture } from "./asset_base.js";

function delay(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }
async function withTimeout(promise, ms){
  return await Promise.race([
    promise,
    (async()=>{ await delay(ms); throw new Error("timeout"); })()
  ]);
}
function boxSize(obj){
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  return { size, center, box };
}
function dropToGround(obj){
  const { size, center } = boxSize(obj);
  obj.position.y += (size.y * 0.5) - center.y;
}
function scaleToHeight(obj, targetH){
  const { size } = boxSize(obj);
  if (size.y > 0.0001) obj.scale.multiplyScalar(targetH / size.y);
}
function fitDiameter(obj, targetDia){
  const { size } = boxSize(obj);
  const dia = Math.max(size.x, size.z);
  if (dia > 0.0001) obj.scale.multiplyScalar(targetDia / dia);
}

function orientCharacterUpright(obj){
  const trials = [
    [0,0,0],
    [-Math.PI*0.5,0,0],
    [Math.PI*0.5,0,0],
    [0,0,Math.PI*0.5],
    [0,0,-Math.PI*0.5],
    [0,Math.PI,0],
    [-Math.PI*0.5,Math.PI,0],
    [Math.PI*0.5,Math.PI,0],
    [0,Math.PI,Math.PI*0.5],
    [0,Math.PI,-Math.PI*0.5]
  ];
  const original = obj.rotation.clone();
  let best = { score: -Infinity, rot: original.clone() };
  for (const [rx,ry,rz] of trials){
    obj.rotation.set(rx,ry,rz);
    obj.updateMatrixWorld(true);
    const { size } = boxSize(obj);
    const score = size.y - Math.max(size.x, size.z) * 0.25;
    if (Number.isFinite(score) && score > best.score){
      best = { score, rot: obj.rotation.clone() };
    }
  }
  obj.rotation.copy(best.rot);
  obj.updateMatrixWorld(true);
}
async function tryLoadGLTF(urls, log, timeoutMs = 12000){
  const loader = new GLTFLoader();
  for (const url of urls){
    try{
      const gltf = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded GLTF:", url);
      return gltf.scene;
    }catch(_err){ log("GLTF miss:", url); }
  }
  return null;
}
async function tryLoadFBX(urls, log, timeoutMs = 12000){
  const loader = new FBXLoader();
  for (const url of urls){
    try{
      const fbx = await withTimeout(loader.loadAsync(url), timeoutMs);
      log("Loaded FBX:", url);
      return fbx;
    }catch(_err){ log("FBX miss:", url); }
  }
  return null;
}
function canvasTexture(width, height, painter){
  const c = document.createElement("canvas");
  c.width = width; c.height = height;
  const x = c.getContext("2d");
  painter(x, width, height, c);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  return tex;
}
function makeSpriteTexture(){
  return canvasTexture(128, 128, (x,w,h)=>{
    const g = x.createRadialGradient(w/2,h/2,3,w/2,h/2,58);
    g.addColorStop(0,"rgba(255,255,255,1)");
    g.addColorStop(0.18,"rgba(220,230,255,0.95)");
    g.addColorStop(0.42,"rgba(180,140,255,0.26)");
    g.addColorStop(1,"rgba(180,140,255,0)");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
  });
}
function makeEarthTexture(){
  return canvasTexture(1024, 512, (x,w,h)=>{
    x.fillStyle = "#0a2c60";
    x.fillRect(0,0,w,h);
    for (let i = 0; i < 68; i++){
      x.fillStyle = `rgba(${20 + Math.random()*40|0}, ${90 + Math.random()*90|0}, ${60 + Math.random()*60|0}, ${0.55 + Math.random()*0.25})`;
      x.beginPath();
      x.ellipse(Math.random()*w, Math.random()*h, 40+Math.random()*130, 18+Math.random()*75, Math.random()*Math.PI, 0, Math.PI*2);
      x.fill();
    }
    x.fillStyle = "rgba(255,255,255,0.22)";
    for (let i = 0; i < 24; i++){
      x.beginPath();
      x.ellipse(Math.random()*w, Math.random()*h, 60+Math.random()*180, 15+Math.random()*40, Math.random()*Math.PI, 0, Math.PI*2);
      x.fill();
    }
  });
}
function makeWoodTexture(){
  return canvasTexture(1024, 256, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,0,h);
    g.addColorStop(0,"#5f381c");
    g.addColorStop(1,"#2a160d");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    for (let i=0;i<180;i++){
      x.strokeStyle = `rgba(${120+Math.random()*80|0},${70+Math.random()*35|0},${35+Math.random()*20|0},0.22)`;
      x.beginPath();
      const yy = Math.random()*h;
      x.moveTo(0,yy);
      x.bezierCurveTo(w*0.25, yy+Math.random()*18-9, w*0.75, yy+Math.random()*18-9, w, yy+Math.random()*12-6);
      x.stroke();
    }
  });
}
function makeChairTexture(){
  return canvasTexture(512, 512, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0,"#2c1a34");
    g.addColorStop(1,"#17111f");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(255,255,255,0.08)";
    x.lineWidth = 2;
    for (let i=0;i<24;i++){
      x.beginPath();
      x.moveTo(0, i*(h/24));
      x.lineTo(w, i*(h/24));
      x.stroke();
    }
  });
}
function buildStars(scene, R){
  const count = 8400;
  const pos = new Float32Array(count * 3);
  const col = new Float32Array(count * 3);
  for (let i = 0; i < count; i++){
    const rr = R + 95 + Math.random() * 220;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI * 0.48 + 0.02;
    pos[i*3+0] = Math.cos(theta) * Math.sin(phi) * rr;
    pos[i*3+1] = Math.cos(phi) * rr * 0.95 + 42;
    pos[i*3+2] = Math.sin(theta) * Math.sin(phi) * rr;
    const tint = 0.84 + Math.random() * 0.16;
    col[i*3+0] = tint;
    col[i*3+1] = 0.88 + Math.random() * 0.12;
    col[i*3+2] = 0.96 + Math.random() * 0.04;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({
    size: 0.082,
    sizeAttenuation: true,
    transparent: true,
    opacity: 0.96,
    map: makeSpriteTexture(),
    vertexColors: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  }));
  scene.add(pts);

  const spriteGroup = new THREE.Group();
  for (let i = 0; i < 360; i++){
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: makeSpriteTexture(),
      color: new THREE.Color(i % 7 === 0 ? 0xb48cff : 0xffffff),
      transparent: true,
      opacity: 0.20 + Math.random() * 0.12,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    }));
    spr.scale.setScalar(0.022 + Math.random() * 0.07);
    const rr = R + 110 + Math.random() * 180;
    const theta = Math.random() * Math.PI * 2;
    const y = 55 + Math.random() * 120;
    spr.position.set(Math.cos(theta) * rr, y, Math.sin(theta) * rr);
    spriteGroup.add(spr);
  }
  scene.add(spriteGroup);
  return { pts, spriteGroup };
}
function createOrbHaloSprite(color = 0xffffff, opacity = 0.5){
  return new THREE.Sprite(new THREE.SpriteMaterial({
    map: makeSpriteTexture(),
    color,
    transparent: true,
    opacity,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  }));
}
function createMatrixBillboardTexture(variant = "main"){
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 1536;
  const ctx = canvas.getContext("2d");
  const glyphs = "0101SVRPOKERALLIN0101011010010110";
  const phrases = variant === "main"
    ? ["SCARLETT VR POKER", "ALL IN", "SPONSOR READY", "DONOR NATION", "WIN MONEY"]
    : ["RESERVED FOR SPONSOR", "BINARY RAIN ACTIVE", "SCARLETT VR POKER"];
  const cols = Array.from({ length: 60 }, (_, i)=>({ x: 12 + i * 17, y: Math.random() * canvas.height, speed: 9 + (i % 7) }));
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  function redraw(t = 0){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    const bg = ctx.createLinearGradient(0,0,0,canvas.height);
    bg.addColorStop(0, "rgba(5,0,12,0.98)");
    bg.addColorStop(1, "rgba(1,2,8,1.0)");
    ctx.fillStyle = bg;
    ctx.fillRect(0,0,canvas.width,canvas.height);

    ctx.font = "bold 22px monospace";
    cols.forEach((c, i)=>{
      const phase = Math.floor(t * 22 + i * 5);
      for (let j = 0; j < 96; j++){
        const yy = (c.y + j * 18) % (canvas.height + 160) - 80;
        const char = glyphs[(phase + j + i * 3) % glyphs.length];
        const hot = j < 4;
        ctx.fillStyle = hot ? "rgba(255,245,255,0.98)" : (i % 2 ? "rgba(238,114,255,0.80)" : "rgba(118,204,255,0.82)");
        ctx.fillText(char, c.x, yy);
      }
      c.y += c.speed;
      if (c.y > canvas.height + 40) c.y = -Math.random() * 180;
    });

    const panelTop = variant === "main" ? 200 : 320;
    const panelH = variant === "main" ? 1080 : 860;
    ctx.fillStyle = "rgba(7,10,18,0.40)";
    ctx.fillRect(70, panelTop, canvas.width - 140, panelH);
    ctx.strokeStyle = "rgba(148,226,255,0.40)";
    ctx.lineWidth = 4;
    ctx.strokeRect(70, panelTop, canvas.width - 140, panelH);

    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    phrases.forEach((line, idx)=>{
      ctx.fillStyle = idx % 2 ? "rgba(202,144,255,0.98)" : "rgba(230,245,255,0.98)";
      ctx.font = idx === 0 ? "bold 62px system-ui, Arial" : "bold 42px system-ui, Arial";
      ctx.fillText(line, canvas.width / 2, panelTop + 130 + idx * 96);
    });
    tex.needsUpdate = true;
  }
  redraw(0);
  return { texture: tex, update: redraw };
}

function createSponsorPlateTexture(title = "MAIN SPONSOR SCREEN", subtitle = "SCARLETT VR POKER"){
  return canvasTexture(1024, 256, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0, "rgba(5,16,30,0.94)");
    g.addColorStop(1, "rgba(25,4,34,0.94)");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(130,210,255,0.95)";
    x.lineWidth = 8;
    x.strokeRect(10,10,w-20,h-20);
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.fillStyle = "#f2f7ff";
    x.font = "bold 56px system-ui, Arial";
    x.fillText(title, w/2, 92);
    x.fillStyle = "rgba(198,136,255,0.96)";
    x.font = "bold 34px system-ui, Arial";
    x.fillText(subtitle, w/2, 172);
  });
}
function createAdBillboardTexture(lines = ["SVRPOKER.COM", "ALL IN"]){
  return canvasTexture(512, 512, (x,w,h)=>{
    const g = x.createLinearGradient(0,0,w,h);
    g.addColorStop(0,"#04122c");
    g.addColorStop(1,"#25092a");
    x.fillStyle = g;
    x.fillRect(0,0,w,h);
    x.strokeStyle = "rgba(127,212,255,0.92)";
    x.lineWidth = 8;
    x.strokeRect(18,18,w-36,h-36);
    x.fillStyle = "#f6fbff";
    x.textAlign = "center";
    x.textBaseline = "middle";
    x.font = "bold 52px system-ui, Arial";
    x.fillText(lines[0], w/2, h/2 - 40);
    x.font = "bold 64px system-ui, Arial";
    x.fillText(lines[1], w/2, h/2 + 38);
  });
}
function buildOuterCity(scene, R){
  const group = new THREE.Group();
  const glassMats = [
    new THREE.MeshPhysicalMaterial({ color: 0x9fdfff, roughness: 0.12, metalness: 0.35, transmission: 0.08, transparent: true, opacity: 0.92, emissive: 0x15396a, emissiveIntensity: 1.8 }),
    new THREE.MeshPhysicalMaterial({ color: 0xb993ff, roughness: 0.14, metalness: 0.30, transmission: 0.06, transparent: true, opacity: 0.9, emissive: 0x31125f, emissiveIntensity: 1.6 }),
    new THREE.MeshPhysicalMaterial({ color: 0x8bd7ff, roughness: 0.10, metalness: 0.32, transmission: 0.1, transparent: true, opacity: 0.92, emissive: 0x1c4e84, emissiveIntensity: 1.9 })
  ];
  const bodyMats = [
    new THREE.MeshStandardMaterial({ color: 0x08111d, roughness: 0.68, metalness: 0.24, emissive: 0x091624, emissiveIntensity: 0.8 }),
    new THREE.MeshStandardMaterial({ color: 0x0b1623, roughness: 0.62, metalness: 0.28, emissive: 0x0c1b2d, emissiveIntensity: 0.9 }),
    new THREE.MeshStandardMaterial({ color: 0x0a131d, roughness: 0.64, metalness: 0.26, emissive: 0x0d1828, emissiveIntensity: 0.85 })
  ];
  const matrix = createMatrixBillboardTexture();
  const adTex = createAdBillboardTexture();
  const billboardUpdaters = [matrix.update];

  const count = 248;
  for (let i = 0; i < count; i++){
    const a = (i / count) * Math.PI * 2;
    const rr = (R + 8) + Math.random() * 22;
    const h = 12 + Math.random() * 46;
    const w = 1.8 + Math.random() * 4.8;
    const d = 1.8 + Math.random() * 4.8;
    const x = Math.cos(a) * rr;
    const z = Math.sin(a) * rr;
    const style = i % 6;
    const bodyMat = bodyMats[i % bodyMats.length];
    const glassMat = glassMats[i % glassMats.length];
    let bodyGeo;
    if (style === 0) bodyGeo = new THREE.BoxGeometry(w, h, d);
    else if (style === 1) bodyGeo = new THREE.CylinderGeometry(w * 0.52, w * 0.66, h, 10);
    else if (style === 2) bodyGeo = new THREE.BoxGeometry(w, h, d * 0.72);
    else if (style === 3) bodyGeo = new THREE.CylinderGeometry(w * 0.54, w * 0.62, h, 8);
    else if (style === 4) bodyGeo = new THREE.BoxGeometry(w * 0.88, h, d * 1.15);
    else bodyGeo = new THREE.BoxGeometry(w * 1.05, h, d * 0.84);
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.set(x, h / 2, z);
    body.rotation.y = -a + Math.PI / 2;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    const outward = new THREE.Vector3(Math.cos(a), 0, Math.sin(a));
    const frontGlass = new THREE.Mesh(new THREE.PlaneGeometry(Math.max(1.0, w * 0.76), Math.max(6, h * 0.86)), glassMat);
    frontGlass.position.set(x - outward.x * (d * 0.5 + 0.04), h * 0.5, z - outward.z * (d * 0.5 + 0.04));
    frontGlass.lookAt(frontGlass.position.clone().sub(outward));
    group.add(frontGlass);

    const stripCount = 3 + (Math.random() * 5 | 0);
    for (let s2 = 0; s2 < stripCount; s2++){
      const strip = new THREE.Mesh(new THREE.BoxGeometry(Math.max(0.4, w * 0.88), 0.18, Math.max(0.18, d * 1.02)), glassMat);
      strip.position.set(x, 2 + ((s2 + 1) / (stripCount + 1)) * (h - 3), z);
      strip.rotation.y = body.rotation.y;
      group.add(strip);
    }

    if (style !== 1){
      const cap = new THREE.Mesh(new THREE.BoxGeometry(w * 0.82, 0.9 + Math.random() * 1.3, d * 0.82), glassMat);
      cap.position.set(x, h + cap.geometry.parameters.height * 0.5, z);
      cap.rotation.y = body.rotation.y;
      group.add(cap);
    }

    if (i % 7 === 0){
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.6 + Math.random() * 3.4, 8), glassMat);
      pole.position.set(x, h + 1.2, z);
      group.add(pole);
      const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 10), glassMat);
      beacon.position.set(x, pole.position.y + pole.geometry.parameters.height * 0.5, z);
      group.add(beacon);
    }

    if (i === 8 || i === 44 || i === 118){
      const tex = i === 44 ? matrix.texture : adTex;
      tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
      const bill = new THREE.Mesh(
        new THREE.PlaneGeometry(2.8, 5.4),
        new THREE.MeshBasicMaterial({ map: tex, transparent: true, side: THREE.DoubleSide })
      );
      bill.position.set(x - outward.x * (w * 0.52 + 0.35), Math.min(h * 0.68, 16), z - outward.z * (w * 0.52 + 0.35));
      bill.lookAt(bill.position.clone().sub(outward));
      group.add(bill);
    }
  }
  scene.add(group);
  return { group, billboardUpdaters };
}

function makeOvalTableTop(scene, tableTopY = 0.86, logoTex = null){
  const felt = new THREE.Mesh(
    new THREE.CircleGeometry(1.72, 80),
    new THREE.MeshStandardMaterial({
      map: logoTex || null,
      color: logoTex ? 0xffffff : 0x5b1e75,
      roughness: 0.94,
      metalness: 0.0,
      emissive: 0x08040c,
      emissiveIntensity: 0.02,
      side: THREE.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: -4,
      polygonOffsetUnits: -4
    })
  );
  felt.rotation.x = -Math.PI / 2;
  felt.scale.set(1.0, 0.70, 1.0);
  felt.position.y = tableTopY + 0.012;
  felt.renderOrder = 8;
  scene.add(felt);

  const rail = new THREE.Mesh(
    new THREE.TorusGeometry(1.90, 0.09, 20, 96),
    new THREE.MeshStandardMaterial({ color: 0x3a2318, roughness: 0.78, metalness: 0.06, emissive: 0x090607, emissiveIntensity: 0.03 })
  );
  rail.rotation.x = Math.PI / 2;
  rail.scale.set(1.0, 1.0, 0.70);
  rail.position.y = tableTopY + 0.02;
  rail.renderOrder = 7;
  scene.add(rail);

  const passLine = new THREE.Mesh(
    new THREE.TorusGeometry(1.36, 0.012, 8, 96, Math.PI * 0.68),
    new THREE.MeshBasicMaterial({ color: 0xf1f1ff, transparent: true, opacity: 0.95 })
  );
  passLine.rotation.x = Math.PI / 2;
  passLine.rotation.z = Math.PI;
  passLine.scale.set(1.0, 1.0, 0.78);
  passLine.position.set(0, tableTopY + 0.016, 0.58);
  passLine.renderOrder = 9;
  scene.add(passLine);

  return { felt, rail, passLine };
}

function makeSeat(scene, x, z, angle, label, chairMat, metalMat){
  const group = new THREE.Group();
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.36, 0.54, 48),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.20, side: THREE.DoubleSide, depthWrite: false })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.028;
  group.add(ring);
  const seatBase = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.11, 0.72, 18), metalMat);
  seatBase.position.y = 0.36;
  group.add(seatBase);
  const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 0.06, 28), metalMat);
  foot.position.y = 0.03;
  group.add(foot);
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.12, 0.68), chairMat);
  seat.position.y = 0.72;
  seat.castShadow = true;
  seat.receiveShadow = true;
  group.add(seat);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.72, 0.12), chairMat);
  back.position.set(0, 1.08, -0.28);
  back.rotation.x = -0.12;
  back.castShadow = true;
  back.receiveShadow = true;
  group.add(back);
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 0.56), chairMat);
  armL.position.set(-0.34, 0.88, 0.02);
  group.add(armL);
  const armR = armL.clone();
  armR.position.x = 0.34;
  group.add(armR);
  const headrest = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.18, 0.1), chairMat);
  headrest.position.set(0, 1.42, -0.24);
  group.add(headrest);
  const legs = [[-0.24,0.34,-0.24],[0.24,0.34,-0.24],[-0.24,0.34,0.24],[0.24,0.34,0.24]];
  for (const [lx,ly,lz] of legs){
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.035, 0.72, 12), metalMat);
    leg.position.set(lx, ly, lz);
    group.add(leg);
  }
  group.position.set(x, 0, z);
  group.rotation.y = angle;
  scene.add(group);
  return { group, ring, x, z, angle, label };
}
function addChipsAndCards(scene, tableTopY = 0.86){
  const group = new THREE.Group();
  const chipMatA = new THREE.MeshStandardMaterial({ color: 0xb48cff, roughness: 0.35, metalness: 0.25, emissive: 0x230d30, emissiveIntensity: 0.35 });
  const chipMatB = new THREE.MeshStandardMaterial({ color: 0x00e2c7, roughness: 0.35, metalness: 0.25, emissive: 0x06261f, emissiveIntensity: 0.28 });
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf2f2ff, roughness: 0.85, metalness: 0.03 });
  const redPip = new THREE.MeshStandardMaterial({ color: 0xd6263d, roughness: 0.7 });
  const stacks = [[-1.08, 1.12, chipMatA],[-0.42, 1.26, chipMatB],[0.48, 1.18, chipMatA],[1.12, 1.04, chipMatB]];
  for (const [x, z, mat] of stacks){
    for (let i = 0; i < 6; i++){
      const chip = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.018, 24), mat);
      chip.position.set(x, tableTopY + 0.015 + i * 0.02, z - 0.19);
      chip.rotation.x = Math.PI / 2;
      chip.castShadow = true;
      chip.receiveShadow = true;
      group.add(chip);
    }
  }
  for (let i = 0; i < 5; i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.004, 0.18), cardMat);
    card.position.set(-0.34 + i * 0.17, tableTopY + 0.008, -0.05 + (i % 2) * 0.01);
    card.rotation.y = -0.18 + i * 0.09;
    card.castShadow = true;
    card.receiveShadow = true;
    group.add(card);
    const pip = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.002, 0.018), redPip);
    pip.position.copy(card.position).add(new THREE.Vector3(0.034, 0.004, 0.055));
    group.add(pip);
  }
  scene.add(group);
  return group;
}

function addDealingDemo(scene, seats, tableTopY = 0.86){
  const group = new THREE.Group();
  const cardMat = new THREE.MeshStandardMaterial({ color: 0xf8f8ff, roughness: 0.82, metalness: 0.04, emissive: 0x161622, emissiveIntensity: 0.12 });
  const redMat = new THREE.MeshStandardMaterial({ color: 0xcf2644, roughness: 0.7, metalness: 0.02 });
  const cards = [];
  const dealer = new THREE.Vector3(0, tableTopY + 0.44, 1.46);
  const targetSeats = seats.filter(s=>s.label !== "Dealer Side");
  for (let i = 0; i < 3; i++){
    const card = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.004, 0.18), cardMat);
    card.castShadow = true; card.receiveShadow = true;
    const pip = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.0022, 0.018), redMat);
    group.add(card); group.add(pip);
    cards.push({ card, pip, offset: i * 0.92 });
  }
  scene.add(group);
  function update(t){
    cards.forEach((rec, idx)=>{
      const loop = (t * 0.75 + rec.offset) % targetSeats.length;
      const seatIndex = Math.floor(loop);
      const nextSeat = targetSeats[seatIndex];
      const f = loop - seatIndex;
      const lift = Math.sin(f * Math.PI) * 0.28;
      const target = new THREE.Vector3(nextSeat.x * 0.48, tableTopY + 0.10 + lift, nextSeat.z * 0.48 - 0.05);
      rec.card.position.lerpVectors(dealer, target, f);
      rec.card.rotation.set(-0.35 - lift * 0.3, Math.atan2(target.x - dealer.x, target.z - dealer.z), 0.08 * Math.sin((t + idx) * 2.2));
      rec.pip.position.copy(rec.card.position).add(new THREE.Vector3(0.032, 0.004, 0.054));
      rec.pip.rotation.copy(rec.card.rotation);
    });
  }
  return { group, update, dealer };
}

function applyEricMaterial(obj, texture, normalTex){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    child.material = new THREE.MeshStandardMaterial({
      map: texture || null,
      normalMap: normalTex || null,
      color: texture ? 0xffffff : 0xd6d4e8,
      roughness: 0.68,
      metalness: 0.02,
      emissive: 0x0d0914,
      emissiveIntensity: 0.06,
      side: THREE.DoubleSide,
      skinning: !!child.isSkinnedMesh
    });
    child.frustumCulled = false;
  });
}
function applyClaudiaMaterial(obj, texture){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    child.material = new THREE.MeshStandardMaterial({
      map: texture || null,
      color: texture ? 0xffffff : 0xe6e6f2,
      roughness: 0.72,
      metalness: 0.02,
      emissive: 0x0b0d18,
      emissiveIntensity: 0.05,
      side: THREE.DoubleSide,
      skinning: !!child.isSkinnedMesh,
      alphaTest: 0.1
    });
    child.frustumCulled = false;
  });
}
function touchModelShadows(obj){
  obj.traverse((child)=>{
    if (!child.isMesh) return;
    child.castShadow = true;
    child.receiveShadow = true;
    if (!Array.isArray(child.material) && child.material) child.material.side = THREE.DoubleSide;
    child.frustumCulled = false;
  });
}
function sanitizeTableSurface(table){
  const box = new THREE.Box3();
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  const hideByName = /circle007|circle008|object002|object001|circle005|circle02/i;
  table.updateMatrixWorld(true);
  table.traverse((child)=>{
    if (!child.isMesh) return;
    box.setFromObject(child);
    box.getSize(size);
    box.getCenter(center);
    const isThinCap = size.y < 0.06 && Math.max(size.x, size.z) > 0.9 && center.y > 0.42;
    if (isThinCap || hideByName.test(child.name || '')) child.visible = false;
  });
}
export async function buildSkylineRoom(scene, { log = console.log } = {}){
  const R = CONFIG.ROOM_RADIUS;
  const H = CONFIG.WALL_HEIGHT;
  scene.fog = new THREE.FogExp2(0x010105, 0.0036);
  const hemi = new THREE.HemisphereLight(0xd8e5ff, 0x02040a, 0.98);
  scene.add(hemi);
  const key = new THREE.DirectionalLight(0xf8fbff, 4.5);
  key.position.set(16, 28, 12);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.left = -24;
  key.shadow.camera.right = 24;
  key.shadow.camera.top = 24;
  key.shadow.camera.bottom = -24;
  scene.add(key);
  const tableSpot = new THREE.SpotLight(0xf8fbff, 14.0, 120, Math.PI * 0.30, 0.24, 1.0);
  tableSpot.position.set(0, 15, 4);
  tableSpot.target.position.set(0, 0.8, 0);
  tableSpot.castShadow = true;
  scene.add(tableSpot);
  scene.add(tableSpot.target);
  const fill = new THREE.PointLight(0x7fafff, 4.2, 220, 1.8);
  fill.position.set(0, 10.2, 0);
  scene.add(fill);
  const rimLight = new THREE.PointLight(0x6d6cff, 5.2, 260, 1.8);
  rimLight.position.set(20, 18, -34);
  scene.add(rimLight);

  const floorTex = await loadFirstTexture(assetUrls("texture/slate_basecolor.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const floorNormal = await loadFirstTexture(assetUrls("texture/slate_normal.png"));
  const floorRough = await loadFirstTexture(assetUrls("texture/slate_roughness.jpg"));
  [floorTex, floorNormal, floorRough].forEach(tex=>{ if (tex){ tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(180,180); } });
  const wallTex = await loadFirstTexture(assetUrls("texture/stonebrick_wall_basecolor.png"), { colorSpace: THREE.SRGBColorSpace });
  const wallNormal = await loadFirstTexture(assetUrls("texture/stonebrick_wall_normal.png"));
  const wallRough = await loadFirstTexture(assetUrls("texture/stonebrick_wall_roughness.png"));
  [wallTex, wallNormal, wallRough].forEach(tex=>{ if (tex){ tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(120,30); } });

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(R + 34, 220),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.9,
      metalness: 0.03,
      map: floorTex || null,
      normalMap: floorNormal || null,
      normalScale: new THREE.Vector2(0.38, 0.38),
      roughnessMap: floorRough || null
    })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const wallHeight = H * 0.56;
  const wall = new THREE.Mesh(
    new THREE.CylinderGeometry(R, R, wallHeight, 220, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.84,
      metalness: 0.04,
      emissive: 0x143154,
      emissiveIntensity: 0.18,
      side: THREE.BackSide,
      map: wallTex || null,
      normalMap: wallNormal || null,
      normalScale: new THREE.Vector2(0.36, 0.36),
      roughnessMap: wallRough || null
    })
  );
  wall.position.set(0, wallHeight / 2, 0);
  scene.add(wall);

  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(R - 1.2, 0.18, 16, 220),
    new THREE.MeshStandardMaterial({
      color: 0xb48cff,
      roughness: 0.2,
      metalness: 0.35,
      emissive: 0x2a0d3a,
      emissiveIntensity: 0.28
    })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.set(0, wallHeight - 0.18, 0);
  scene.add(rim);

  const innerPlatform = new THREE.Mesh(
    new THREE.CylinderGeometry(9.4, 9.7, 0.08, 96),
    new THREE.MeshStandardMaterial({
      color: 0x101018,
      roughness: 0.86,
      metalness: 0.08,
      emissive: 0x090814,
      emissiveIntensity: 0.06
    })
  );
  innerPlatform.position.y = -0.12;
  innerPlatform.receiveShadow = true;
  scene.add(innerPlatform);

  const city = buildOuterCity(scene, R);
  const stars = buildStars(scene, R);
  const spawnLogoTex = await loadFirstTexture(assetUrls("ui/logo.png", "logo.png"), { colorSpace: THREE.SRGBColorSpace });
  const wallPanels = [];
  const wallPanelUpdaters = [];
  [
    { angle: Math.PI, kind: "main", title: "MAIN SPONSOR SCREEN", subtitle: "SCARLETT VR POKER", size: [8.8, wallHeight - 0.36], logo: [2.3, 2.3], y: wallHeight * 0.5 },
    { angle: 0, kind: "reserve", title: "RESERVED FOR SPONSOR", subtitle: "SOUTH SPAWN", size: [6.8, wallHeight - 0.46], logo: [1.8, 1.8], y: wallHeight * 0.5 },
    { angle: -Math.PI * 0.5, kind: "reserve", title: "RESERVED FOR SPONSOR", subtitle: "EAST SPAWN", size: [6.8, wallHeight - 0.46], logo: [1.8, 1.8], y: wallHeight * 0.5 },
    { angle: Math.PI * 0.5, kind: "reserve", title: "RESERVED FOR SPONSOR", subtitle: "WEST SPAWN", size: [6.8, wallHeight - 0.46], logo: [1.8, 1.8], y: wallHeight * 0.5 }
  ].forEach(({ angle, kind, title, subtitle, size, logo, y })=>{
    const matrix = createMatrixBillboardTexture(kind === "main" ? "main" : "reserve");
    wallPanelUpdaters.push(matrix.update);
    const panel = new THREE.Mesh(
      new THREE.PlaneGeometry(size[0], size[1]),
      new THREE.MeshBasicMaterial({ map: matrix.texture, transparent: true, side: THREE.DoubleSide })
    );
    const rr = R - 0.28;
    panel.position.set(Math.cos(angle) * rr, y, Math.sin(angle) * rr);
    panel.lookAt(0, y, 0);
    scene.add(panel);
    wallPanels.push(panel);
    if (spawnLogoTex){
      const logoMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(logo[0], logo[1]),
        new THREE.MeshBasicMaterial({ map: spawnLogoTex, transparent: true, side: THREE.DoubleSide })
      );
      logoMesh.position.copy(panel.position).add(new THREE.Vector3(0, kind === "main" ? 1.85 : 1.25, 0));
      logoMesh.lookAt(0, y, 0);
      scene.add(logoMesh);
      wallPanels.push(logoMesh);
    }
    const plateTex = createSponsorPlateTexture(title, subtitle);
    const plate = new THREE.Mesh(
      new THREE.PlaneGeometry(kind === "main" ? 5.4 : 4.5, 1.3),
      new THREE.MeshBasicMaterial({ map: plateTex, transparent: true, side: THREE.DoubleSide })
    );
    plate.position.copy(panel.position).add(new THREE.Vector3(0, -(size[1] * 0.33), 0));
    plate.lookAt(0, y, 0);
    scene.add(plate);
    wallPanels.push(plate);
  });

  const moonTex = await loadFirstTexture(assetUrls("texture/moon_diffuse.png"), { colorSpace: THREE.SRGBColorSpace });
  const moonBump = await loadFirstTexture(assetUrls("texture/moon_bump.png"));
  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(11.6, 56, 56),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.78,
      metalness: 0.02,
      map: makeEarthTexture(),
      emissive: 0x57a8ff,
      emissiveIntensity: 2.8
    })
  );
  earth.position.set(0, 76, -30);
  earth.rotation.z = 0.35;
  scene.add(earth);
  const earthHalo = createOrbHaloSprite(0x6bc4ff, 0.62);
  earthHalo.scale.set(110, 110, 1);
  scene.add(earthHalo);
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(5.9, 48, 48),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.94,
      metalness: 0.0,
      map: moonTex || null,
      bumpMap: moonBump || null,
      bumpScale: moonBump ? 0.24 : 0,
      emissive: 0xa9c2ff,
      emissiveIntensity: 2.2
    })
  );
  moon.position.set(12, 82, -18);
  scene.add(moon);
  const moonHalo = createOrbHaloSprite(0xf4f7ff, 0.5);
  moonHalo.scale.set(72, 72, 1);
  scene.add(moonHalo);
  const earthSpark = new THREE.Group();
  for (let i = 0; i < 20; i++){
    const spr = createOrbHaloSprite(i % 2 ? 0x79d8ff : 0xffffff, 0.40);
    spr.scale.setScalar(2.0 + (i % 3) * 0.8);
    earthSpark.add(spr);
  }
  scene.add(earthSpark);
  const moonSpark = new THREE.Group();
  for (let i = 0; i < 14; i++){
    const spr = createOrbHaloSprite(i % 2 ? 0xfefefe : 0xbcd3ff, 0.34);
    spr.scale.setScalar(1.4 + (i % 3) * 0.6);
    moonSpark.add(spr);
  }
  scene.add(moonSpark);
  const earthGlow = new THREE.PointLight(0x70c8ff, 240.0, 1200, 1.22);
  scene.add(earthGlow);
  const moonGlow = new THREE.PointLight(0xfaf8ff, 180.0, 980, 1.20);
  scene.add(moonGlow);
  const skylineGlow = new THREE.PointLight(0x3b74ff, 15.8, 420, 1.7);
  skylineGlow.position.set(0, 26, -(R + 8));
  scene.add(skylineGlow);
  const accentGlow = new THREE.PointLight(0x92c2ff, 3.8, 110, 2.0);
  accentGlow.position.set(-9, 8, 7);
  scene.add(accentGlow);
  const atmosphereGlow = new THREE.Mesh(
    new THREE.SphereGeometry(R + 18, 42, 42),
    new THREE.MeshBasicMaterial({ color: 0x0a1f3f, transparent: true, opacity: 0.0, side: THREE.BackSide })
  );
  scene.add(atmosphereGlow);
  const haze = new THREE.Mesh(
    new THREE.CylinderGeometry(14, 22, 6, 64, 1, true),
    new THREE.MeshBasicMaterial({ color: 0x251138, transparent: true, opacity: 0.0, side: THREE.DoubleSide })
  );
  haze.position.y = 3.5;
  scene.add(haze);

  const chairTex = makeChairTexture();
  chairTex.repeat.set(2,2);
  const chairMat = new THREE.MeshStandardMaterial({ map: chairTex, color: 0xffffff, roughness: 0.62, metalness: 0.12, emissive: 0x12081a, emissiveIntensity: 0.10 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x272a31, roughness: 0.35, metalness: 0.55, emissive: 0x0e1016, emissiveIntensity: 0.08 });
  const seatRadius = 3.45;
  const seats = [
    makeSeat(scene, 0, -seatRadius, 0, "Front Center", chairMat, metalMat),
    makeSeat(scene, -2.8, -1.76, -Math.PI * 0.28, "Front Left", chairMat, metalMat),
    makeSeat(scene,  2.8, -1.76,  Math.PI * 0.28, "Front Right", chairMat, metalMat),
    makeSeat(scene, -2.8, 1.76, -Math.PI * 0.72, "Back Left", chairMat, metalMat),
    makeSeat(scene,  2.8, 1.76,  Math.PI * 0.72, "Back Right", chairMat, metalMat),
    makeSeat(scene, 0, seatRadius, Math.PI, "Dealer Side", chairMat, metalMat)
  ];

  const table = await tryLoadGLTF(assetUrls("models/table.glb"), log, 10000) || await tryLoadFBX(assetUrls("models/table.fbx"), log, 10000);
  let tableTopY = 0.86;
  if (table){
    touchModelShadows(table);
    scaleToHeight(table, 1.04);
    dropToGround(table);
    fitDiameter(table, 4.05);
    dropToGround(table);
    table.position.set(0, 0, 0);
    sanitizeTableSurface(table);
    scene.add(table);
    const tbox = new THREE.Box3().setFromObject(table);
    tableTopY = tbox.max.y - 0.03;
  }
  makeOvalTableTop(scene, tableTopY, spawnLogoTex);
  const feltGlow = new THREE.Mesh(
    new THREE.RingGeometry(0.94, 1.36, 64),
    new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false })
  );
  feltGlow.rotation.x = -Math.PI / 2;
  feltGlow.position.y = tableTopY + 0.006;
  feltGlow.visible = false;
  scene.add(feltGlow);
  const tableAccentA = new THREE.PointLight(0xb48cff, 0.0, 12, 2.0);
  tableAccentA.position.set(-1.2, tableTopY + 0.6, 0.4);
  scene.add(tableAccentA);
  const tableAccentB = new THREE.PointLight(0x7bd5ff, 0.0, 12, 2.0);
  tableAccentB.position.set(1.2, tableTopY + 0.6, -0.4);
  scene.add(tableAccentB);
  addChipsAndCards(scene, tableTopY);
  const dealingDemo = addDealingDemo(scene, seats, tableTopY);

  let claudia = null;
  let claudiaAnchor = null;
  let claudiaMixer = null;
  const claudiaUpper = [];
  const claudiaTex = await loadFirstTexture(assetUrls("models/claudia/rp_claudia_rigged_002_dif.jpg"), { colorSpace: THREE.SRGBColorSpace });
  const claudiaBase = await tryLoadFBX(assetUrls("models/claudia/claudia.fbx"), log, 14000);
  const claudiaWalk = await tryLoadFBX(assetUrls("models/claudia/walking.fbx"), log, 14000);
  if (claudiaBase){
    claudia = claudiaBase;
    applyClaudiaMaterial(claudia, claudiaTex);
    orientCharacterUpright(claudia);
    scaleToHeight(claudia, 1.72);
    dropToGround(claudia);
    const cb = boxSize(claudia).box;
    claudia.position.set(0, Math.max(0.04, -cb.min.y + 0.04), 0);
    claudia.traverse((obj)=>{ if (obj.isBone && /(arm|forearm|hand|spine|shoulder)/i.test(obj.name || "")) claudiaUpper.push(obj); });
    claudiaAnchor = new THREE.Group();
    claudiaAnchor.position.set(0.0, 0.02, 2.42);
    claudiaAnchor.add(claudia);
    claudiaAnchor.lookAt(new THREE.Vector3(0, 1.05, -0.9));
    scene.add(claudiaAnchor);
 catch(err) {
        log("Claudia animation fallback", err?.message || err);
      }
    }
  }

  scene.userData._tickWorld = (dt)=>{
    scene.userData._time = (scene.userData._time || 0) + dt;
    const t = scene.userData._time;
    dealingDemo.update(t);
    earth.rotation.y += dt * 0.12;
    earth.rotation.z = 0.16 + Math.sin(t * 0.14) * 0.03;
    const roomOrbit = t * 0.04;
    earth.position.set(
      Math.cos(roomOrbit) * 18,
      76 + Math.sin(t * 0.08) * 3.0,
      -28 + Math.sin(roomOrbit) * 12
    );
    const orbitA = t * 0.22;
    const moonNear = 12 + Math.sin(t * 0.24) * 1.8;
    moon.position.set(
      earth.position.x + Math.cos(orbitA) * moonNear,
      earth.position.y + 6 + Math.sin(orbitA * 1.3) * 2.6,
      earth.position.z + Math.sin(orbitA) * (moonNear * 0.92)
    );
    moon.rotation.y += dt * 0.08;
    moonGlow.position.copy(moon.position).add(new THREE.Vector3(4, 0, 6));
    moonHalo.position.copy(moon.position);
    earthGlow.position.copy(earth.position).add(new THREE.Vector3(0, 0, 10));
    earthHalo.position.copy(earth.position);
    earthSpark.visible = false;
    moonSpark.visible = false;
    earthSpark.children.forEach((spr, i)=>{
      const a = t * 0.6 + i * 0.45;
      spr.position.set(
        earth.position.x + Math.cos(a) * (10.8 + (i % 3) * 0.8),
        earth.position.y + Math.sin(a * 1.2) * 2.4,
        earth.position.z + Math.sin(a) * (8.8 + (i % 4) * 0.7)
      );
    });
    moonSpark.children.forEach((spr, i)=>{
      const a = t * 0.75 + i * 0.6;
      spr.position.set(
        moon.position.x + Math.cos(a) * (6.2 + (i % 3) * 0.5),
        moon.position.y + Math.sin(a * 1.1) * 1.8,
        moon.position.z + Math.sin(a) * (5.4 + (i % 2) * 0.5)
      );
    });
    rim.material.emissiveIntensity = 0.88;
    seats.forEach((seat)=>{ seat.ring.material.opacity = 0.42; });
    stars.spriteGroup.rotation.y += dt * 0.0018;
    stars.pts.material.opacity = 0.88;
    city.billboardUpdaters.forEach(fn=>fn(t));
    wallPanelUpdaters.forEach(fn=>fn(t));
    
    if (claudiaAnchor && claudia){
      claudia.position.y = 0.04;
      claudiaAnchor.lookAt(new THREE.Vector3(0, 1.05, -0.9));
      claudiaAnchor.rotation.z = 0;
      claudiaAnchor.position.y = 0.02;
      claudiaUpper.forEach((bone)=>{ if (/arm|forearm/i.test(bone.name || "")) { bone.rotation.z = 0; bone.rotation.x = 0; } });
    }
  };

  return {
    roomClamp: R - 2.5,
    tableCenter: new THREE.Vector3(0, 0, 0),
    seats,
    joinRadius: 6.3,
    previewOrbitRadius: 15.5
  };
}
