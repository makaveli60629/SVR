AFRAME.registerComponent('lobby-layout',{
  init:function(){
    const root=this.el;
    const floor=document.createElement('a-plane');
    floor.setAttribute('id','floor'); floor.setAttribute('class','teleportable'); floor.setAttribute('width','34'); floor.setAttribute('height','34'); floor.setAttribute('rotation','-90 0 0'); floor.setAttribute('position','0 0 0');
    floor.setAttribute('material','color:#12051f; roughness:.82; metalness:.05');
    root.appendChild(floor);

    const ring=document.createElement('a-torus'); ring.setAttribute('position','0 .04 0'); ring.setAttribute('radius','12.8'); ring.setAttribute('radius-tubular','.028'); ring.setAttribute('rotation','90 0 0');
    ring.setAttribute('material','color:#7d33ff; emissive:#7d33ff; emissiveIntensity:.55');
    root.appendChild(ring);

    const wallMat='src:#wallCanvas; roughness:.82; metalness:.02; emissive:#160426; emissiveIntensity:.18';
    [['0 2.25 -17','34','4.5','.22'],['0 2.25 17','34','4.5','.22'],['-17 2.25 0','.22','4.5','34'],['17 2.25 0','.22','4.5','34']].forEach(v=>{
      const b=document.createElement('a-box'); b.setAttribute('position',v[0]); b.setAttribute('width',v[1]); b.setAttribute('height',v[2]); b.setAttribute('depth',v[3]); b.setAttribute('material',wallMat); root.appendChild(b);
    });

    // original-lobby signage placeholders; no copyrighted sponsor marks
    const signs=[['ABOUT SVR',-5.7,2.6,-16.86],['LEADER WALL',0,2.6,-16.86],['PARTNERS',5.7,2.6,-16.86]];
    signs.forEach(s=>{
      const p=document.createElement('a-entity'); p.setAttribute('position',`${s[1]} ${s[2]} ${s[3]}`);
      p.innerHTML=`<a-plane width="4.2" height="1.3" material="color:#080010; opacity:.92; side:double; emissive:#28004a; emissiveIntensity:.22"></a-plane><a-text value="${s[0]}" align="center" width="5.5" position="0 .15 .02" material="color:#e9dcff"></a-text><a-text value="Under construction" align="center" width="3.8" position="0 -.25 .02" material="color:#b987ff"></a-text>`;
      root.appendChild(p);
    });

    // glow sprites: circular blurred feel using small emissive spheres
    for(let i=0;i<34;i++){
      const a=(i/34)*Math.PI*2, r=5.2+(i%6)*1.35, y=1.7+(i%7)*.42;
      const g=document.createElement('a-sphere'); g.setAttribute('position',`${Math.cos(a)*r} ${y} ${Math.sin(a)*r}`); g.setAttribute('radius',`${.035+(i%4)*.015}`);
      g.setAttribute('material','color:#bd75ff; emissive:#bd75ff; emissiveIntensity:1.65; transparent:true; opacity:.58');
      g.setAttribute('animation__rise',`property: position; dir: alternate; dur:${4200+i*150}; easing:easeInOutSine; loop:true; to:${Math.cos(a)*r} ${y+.6} ${Math.sin(a)*r}`);
      g.setAttribute('animation__pulse',`property: scale; dir: alternate; dur:${1500+i*50}; loop:true; to:1.8 1.8 1.8`);
      root.appendChild(g);
    }
  }
});