
AFRAME.registerComponent('fist-teleport', {
init: function () {
const rig=document.querySelector('#rig');
window.addEventListener('keydown', function(e){
if(e.key==='f'){
rig.setAttribute('position',{
x: rig.object3D.position.x,
y: rig.object3D.position.y,
z: rig.object3D.position.z - 3
});
}
});
}
});
