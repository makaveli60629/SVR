
export function enableTeleport(){
console.log("Teleport system ready");
}
