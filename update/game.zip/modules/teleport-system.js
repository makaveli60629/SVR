AFRAME.registerComponent('teleport-system',{
  schema:{hand:{default:'right'}},
  init:function(){
    this.active=false; this.target=null;
    const ring=document.createElement('a-torus'); ring.setAttribute('id','teleportGlow'); ring.setAttribute('radius','.115'); ring.setAttribute('radius-tubular','.008'); ring.setAttribute('rotation','90 0 0'); ring.setAttribute('visible','false'); ring.setAttribute('material','color:#c77dff; emissive:#c77dff; emissiveIntensity:2.2; transparent:true; opacity:.95'); ring.setAttribute('animation__pulse','property: scale; from:1 1 1; to:1.25 1.25 1.25; dir:alternate; dur:650; loop:true'); this.el.appendChild(ring); this.glow=ring;
    const marker=document.createElement('a-entity'); marker.setAttribute('id','teleportMarker'); marker.setAttribute('visible','false'); marker.innerHTML='<a-plane width="1.15" height="1.15" rotation="-90 0 0" position="0 .038 0" material="src:#logoFloorCanvas; transparent:true; opacity:.92; alphaTest:.03; side:double; emissive:#8d33ff; emissiveIntensity:.45"></a-plane><a-torus radius=".64" radius-tubular=".012" rotation="90 0 0" position="0 .05 0" material="color:#c77dff; emissive:#c77dff; emissiveIntensity:1.8; transparent:true; opacity:.95"></a-torus><a-torus radius=".42" radius-tubular=".006" rotation="90 0 0" position="0 .055 0" material="color:#6fe9ff; emissive:#6fe9ff; emissiveIntensity:1.1; transparent:true; opacity:.62"></a-torus>';
    document.querySelector('a-scene').appendChild(marker); this.marker=marker;
    this.el.addEventListener('gripdown',()=>this.toggle()); this.el.addEventListener('pinchstarted',()=>this.toggle()); this.el.addEventListener('triggerdown',()=>{this.active=true;}); this.el.addEventListener('triggerup',()=>this.jump()); this.el.addEventListener('pinchended',()=>this.jump());
    window.addEventListener('keydown',e=>{if(e.key.toLowerCase()==='f'){this.toggle(); if(this.active)this.target=this.getForwardFloorPoint();}});
  },
  tick:function(){
    if(!this.glow||!this.marker)return;
    this.glow.setAttribute('visible',this.active); this.el.setAttribute('line',`color:${this.active?'#c77dff':'#694098'}; opacity:${this.active?'.95':'.35'}`);
    if(!this.active){this.marker.setAttribute('visible',false);return;}
    let p=this.target; const rc=this.el.components.raycaster,hits=rc&&rc.intersections?rc.intersections:[],hit=hits.find(h=>h.object&&h.object.el&&h.object.el.classList&&h.object.el.classList.contains('teleportable'));
    if(hit)p=hit.point; if(!p)p=this.getForwardFloorPoint();
    if(p){this.target=p; this.marker.object3D.position.set(p.x,.005,p.z); this.marker.setAttribute('visible',true);}
  },
  getForwardFloorPoint:function(){
    const cam=document.getElementById('camera'); if(!cam)return null; const dir=new THREE.Vector3(0,0,-1); cam.object3D.getWorldDirection(dir); const pos=new THREE.Vector3(); cam.object3D.getWorldPosition(pos);
    let x=pos.x+dir.x*3.6,z=pos.z+dir.z*3.6; x=Math.max(-14.5,Math.min(14.5,x)); z=Math.max(-14.5,Math.min(14.5,z)); return new THREE.Vector3(x,0,z);
  },
  toggle:function(){this.active=!this.active; if(this.active)this.target=this.getForwardFloorPoint();},
  jump:function(){if(!this.active||!this.target)return; const rig=document.getElementById('rig'); if(!rig)return; rig.object3D.position.x=this.target.x; rig.object3D.position.z=this.target.z; this.active=false;}
});