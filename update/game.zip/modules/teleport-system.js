/* SVR Phase 2 teleport:
   - Floor marker is always visible while teleport is ON.
   - Uses raycaster hits when available.
   - Falls back to camera-forward projection, so marker never disappears.
*/
AFRAME.registerComponent('teleport-system',{
  schema:{hand:{default:'right'}},
  init:function(){
    this.active=false;
    this.target=null;
    this.makeLogoTexture();

    const ring=document.createElement('a-torus');
    ring.setAttribute('id','teleportGlow');
    ring.setAttribute('radius','.115');
    ring.setAttribute('radius-tubular','.008');
    ring.setAttribute('rotation','90 0 0');
    ring.setAttribute('visible','false');
    ring.setAttribute('material','color:#c77dff; emissive:#c77dff; emissiveIntensity:2.2; transparent:true; opacity:.95');
    ring.setAttribute('animation__pulse','property: scale; from:1 1 1; to:1.25 1.25 1.25; dir:alternate; dur:650; loop:true');
    this.el.appendChild(ring);
    this.glow=ring;

    const marker=document.createElement('a-entity');
    marker.setAttribute('id','teleportMarker');
    marker.setAttribute('visible','false');
    marker.innerHTML = `
      <a-plane width="1.15" height="1.15" rotation="-90 0 0" position="0 .038 0"
        material="src:#logoFloorCanvas; transparent:true; opacity:.92; alphaTest:.03; side:double; emissive:#8d33ff; emissiveIntensity:.45"></a-plane>
      <a-torus radius=".64" radius-tubular=".012" rotation="90 0 0" position="0 .05 0"
        material="color:#c77dff; emissive:#c77dff; emissiveIntensity:1.8; transparent:true; opacity:.95"></a-torus>
      <a-torus radius=".42" radius-tubular=".006" rotation="90 0 0" position="0 .055 0"
        material="color:#6fe9ff; emissive:#6fe9ff; emissiveIntensity:1.1; transparent:true; opacity:.62"></a-torus>
    `;
    document.querySelector('a-scene').appendChild(marker);
    this.marker=marker;

    this.el.addEventListener('gripdown',()=>this.toggle());
    this.el.addEventListener('pinchstarted',()=>this.toggle());
    this.el.addEventListener('triggerdown',()=>{this.active=true;});
    this.el.addEventListener('triggerup',()=>this.jump());
    this.el.addEventListener('pinchended',()=>this.jump());

    this.el.addEventListener('raycaster-intersection',(evt)=>{
      if(!evt.detail || !evt.detail.intersections || !evt.detail.intersections.length)return;
      const hit=evt.detail.intersections.find(h=>h.object&&h.object.el&&h.object.el.classList&&h.object.el.classList.contains('teleportable'));
      if(hit) this.target=hit.point.clone ? hit.point.clone() : hit.point;
    });
  },
  tick:function(){
    if(!this.glow||!this.marker)return;
    this.glow.setAttribute('visible',this.active);
    this.el.setAttribute('line',`color:${this.active?'#c77dff':'#694098'}; opacity:${this.active?'.95':'.35'}`);

    if(!this.active){
      this.marker.setAttribute('visible',false);
      return;
    }

    let p=this.target;
    const rc=this.el.components.raycaster;
    const hits=rc&&rc.intersections?rc.intersections:[];
    const hit=hits.find(h=>h.object&&h.object.el&&h.object.el.classList&&h.object.el.classList.contains('teleportable'));
    if(hit) p=hit.point;

    if(!p) p=this.getForwardFloorPoint();

    if(p){
      this.target=p;
      this.marker.object3D.position.set(p.x,.005,p.z);
      this.marker.setAttribute('visible',true);
    }
  },
  getForwardFloorPoint:function(){
    const cam=document.getElementById('camera');
    if(!cam)return null;
    const dir=new THREE.Vector3(0,0,-1);
    cam.object3D.getWorldDirection(dir);
    const pos=new THREE.Vector3();
    cam.object3D.getWorldPosition(pos);
    let x=pos.x + dir.x*3.5;
    let z=pos.z + dir.z*3.5;
    x=Math.max(-13.5,Math.min(13.5,x));
    z=Math.max(-13.5,Math.min(13.5,z));
    return new THREE.Vector3(x,0,z);
  },
  toggle:function(){
    this.active=!this.active;
    if(this.active) this.target=this.getForwardFloorPoint();
  },
  jump:function(){
    if(!this.active||!this.target)return;
    const rig=document.getElementById('rig');
    if(!rig)return;
    rig.object3D.position.x=this.target.x;
    rig.object3D.position.z=this.target.z;
    this.active=false;
  },
  makeLogoTexture:function(){
    const c=document.getElementById('logoFloorCanvas');
    if(!c)return;
    const x=c.getContext('2d');
    x.clearRect(0,0,512,512);
    const g=x.createRadialGradient(256,256,10,256,256,240);
    g.addColorStop(0,'rgba(210,150,255,.72)');
    g.addColorStop(.55,'rgba(110,35,210,.42)');
    g.addColorStop(1,'rgba(30,0,60,0)');
    x.fillStyle=g;
    x.fillRect(0,0,512,512);
    x.beginPath();
    x.arc(256,256,212,0,Math.PI*2);
    x.fillStyle='rgba(98,26,180,.28)';
    x.fill();
    x.lineWidth=20;
    x.strokeStyle='rgba(220,160,255,.95)';
    x.stroke();
    x.lineWidth=8;
    x.strokeStyle='rgba(100,230,255,.70)';
    x.beginPath();
    x.arc(256,256,164,0,Math.PI*2);
    x.stroke();
    x.font='bold 92px Arial';
    x.textAlign='center';
    x.textBaseline='middle';
    x.fillStyle='rgba(245,235,255,.98)';
    x.fillText('SVR',256,224);
    x.font='bold 54px Arial';
    x.fillText('POKER',256,304);
  }
});
