AFRAME.registerComponent('npc-system',{
  init:function(){this.makeNPC('ERIC',-1.7,-2.55,'#442d71',true,'#ericGLB'); this.makeNPC('CARLA',1.7,-2.55,'#2d416f',false,'#carlaGLB');},
  makeNPC:function(name,x,z,color,dealer,asset){
    const n=document.createElement('a-entity'); n.setAttribute('position',`${x} .02 ${z}`); n.setAttribute('rotation',`0 ${x<0?28:-28} 0`);
    const model=document.createElement('a-entity'); model.setAttribute('gltf-model',asset); model.setAttribute('scale','.8 .8 .8'); model.setAttribute('visible','false'); n.appendChild(model);
    model.addEventListener('model-loaded',()=>{model.setAttribute('visible','true'); const fb=n.querySelector('.npcFallback'); if(fb)fb.setAttribute('visible','false');});
    const fb=document.createElement('a-entity'); fb.setAttribute('class','npcFallback');
    fb.innerHTML=`<a-cylinder radius='.18' height='.9' position='0 .82 0' material='color:${color}; roughness:.55'></a-cylinder><a-sphere radius='.19' position='0 1.38 0' material='color:#d8b6ff; roughness:.45'></a-sphere><a-cylinder radius='.045' height='.48' position='-.24 .95 0' rotation='0 0 18' material='color:#d8b6ff'></a-cylinder><a-cylinder radius='.045' height='.48' position='.24 .95 0' rotation='0 0 -18' material='color:#d8b6ff'></a-cylinder><a-text value='${name}' align='center' width='2' position='0 1.78 0' material='color:#ffffff; emissive:#8f54ff; emissiveIntensity:.6'></a-text>`;
    n.appendChild(fb); n.setAttribute('animation__idle',`property: position; dir: alternate; dur:1800; loop:true; easing:easeInOutSine; to:${x} .06 ${z}`);
    if(dealer)n.setAttribute('animation__deal','property: rotation; dir:alternate; dur:1200; loop:true; easing:easeInOutSine; to:0 0 0'); else n.setAttribute('animation__walkhint',`property: position; dir:alternate; dur:3200; loop:true; easing:easeInOutSine; to:${x+.45} .02 ${z+.18}`);
    this.el.appendChild(n);
  }
});