AFRAME.registerComponent('lobby-lighting',{
  init:function(){
    const add=(tag,attrs)=>{const el=document.createElement(tag);Object.entries(attrs).forEach(([k,v])=>el.setAttribute(k,v));this.el.appendChild(el);return el;};
    add('a-light',{type:'ambient',color:'#4c2b70',intensity:'.76'});
    add('a-light',{type:'hemisphere',color:'#caa1ff',groundColor:'#06000e',intensity:'.58'});
    add('a-light',{type:'point',color:'#bd70ff',intensity:'1.35',distance:'15',position:'0 4 1'});
    add('a-light',{type:'point',color:'#6fd8ff',intensity:'.85',distance:'10',position:'-4 2.8 -2'});
    add('a-light',{type:'point',color:'#ff62d8',intensity:'.55',distance:'10',position:'4 2.4 -2'});
  }
});