/* SVR Phase 2: Moon and Mars moved higher/safer behind skyline. */
AFRAME.registerComponent('moon-stars',{
  init:function(){
    this.makeMoonTexture();
    this.makeMarsTexture();

    const moon=document.createElement('a-sphere');
    moon.setAttribute('position','-8.5 13 -18.5');
    moon.setAttribute('radius','1.0');
    moon.setAttribute('segments-width','48');
    moon.setAttribute('segments-height','24');
    moon.setAttribute('material','src:#moonCanvas; roughness:.9; metalness:0; emissive:#bba8ff; emissiveIntensity:.16');
    moon.setAttribute('animation__spin','property: rotation; to:0 360 0; dur:90000; loop:true; easing:linear');
    this.el.appendChild(moon);

    const mars=document.createElement('a-sphere');
    mars.setAttribute('position','7.8 12.3 -19.2');
    mars.setAttribute('radius','.48');
    mars.setAttribute('segments-width','36');
    mars.setAttribute('segments-height','18');
    mars.setAttribute('material','src:#marsCanvas; roughness:.88; metalness:0; emissive:#8b2c18; emissiveIntensity:.22');
    mars.setAttribute('animation__orbit','property: position; dir:alternate; dur:65000; loop:true; easing:easeInOutSine; to:9.5 12.9 -18.7');
    mars.setAttribute('animation__spin','property: rotation; to:0 360 0; dur:55000; loop:true; easing:linear');
    this.el.appendChild(mars);

    for(let i=0;i<180;i++){
      const s=document.createElement('a-sphere');
      const px=-20+Math.random()*40;
      const py=5+Math.random()*13;
      const pz=-22+Math.random()*7;
      const rr=.006+Math.random()*.018;
      s.setAttribute('position',`${px} ${py} ${pz}`);
      s.setAttribute('radius',rr);
      s.setAttribute('material','color:#eee5ff; emissive:#eee5ff; emissiveIntensity:1.2');
      if(i%4===0)s.setAttribute('animation__twinkle','property: scale; from:1 1 1; to:1.9 1.9 1.9; dir:alternate; dur:1300; loop:true');
      this.el.appendChild(s);
    }
  },
  makeMoonTexture:function(){
    const c=document.getElementById('moonCanvas');
    if(!c)return;
    const x=c.getContext('2d'),g=x.createRadialGradient(210,170,20,256,256,290);
    g.addColorStop(0,'#f1eaff');
    g.addColorStop(.55,'#b7a6d8');
    g.addColorStop(1,'#51466d');
    x.fillStyle=g;x.fillRect(0,0,512,512);
    for(let i=0;i<90;i++){
      x.beginPath();
      x.fillStyle=`rgba(40,30,60,${.05+Math.random()*.18})`;
      x.arc(Math.random()*512,Math.random()*512,5+Math.random()*34,0,Math.PI*2);
      x.fill();
    }
  },
  makeMarsTexture:function(){
    const assets=document.querySelector('a-assets');
    if(!document.getElementById('marsCanvas')){
      const c=document.createElement('canvas');
      c.id='marsCanvas'; c.width=512; c.height=512;
      assets.appendChild(c);
    }
    const c=document.getElementById('marsCanvas');
    const x=c.getContext('2d'),g=x.createRadialGradient(210,160,20,256,256,290);
    g.addColorStop(0,'#ffb27a');
    g.addColorStop(.55,'#9b321e');
    g.addColorStop(1,'#35100c');
    x.fillStyle=g;x.fillRect(0,0,512,512);
    for(let i=0;i<50;i++){
      x.beginPath();
      x.fillStyle=`rgba(80,20,10,${.08+Math.random()*.20})`;
      x.ellipse(Math.random()*512,Math.random()*512,20+Math.random()*55,4+Math.random()*18,Math.random()*Math.PI,0,Math.PI*2);
      x.fill();
    }
  }
});
