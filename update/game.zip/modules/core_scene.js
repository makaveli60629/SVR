import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";

export function createCore({ containerId = "app" } = {}){
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x050508);

  const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.05, 1200);

  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: false,
    depth: true,
    stencil: false,
    powerPreference: "high-performance",
    preserveDrawingBuffer: false
  });

  renderer.setClearColor(0x050508, 1);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.xr.enabled = true;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.18;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  document.getElementById(containerId).appendChild(renderer.domElement);

  const vrButton = document.createElement("button");
  vrButton.className = "svr-vr-button";
  vrButton.textContent = "CHECKING VR...";
  Object.assign(vrButton.style, {
    position: "fixed",
    right: "14px",
    top: "86px",
    zIndex: "40",
    border: "1px solid rgba(180,140,255,.72)",
    background: "rgba(14,10,24,.92)",
    color: "#fff",
    borderRadius: "14px",
    padding: "12px 20px",
    fontWeight: "700",
    letterSpacing: ".03em",
    cursor: "pointer",
    display: "block"
  });
  document.body.appendChild(vrButton);

  let currentSession = null;
  async function updateVrButton(){
    if (!(navigator.xr && renderer.xr)) {
      vrButton.textContent = "VR NOT SUPPORTED";
      vrButton.disabled = true;
      vrButton.style.opacity = ".55";
      return;
    }
    try{
      const supported = await navigator.xr.isSessionSupported('immersive-vr');
      if (!supported){
        vrButton.textContent = "VR UNAVAILABLE";
        vrButton.disabled = true;
        vrButton.style.opacity = ".55";
        return;
      }
      vrButton.textContent = currentSession ? "EXIT VR" : "ENTER VR";
      vrButton.disabled = false;
      vrButton.style.opacity = "1";
    }catch(_err){
      vrButton.textContent = "VR ERROR";
      vrButton.disabled = true;
      vrButton.style.opacity = ".55";
    }
  }

  vrButton.addEventListener('click', async ()=>{
    if (!navigator.xr) return;
    try{
      if (currentSession){
        await currentSession.end();
        return;
      }
      const session = await navigator.xr.requestSession('immersive-vr', {
        requiredFeatures: ['local-floor'],
        optionalFeatures: ['bounded-floor', 'hand-tracking']
      });
      currentSession = session;
      renderer.xr.setSession(session);
      session.addEventListener('end', ()=>{ currentSession = null; updateVrButton(); });
      updateVrButton();
    }catch(_err){
      vrButton.textContent = "VR FAILED";
    }
  });
  updateVrButton();

  window.addEventListener("resize", ()=>{
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  return { scene, camera, renderer };
}
