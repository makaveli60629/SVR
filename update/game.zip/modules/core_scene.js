import * as THREE from "three";
import { VRButton } from "three/addons/webxr/VRButton.js";
import { CONFIG } from "./config.js";

export function createCore({ containerId="app", spectatorCanvasId="spectatorCanvas", enableSpectator = true } = {}) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x000000);
  scene.fog = new THREE.FogExp2(0x06040d, 0.0068);

  const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.03, 1200);
  camera.position.set(CONFIG.SPAWN.x, CONFIG.SPAWN.y, CONFIG.SPAWN.z);
  camera.rotation.order = "YXZ";
  camera.rotation.y = CONFIG.SPAWN.yaw;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.05));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.xr.enabled = true;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.89;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  document.getElementById(containerId).appendChild(renderer.domElement);
  (document.getElementById("vrButtonSlot") || document.body).appendChild(VRButton.createButton(renderer, {
    requiredFeatures: ["local-floor"],
    optionalFeatures: ["bounded-floor", "hand-tracking"]
  }));

  const spectatorCanvas = enableSpectator ? document.getElementById(spectatorCanvasId) : null;
  const spectatorRenderer = spectatorCanvas
    ? new THREE.WebGLRenderer({ canvas: spectatorCanvas, antialias: true, alpha: false, powerPreference: "high-performance" })
    : null;
  if (spectatorRenderer) {
    spectatorRenderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.15));
    spectatorRenderer.setSize(spectatorCanvas.clientWidth || 320, spectatorCanvas.clientHeight || 180, false);
    spectatorRenderer.outputColorSpace = THREE.SRGBColorSpace;
    spectatorRenderer.toneMapping = THREE.ACESFilmicToneMapping;
    spectatorRenderer.toneMappingExposure = 0.98;
  }

  const spectatorCamera = spectatorCanvas
    ? new THREE.PerspectiveCamera(58, (spectatorCanvas.clientWidth || 320) / (spectatorCanvas.clientHeight || 180), 0.1, 1200)
    : null;
  if (spectatorCamera) spectatorCamera.position.set(6, 4, 6);

  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    if (spectatorCanvas && spectatorCamera && spectatorRenderer) {
      const w = spectatorCanvas.clientWidth || 320;
      const h = spectatorCanvas.clientHeight || 180;
      spectatorCamera.aspect = w / h;
      spectatorCamera.updateProjectionMatrix();
      spectatorRenderer.setSize(w, h, false);
    }
  });

  const hemi = new THREE.HemisphereLight(0xece7ff, 0x070710, 0.92);
  scene.add(hemi);

  const key = new THREE.DirectionalLight(0xf8f5ff, 1.38);
  key.position.set(10, 18, 8);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 0.1;
  key.shadow.camera.far = 60;
  key.shadow.camera.left = -18;
  key.shadow.camera.right = 18;
  key.shadow.camera.top = 18;
  key.shadow.camera.bottom = -18;
  scene.add(key);

  const rim = new THREE.PointLight(0xb48cff, 1.18, 54, 2);
  rim.position.set(0, 6.5, 0);
  scene.add(rim);
  const skylineWash = new THREE.PointLight(0x67b9ff, 0.32, 72, 2);
  skylineWash.position.set(-12, 10, -22);
  scene.add(skylineWash);

  const loungeWash = new THREE.PointLight(0x79f3da, 0.28, 42, 2);
  loungeWash.position.set(10, 4, 12);
  scene.add(loungeWash);

  return { scene, camera, renderer, spectatorCamera, spectatorRenderer };
}
