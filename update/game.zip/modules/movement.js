
AFRAME.registerComponent('player-movement',{
init:function(){
const rig=this.el;
window.addEventListener('keydown',function(e){
let pos=rig.object3D.position;
if(e.key==='w') pos.z -= 0.4;
if(e.key==='s') pos.z += 0.4;
if(e.key==='a') pos.x -= 0.4;
if(e.key==='d') pos.x += 0.4;
});
}
});
