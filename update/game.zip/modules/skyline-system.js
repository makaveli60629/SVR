AFRAME.registerComponent('skyline-system',{
  init:function(){
    const r=document.createElement('a-entity'); r.setAttribute('id','skyline'); this.el.appendChild(r);
    const bs=[['Willis',-5.2,-14,9.8,1.2,1.2,'#090812','#ffb55d'],['Trump',0,-15,8.2,1.35,1.05,'#0a1122','#82d8ff'],['Hancock',5.2,-14,7.6,1.15,1.1,'#07101e','#a9e7ff'],['TowerA',-9,-12,4.9,1.6,1.1,'#0d0820','#be7cff'],['TowerB',8.8,-12,5.4,1.7,1.1,'#0c0718','#7ee9ff']];
    bs.forEach((b,idx)=>{
      const [n,x,z,h,w,d,c,e]=b,box=document.createElement('a-box'); box.setAttribute('position',`${x} ${h/2} ${z}`); box.setAttribute('width',w); box.setAttribute('height',h); box.setAttribute('depth',d); box.setAttribute('material',`color:${c}; roughness:.72; metalness:.08; emissive:${c}; emissiveIntensity:.15`); r.appendChild(box);
      if(idx<3){const ant=document.createElement('a-cylinder');ant.setAttribute('position',`${x} ${h+.8} ${z}`);ant.setAttribute('radius','.035');ant.setAttribute('height','1.6');ant.setAttribute('material',`color:${e}; emissive:${e}; emissiveIntensity:.85`);r.appendChild(ant);}
      for(let row=0;row<Math.floor(h*1.35);row++){if(row%3===0&&Math.random()<.22)continue;const win=document.createElement('a-box');win.setAttribute('position',`${x} ${.6+row*.52} ${z+d/2+.006}`);win.setAttribute('width',`${w*.72}`);win.setAttribute('height','.035');win.setAttribute('depth','.01');win.setAttribute('material',`color:${e}; emissive:${e}; emissiveIntensity:${.35+Math.random()*.55}; transparent:true; opacity:.82`);r.appendChild(win);}
    });
    for(let i=0;i<36;i++){const x=-18+i*1.05,h=1.7+((i*7)%10)*.32,z=-16+(i%4)*.42,b=document.createElement('a-box');b.setAttribute('position',`${x} ${h/2} ${z}`);b.setAttribute('width','.7');b.setAttribute('height',h);b.setAttribute('depth','.65');b.setAttribute('material','color:#06030d; emissive:#13051f; emissiveIntensity:.25');r.appendChild(b);}
  }
});