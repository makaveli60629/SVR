let isCharging = false;
let targetPosition = null;

export function onFistClench() {
    isCharging = true;
    console.log("Charging teleport...");
}

export function onHandMove(pos) {
    if (!isCharging) return;
    targetPosition = pos;
}

export function onFistRelease() {
    if (!targetPosition) return;
    console.log("Teleporting to", targetPosition);
    isCharging = false;
}