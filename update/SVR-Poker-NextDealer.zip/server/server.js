const http = require('http');
const server = http.createServer((req,res)=>{
    res.end("SVR Poker Server Running");
});
server.listen(3000);