# Reiki Teleport System

Energy-based teleportation:
- Clench fist to charge
- Aim to select location
- Release to teleport

Visual:
Purple chakra energy + particle effects
