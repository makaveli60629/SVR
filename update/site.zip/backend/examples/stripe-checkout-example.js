/**
 * Example server endpoint for Stripe Checkout.
 * Store STRIPE_SECRET_KEY and DATABASE_URL in environment variables, not in website files.
 */
import express from 'express';
import Stripe from 'stripe';

const app = express();
app.use(express.json());

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const baseUrl = process.env.PUBLIC_BASE_URL || 'https://svrpoker.com';

app.post('/api/create-checkout-session', async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: { name: req.body?.product || 'Scarlett VR Poker Founders Table' },
            unit_amount: 2500
          },
          quantity: 1
        }
      ],
      success_url: `${baseUrl}/?checkout=success`,
      cancel_url: `${baseUrl}/?checkout=cancelled`
    });

    res.json({ url: session.url });
  } catch (error) {
    res.status(500).json({ error: error.message || 'Unable to create checkout session' });
  }
});

app.listen(8787, () => {
  console.log('Stripe checkout example listening on http://localhost:8787');
});
