create table if not exists members (
  id bigserial primary key,
  email text not null unique,
  display_name text,
  tier text not null default 'public-preview',
  created_at timestamptz not null default now()
);

create table if not exists orders (
  id bigserial primary key,
  member_id bigint references members(id) on delete set null,
  stripe_session_id text unique,
  stripe_customer_id text,
  product_name text not null,
  status text not null default 'pending',
  amount_cents integer,
  currency text default 'usd',
  created_at timestamptz not null default now()
);

create table if not exists payments (
  id bigserial primary key,
  order_id bigint not null references orders(id) on delete cascade,
  provider text not null default 'stripe',
  provider_payment_id text,
  status text not null,
  payload jsonb,
  created_at timestamptz not null default now()
);
