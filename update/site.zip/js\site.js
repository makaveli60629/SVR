console.log("SVR site loaded"); 
