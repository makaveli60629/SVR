
# SVR Repaired Project

This project represents a restructured and repaired version of the original SVR (Simple Virtual Reality) repository. The goal of this refactor is to modularize the site and game components, improving maintainability and extensibility.

## Structure Overview

- **.github/workflows/deploy.yml** – GitHub Actions workflow to deploy the site to the `gh-pages` branch.
- **assets/** – Static resources shared by the site, including CSS, JavaScript and model assets.
  - `css/style.css` – Defines the purple matrix theme and layout styles.
  - `js/matrix.js` – Implements the matrix rain background effect using the letters "SVR".
  - `models/poker_table.fbx` – Placeholder model file (empty); replace with a real FBX model for the poker table.
- **modules/updater/updater.js** – Checks `update/version.json` for changes and reloads the page when a new version is detected.
- **update/version.json** – Contains the current version numbers for the site and game.
- **game/** – Contains the 3D game component.
  - `index.html` – Bootstraps the Three.js scene.
  - `scripts/core.js` – Initializes Three.js, loads the poker table model (or falls back to a simple cylinder), adds lights and floor, and implements a teleport feature using the `T` key.
  - `scripts/seat-system.js` – Simple A-Frame seat system stub.

## Running Locally

You can serve this project locally by opening `index.html` in a modern browser. No build step is required because all dependencies are loaded via CDN.

To deploy to GitHub Pages, push the contents of this directory to the `main` branch of your repository. The included GitHub Actions workflow will automatically deploy to the `gh-pages` branch.
