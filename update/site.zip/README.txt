
SVR Poker Full Build Scaffold

Folders:
site/        -> website
site/game/   -> VR game scene
admin/       -> admin panel
sql/         -> database schema

Upload site folder to your web root.
