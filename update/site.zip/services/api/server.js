
import express from 'express';
const app = express();
app.get('/',(req,res)=>res.send('SVR API Running'));
app.listen(3000,()=>console.log('API running'));
