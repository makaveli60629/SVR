
export function createCheckout(){
console.log("Stripe checkout placeholder");
}
