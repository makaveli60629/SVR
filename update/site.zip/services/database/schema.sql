
CREATE TABLE users(
id SERIAL PRIMARY KEY,
email TEXT,
token_balance INTEGER
);
