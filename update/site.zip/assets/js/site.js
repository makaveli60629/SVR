(() => {
  document.querySelectorAll("[data-year]").forEach(el => el.textContent = new Date().getFullYear());
  document.querySelectorAll("form[data-demo]").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      const note = form.querySelector(".notice");
      if (note) note.textContent = "Saved locally for preview. Backend wiring comes in the Azure/API phase.";
    });
  });
})();