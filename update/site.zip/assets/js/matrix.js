(() => {
  const canvas = document.getElementById("matrix");
  if (!canvas) return;
  const ctx = canvas.getContext("2d", { alpha: true });
  const glyphs = "010101SVRPOKERアイウエオカキクケコサシスセソ";
  const fontSize = 16;
  let w, h, cols, drops;
  function resize(){
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
    cols = Math.max(1, Math.floor(w / fontSize));
    drops = Array.from({length: cols}, () => Math.random() * h / fontSize);
  }
  window.addEventListener("resize", resize, {passive:true});
  resize();
  function draw(){
    ctx.fillStyle = "rgba(7,0,15,.10)";
    ctx.fillRect(0,0,w,h);
    ctx.font = fontSize + "px monospace";
    for(let i=0;i<cols;i++){
      const x=i*fontSize, y=drops[i]*fontSize;
      const ch=glyphs[(Math.random()*glyphs.length)|0];
      ctx.fillStyle="rgba(210,160,255,.92)";
      ctx.fillText(ch,x,y);
      ctx.fillStyle="rgba(111,233,255,.18)";
      ctx.fillText(ch,x,y-fontSize*5);
      if(y>h && Math.random()>.975) drops[i]=0;
      drops[i]+=0.82;
    }
    requestAnimationFrame(draw);
  }
  draw();
})();