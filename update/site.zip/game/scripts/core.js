
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js";

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(
70,
window.innerWidth/window.innerHeight,
0.1,
1000
);

camera.position.set(0,6,10);
camera.lookAt(0,1,0);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
document.body.appendChild(renderer.domElement);

const ambient = new THREE.AmbientLight(0xffffff,1.2);
scene.add(ambient);

const light = new THREE.PointLight(0xffffff,2);
light.position.set(5,10,5);
scene.add(light);

const floor = new THREE.Mesh(
new THREE.PlaneGeometry(200,200),
new THREE.MeshStandardMaterial({color:0x111111})
);

floor.rotation.x = -Math.PI/2;
scene.add(floor);

const table = new THREE.Mesh(
new THREE.CylinderGeometry(3.5,3.5,0.6,64),
new THREE.MeshStandardMaterial({color:0x0b5d0b})
);

table.position.y = 1;
scene.add(table);

function animate(){
requestAnimationFrame(animate);
renderer.render(scene,camera);
}

animate();

window.addEventListener("resize",()=>{
camera.aspect = window.innerWidth/window.innerHeight;
camera.updateProjectionMatrix();
renderer.setSize(window.innerWidth,window.innerHeight);
});
