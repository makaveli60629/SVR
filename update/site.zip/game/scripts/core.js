
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.161/build/three.module.js";

const scene=new THREE.Scene();

const camera=new THREE.PerspectiveCamera(70,window.innerWidth/window.innerHeight,0.1,1000);
camera.position.set(0,8,14);
camera.lookAt(0,0,0);

const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth,window.innerHeight);
document.body.appendChild(renderer.domElement);

const ambient=new THREE.AmbientLight(0xffffff,1.2);
scene.add(ambient);

const light=new THREE.PointLight(0xffffff,2);
light.position.set(10,20,10);
scene.add(light);

const floor=new THREE.Mesh(
new THREE.PlaneGeometry(300,300),
new THREE.MeshStandardMaterial({color:0x111111})
);
floor.rotation.x=-Math.PI/2;
scene.add(floor);

const table=new THREE.Mesh(
new THREE.CylinderGeometry(4,4,0.6,64),
new THREE.MeshStandardMaterial({color:0x0b5d0b})
);
table.position.y=1;
scene.add(table);

const seats=[[0,0,7],[5,0,4],[5,0,-4],[0,0,-7],[-5,0,-4],[-5,0,4]];
seats.forEach(p=>{
const seat=new THREE.Mesh(
new THREE.BoxGeometry(1.4,0.6,1.4),
new THREE.MeshStandardMaterial({color:0x333333})
);
seat.position.set(p[0],0.3,p[2]);
scene.add(seat);
});

for(let i=0;i<80;i++){
const h=Math.random()*40+10;
const building=new THREE.Mesh(
new THREE.BoxGeometry(Math.random()*6+2,h,Math.random()*6+2),
new THREE.MeshStandardMaterial({color:0x111144})
);
building.position.set((Math.random()-0.5)*250,h/2,(Math.random()-0.5)*250);
scene.add(building);
}

const moon=new THREE.Mesh(
new THREE.SphereGeometry(6,32,32),
new THREE.MeshBasicMaterial({color:0xffffff})
);
moon.position.set(40,60,-120);
scene.add(moon);

function animate(){
requestAnimationFrame(animate);
renderer.render(scene,camera);
}
animate();

window.addEventListener("resize",()=>{
camera.aspect=window.innerWidth/window.innerHeight;
camera.updateProjectionMatrix();
renderer.setSize(window.innerWidth,window.innerHeight);
});
