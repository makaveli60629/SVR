AFRAME.registerComponent('hands',{
init:function(){
console.log("Hands module ready")
}
})