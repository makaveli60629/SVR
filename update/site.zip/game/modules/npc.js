AFRAME.registerComponent('npc',{
init:function(){
console.log("NPC Loaded")
}
})