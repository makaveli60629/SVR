let teleportEnabled=false

document.addEventListener("keydown",e=>{

if(e.key==="t"){
teleportEnabled=!teleportEnabled
console.log("Teleport:",teleportEnabled)
}

})