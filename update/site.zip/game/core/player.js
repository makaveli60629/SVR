AFRAME.registerComponent('player',{
init:function(){
console.log("Player system loaded")
}
})