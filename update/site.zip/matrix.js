const canvas = document.getElementById('matrix');
if (canvas) {
  const ctx = canvas.getContext('2d');
  const chars = 'SVRPOKER0101';
  let fontSize = 16;
  let cols = 0;
  let drops = [];
  function resize(){
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    cols = Math.floor(canvas.width / fontSize);
    drops = Array(cols).fill(1);
  }
  function draw(){
    ctx.fillStyle = 'rgba(0,0,0,0.08)';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle = '#9f54ff';
    ctx.font = fontSize + 'px monospace';
    for(let i=0;i<drops.length;i++){
      const text = chars[Math.floor(Math.random()*chars.length)];
      ctx.fillText(text, i*fontSize, drops[i]*fontSize);
      if(drops[i]*fontSize > canvas.height && Math.random() > 0.975) drops[i]=0;
      drops[i]++;
    }
  }
  resize();
  addEventListener('resize', resize);
  setInterval(draw, 36);
}
