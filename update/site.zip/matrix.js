(() => {
  const canvas = document.getElementById('binary-rain');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const easterEggs = [
    '01001001 00100000 01001100 01001111 01010110 01000101 00100000 01010011 01001000 01011001',
    '01001001 00100000 01001100 01001111 01010110 01000101 00100000 01010011 01000011 01000001 01010010 01001100 01000101 01010100 01010100'
  ];
  const glyphs = '01';
  let width = 0;
  let height = 0;
  let fontSize = 16;
  let columns = 0;
  let drops = [];
  let injections = [];

  function resize() {
    const dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    fontSize = Math.max(14, Math.min(22, Math.floor(width / 82)));
    columns = Math.ceil(width / fontSize);
    drops = Array.from({ length: columns }, () => Math.random() * -height / fontSize);
    ctx.font = `700 ${fontSize}px Orbitron, monospace`;
  }

  function spawnEgg() {
    const text = easterEggs[Math.floor(Math.random() * easterEggs.length)];
    injections.push({
      x: Math.random() * (width - 280),
      y: -40,
      speed: 1.25 + Math.random() * 0.5,
      text,
      alpha: 0.72 + Math.random() * 0.18
    });
    if (injections.length > 6) injections.shift();
  }

  function drawColumns() {
    for (let i = 0; i < drops.length; i++) {
      const char = glyphs[Math.floor(Math.random() * glyphs.length)];
      const x = i * fontSize;
      const y = drops[i] * fontSize;
      const pulse = Math.sin((Date.now() / 240) + i * 0.4) * 0.5 + 0.5;
      ctx.fillStyle = `rgba(${90 + Math.floor(120 * pulse)}, ${178 + Math.floor(42 * pulse)}, 255, 0.88)`;
      ctx.shadowColor = 'rgba(166, 84, 255, 0.8)';
      ctx.shadowBlur = 16;
      ctx.fillText(char, x, y);
      ctx.shadowBlur = 0;
      if (y > height && Math.random() > 0.978) drops[i] = Math.random() * -26;
      drops[i] += 0.86;
    }
  }

  function drawEggs() {
    for (const egg of injections) {
      egg.y += egg.speed;
      ctx.save();
      ctx.globalAlpha = egg.alpha;
      ctx.fillStyle = 'rgba(255, 120, 247, 0.92)';
      ctx.shadowColor = 'rgba(97, 227, 255, 0.75)';
      ctx.shadowBlur = 18;
      ctx.fillText(egg.text, egg.x, egg.y);
      ctx.restore();
    }
    injections = injections.filter(item => item.y < height + 40);
  }

  function frame() {
    ctx.fillStyle = 'rgba(4, 4, 10, 0.16)';
    ctx.fillRect(0, 0, width, height);
    drawColumns();
    drawEggs();
    if (Math.random() < 0.006) spawnEgg();
    requestAnimationFrame(frame);
  }

  window.addEventListener('resize', resize, { passive: true });
  resize();
  setInterval(spawnEgg, 5200);
  frame();
})();
