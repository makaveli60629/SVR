(() => {
  const canvas = document.getElementById('binary-rain');
  if (!canvas) return;
  const ctx = canvas.getContext('2d', { alpha: true });

  const glyphs = ['0', '1'];
  const eggs = ['I LOVE SHY', 'I LOVE SCARLETT'];

  let width = 0;
  let height = 0;
  let dpr = 1;
  let fontSize = 14;
  let trail = 18;
  let columns = [];
  let messageStreams = [];
  let last = 0;
  let spawnTimer = 0;

  function reset() {
    dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    fontSize = Math.max(12, Math.min(16, Math.round(width / 105)));
    trail = Math.max(16, Math.floor(height / fontSize / 6));
    const count = Math.ceil(width / fontSize) + 2;
    columns = Array.from({ length: count }, (_, i) => ({
      x: i * fontSize,
      row: Math.random() * (-height / fontSize),
      speed: 16 + Math.random() * 14,
      drift: Math.random() * Math.PI * 2
    }));
    messageStreams = [];
    ctx.font = `700 ${fontSize}px Orbitron, monospace`;
    ctx.textBaseline = 'top';
  }

  function spawnMessage() {
    const index = Math.floor(Math.random() * columns.length);
    messageStreams.push({
      column: index,
      text: eggs[Math.floor(Math.random() * eggs.length)],
      startRow: -Math.floor(Math.random() * 18) - 6,
      speed: 13 + Math.random() * 8,
      glow: Math.random() * Math.PI * 2
    });
    if (messageStreams.length > 6) messageStreams.shift();
  }

  function messageChar(stream, rowIndex) {
    const offset = rowIndex - stream.startRow;
    if (offset < 0 || offset >= stream.text.length) return null;
    return stream.text[offset];
  }

  function drawGlyph(x, y, char, alpha, head = false, highlight = false, ts = 0) {
    if (!char || char === ' ') return;
    if (highlight) {
      const pulse = 0.65 + 0.35 * Math.sin(ts * 0.004 + y * 0.02);
      ctx.fillStyle = `rgba(255, ${120 + Math.floor(80 * pulse)}, 240, ${Math.min(1, alpha + 0.2)})`;
      ctx.shadowColor = `rgba(99, 230, 255, ${0.35 + pulse * 0.2})`;
      ctx.shadowBlur = 10;
      ctx.fillText(char, x, y);
      ctx.shadowBlur = 0;
      return;
    }
    const pulse = 0.5 + 0.5 * Math.sin(ts * 0.0015 + x * 0.01 + y * 0.015);
    const r = 150 + Math.floor(35 * pulse);
    const g = 72 + Math.floor(18 * pulse);
    const b = 255;
    const a = head ? Math.max(alpha, 0.92) : alpha;
    ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
    if (head) {
      ctx.shadowColor = 'rgba(217,127,255,0.45)';
      ctx.shadowBlur = 9;
    }
    ctx.fillText(char, x, y);
    if (head) ctx.shadowBlur = 0;
  }

  function tick(ts) {
    if (!last) last = ts;
    const dt = Math.min((ts - last) / 1000, 0.05);
    last = ts;
    spawnTimer += dt;

    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.fillRect(0, 0, width, height);

    for (const col of columns) {
      col.row += col.speed * dt;
      const x = col.x;
      const headRow = Math.floor(col.row);
      if ((headRow - trail) * fontSize > height + fontSize * 2) {
        col.row = Math.random() * (-height / fontSize) - Math.random() * 18;
        col.speed = 16 + Math.random() * 14;
      }

      const stream = messageStreams.find((m) => m.column === columns.indexOf(col));
      for (let i = 0; i < trail; i++) {
        const rowIndex = headRow - i;
        const y = rowIndex * fontSize;
        if (y < -fontSize || y > height + fontSize) continue;
        let char = glyphs[Math.random() < 0.5 ? 0 : 1];
        let highlight = false;
        if (stream) {
          const special = messageChar(stream, rowIndex);
          if (special) {
            char = special;
            highlight = true;
          }
        }
        const alpha = i === 0 ? 0.98 : Math.max(0.04, 0.42 - i * 0.022);
        drawGlyph(x, y, char, alpha, i === 0 && !highlight, highlight, ts);
      }
    }

    messageStreams = messageStreams.filter((stream) => {
      stream.startRow += stream.speed * dt;
      return stream.startRow * fontSize < height + fontSize * 6;
    });

    if (spawnTimer > 3.6) {
      spawnTimer = 0;
      spawnMessage();
    }

    requestAnimationFrame(tick);
  }

  reset();
  window.addEventListener('resize', reset);
  requestAnimationFrame(tick);
})();
