(() => {
  const canvas = document.getElementById('matrix-rain');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let width = 0;
  let height = 0;
  let fontSize = 18;
  let columns = 0;
  let drops = [];
  const glyphs = 'アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789SVRPOKER#$%&*+-';

  function resize() {
    const dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    fontSize = Math.max(14, Math.min(22, Math.floor(width / 70)));
    columns = Math.ceil(width / fontSize);
    drops = Array.from({ length: columns }, () => Math.random() * -height / fontSize);
    ctx.font = `700 ${fontSize}px Orbitron, monospace`;
  }

  function draw() {
    ctx.fillStyle = 'rgba(4, 4, 10, 0.15)';
    ctx.fillRect(0, 0, width, height);

    for (let i = 0; i < drops.length; i++) {
      const text = glyphs[Math.floor(Math.random() * glyphs.length)];
      const x = i * fontSize;
      const y = drops[i] * fontSize;
      const pulse = Math.sin((Date.now() / 260) + i) * 0.5 + 0.5;
      ctx.fillStyle = `rgba(${90 + Math.floor(110 * pulse)}, ${180 + Math.floor(40 * pulse)}, 255, 0.86)`;
      ctx.shadowColor = 'rgba(159, 75, 255, 0.75)';
      ctx.shadowBlur = 16;
      ctx.fillText(text, x, y);
      ctx.shadowBlur = 0;

      if (y > height && Math.random() > 0.975) {
        drops[i] = Math.random() * -20;
      }
      drops[i] += 0.72;
    }

    requestAnimationFrame(draw);
  }

  window.addEventListener('resize', resize, { passive: true });
  resize();
  draw();
})();
