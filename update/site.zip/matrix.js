(() => {
  const canvas = document.getElementById('binary-rain');
  if (!canvas) return;
  const ctx = canvas.getContext('2d', { alpha: true });

  const glyphs = '01<>[]{}:/\\|+-=';
  const eggs = [
    '01001001 00100000 01001100 01001111 01010110 01000101 00100000 01010011 01001000 01011001',
    '01001001 00100000 01001100 01001111 01010110 01000101 00100000 01010011 01000011 01000001 01010010 01001100 01000101 01010100 01010100'
  ];

  let width = 0;
  let height = 0;
  let dpr = 1;
  let fontSize = 12;
  let columns = [];
  let messages = [];

  function reset() {
    dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    fontSize = Math.max(10, Math.min(16, Math.round(width / 115)));
    columns = Array.from({ length: Math.ceil(width / fontSize) + 2 }, (_, i) => ({
      x: i * fontSize,
      y: Math.random() * -height,
      speed: 130 + Math.random() * 180,
      trail: 14 + Math.floor(Math.random() * 18),
      drift: Math.random() * Math.PI * 2
    }));
    ctx.font = `700 ${fontSize}px Orbitron, monospace`;
    ctx.textBaseline = 'top';
  }

  function spawnEgg() {
    messages.push({
      text: eggs[(Math.random() * eggs.length) | 0],
      x: Math.random() * Math.max(20, width - 420),
      y: -fontSize * 2,
      speed: 40 + Math.random() * 40,
      alpha: 0.08 + Math.random() * 0.06
    });
    if (messages.length > 4) messages.shift();
  }

  let last = 0;
  let eggTimer = 0;
  function tick(ts) {
    if (!last) last = ts;
    const dt = Math.min((ts - last) / 1000, 0.05);
    last = ts;
    eggTimer += dt;

    ctx.fillStyle = 'rgba(0,0,0,0.16)';
    ctx.fillRect(0, 0, width, height);

    for (const col of columns) {
      col.y += col.speed * dt;
      if (col.y - col.trail * fontSize > height + fontSize * 2) {
        col.y = Math.random() * -height * 0.45;
        col.speed = 130 + Math.random() * 180;
        col.trail = 14 + Math.floor(Math.random() * 18);
      }
      for (let i = 0; i < col.trail; i++) {
        const y = col.y - i * fontSize;
        if (y < -fontSize || y > height + fontSize) continue;
        const fade = 1 - i / col.trail;
        const pulse = Math.sin(ts * 0.001 + col.drift + i * 0.18) * 0.5 + 0.5;
        const head = i === 0;
        const r = 150 + Math.floor(60 * pulse);
        const g = 72 + Math.floor(32 * pulse);
        const b = 255;
        const a = head ? 0.92 : 0.06 + fade * 0.34;
        ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
        ctx.shadowColor = head ? 'rgba(217,127,255,0.48)' : 'transparent';
        ctx.shadowBlur = head ? 12 : 0;
        ctx.fillText(glyphs[(Math.random() * glyphs.length) | 0], col.x, y);
      }
    }
    ctx.shadowBlur = 0;

    messages = messages.filter((msg) => msg.y < height + 40);
    for (const msg of messages) {
      msg.y += msg.speed * dt;
      ctx.save();
      ctx.globalAlpha = msg.alpha;
      ctx.fillStyle = 'rgba(255,138,234,0.95)';
      ctx.shadowColor = 'rgba(110, 222, 255, 0.20)';
      ctx.shadowBlur = 8;
      ctx.fillText(msg.text, msg.x, msg.y);
      ctx.restore();
    }

    if (eggTimer > 5.8) {
      eggTimer = 0;
      spawnEgg();
    }
    requestAnimationFrame(tick);
  }

  reset();
  window.addEventListener('resize', reset);
  requestAnimationFrame(tick);
})();
