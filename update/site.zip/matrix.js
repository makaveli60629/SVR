(() => {
  const canvas = document.getElementById('binary-rain');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  const easterEggs = [
    '01001001 00100000 01001100 01001111 01010110 01000101 00100000 01010011 01001000 01011001',
    '01001001 00100000 01001100 01001111 01010110 01000101 00100000 01010011 01000011 01000001 01010010 01001100 01000101 01010100 01010100'
  ];

  const glyphs = ['0', '1'];
  let width = 0;
  let height = 0;
  let dpr = 1;
  let fontSize = 12;
  let columns = [];
  let eggs = [];

  function makeColumn(xIndex) {
    return {
      x: xIndex * fontSize,
      y: Math.random() * -height,
      speed: 85 + Math.random() * 95,
      trail: 10 + Math.floor(Math.random() * 22),
      pulse: Math.random() * Math.PI * 2
    };
  }

  function resize() {
    dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    fontSize = Math.max(10, Math.min(14, Math.round(width / 120)));
    ctx.font = `700 ${fontSize}px Orbitron, monospace`;
    ctx.textBaseline = 'top';
    columns = Array.from({ length: Math.ceil(width / fontSize) + 2 }, (_, i) => makeColumn(i));
  }

  function spawnEgg() {
    eggs.push({
      text: easterEggs[Math.floor(Math.random() * easterEggs.length)],
      x: Math.random() * Math.max(20, width - 420),
      y: -fontSize * 3,
      speed: 34 + Math.random() * 22,
      alpha: 0.16 + Math.random() * 0.1
    });
    if (eggs.length > 4) eggs.shift();
  }

  function drawColumn(col, t) {
    col.y += col.speed / 60;
    if (col.y - col.trail * fontSize > height + fontSize * 2) {
      Object.assign(col, makeColumn(Math.round(col.x / fontSize)));
      col.y = Math.random() * -height * 0.4;
    }

    for (let i = 0; i < col.trail; i++) {
      const y = col.y - i * fontSize;
      if (y < -fontSize || y > height + fontSize) continue;
      const char = glyphs[(Math.random() * glyphs.length) | 0];
      const fade = 1 - i / col.trail;
      const pulse = Math.sin(t * 0.0014 + col.pulse + i * 0.22) * 0.5 + 0.5;
      const r = 115 + Math.floor(88 * pulse);
      const g = 92 + Math.floor(54 * pulse);
      const b = 255;
      const a = 0.1 + fade * 0.42;
      ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${a})`;
      if (i === 0) {
        ctx.shadowColor = 'rgba(117, 232, 255, 0.34)';
        ctx.shadowBlur = 12;
      } else {
        ctx.shadowBlur = 0;
      }
      ctx.fillText(char, col.x, y);
    }
    ctx.shadowBlur = 0;
  }

  function drawEggs() {
    eggs = eggs.filter((egg) => egg.y < height + 30);
    for (const egg of eggs) {
      egg.y += egg.speed / 60;
      ctx.save();
      ctx.globalAlpha = egg.alpha;
      ctx.fillStyle = 'rgba(255, 118, 233, 0.95)';
      ctx.shadowColor = 'rgba(117, 232, 255, 0.24)';
      ctx.shadowBlur = 10;
      ctx.fillText(egg.text, egg.x, egg.y);
      ctx.restore();
    }
  }

  function frame(t) {
    ctx.fillStyle = 'rgba(3, 3, 10, 0.18)';
    ctx.fillRect(0, 0, width, height);
    for (const col of columns) drawColumn(col, t);
    drawEggs();
    requestAnimationFrame(frame);
  }

  window.addEventListener('resize', resize, { passive: true });
  resize();
  setInterval(spawnEgg, 5000);
  spawnEgg();
  requestAnimationFrame(frame);
})();
