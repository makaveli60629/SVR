import * as THREE from 'three';
import { VRButton } from 'three/addons/webxr/VRButton.js';
import { XRControllerModelFactory } from 'three/addons/webxr/XRControllerModelFactory.js';
import { XRHandModelFactory } from 'three/addons/webxr/XRHandModelFactory.js';

const statusText = document.getElementById('status-text');
const trainingCard = document.getElementById('training-card');
const dismissCard = document.getElementById('dismiss-card');
const isEmbedded = new URLSearchParams(window.location.search).get('embed') === '1';

if (isEmbedded) {
  document.querySelector('.topbar')?.classList.add('hidden');
  trainingCard?.classList.add('hidden');
  document.querySelector('.instructions')?.classList.add('hidden');
}

dismissCard?.addEventListener('click', () => trainingCard?.classList.add('hidden'));

function setStatus(message) {
  if (statusText) statusText.textContent = message;
}

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x02030a);
scene.fog = new THREE.Fog(0x02030a, 14, 74);

const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.01, 200);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor');
renderer.outputColorSpace = THREE.SRGBColorSpace;
document.body.appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer));

const playerRig = new THREE.Group();
scene.add(playerRig);
playerRig.position.set(0, 0, 10.8);

const head = new THREE.Group();
head.position.y = 1.67;
playerRig.add(head);
head.add(camera);

const world = new THREE.Group();
scene.add(world);

const keys = Object.create(null);
const clock = new THREE.Clock();
const tempVec = new THREE.Vector3();
const raycaster = new THREE.Raycaster();
const controllers = [];
const hands = [];
const seated = [];
const walkers = [];
const redBeacons = [];
let desktopYaw = 0;
let mouseDown = false;
let lastX = 0;
let teleportActive = false;
let currentTeleportPoint = null;
let lastSafeAngle = 0;
const TABLE_CLEAR_RADIUS = 6.9;
const PLAY_RADIUS = 14.8;

const ambient = new THREE.HemisphereLight(0xb8c8ff, 0x141014, 1.42);
scene.add(ambient);
const dir = new THREE.DirectionalLight(0xdce6ff, 1.0);
dir.position.set(8, 12, 6);
scene.add(dir);

const moonLight = new THREE.DirectionalLight(0x9dc7ff, 0.9);
moonLight.position.set(-12, 14, -20);
scene.add(moonLight);

const topGlow = new THREE.PointLight(0x8c62ff, 14, 50, 1.8);
topGlow.position.set(0, 6, 0);
world.add(topGlow);

const textureLoader = new THREE.TextureLoader();
function loadTexture(path) {
  const tex = textureLoader.load(path);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeRadialSprite(size, colorA, colorB) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createRadialGradient(64, 64, 5, 64, 64, 58);
  grad.addColorStop(0, colorA);
  grad.addColorStop(0.45, colorB);
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const mat = new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, depthWrite: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(size, size, 1);
  return sprite;
}

function makeLabelSprite(text) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(5, 7, 18, 0.45)';
  ctx.fillRect(0, 0, 512, 128);
  ctx.strokeStyle = 'rgba(150, 120, 255, 0.6)';
  ctx.strokeRect(3, 3, 506, 122);
  ctx.fillStyle = '#f7f4ff';
  ctx.font = 'bold 38px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, 256, 64);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false }));
  sprite.scale.set(2.8, 0.7, 1);
  return sprite;
}

function makeWindowTexture(cols = 6, rows = 14, onColor = '#ffd96b') {
  const canvas = document.createElement('canvas');
  canvas.width = cols * 24;
  canvas.height = rows * 24;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#0a0f19';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const lit = Math.random() > 0.34;
      ctx.fillStyle = lit ? onColor : 'rgba(255,255,255,0.04)';
      ctx.fillRect(x * 24 + 5, y * 24 + 5, 14, 14);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1, 1);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeFeltTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#0f6a37';
  ctx.fillRect(0, 0, 1024, 1024);
  for (let i = 0; i < 9000; i++) {
    const x = Math.random() * 1024;
    const y = Math.random() * 1024;
    const a = 0.02 + Math.random() * 0.05;
    ctx.fillStyle = `rgba(255,255,255,${a})`;
    ctx.fillRect(x, y, 2, 2);
  }
  ctx.strokeStyle = 'rgba(242,225,170,0.75)';
  ctx.lineWidth = 16;
  ctx.strokeRect(80, 110, 864, 804);
  ctx.globalAlpha = 0.1;
  ctx.strokeStyle = 'rgba(255,255,255,0.18)';
  ctx.lineWidth = 10;
  ctx.beginPath();
  ctx.ellipse(512, 512, 220, 82, 0, 0, Math.PI * 2);
  ctx.stroke();
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy?.() || 1);
  return tex;
}

function makeWoodTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createLinearGradient(0, 0, 1024, 1024);
  grad.addColorStop(0, '#2f170f');
  grad.addColorStop(0.5, '#5a3020');
  grad.addColorStop(1, '#2c170f');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1024, 1024);
  for (let i = 0; i < 1800; i++) {
    const y = Math.random() * 1024;
    const a = 0.04 + Math.random() * 0.08;
    ctx.fillStyle = `rgba(255,220,180,${a})`;
    ctx.fillRect(0, y, 1024, 1 + Math.random() * 2.5);
  }
  for (let i = 0; i < 60; i++) {
    ctx.strokeStyle = `rgba(40,10,0,${0.08 + Math.random() * 0.08})`;
    ctx.lineWidth = 1 + Math.random() * 6;
    ctx.beginPath();
    const startY = Math.random() * 1024;
    ctx.moveTo(0, startY);
    ctx.bezierCurveTo(300, startY + Math.random() * 60 - 30, 700, startY + Math.random() * 60 - 30, 1024, startY + Math.random() * 60 - 30);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy?.() || 1);
  return tex;
}

function makeMetalTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 512;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createLinearGradient(0, 0, 512, 512);
  grad.addColorStop(0, '#6f7078');
  grad.addColorStop(0.5, '#2e3138');
  grad.addColorStop(1, '#767b86');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 1200; i++) {
    const y = Math.random() * 512;
    const a = 0.05 + Math.random() * 0.07;
    ctx.fillStyle = `rgba(255,255,255,${a})`;
    ctx.fillRect(0, y, 512, 1);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy?.() || 1);
  return tex;
}

const floor = new THREE.Mesh(
  new THREE.CircleGeometry(22.8, 96),
  new THREE.MeshStandardMaterial({ color: 0x0d0e14, roughness: 0.96, metalness: 0.02 })
);
floor.rotation.x = -Math.PI / 2;
floor.receiveShadow = false;
world.add(floor);

const floorGlow = new THREE.Mesh(
  new THREE.RingGeometry(8.2, 8.9, 90),
  new THREE.MeshBasicMaterial({ color: 0x6d4cff, transparent: true, opacity: 0.18, side: THREE.DoubleSide })
);
floorGlow.rotation.x = -Math.PI / 2;
floorGlow.position.y = 0.012;
world.add(floorGlow);

const carpet = new THREE.Mesh(
  new THREE.CircleGeometry(7.35, 72),
  new THREE.MeshStandardMaterial({ color: 0x2b0830, roughness: 0.9 })
);
carpet.rotation.x = -Math.PI / 2;
carpet.position.y = 0.01;
world.add(carpet);

const parapet = new THREE.Mesh(
  new THREE.CylinderGeometry(20.2, 20.2, 1.45, 96, 1, true),
  new THREE.MeshStandardMaterial({ color: 0x131520, side: THREE.BackSide, roughness: 0.92 })
);
parapet.position.y = 0.725;
world.add(parapet);

const parapetTop = new THREE.Mesh(
  new THREE.TorusGeometry(20.05, 0.11, 10, 128),
  new THREE.MeshStandardMaterial({ color: 0x1c2135, emissive: 0x090b14, emissiveIntensity: 0.6 })
);
parapetTop.rotation.x = Math.PI / 2;
parapetTop.position.y = 1.46;
world.add(parapetTop);

const upperRing = new THREE.Mesh(
  new THREE.CylinderGeometry(20.2, 20.2, 0.45, 96, 1, true),
  new THREE.MeshStandardMaterial({ color: 0x0b0c10, side: THREE.BackSide, transparent: true, opacity: 0.78 })
);
upperRing.position.y = 7.15;
world.add(upperRing);

const trimRing1 = new THREE.Mesh(
  new THREE.TorusGeometry(19.85, 0.08, 10, 140),
  new THREE.MeshStandardMaterial({ color: 0x8752ff, emissive: 0x5725ff, emissiveIntensity: 0.85 })
);
trimRing1.rotation.x = Math.PI / 2;
trimRing1.position.y = 4.85;
world.add(trimRing1);

const trimRing2 = trimRing1.clone();
trimRing2.material = trimRing1.material.clone();
trimRing2.material.color = new THREE.Color(0x52d6ff);
trimRing2.material.emissive = new THREE.Color(0x1762ff);
trimRing2.position.y = 5.9;
world.add(trimRing2);

const moon = makeRadialSprite(6.3, 'rgba(255,255,255,1)', 'rgba(188,210,255,0.7)');
moon.position.set(-12.5, 13.5, -26.5);
world.add(moon);

for (let i = 0; i < 180; i++) {
  const color = i % 3 === 0 ? 'rgba(214,122,255,0.82)' : 'rgba(134,227,255,0.78)';
  const sprite = makeRadialSprite(0.12 + Math.random() * 0.2, 'rgba(255,255,255,1)', color);
  const angle = Math.random() * Math.PI * 2;
  const radius = 22 + Math.random() * 16;
  sprite.position.set(Math.cos(angle) * radius, 5 + Math.random() * 10, Math.sin(angle) * radius);
  world.add(sprite);
}

const skylineGroup = new THREE.Group();
world.add(skylineGroup);

function buildingMaterial(onColor = '#ffd96b') {
  const tex = makeWindowTexture(7, 18, onColor);
  return new THREE.MeshStandardMaterial({
    color: 0x0a101b,
    emissive: 0x1f2f4d,
    emissiveIntensity: 0.52,
    map: tex,
    roughness: 0.68,
    metalness: 0.18
  });
}

function addBeacon(parent, x, y, z) {
  const light = new THREE.Mesh(
    new THREE.SphereGeometry(0.08, 10, 10),
    new THREE.MeshBasicMaterial({ color: 0xff2d3e })
  );
  light.position.set(x, y, z);
  parent.add(light);
  redBeacons.push(light);
}

function createGenericTower(width, height, depth, color = '#ffd96b') {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), buildingMaterial(color));
  mesh.position.y = height / 2 - 1.8;
  if (height > 8) addBeacon(mesh, 0, height / 2 + 0.1, 0);
  return mesh;
}

function createWillisTower() {
  const group = new THREE.Group();
  const mat = buildingMaterial('#ffe28a');
  const core = new THREE.Mesh(new THREE.BoxGeometry(2.7, 15.5, 2.7), mat);
  core.position.y = 7.75;
  group.add(core);
  const west = new THREE.Mesh(new THREE.BoxGeometry(1.1, 11.8, 1.1), mat.clone());
  west.position.set(-1.85, 5.9, 0.72);
  group.add(west);
  const east = west.clone();
  east.position.set(1.85, 5.4, -0.72);
  group.add(east);
  const west2 = new THREE.Mesh(new THREE.BoxGeometry(1.1, 9.3, 1.1), mat.clone());
  west2.position.set(-0.72, 4.65, -1.85);
  group.add(west2);
  const east2 = west2.clone();
  east2.position.set(0.72, 4.3, 1.85);
  group.add(east2);
  const antennaMat = new THREE.MeshStandardMaterial({ color: 0xbec8d6, emissive: 0x5b6780, emissiveIntensity: 0.5 });
  const antenna1 = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.3, 8), antennaMat);
  antenna1.position.set(-0.42, 16.6, 0);
  const antenna2 = antenna1.clone();
  antenna2.position.set(0.42, 16.2, 0.1);
  group.add(antenna1, antenna2);
  addBeacon(group, -0.42, 17.75, 0);
  addBeacon(group, 0.42, 17.35, 0.1);
  return group;
}

function createHancockTower() {
  const group = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.55, 13.6, 2.2), buildingMaterial('#d6ebff'));
  body.position.y = 6.8;
  group.add(body);
  const cap = new THREE.Mesh(new THREE.BoxGeometry(2.15, 1.3, 1.85), body.material.clone());
  cap.position.y = 13.65;
  group.add(cap);
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xaec9ff, transparent: true, opacity: 0.55 });
  for (let i = -1; i <= 1; i += 2) {
    const diag1 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 4.1, 0.02), lineMat);
    diag1.position.set(i * 0.95, 4.1, 1.11);
    diag1.rotation.z = i * 0.53;
    group.add(diag1);
    const diag2 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 4.1, 0.02), lineMat);
    diag2.position.set(i * 0.95, 9.0, 1.11);
    diag2.rotation.z = -i * 0.53;
    group.add(diag2);
  }
  const antennaMat = new THREE.MeshStandardMaterial({ color: 0xcbd2de, emissive: 0x55647b, emissiveIntensity: 0.45 });
  const antenna1 = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 2.7, 8), antennaMat);
  antenna1.position.set(-0.35, 15.8, 0);
  const antenna2 = antenna1.clone();
  antenna2.position.set(0.35, 15.5, 0);
  group.add(antenna1, antenna2);
  addBeacon(group, -0.35, 17.15, 0);
  addBeacon(group, 0.35, 16.85, 0);
  return group;
}

function createTrumpTower() {
  const group = new THREE.Group();
  const mat = buildingMaterial('#cbe7ff');
  const base = new THREE.Mesh(new THREE.BoxGeometry(2.8, 6.2, 2.1), mat);
  base.position.y = 3.1;
  const mid = new THREE.Mesh(new THREE.BoxGeometry(2.3, 4.6, 1.8), mat.clone());
  mid.position.y = 8.5;
  const top = new THREE.Mesh(new THREE.BoxGeometry(1.8, 3.3, 1.5), mat.clone());
  top.position.y = 12.45;
  group.add(base, mid, top);
  addBeacon(group, 0, 14.25, 0);
  return group;
}

function createAonTower() {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(2.2, 12.6, 2.2),
    buildingMaterial('#dff5ff')
  );
  mesh.position.y = 6.3;
  addBeacon(mesh, 0, 6.5, 0);
  return mesh;
}

function placeSkylineTower(object, x, z, rotY = 0) {
  object.position.set(x, -2.1, z);
  object.rotation.y = rotY;
  skylineGroup.add(object);
}

for (let i = 0; i < 64; i++) {
  const angle = THREE.MathUtils.degToRad(-170 + (340 / 63) * i);
  const radius = 24.4 + (i % 5) * 0.9;
  const height = 8 + Math.random() * 12.5;
  const width = 1.05 + Math.random() * 2.2;
  const depth = 0.95 + Math.random() * 2.0;
  const tower = createGenericTower(width, height, depth, i % 4 ? '#ffd96b' : '#dff5ff');
  tower.position.set(Math.sin(angle) * radius, height / 2 - 1.9, Math.cos(angle) * radius);
  tower.lookAt(0, 4.5, 0);
  skylineGroup.add(tower);
}
for (let i = 0; i < 28; i++) {
  const angle = THREE.MathUtils.degToRad(-180 + (360 / 28) * i);
  const radius = 28.8 + (i % 3) * 1.1;
  const height = 5.5 + Math.random() * 7.8;
  const width = 1.1 + Math.random() * 1.8;
  const depth = 1.0 + Math.random() * 1.6;
  const tower = createGenericTower(width, height, depth, i % 2 ? '#ffd96b' : '#cfe8ff');
  tower.position.set(Math.sin(angle) * radius, height / 2 - 2.5, Math.cos(angle) * radius);
  tower.lookAt(0, 5, 0);
  skylineGroup.add(tower);
}

placeSkylineTower(createWillisTower(), -4.1, -24.9, 0.08);
placeSkylineTower(createHancockTower(), 7.6, -24.0, -0.08);
placeSkylineTower(createTrumpTower(), -12.4, -23.4, 0.06);
placeSkylineTower(createAonTower(), 13.6, -25.1, -0.02);

const logoSign = new THREE.Mesh(
  new THREE.PlaneGeometry(6.6, 2.2),
  new THREE.MeshBasicMaterial({ map: loadTexture('./assets/logo.png'), transparent: true })
);
logoSign.position.set(0, 4.2, 17.6);
logoSign.rotation.y = Math.PI;
world.add(logoSign);

const logoFrame = new THREE.Mesh(
  new THREE.PlaneGeometry(7.1, 2.65),
  new THREE.MeshBasicMaterial({ color: 0x05060b, transparent: true, opacity: 0.66 })
);
logoFrame.position.set(0, 4.2, 17.65);
logoFrame.rotation.y = Math.PI;
world.add(logoFrame);

const feltTexture = makeFeltTexture();
const woodTexture = makeWoodTexture();
const metalTexture = makeMetalTexture();
const tableGroup = new THREE.Group();
const tableTop = new THREE.Mesh(
  new THREE.CylinderGeometry(3.02, 3.28, 0.22, 56),
  new THREE.MeshStandardMaterial({ map: feltTexture, roughness: 0.84, metalness: 0.02 })
);
tableTop.position.y = 1.08;
const railMat = new THREE.MeshStandardMaterial({ map: woodTexture, roughness: 0.55, metalness: 0.08 });
railMat.map.repeat.set(2.2, 1);
const tableRail = new THREE.Mesh(
  new THREE.TorusGeometry(2.95, 0.18, 18, 96),
  railMat
);
tableRail.rotation.x = Math.PI / 2;
tableRail.position.y = 1.19;
const tableApron = new THREE.Mesh(
  new THREE.CylinderGeometry(2.92, 3.08, 0.18, 56, 1, true),
  new THREE.MeshStandardMaterial({ map: woodTexture, roughness: 0.62, metalness: 0.05 })
);
tableApron.position.y = 1.0;
const railTrim = new THREE.Mesh(
  new THREE.TorusGeometry(2.72, 0.04, 12, 96),
  new THREE.MeshStandardMaterial({ color: 0xd8c496, emissive: 0x5a4a24, emissiveIntensity: 0.18, roughness: 0.4, metalness: 0.62 })
);
railTrim.rotation.x = Math.PI / 2;
railTrim.position.y = 1.18;
const tableBase = new THREE.Mesh(
  new THREE.CylinderGeometry(0.3, 0.48, 0.98, 24),
  new THREE.MeshStandardMaterial({ map: metalTexture, roughness: 0.42, metalness: 0.88 })
);
tableBase.position.y = 0.54;
const tableCollar = new THREE.Mesh(
  new THREE.CylinderGeometry(0.58, 0.62, 0.08, 24),
  new THREE.MeshStandardMaterial({ color: 0x7d858f, roughness: 0.34, metalness: 0.92 })
);
tableCollar.position.y = 0.98;
const tableFoot = new THREE.Mesh(
  new THREE.CylinderGeometry(1.14, 1.34, 0.14, 28),
  new THREE.MeshStandardMaterial({ map: metalTexture, roughness: 0.4, metalness: 0.92 })
);
tableFoot.position.y = 0.07;
const dealerDeck = new THREE.Mesh(
  new THREE.BoxGeometry(0.52, 0.11, 0.78),
  new THREE.MeshStandardMaterial({ color: 0xf5f0e6, roughness: 0.5 })
);
dealerDeck.position.set(0, 1.22, -1.05);
const tableBadge = new THREE.Mesh(
  new THREE.RingGeometry(0.68, 0.9, 48),
  new THREE.MeshBasicMaterial({ color: 0x8c62ff, transparent: true, opacity: 0.28, side: THREE.DoubleSide })
);
tableBadge.rotation.x = -Math.PI / 2;
tableBadge.position.set(0, 1.194, 0.32);
tableGroup.add(tableTop, tableRail, tableApron, railTrim, tableBase, tableCollar, tableFoot, dealerDeck, tableBadge);
world.add(tableGroup);

function createCard(x, z, hue = 0xffffff) {
  const card = new THREE.Mesh(
    new THREE.BoxGeometry(0.46, 0.028, 0.68),
    new THREE.MeshStandardMaterial({ color: hue, roughness: 0.56 })
  );
  card.position.set(x, 1.23, z);
  card.rotation.x = -0.08;
  card.rotation.z = (Math.random() - 0.5) * 0.08;
  return card;
}

[-1.0, -0.5, 0, 0.5, 1.0].forEach((x, idx) => {
  world.add(createCard(x, idx === 2 ? 0.15 : -0.08 + idx * 0.05, idx === 2 ? 0xfff4d5 : 0xffffff));
});

function createChip(color) {
  const chip = new THREE.Mesh(
    new THREE.CylinderGeometry(0.13, 0.13, 0.04, 20),
    new THREE.MeshStandardMaterial({ color, roughness: 0.5, metalness: 0.2 })
  );
  return chip;
}
for (let i = 0; i < 4; i++) {
  const stack = new THREE.Group();
  for (let j = 0; j < 4 + i; j++) {
    const chip = createChip(i % 2 ? 0xa24cff : 0x29d5ff);
    chip.position.y = 1.12 + j * 0.042;
    stack.add(chip);
  }
  stack.position.set(-1.4 + i * 0.9, 0, 1.1 + (i % 2) * 0.25);
  world.add(stack);
}

function createChair(stool = false) {
  const chair = new THREE.Group();
  const seat = new THREE.Mesh(
    new THREE.BoxGeometry(stool ? 0.64 : 0.74, 0.11, stool ? 0.64 : 0.74),
    new THREE.MeshStandardMaterial({ color: stool ? 0x2a1a33 : 0x1f1f27, roughness: 0.9 })
  );
  seat.position.y = 0.56;
  chair.add(seat);
  if (!stool) {
    const back = new THREE.Mesh(
      new THREE.BoxGeometry(0.74, 0.8, 0.12),
      new THREE.MeshStandardMaterial({ color: 0x25253a, roughness: 0.9 })
    );
    back.position.set(0, 0.98, -0.31);
    chair.add(back);
  }
  for (const sx of [-0.24, 0.24]) {
    for (const sz of [-0.24, 0.24]) {
      const leg = new THREE.Mesh(
        new THREE.BoxGeometry(0.07, 0.52, 0.07),
        new THREE.MeshStandardMaterial({ color: 0x101014 })
      );
      leg.position.set(sx, 0.28, sz);
      chair.add(leg);
    }
  }
  return chair;
}

for (let i = 0; i < 6; i++) {
  const angle = (i / 6) * Math.PI * 2;
  const playerSeat = i === 3;
  const chair = createChair(playerSeat);
  chair.position.set(Math.sin(angle) * 4.36, 0, Math.cos(angle) * 4.36);
  chair.lookAt(0, 1.0, 0);
  world.add(chair);
  if (playerSeat) {
    const tag = makeLabelSprite('YOUR SEAT');
    tag.position.copy(chair.position).setY(1.65);
    world.add(tag);
  }
}

function clothingTexture(primary = '#2a345c', stripe = '#8ec9ff') {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 256;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = primary;
  ctx.fillRect(0, 0, 256, 256);
  ctx.fillStyle = stripe;
  for (let i = 0; i < 6; i++) ctx.fillRect(0, i * 42 + 8, 256, 8);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createAvatar(name, options = {}) {
  const {
    seatedAvatar = false,
    walkColor = '#2e3656',
    accent = '#8ac7ff',
    dealer = false,
    addCards = false,
    skin = 0xd2ac8d
  } = options;
  const group = new THREE.Group();
  const clothMat = new THREE.MeshStandardMaterial({ map: clothingTexture(walkColor, accent), roughness: 0.88 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, seatedAvatar ? 0.62 : 0.84, 4, 10), clothMat);
  body.position.y = seatedAvatar ? 0.98 : 1.2;
  const headMesh = new THREE.Mesh(new THREE.SphereGeometry(0.19, 20, 20), new THREE.MeshStandardMaterial({ color: skin }));
  headMesh.position.y = seatedAvatar ? 1.54 : 1.78;
  const armL = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.42, 4, 8), clothMat.clone());
  const armR = armL.clone();
  armL.position.set(-0.25, seatedAvatar ? 1.14 : 1.32, 0.02);
  armR.position.set(0.25, seatedAvatar ? 1.14 : 1.32, 0.02);
  armL.rotation.z = 0.48;
  armR.rotation.z = -0.48;
  const legL = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, seatedAvatar ? 0.3 : 0.62, 4, 8), clothMat.clone());
  const legR = legL.clone();
  if (seatedAvatar) {
    legL.position.set(-0.13, 0.55, 0.16); legL.rotation.x = 1.3;
    legR.position.set(0.13, 0.55, 0.16); legR.rotation.x = 1.3;
  } else {
    legL.position.set(-0.12, 0.46, 0); legR.position.set(0.12, 0.46, 0);
  }
  group.add(body, headMesh, armL, armR, legL, legR);
  if (dealer) {
    const vest = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.62, 0.18), new THREE.MeshStandardMaterial({ color: 0x181818 }));
    vest.position.set(0, seatedAvatar ? 1.02 : 1.18, 0.14);
    group.add(vest);
  }
  if (addCards) {
    const leftCard = createCard(-0.12, 0, 0xffffff);
    leftCard.scale.set(0.65, 0.65, 0.65);
    leftCard.rotation.set(Math.PI / 2.2, 0.2, 0.2);
    leftCard.position.set(-0.28, seatedAvatar ? 1.1 : 1.3, 0.12);
    const rightCard = leftCard.clone();
    rightCard.position.set(0.28, seatedAvatar ? 1.1 : 1.3, 0.12);
    rightCard.rotation.z = -0.2;
    group.add(leftCard, rightCard);
  }
  const label = makeLabelSprite(name.toUpperCase());
  label.position.y = seatedAvatar ? 2.15 : 2.35;
  label.scale.multiplyScalar(0.72);
  group.add(label);
  group.userData = { armL, armR, headMesh, seatedAvatar, name, label };
  return group;
}

const dealerEric = createAvatar('Eric', { dealer: true, walkColor: '#2b3552', accent: '#84d5ff', addCards: true });
dealerEric.position.set(0, 0, -4.7);
dealerEric.lookAt(0, 1.1, 0);
world.add(dealerEric);

const dealerClaudia = createAvatar('Claudia', { seatedAvatar: false, dealer: true, walkColor: '#4b2e5e', accent: '#ffb6ee', addCards: true, skin: 0xe2b596 });
dealerClaudia.position.set(2.35, 0, -4.1);
dealerClaudia.lookAt(0, 1.1, 0);
world.add(dealerClaudia);

const seatedAngles = [0.22, 0.95, 1.65, 2.35, 3.95, 4.75, 5.42];
seatedAngles.forEach((angle, idx) => {
  const bot = createAvatar(idx % 2 ? 'Player' : 'Guest', {
    seatedAvatar: true,
    walkColor: idx % 2 ? '#363b5a' : '#2c2f3d',
    accent: idx % 2 ? '#9fd1ff' : '#c795ff',
    addCards: true,
    skin: idx % 2 ? 0xdcb08d : 0xc79674
  });
  bot.position.set(Math.sin(angle) * 3.24, 0, Math.cos(angle) * 3.24);
  bot.lookAt(0, 1.15, 0);
  seated.push(bot);
  world.add(bot);
});

['Claudia', 'Eric', 'Walker A', 'Walker B', 'Walker C', 'Walker D', 'Walker E', 'Walker F'].forEach((name, idx) => {
  const bot = createAvatar(name, { walkColor: idx % 2 ? '#3f2a62' : '#2b4358', accent: idx % 2 ? '#ffb1f1' : '#8fdcff', skin: idx % 2 ? 0xe0b28f : 0xd3a07d });
  bot.userData.radius = 11.8 + idx * 0.9;
  bot.userData.speed = 0.1 + idx * 0.02;
  bot.userData.phase = idx * 1.2;
  walkers.push(bot);
  world.add(bot);
});

const teleportMarker = new THREE.Mesh(
  new THREE.RingGeometry(0.46, 0.94, 56),
  new THREE.MeshBasicMaterial({ color: 0x6ad8ff, transparent: true, opacity: 0.9, side: THREE.DoubleSide })
);
teleportMarker.rotation.x = -Math.PI / 2;
teleportMarker.visible = false;
world.add(teleportMarker);

const markerBeam = new THREE.Mesh(
  new THREE.CylinderGeometry(0.035, 0.035, 0.9, 10),
  new THREE.MeshBasicMaterial({ color: 0x7ee3ff, transparent: true, opacity: 0.55 })
);
markerBeam.visible = false;
world.add(markerBeam);

const markerTag = makeLabelSprite('MOVE HERE');
markerTag.visible = false;
world.add(markerTag);

const pointerSphere = new THREE.Mesh(
  new THREE.SphereGeometry(0.11, 20, 20),
  new THREE.MeshBasicMaterial({ color: 0x6ad8ff })
);
pointerSphere.visible = false;
world.add(pointerSphere);

const controllerFactory = new XRControllerModelFactory();
const handFactory = new XRHandModelFactory();
const lineGeometry = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, -1.4)]);

for (let i = 0; i < 2; i++) {
  const controller = renderer.xr.getController(i);
  const line = new THREE.Line(lineGeometry, new THREE.LineBasicMaterial({ color: i === 0 ? 0x7ce6ff : 0xcc92ff }));
  line.name = 'ray';
  line.visible = false;
  controller.add(line);
  playerRig.add(controller);
  controllers.push(controller);

  const grip = renderer.xr.getControllerGrip(i);
  grip.add(controllerFactory.createControllerModel(grip));
  playerRig.add(grip);

  const hand = renderer.xr.getHand(i);
  hand.userData.side = i === 0 ? 'left' : 'right';
  hand.userData.wasClosed = false;
  hand.userData.wasPinched = false;
  hand.userData.hasBeenOpen = false;
  hand.userData.toggleLatch = false;
  hand.userData.closeStart = 0;
  hand.add(handFactory.createHandModel(hand, 'mesh'));
  playerRig.add(hand);
  hands.push(hand);

  controller.addEventListener('selectstart', () => {
    if (teleportActive && currentTeleportPoint) doTeleport(currentTeleportPoint);
  });
}

function getJoint(hand, name) {
  return hand.joints?.[name] || hand.getObjectByName(name);
}

function jointWorldPosition(joint) {
  const v = new THREE.Vector3();
  joint.getWorldPosition(v);
  return v;
}

function handIsClosed(hand) {
  const wrist = getJoint(hand, 'wrist');
  if (!wrist) return false;
  const fingerNames = ['index-finger-tip', 'middle-finger-tip', 'ring-finger-tip', 'pinky-finger-tip'];
  const wristPos = jointWorldPosition(wrist);
  let total = 0;
  let count = 0;
  for (const name of fingerNames) {
    const joint = getJoint(hand, name);
    if (!joint) continue;
    total += jointWorldPosition(joint).distanceTo(wristPos);
    count += 1;
  }
  return count >= 3 && (total / count) < 0.18;
}

function handIsPinching(hand) {
  const thumb = getJoint(hand, 'thumb-tip');
  const index = getJoint(hand, 'index-finger-tip');
  if (!thumb || !index) return false;
  return jointWorldPosition(thumb).distanceTo(jointWorldPosition(index)) < 0.035;
}

function keepPlayerOutsideTable() {
  const minRadius = TABLE_CLEAR_RADIUS;
  const x = playerRig.position.x;
  const z = playerRig.position.z;
  const radius = Math.hypot(x, z);
  if (radius < minRadius) {
    const angle = radius > 0.001 ? Math.atan2(x, z) : lastSafeAngle;
    playerRig.position.x = Math.sin(angle) * minRadius;
    playerRig.position.z = Math.cos(angle) * minRadius;
  } else {
    lastSafeAngle = Math.atan2(x, z);
  }
  playerRig.position.y = 0;
}

function movePlayerToSafeSpawn() {
  playerRig.position.set(0, 0, 11.8);
  lastSafeAngle = 0;
  keepPlayerOutsideTable();
}

function getSafeTeleportPoint(point) {
  const safe = point.clone();
  const radius = Math.hypot(safe.x, safe.z);
  if (radius < TABLE_CLEAR_RADIUS) {
    const angle = radius > 0.001 ? Math.atan2(safe.x, safe.z) : lastSafeAngle;
    safe.x = Math.sin(angle) * TABLE_CLEAR_RADIUS;
    safe.z = Math.cos(angle) * TABLE_CLEAR_RADIUS;
  }
  if (radius > PLAY_RADIUS) {
    safe.x *= PLAY_RADIUS / radius;
    safe.z *= PLAY_RADIUS / radius;
  }
  safe.y = 0;
  return safe;
}

function doTeleport(point) {
  const safe = getSafeTeleportPoint(point);
  playerRig.position.x = THREE.MathUtils.clamp(safe.x, -PLAY_RADIUS, PLAY_RADIUS);
  playerRig.position.z = THREE.MathUtils.clamp(safe.z, -PLAY_RADIUS, PLAY_RADIUS);
  keepPlayerOutsideTable();
  setStatus(`Teleported to ${playerRig.position.x.toFixed(1)}, ${playerRig.position.z.toFixed(1)}.`);
}

window.addEventListener('keydown', (e) => {
  keys[e.code] = true;
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });
window.addEventListener('resize', onResize);
window.addEventListener('pointerdown', (e) => { mouseDown = true; lastX = e.clientX; });
window.addEventListener('pointerup', () => { mouseDown = false; });
window.addEventListener('pointermove', (e) => {
  if (!mouseDown || renderer.xr.isPresenting) return;
  desktopYaw -= (e.clientX - lastX) * 0.003;
  lastX = e.clientX;
});
window.addEventListener('click', () => {
  // Desktop players walk only; teleport is XR-only to avoid controller/input conflicts.
});

renderer.xr.addEventListener('sessionstart', () => {
  head.position.y = 0;
  teleportActive = false;
  currentTeleportPoint = null;
  movePlayerToSafeSpawn();
  setStatus('XR started. Standing mode active. Open your left hand, then close a left fist to toggle teleport. Aim with your right hand and pinch or use trigger to move.')
});
renderer.xr.addEventListener('sessionend', () => {
  head.position.y = 1.67;
  teleportActive = false;
  currentTeleportPoint = null;
  movePlayerToSafeSpawn();
  setStatus('XR ended. Desktop preview active.');
});

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function updateDesktopMovement(dt) {
  if (renderer.xr.isPresenting) return;
  const move = new THREE.Vector3();
  if (keys.KeyW) move.z -= 1;
  if (keys.KeyS) move.z += 1;
  if (keys.KeyA) move.x -= 1;
  if (keys.KeyD) move.x += 1;
  if (move.lengthSq() > 0) {
    move.normalize().multiplyScalar(dt * 3.3);
    move.applyAxisAngle(new THREE.Vector3(0, 1, 0), desktopYaw);
    playerRig.position.add(move);
  }
  camera.rotation.set(0, desktopYaw, 0);
  clampPlayer();
}

function updateGamepadMovement(dt) {
  if (renderer.xr.isPresenting) return;
  const pads = navigator.getGamepads?.() || [];
  const pad = Array.from(pads).find(Boolean);
  if (!pad) return;
  const x = pad.axes?.[0] || 0;
  const z = pad.axes?.[1] || 0;
  if (Math.abs(x) < 0.12 && Math.abs(z) < 0.12) return;
  tempVec.set(x, 0, z).normalize().multiplyScalar(dt * 3.2);
  tempVec.applyAxisAngle(new THREE.Vector3(0, 1, 0), desktopYaw);
  playerRig.position.add(tempVec);
  clampPlayer();
}

function updateXRMovement(dt) {
  const session = renderer.xr.getSession();
  if (!session) return;
  for (const source of session.inputSources) {
    if (!source.gamepad || source.handedness !== 'left') continue;
    const axes = source.gamepad.axes || [];
    const x = axes[2] ?? axes[0] ?? 0;
    const z = axes[3] ?? axes[1] ?? 0;
    if (Math.abs(x) < 0.08 && Math.abs(z) < 0.08) continue;
    tempVec.set(x, 0, z).normalize().multiplyScalar(dt * 2.8);
    tempVec.applyQuaternion(camera.quaternion);
    tempVec.y = 0;
    playerRig.position.add(tempVec);
    clampPlayer();
  }
}

function clampPlayer() {
  const radius = Math.hypot(playerRig.position.x, playerRig.position.z);
  if (radius > 14.8) {
    playerRig.position.x *= 14.8 / radius;
    playerRig.position.z *= 14.8 / radius;
  }
  keepPlayerOutsideTable();
}

function updateAvatars(elapsed) {
  seated.forEach((bot, i) => {
    bot.userData.headMesh.rotation.y = Math.sin(elapsed * 1.7 + i) * 0.14;
    bot.userData.armL.rotation.z = 0.44 + Math.sin(elapsed * 2.2 + i) * 0.06;
    bot.userData.armR.rotation.z = -0.44 - Math.sin(elapsed * 2.15 + i) * 0.06;
  });
  walkers.forEach((bot, i) => {
    const angle = elapsed * bot.userData.speed + bot.userData.phase;
    const r = bot.userData.radius;
    bot.position.set(Math.cos(angle) * r, 0, Math.sin(angle) * r);
    bot.lookAt(Math.cos(angle + 0.18) * r, 1.3, Math.sin(angle + 0.18) * r);
    bot.userData.armL.rotation.x = Math.sin(elapsed * 4 + i) * 0.5;
    bot.userData.armR.rotation.x = -Math.sin(elapsed * 4 + i) * 0.5;
  });
  dealerEric.userData.armL.rotation.x = Math.sin(elapsed * 3.2) * 0.32;
  dealerEric.userData.armR.rotation.x = -Math.sin(elapsed * 3.2) * 0.32;
  dealerClaudia.userData.armL.rotation.x = Math.cos(elapsed * 2.8) * 0.24;
  dealerClaudia.userData.armR.rotation.x = -Math.cos(elapsed * 2.8) * 0.24;
}

function updateBeacons(elapsed) {
  redBeacons.forEach((light, idx) => {
    const on = Math.sin(elapsed * 4 + idx * 0.7) > 0.25;
    light.visible = on;
  });
}

function getTeleportSource() {
  const rightHand = hands.find((hand) => hand.userData.side === 'right');
  if (rightHand) {
    const wrist = getJoint(rightHand, 'wrist');
    const indexTip = getJoint(rightHand, 'index-finger-tip');
    if (wrist && indexTip) {
      const origin = jointWorldPosition(indexTip);
      const direction = jointWorldPosition(indexTip).sub(jointWorldPosition(wrist)).normalize();
      if (direction.lengthSq() > 0.0001 && origin.y > 0.25) {
        return { origin, direction };
      }
    }
  }
  const controller = controllers[1] || controllers[0];
  if (controller) {
    const origin = new THREE.Vector3();
    const direction = new THREE.Vector3();
    controller.getWorldPosition(origin);
    direction.set(0, 0, -1).applyQuaternion(controller.getWorldQuaternion(new THREE.Quaternion())).normalize();
    if (origin.y > 0.25) return { origin, direction };
  }
  return null;
}

function updateTeleportFromHands(elapsed) {
  if (!renderer.xr.isPresenting) {
    pointerSphere.visible = false;
    teleportMarker.visible = false;
    markerBeam.visible = false;
    markerTag.visible = false;
    return;
  }

  hands.forEach((hand) => {
    const closed = handIsClosed(hand);
    const pinching = handIsPinching(hand);
    const opened = !closed;

    if (opened) {
      hand.userData.hasBeenOpen = true;
      hand.userData.toggleLatch = false;
      hand.userData.closeStart = 0;
    }

    if (hand.userData.side === 'left') {
      if (closed && hand.userData.hasBeenOpen) {
        if (!hand.userData.closeStart) hand.userData.closeStart = elapsed;
        if (!hand.userData.toggleLatch && elapsed - hand.userData.closeStart > 0.14) {
          teleportActive = !teleportActive;
          hand.userData.toggleLatch = true;
          currentTeleportPoint = null;
          setStatus(teleportActive ? 'Teleporter on. Aim with your right hand, then pinch or use trigger to move. Close a left fist again to turn it off.' : 'Teleporter off.');
        }
      }
    }

    if (hand.userData.side === 'right' && teleportActive && pinching && !hand.userData.wasPinched && currentTeleportPoint) {
      doTeleport(currentTeleportPoint);
    }
    hand.userData.wasClosed = closed;
    hand.userData.wasPinched = pinching;
  });

  controllers.forEach((controller) => {
    controller.getObjectByName('ray').visible = teleportActive;
  });

  if (!teleportActive) {
    pointerSphere.visible = false;
    teleportMarker.visible = false;
    markerBeam.visible = false;
    markerTag.visible = false;
    currentTeleportPoint = null;
    return;
  }

  const source = getTeleportSource();
  if (!source) {
    pointerSphere.visible = false;
    teleportMarker.visible = false;
    markerBeam.visible = false;
    markerTag.visible = false;
    currentTeleportPoint = null;
    return;
  }

  raycaster.set(source.origin, source.direction);
  const hit = raycaster.intersectObject(floor, false)[0];
  if (hit) {
    const safePoint = getSafeTeleportPoint(hit.point);
    currentTeleportPoint = safePoint.clone();
    pointerSphere.visible = true;
    pointerSphere.position.copy(safePoint).setY(0.72);
    teleportMarker.visible = true;
    teleportMarker.position.copy(safePoint).setY(0.04);
    markerBeam.visible = true;
    markerBeam.position.copy(safePoint).setY(0.56);
    markerTag.visible = true;
    markerTag.position.copy(safePoint).setY(1.28);
  } else {
    pointerSphere.visible = false;
    teleportMarker.visible = false;
    markerBeam.visible = false;
    markerTag.visible = false;
    currentTeleportPoint = null;
  }
}

function animate() {
  const dt = Math.min(clock.getDelta(), 0.05);
  const elapsed = clock.elapsedTime;
  updateDesktopMovement(dt);
  updateGamepadMovement(dt);
  updateXRMovement(dt);
  updateAvatars(elapsed);
  updateBeacons(elapsed);
  updateTeleportFromHands(elapsed);

  moon.position.x = -12.5 + Math.sin(elapsed * 0.08) * 1.2;
  moon.position.y = 13.5 + Math.sin(elapsed * 0.11) * 0.28;
  moonLight.position.set(moon.position.x * 0.9, moon.position.y + 1.2, moon.position.z * 0.9);
  trimRing1.material.emissiveIntensity = 0.7 + Math.sin(elapsed * 1.6) * 0.14;
  trimRing2.material.emissiveIntensity = 0.72 + Math.cos(elapsed * 1.8) * 0.14;
  floorGlow.material.opacity = 0.16 + Math.sin(elapsed * 1.4) * 0.04;
  if (teleportMarker.visible) {
    teleportMarker.material.opacity = 0.72 + Math.sin(elapsed * 4) * 0.16;
    teleportMarker.rotation.z += dt * 0.8;
    markerBeam.material.opacity = 0.35 + Math.sin(elapsed * 5) * 0.14;
    markerTag.material.opacity = 0.82 + Math.sin(elapsed * 5) * 0.08;
  }
  renderer.render(scene, camera);
}

movePlayerToSafeSpawn();
setStatus('Chicago rooftop recovery room loaded. Desktop: drag + WASD/gamepad walk only. XR: open left hand, then close left fist to toggle teleport. Aim with right hand and pinch or trigger to move.');
renderer.setAnimationLoop(animate);
