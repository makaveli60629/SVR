<?php
/**
 * Database connection placeholder.
 *
 * Replace these values with your actual database credentials when wiring up SQL.
 */
$host = 'localhost';
$user = 'db_user';
$pass = 'db_password';
$dbname = 'svr_database';

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
?>
