# Backend Setup

This directory contains placeholders for backend integration.

## db.php

Contains a template for connecting to a MySQL database. Replace the placeholder values with your actual database host, username, password, and database name. Use this file as the basis for your SQL queries when wiring up login, store, profile, chips, and other dynamic features.

## stripe_config.php

Contains placeholders for Stripe keys. Replace with your actual Stripe secret and publishable keys when wiring up payment processing (memberships, chip purchases, etc.).

These files are not used directly by the current static site, but they provide a starting point for server-side integration on a PHP-capable hosting platform. GitHub Pages does not support server-side code; deploy to a suitable environment (e.g., a PHP server) when ready.
