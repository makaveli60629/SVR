<?php
/**
 * Stripe configuration placeholder.
 *
 * Replace these values with your actual Stripe API keys for payments.
 */
$stripeSecretKey = 'sk_test_xxxxxxxxxxxxxxxxxxxxxx';
$stripePublishableKey = 'pk_test_xxxxxxxxxxxxxxxxxxxxxx';
?>
