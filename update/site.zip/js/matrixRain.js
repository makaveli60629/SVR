(function () {
  const canvas = document.getElementById('matrixCanvas');
  const ctx = canvas.getContext('2d');

  let width, height;
  const fontSize = 16;
  const symbols = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*';
  let columns;

  // Initialize canvas size and columns
  function init() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
    // Create columns representing drop positions for each character column
    columns = new Array(Math.floor(width / fontSize)).fill(0);
  }

  // Draw a single frame of the matrix rain animation
  function draw() {
    // Fade the canvas slightly with a transparent overlay to create trailing effect
    ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = '#b19cff'; // purple characters
    ctx.font = fontSize + 'px monospace';

    // Draw characters and update column positions
    for (let i = 0; i < columns.length; i++) {
      const x = i * fontSize;
      const y = columns[i] * fontSize;

      // Pick a random symbol from the string
      const text = symbols.charAt(Math.floor(Math.random() * symbols.length));
      ctx.fillText(text, x, y);

      // Reset column to the top randomly to vary the drops
      if (y > height && Math.random() > 0.975) {
        columns[i] = 0;
      } else {
        columns[i]++;
      }
    }

    requestAnimationFrame(draw);
  }

  window.addEventListener('resize', init);
  init();
  draw();
})();