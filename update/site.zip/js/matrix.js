(() => {
  const canvas = document.getElementById('matrix-rain');
  if (!canvas) return;
  const ctx = canvas.getContext('2d', { alpha: true });
  const glyphs = '01SVR♦♣♠♥';
  let width = 0;
  let height = 0;
  let columns = 0;
  let drops = [];
  let fontSize = 18;
  let last = 0;

  function resize() {
    const ratio = Math.min(window.devicePixelRatio || 1, 1.8);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * ratio);
    canvas.height = Math.floor(height * ratio);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    fontSize = width < 700 ? 14 : 18;
    columns = Math.ceil(width / fontSize);
    drops = Array.from({ length: columns }, () => Math.random() * height / fontSize);
  }

  function draw(ts) {
    if (!last) last = ts;
    const delta = ts - last;
    if (delta < 45) {
      requestAnimationFrame(draw);
      return;
    }
    last = ts;

    ctx.fillStyle = 'rgba(2, 2, 5, 0.12)';
    ctx.fillRect(0, 0, width, height);

    ctx.font = fontSize + 'px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.textAlign = 'center';

    for (let i = 0; i < columns; i += 1) {
      const x = i * fontSize + fontSize * 0.5;
      const y = drops[i] * fontSize;
      const char = glyphs[Math.floor(Math.random() * glyphs.length)];
      const alpha = 0.22 + Math.random() * 0.45;
      ctx.fillStyle = `rgba(162, 104, 255, ${alpha})`;
      ctx.fillText(char, x, y);
      if (Math.random() > 0.82) {
        ctx.fillStyle = `rgba(82, 233, 255, ${alpha * 0.8})`;
        ctx.fillText(char, x, y - fontSize);
      }
      if (y > height && Math.random() > 0.975) {
        drops[i] = 0;
      } else {
        drops[i] += 0.7 + Math.random() * 0.55;
      }
    }

    requestAnimationFrame(draw);
  }

  resize();
  window.addEventListener('resize', resize, { passive: true });
  requestAnimationFrame(draw);
})();
