(() => {
  const ok = document.getElementById('welcomeOk');
  const toast = document.getElementById('welcomeToast');
  ok?.addEventListener('click', () => toast?.remove());

  const layout = document.getElementById('layout');
  const tabs = document.getElementById('tabs');
  const tabButtons = tabs ? Array.from(tabs.querySelectorAll('.tab')) : [];
  function show(which){
    if(!layout) return;
    layout.dataset.show = which;
    tabButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.tab === which));
  }
  tabButtons.forEach(btn => btn.addEventListener('click', () => show(btn.dataset.tab)));
  show('game');

  const slides = Array.from(document.querySelectorAll('.featureSlide'));
  const dotsWrap = document.getElementById('slideDots');
  const metaTitle = document.getElementById('slideMetaTitle');
  const prev = document.getElementById('prevSlide');
  const next = document.getElementById('nextSlide');
  let current = 0;
  let timer = null;

  if (slides.length && dotsWrap) {
    const dots = slides.map((slide, idx) => {
      const dot = document.createElement('button');
      dot.type = 'button';
      dot.className = 'dot';
      dot.setAttribute('aria-label', `Go to banner ${idx + 1}`);
      dot.addEventListener('click', () => {
        current = idx;
        render();
        restart();
      });
      dotsWrap.appendChild(dot);
      return dot;
    });

    function render() {
      slides.forEach((slide, idx) => slide.classList.toggle('active', idx === current));
      dots.forEach((dot, idx) => dot.classList.toggle('active', idx === current));
      if (metaTitle) metaTitle.textContent = slides[current].dataset.title || 'Banner Details';
    }

    function go(dir) {
      current = (current + dir + slides.length) % slides.length;
      render();
    }

    function restart() {
      if (timer) window.clearInterval(timer);
      timer = window.setInterval(() => go(1), 5000);
    }

    prev?.addEventListener('click', () => { go(-1); restart(); });
    next?.addEventListener('click', () => { go(1); restart(); });
    render();
    restart();
  }
})();
