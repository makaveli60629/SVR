(() => {
  const year = document.getElementById('year');
  if (year) year.textContent = String(new Date().getFullYear());

  const btn = document.getElementById('checkoutButton');
  const msg = document.getElementById('checkoutMessage');
  const label = document.getElementById('checkoutButtonLabel');
  const config = window.SVR_STRIPE_CONFIG || {};

  if (label && config.buttonLabel) label.textContent = config.buttonLabel;

  function setMessage(text, tone = 'default') {
    if (!msg) return;
    msg.textContent = text;
    msg.style.color = tone === 'ok'
      ? '#9ef0ca'
      : tone === 'warn'
      ? '#ffd7a8'
      : '#d5caf0';
  }

  if (btn) {
    btn.addEventListener('click', async () => {
      btn.setAttribute('aria-busy', 'true');
      try {
        if (config.paymentLink) {
          setMessage('Opening your configured Stripe Payment Link…', 'ok');
          window.location.href = config.paymentLink;
          return;
        }

        if (config.checkoutEndpoint) {
          setMessage('Requesting a hosted checkout session…');
          const res = await fetch(config.checkoutEndpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product: config.productLabel || 'Founders Table Pass' })
          });
          if (!res.ok) throw new Error('Checkout endpoint returned ' + res.status);
          const data = await res.json();
          if (data?.url) {
            setMessage('Redirecting to Stripe Checkout…', 'ok');
            window.location.href = data.url;
            return;
          }
          throw new Error('Checkout response did not include a url');
        }

        setMessage('Stripe is wired as a placeholder. Add either a Payment Link or a backend checkout endpoint in js/stripe-config.js. Secret keys should stay on the server.', 'warn');
      } catch (err) {
        setMessage((err && err.message) ? err.message : 'Unable to start checkout.', 'warn');
      } finally {
        btn.removeAttribute('aria-busy');
      }
    });
  }
})();
