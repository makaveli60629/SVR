window.SVR_STRIPE_CONFIG = {
  paymentLink: '',
  checkoutEndpoint: '',
  publishableKey: '',
  priceId: '',
  buttonLabel: 'Stripe Checkout Setup',
  productLabel: 'Founders Table Pass',
  sqlEndpoint: '/api/member-intake'
};
