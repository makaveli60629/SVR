(() => {
  const canvas = document.getElementById('matrix');
  const ctx = canvas.getContext('2d');
  let w = canvas.width = innerWidth;
  let h = canvas.height = innerHeight;
  const font = 18;
  let cols = Math.floor(w / font);
  let drops = Array(cols).fill(1);
  const chars = "SVRPOKER01".split("");

  function resize() {
    w = canvas.width = innerWidth;
    h = canvas.height = innerHeight;
    cols = Math.floor(w / font);
    drops = Array(cols).fill(1);
  }

  function draw() {
    ctx.fillStyle = "rgba(0,0,0,.08)";
    ctx.fillRect(0,0,w,h);
    ctx.fillStyle = "#9445ff";
    ctx.font = `${font}px monospace`;
    for (let i=0;i<drops.length;i++) {
      const ch = chars[Math.floor(Math.random() * chars.length)];
      ctx.fillText(ch, i * font, drops[i] * font);
      if (drops[i] * font > h && Math.random() > 0.975) drops[i] = 0;
      drops[i]++;
    }
  }

  function toggleModal(id, show) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.toggle('hidden', !show);
    el.setAttribute('aria-hidden', String(!show));
  }

  document.querySelectorAll('[data-open]').forEach(btn => {
    btn.addEventListener('click', () => toggleModal(btn.dataset.open, true));
  });

  document.querySelectorAll('[data-close]').forEach(btn => {
    btn.addEventListener('click', () => toggleModal(btn.dataset.close, false));
  });

  document.querySelectorAll('.checkout-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const result = await SVR_API.createCheckout(btn.dataset.sku || 'unknown');
      alert(result.message || 'Checkout wired.');
    });
  });

  window.addEventListener('resize', resize);
  setInterval(draw, 45);
})();
