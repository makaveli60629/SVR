
export function launchGame(){
window.location.href="/game/";
}
