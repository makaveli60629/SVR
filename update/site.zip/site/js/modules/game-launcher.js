
export function launchGame(){window.location="/game/";}
