
import {checkUpdate} from "./updater.js";
import {loadPage} from "./router.js";
import {launchGame} from "../modules/game-launcher.js";

window.loadPage=loadPage;
window.launchGame=launchGame;

window.addEventListener("DOMContentLoaded",()=>{checkUpdate();});
