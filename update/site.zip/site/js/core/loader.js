
import {checkUpdate} from "./updater.js";
import {launchGame} from "../modules/game-launcher.js";

window.launchGame=launchGame;

window.addEventListener("DOMContentLoaded",()=>{
checkUpdate();
});
