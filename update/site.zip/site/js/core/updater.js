
import {CONFIG} from "./config.js";
export async function checkUpdate(){
try{
const r=await fetch(CONFIG.UPDATE_PATH);
const v=await r.json();
if(v.site!==CONFIG.SITE_VERSION){
const bar=document.createElement("div");
bar.style.position="fixed";
bar.style.top="0";
bar.style.width="100%";
bar.style.background="#7a3cff";
bar.style.color="white";
bar.style.padding="10px";
bar.innerHTML="New update available";
document.body.appendChild(bar);
}
}catch(e){console.log(e)}
}
