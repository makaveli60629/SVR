
export const CONFIG = {
SITE_VERSION:"2.0.0",
UPDATE_PATH:"/updates/version.json",
GAME_PATH:"/game/"
};
