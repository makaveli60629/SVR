
export const CONFIG={SITE_VERSION:"1.0.0",UPDATE_PATH:"/update/version.json"};
