
export function loadPage(page){
console.log("page load",page);
}
