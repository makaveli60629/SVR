
export function loadPage(page){
const frame=document.getElementById("appFrame");
frame.src="/site/pages/"+page+".html";
}
