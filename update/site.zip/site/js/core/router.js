
export function loadPage(page){
document.getElementById("frame").src="/site/pages/"+page+".html";
}
