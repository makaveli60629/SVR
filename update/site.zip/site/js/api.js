window.SVR_CONFIG = {
  apiBase: "https://your-railway-or-azure-api.example.com",
  stripePublishableKey: "pk_test_replace_me",
  endpoints: {
    health: "/health",
    login: "/auth/login",
    register: "/auth/register",
    catalog: "/store/catalog",
    checkout: "/payments/create-checkout",
    wallet: "/wallet/balance"
  }
};

window.SVR_API = {
  async ping() {
    const url = `${SVR_CONFIG.apiBase}${SVR_CONFIG.endpoints.health}`;
    const res = await fetch(url, { cache: "no-store" });
    return res.ok;
  },
  async createCheckout(sku) {
    return {
      ok: false,
      message: `Checkout scaffold only. Wire ${SVR_CONFIG.endpoints.checkout} on your live backend for ${sku}.`
    };
  }
};
