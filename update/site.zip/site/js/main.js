/*
  Entry point for the SVR landing page.  This module boots the
  Matrix effect after the DOM has loaded.  Keeping initialization in
  its own module makes it trivial to add more behaviours later without
  cluttering the HTML.
*/

import { startMatrixEffect } from './matrix.js';

// When the document is fully parsed, start the matrix animation.  We
// intentionally avoid starting on `window.onload` to allow the effect
// to appear while images and other resources continue loading.
document.addEventListener('DOMContentLoaded', () => {
  startMatrixEffect();
});