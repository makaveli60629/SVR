/*
  Matrix rain effect for the SVR landing page.

  This module exports a single function `startMatrixEffect` which, when
  called, creates a full‑screen canvas and renders a purple rain of
  characters.  The effect is inspired by the film "The Matrix" and
  continuously repaints the canvas on an interval.  It is safe to call
  this function multiple times, though it should generally be invoked
  only once per page load.
*/

export function startMatrixEffect() {
  const canvas = document.createElement('canvas');
  document.body.appendChild(canvas);
  const ctx = canvas.getContext('2d');

  // Style the canvas so it sits behind all other content.
  canvas.style.position = 'fixed';
  canvas.style.top = 0;
  canvas.style.left = 0;
  canvas.style.zIndex = -1;

  // Set the initial canvas size to the viewport size.  Resize listener
  // keeps it in sync when the window is resized.
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const letters = 'SVR';
  const fontSize = 16;
  let columns = Math.floor(canvas.width / fontSize);
  let drops = Array.from({ length: columns }, () => 1);

  function draw() {
    // Create a semi‑transparent overlay to fade the previous frame.
    ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Set the font for the characters.
    ctx.fillStyle = '#a020f0';
    ctx.font = `${fontSize}px monospace`;

    drops.forEach((y, i) => {
      const text = letters[Math.floor(Math.random() * letters.length)];
      ctx.fillText(text, i * fontSize, y * fontSize);
      // Send a drop back to the top randomly after it has passed the bottom.
      if (y * fontSize > canvas.height && Math.random() > 0.975) {
        drops[i] = 0;
      }
      drops[i]++;
    });
  }

  // Main loop.  Set an interval rather than recursive requestAnimationFrame
  // since the effect does not rely on vsync and benefits from a fixed
  // cadence.
  return setInterval(draw, 35);
}