
/* Placeholder for hand‑tracking gesture teleport */

console.log("Fist teleport module loaded")

function detectFist(){

/* future Quest hand tracking detection */

}

setInterval(detectFist,200)
