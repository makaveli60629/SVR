
let teleportEnabled=false

window.addEventListener("keydown",e=>{

if(e.key==="f"){

teleportEnabled=!teleportEnabled

console.log("Teleport",teleportEnabled)

}

})
