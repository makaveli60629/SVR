
export async function checkUpdate(){

try{

const r = await fetch('/update/version.json');
const v = await r.json();

console.log("Version check:",v);

}catch(e){

console.log("Updater error",e);

}

}
