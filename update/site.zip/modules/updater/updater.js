
export async function checkForUpdate(){

try{

const response = await fetch("/update/patch.json");
const data = await response.json();

const currentVersion = localStorage.getItem("svr_version") || "0";

if(data.version !== currentVersion){

console.log("New update detected:",data.version);

localStorage.setItem("svr_version",data.version);

alert("SVR update detected. Reloading.");
location.reload();

}

}catch(err){

console.warn("Updater error:",err);

}

}
