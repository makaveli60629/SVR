# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qs
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
PARAMS = parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 and sys.argv[2].startswith("?") else {}

def add_action(label, action):
    item = xbmcgui.ListItem(label=label)
    item.setInfo("video", {"title": label, "plot": "King Media repository preview"})
    url = sys.argv[0] + "?action=" + action
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

action = PARAMS.get("action", [""])[0]

if action == "about":
    xbmcgui.Dialog().ok(
        "King Media",
        "Repository test passed.\n\nKing Media is installed from the King Kodi Repository at svrpoker.com/kodi."
    )
elif action == "updates":
    xbmcgui.Dialog().ok(
        "King Media Updates",
        "Updates are delivered through the repository. A newer add-on version can be published without reinstalling the repository ZIP."
    )
else:
    xbmcplugin.setPluginCategory(HANDLE, "King Media")
    xbmcplugin.setContent(HANDLE, "videos")
    add_action("Repository Test", "about")
    add_action("How Updates Work", "updates")

xbmcplugin.endOfDirectory(HANDLE)
