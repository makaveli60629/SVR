# SVR Version 1.4.2 - Site/Game Adaptation Manifest

## Purpose
This manifest adapts the Reiki / wellness partner network concept into the SVR website and game without touching locked systems unless explicitly authorized.

## Locked Systems
- Public website Matrix baseline remains locked unless a site-specific patch is approved.
- Reiki storefront hub remains locked and must not be modified unless explicitly unlocked.
- Game lobby remains a storefront portal hub.
- No SQL passwords, Stripe secret keys, or API secrets go into public site or game files.

## Partner Module Structure
Each partner module must have:
1. Lobby storefront portal.
2. Private 3D room.
3. Config-driven branding/content.
4. Approval status flag.
5. Immediate neutral fallback.
6. Admin/analytics hooks.
7. Removal path that does not break the lobby.

## Reiki Module Requirements
- Storefront remains locked until approved unlock.
- Private Reiki room must load as 3D, not 2D.
- Hologram video should be split into two optimized clips.
- Partner-specific assets remain review-only until approved.
- If approval is denied, all partner-specific content is removed and replaced by neutral SVR wellness placeholders.

## PGA Mother-Module Adaptation
- Use the same storefront/private-room structure, not the locked Reiki assets.
- PGA storefront includes instructor/profile panel, Drive route, Chip/Putt route, and clear business CTA.
- PGA Drive and Chip/Putt must route to private 3D rooms.

## Website Adaptation
- Add private partner review page for proposal/demo materials.
- Add safe booking-interest form through backend API.
- Keep payments disabled until business/legal approval.
- Track visits, inquiry clicks, video plays, and partner room interest.

## Game Adaptation
- Add route-health diagnostic panel or JSON route map.
- Confirm every private room loads before presentation.
- Add return-to-lobby paths for each private room.
- Optimize hologram video assets for Quest playback.
- Keep play-chip rewards time-gated and play-money only.

## Database Planning
Tables to plan:
- ProviderProfile
- ServiceListing
- BookingRequest
- SessionEvent
- LeadAnalytics
- PartnerAdminLog

## Admin Dashboard Planning
Lead partner access:
- Bookings
- Leads
- Provider approvals
- State activity
- Session schedules
- Analytics
- Content approval

SVR owner-only access:
- Deployment
- Global moderation
- Payment activation
- Database secrets
- System analytics

## Phase Roadmap
- 1.4.2 Planning: PDF packet, database plan, site/game adaptation plan.
- 1.4.2A Proposal Pack: final PDF/email/screenshots/demo links.
- 1.4.2B Game Route Audit: Reiki/PGA private scenes and portals verified.
- 1.4.2C Hologram Optimization: split and encode two clips.
- 1.4.2D Partner Review Page: site-side private review page.
- 1.4.2E Admin Prototype: dashboard mockup and backend hooks.
